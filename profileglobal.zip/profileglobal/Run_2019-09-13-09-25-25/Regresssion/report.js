$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("ContactChannel_ILIUpdate.feature");
formatter.feature({
  "line": 2,
  "name": "ILI contact channel \u0026 Address Update",
  "description": "",
  "id": "ili-contact-channel-\u0026-address-update",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@ContactChannelUpdate6"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "1\t-\tupdate an user with BYC and open block policy - Update contactchannels ( Phone Numbers ) . Verify the Get profile call retrieves the recent record from usereventstatus",
  "description": "",
  "id": "ili-contact-channel-\u0026-address-update;1---update-an-user-with-byc-and-open-block-policy---update-contactchannels-(-phone-numbers-)-.-verify-the-get-profile-call-retrieves-the-recent-record-from-usereventstatus",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@ContactChannelUpdate61"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "back to back a working endpoint exists for \"ProfileV4\" APIs",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "GET ILI Profile details from APIs using sourceID \"0851724951\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "PUT hit the request with the details obtained from GET ILI using the credentials username \"honglanan_mig\" and password \"Pru12345\" and with the ssoid \"25108854\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the data is updated correctly and success response code 200 is recieved succesfull result",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "verify table USEREVENTSTATUS for contact channel update121222",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "verify update on BU is complete by verifying GET BU api contact channel update",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "hit the PUT request with the same ILI data that used in the step3 using the credentials username \"honglanan_mig\" and password \"Pru12345\" and with the ssoid \"25108854\"",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "verify table USEREVENTSTATUS for back to back update",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "GET INDV Profile details from APIs using SSOID \"25246661\"",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "PUT hit the request with the details obtained from GET INDV with ssoid",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "ProfileV4",
      "offset": 44
    }
  ],
  "location": "SOUpdate.user_has_primary_email_address_in_for_single_profiles(String)"
});
formatter.result({
  "duration": 1001992600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "0851724951",
      "offset": 50
    }
  ],
  "location": "SOUpdate.GET_request_sent_to_Event_Api_to_Update_primary_email(String)"
});
formatter.result({
  "duration": 14486892400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "honglanan_mig",
      "offset": 91
    },
    {
      "val": "Pru12345",
      "offset": 120
    },
    {
      "val": "25108854",
      "offset": 150
    }
  ],
  "location": "SOUpdate.post_request_sent_to_Event_Api_to_Update_primary_email(String,String,String)"
});
formatter.result({
  "duration": 34152748800,
  "status": "passed"
});
formatter.match({
  "location": "SOUpdate.the_data_is_updated_and_success_response_code_200_is_recieved_successfully_result()"
});
formatter.result({
  "duration": 7411300,
  "status": "passed"
});
formatter.match({
  "location": "SOUpdate.verify_table_USEREVENTSTATUS_for_Added_contact_channel()"
});
formatter.result({
  "duration": 50194618600,
  "error_message": "java.lang.AssertionError: TYPE is MATCHING PRIMARY expected [COMPLETED] but found [REJECTED]\r\n\tat org.testng.Assert.fail(Assert.java:94)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:494)\r\n\tat org.testng.Assert.assertEquals(Assert.java:123)\r\n\tat org.testng.Assert.assertEquals(Assert.java:176)\r\n\tat com.Profile.stepDefinitions.SOUpdate.verify_table_USEREVENTSTATUS_for_Added_contact_channel(SOUpdate.java:1151)\r\n\tat ✽.Then verify table USEREVENTSTATUS for contact channel update121222(ContactChannel_ILIUpdate.feature:9)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "SOUpdate.verify_update_on_BU_is_complete_by_verifying_GET_BU_api()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "honglanan_mig",
      "offset": 98
    },
    {
      "val": "Pru12345",
      "offset": 127
    },
    {
      "val": "25108854",
      "offset": 157
    }
  ],
  "location": "SOUpdate.put_request_sent_to_Event_Api_to_Update_primary_email(String,String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SOUpdate.verify_table_USEREVENTSTATUS_for_back_to_back_update()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "25246661",
      "offset": 48
    }
  ],
  "location": "SOUpdate.GET_request_sent_to_Event_Api_to_Update_INDV(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SOUpdate.post_request_sent_to_Event_Api_to_Update_INDV()"
});
formatter.result({
  "status": "skipped"
});
});