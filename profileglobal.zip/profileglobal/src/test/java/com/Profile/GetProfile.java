package com.Profile;

import com.google.gson.Gson;
import com.test.mapper.pojos.Profile;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static io.restassured.RestAssured.given;


public class GetProfile {

    private static Logger logger = LogManager.getLogger();

    public void getAutomationReq() {

        String Service_Url_Get = "https://api-stage.prudential.com/co/stage/secure/profiles/v3/profile?coUserId=200083246006";
        io.restassured.response.Response responseGet = null;
        RequestSpecification request = null;
        String resultbody = null;
        Profile profile = new Profile();
        Gson gson = new Gson();
        String requestID = "CreateProfileImr";

        String payload = gson.toJson(profile);
        String authorization = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";

        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", authorization);

        responseGet = request.contentType(ContentType.JSON).get(Service_Url_Get).andReturn();
        logger.info("GET Response-->" + responseGet.prettyPrint());
    }

}
