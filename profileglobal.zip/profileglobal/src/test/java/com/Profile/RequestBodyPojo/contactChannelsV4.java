package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;



public class contactChannelsV4{
	String contactChannelId;
	String contactChannel;
	String contactChannelType;
	String contactChannelValue;
	String phoneExtension;
	String contactStatus;
	String deleted;
	String editableReasonCode;
	String editableReasonDescription;
	boolean isEditable;
	boolean isUpdated;
	boolean isDeleted;
	public contactChannelsV4(){}
	public contactChannelsV4(String contactChannelId, String contactChannel, String contactChannelType,
			String contactChannelValue, String phoneExtension, String contactStatus,String deleted, String editableReasonCode,
			String editableReasonDescription, boolean isEditable, boolean isUpdated, boolean isDeleted) {
		
		this.contactChannelId = contactChannelId;
		this.contactChannel = contactChannel;
		this.contactChannelType = contactChannelType;
		this.contactChannelValue = contactChannelValue;
		this.phoneExtension = phoneExtension;
		this.contactStatus = contactStatus;
		this.deleted = deleted;
		this.editableReasonCode = editableReasonCode;
		this.editableReasonDescription = editableReasonDescription;
		this.isEditable = isEditable;
		this.isUpdated = isUpdated;
		this.isDeleted = isDeleted;
	}
	
	
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	public String getContactChannelId() {
		return contactChannelId;
	}
	public void setcontactChannelId(String contactChannelId) {
		this.contactChannelId = contactChannelId;
	}
	public String getContactChannel() {
		return contactChannel;
	}
	public void setcontactChannel(String contactChannel) {
		this.contactChannel = contactChannel;
	}
	public String getContactChannelType() {
		return contactChannelType;
	}
	public void setcontactChannelType(String contactChannelType) {
		this.contactChannelType = contactChannelType;
	}
	public String getContactChannelValue() {
		return contactChannelValue;
	}
	public void setcontactChannelValue(String contactChannelValue) {
		this.contactChannelValue = contactChannelValue;
	}
	public String getPhoneExtension() {
		return phoneExtension;
	}
	public void setphoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}
	public String getContactStatus() {
		return contactStatus;
	}
	public void setcontactStatus(String contactStatus) {
		this.contactStatus = contactStatus;
	}
	public String geteditableReasonCode() {
		return editableReasonCode;
	}
	public void seteditableReasonCode(String editableReasonCode) {
		this.editableReasonCode = editableReasonCode;
	}
	public String geteditableReasonDescription() {
		return editableReasonDescription;
	}
	public void seteditableReasonDescription(String editableReasonDescription) {
		this.editableReasonDescription = editableReasonDescription;
	}
	public boolean getisEditable() {
		return isEditable;
	}
	public void setisEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}
	public boolean getisUpdated() {
		return isUpdated;
	}
	public void setisUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}
	public boolean getisDeleted() {
		return isDeleted;
	}
	public void setisDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
}
