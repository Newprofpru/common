package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class personalInfo {
	String prefix;
	String firstName;
	String middleName;
	String lastName;
	String suffix;
	String preferredName;
	String maritalStatus;
	String dateOfBirth;
	String gender;
	String ssn;
	String userType;
	String userSource;
	String citizenship;
	String countryOfBirth;
	String occupation;
	String salary;
	String employmentStatus;
	String employerName;
	String visaType;
	String visaExpiration;
	String permanentResident;
	String euResidentFlag;
	
	
	public personalInfo(){}
	
	public personalInfo(String firstName, String middleName, String lastName, String prefix, String suffix,
			String preferredName, String maritalStatus, String dateOfBirth, String gender, String ssn,String userType,
			String userSource, String citizenship, String occupation, String salary,
			String permanentResident, String visaType, String visaExpiration, String countryOfBirth,
			String employmentStatus, String employerName, String euResidentFlag) {
		
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.prefix = prefix;
		this.suffix = suffix;
		this.preferredName = preferredName;
		this.maritalStatus = maritalStatus;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.ssn = ssn;
		this.userType = userType;
		this.userSource = userSource;
		this.citizenship = citizenship;
		this.occupation = occupation;
		this.salary = salary;
		this.permanentResident = permanentResident;
		this.visaType = visaType;
		this.visaExpiration = visaExpiration;
		this.countryOfBirth = countryOfBirth;
		this.employmentStatus = employmentStatus;
		this.employerName = employerName;
		this.euResidentFlag = euResidentFlag;
	}
	
	

	public void setUserSource(String userSource) {
		this.userSource = userSource;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setmiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setlastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setprefix(String prefix) {
		this.prefix = prefix;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setsuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public void setpreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setmaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setdateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setgender(String gender) {
		this.gender = gender;
	}

	public String getSsn() {
		return ssn;
	}

	public void setssn(String ssn) {
		this.ssn = ssn;
	}

	public String getUserSource() {
		return userSource;
	}

	public String getUserType() {
		return userType;
	}

	public void setuserType(String userType) {
		this.userType = userType;
	}

	public void setuserSource(String userSource) {
		this.userSource = userSource;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setcitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setoccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSalary() {
		return salary;
	}

	public void setsalary(String salary) {
		this.salary = salary;
	}

	public String getPermanentResident() {
		return permanentResident;
	}

	public void setpermanentResident(String permanentResident) {
		this.permanentResident = permanentResident;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setvisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getVisaExpiration() {
		return visaExpiration;
	}

	public void setvisaExpiration(String visaExpiration) {
		this.visaExpiration = visaExpiration;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setcountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setemploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setemployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getEuResidentFlag() {
		return euResidentFlag;
	}

	public void seteuResidentFlag(String euResidentFlag) {
		this.euResidentFlag = euResidentFlag;
	}
}
