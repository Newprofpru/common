package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class disclosures {
	
	String controlPerson;
	String companySymbols;
	String politicallyExposed;
	String organization;
	String relationship;
	String finraAffiliated;
	String firmName;
	String affliatedApprovalID;
	String disClRelcode;
	String disAffiliationTypeCode;
	String disCntrPersOccupation;
	String disCntrPersonFirmName;
	String disCntrPersFirmAdd1;
	String disCntrPersFirmAdd2;
	String disCntrPersFirmAddCity;
	String disCntrPersfirmaddStCde;
	String disCntrPersFirmAddZipCode;
	String disCntrPersFirmAddCntryCode;
	
	public disclosures(){}
	public disclosures(String controlPerson, String companySymbols, String politicallyExposed, String organization,
			String relationship, String finraAffiliated, String firmName, String affliatedApprovalID,String disClRelcode,
			String disAffiliationTypeCode, String disCntrPersOccupation, String disCntrPersonFirmName, String disCntrPersFirmAdd1,
			String disCntrPersFirmAdd2, String disCntrPersFirmAddCity, String disCntrPersfirmaddStCde, String disCntrPersFirmAddZipCode,
			String disCntrPersFirmAddCntryCode) {
		this.controlPerson = controlPerson;
		this.companySymbols = companySymbols;
		this.politicallyExposed = politicallyExposed;
		this.organization = organization;
		this.relationship = relationship;
		this.finraAffiliated = finraAffiliated;
		this.firmName = firmName;
		this.affliatedApprovalID = affliatedApprovalID;
		this.disClRelcode = disClRelcode;
		this.disAffiliationTypeCode = disAffiliationTypeCode;
		this.disCntrPersOccupation = disCntrPersOccupation;
		this.disCntrPersonFirmName = disCntrPersonFirmName;
		this.disCntrPersFirmAdd1 = disCntrPersFirmAdd1;
		this.disCntrPersFirmAdd2 = disCntrPersFirmAdd2;
		this.disCntrPersFirmAddCity = disCntrPersFirmAddCity;
		this.disCntrPersfirmaddStCde = disCntrPersfirmaddStCde;
		this.disCntrPersFirmAddZipCode = disCntrPersFirmAddZipCode;
		this.disCntrPersFirmAddCntryCode = disCntrPersFirmAddCntryCode;
	}	
	
	public String getControlPerson() {
		return controlPerson;
	}
	public void setcontrolPerson(String controlPerson) {
		this.controlPerson = controlPerson;
	}
	public String getCompanySymbols() {
		return companySymbols;
	}
	public void setcompanySymbols(String companySymbols) {
		this.companySymbols = companySymbols;
	}
	public String getpoliticallyExposed() {
		return politicallyExposed;
	}
	public void setpoliticallyExposed(String politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}
	public String getorganization() {
		return organization;
	}
	public void setorganization(String organization) {
		this.organization = organization;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setrelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getFinraAffiliated() {
		return finraAffiliated;
	}
	public void setfinraAffiliated(String finraAffiliated) {
		this.finraAffiliated = finraAffiliated;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setfirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getAffliatedApprovalID() {
		return affliatedApprovalID;
	}
	public void setaffliatedApprovalID(String affliatedApprovalID) {
		this.affliatedApprovalID = affliatedApprovalID;
	}
	public String getDisClRelcode() {
		return disClRelcode;
	}
	public void setdisClRelcode(String disClRelcode) {
		this.disClRelcode = disClRelcode;
	}
	public String getDisAffiliationTypeCode() {
		return disAffiliationTypeCode;
	}
	public void setdisAffiliationTypeCode(String disAffiliationTypeCode) {
		this.disAffiliationTypeCode = disAffiliationTypeCode;
	}
	public String getDisCntrPersOccupation() {
		return disCntrPersOccupation;
	}
	public void setdisCntrPersOccupation(String disCntrPersOccupation) {
		this.disCntrPersOccupation = disCntrPersOccupation;
	}
	public String getDisCntrPersonFirmName() {
		return disCntrPersonFirmName;
	}
	public void setdisCntrPersonFirmName(String disCntrPersonFirmName) {
		this.disCntrPersonFirmName = disCntrPersonFirmName;
	}
	public String getDisCntrPersFirmAdd1() {
		return disCntrPersFirmAdd1;
	}
	public void setdisCntrPersFirmAdd1(String disCntrPersFirmAdd1) {
		this.disCntrPersFirmAdd1 = disCntrPersFirmAdd1;
	}
	public String getDisCntrPersFirmAdd2() {
		return disCntrPersFirmAdd2;
	}
	public void setdisCntrPersFirmAdd2(String disCntrPersFirmAdd2) {
		this.disCntrPersFirmAdd2 = disCntrPersFirmAdd2;
	}
	public String getDisCntrPersFirmAddCity() {
		return disCntrPersFirmAddCity;
	}
	public void setdisCntrPersFirmAddCity(String disCntrPersFirmAddCity) {
		this.disCntrPersFirmAddCity = disCntrPersFirmAddCity;
	}
	public String getDisCntrPersfirmaddStCde() {
		return disCntrPersfirmaddStCde;
	}
	public void setdisCntrPersfirmaddStCde(String disCntrPersfirmaddStCde) {
		this.disCntrPersfirmaddStCde = disCntrPersfirmaddStCde;
	}
	public String getDisCntrPersFirmAddZipCode() {
		return disCntrPersFirmAddZipCode;
	}
	public void setdisCntrPersFirmAddZipCode(String disCntrPersFirmAddZipCode) {
		this.disCntrPersFirmAddZipCode = disCntrPersFirmAddZipCode;
	}
	public String getDisCntrPersFirmAddCntryCode() {
		return disCntrPersFirmAddCntryCode;
	}
	public void setdisCntrPersFirmAddCntryCode(String disCntrPersFirmAddCntryCode) {
		this.disCntrPersFirmAddCntryCode = disCntrPersFirmAddCntryCode;
	}
}
