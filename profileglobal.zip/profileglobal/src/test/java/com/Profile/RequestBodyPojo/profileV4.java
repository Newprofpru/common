package com.Profile.RequestBodyPojo;

import java.util.List;

public class profileV4 {
	
	personalInfo personalInfo;
    disclosures disclosures;
	suitability suitability;
	investmentInfo investmentInfo;
	trustedContactPerson trustedContactPerson;
	List<contactChannelsV4> contactChannels;
	List<contactAddressesV4> contactAddresses;
	List<userRelations> userRelations;
	List<employers> employers;

	String ssoId;
	String coUserId;
	String contractId;
	String relationshipToAccount;
	String minorCoUserId;
//	String businessUnit;
	String benefitClaimId;
	String deleted;	
	String bURelationShip;
	String userType;
	String lineOfBusinessCode;
	String userSourceCode;
//	String isMigratedAndEligibleToDelete;
	String sourceApplication;
	String sourceId;
	String productName;
	String productGroup;
//	boolean isEditable;
	String openBlock;
	String eventStatus;
	
	
	
	
	
	public profileV4(){}
	public profileV4(
			personalInfo personalInfo,disclosures disclosures, suitability suitability, investmentInfo investmentInfo,trustedContactPerson trustedContactPerson,
			List<contactChannelsV4> contactChannels, List<contactAddressesV4> contactAddresses, List<userRelations> userRelations,
			List<employers> employers, String ssoId,
			String coUserId, String contractId, String relationshipToAccount, String minorCoUserId, String benefitClaimId, String deleted,
//			boolean isEditable,String businessUnit,
			String bURelationShip, String userType, String lineOfBusinessCode, String userSourceCode,
			String sourceApplication, String sourceId, String productName, String productGroup, String openBlock, String eventStatus) {
		
		this.personalInfo = personalInfo;
		this.disclosures = disclosures;
		this.suitability = suitability;
		this.investmentInfo = investmentInfo;
		this.trustedContactPerson = trustedContactPerson;
		this.contactChannels = contactChannels;
		this.contactAddresses = contactAddresses;
		this.userRelations  = userRelations;
		this.employers = employers;
		
		this.ssoId = ssoId;
		this.coUserId = coUserId;
		this.contractId = contractId;
		this.relationshipToAccount = relationshipToAccount;
		this.minorCoUserId = minorCoUserId;
//		this.businessUnit = businessUnit;
		this.benefitClaimId = benefitClaimId;
		this.deleted = deleted;
		this.bURelationShip = bURelationShip;
		this.userType = userType;
		this.lineOfBusinessCode = lineOfBusinessCode;
		this.userSourceCode = userSourceCode;
		this.sourceApplication = sourceApplication;
		this.sourceId = sourceId;
		this.productName = productName;
		this.productGroup = productGroup;
		this.openBlock = openBlock;
		this.eventStatus = eventStatus;
//		this.isEditable = isEditable;
	}
	
	public personalInfo getPersonalInfo() {
		return personalInfo;
	}
	public void setpersonalInfo(personalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}
	public disclosures getDisclosures() {
		return disclosures;
	}
	public void setdisclosures(disclosures disclosures) {
		this.disclosures = disclosures;
	}
	public suitability getSuitability() {
		return suitability;
	}
	public void setsuitability(suitability suitability) {
		this.suitability = suitability;
	}
	public investmentInfo getInvestmentInfo() {
		return investmentInfo;
	}
	public void setinvestmentInfo(investmentInfo investmentInfo) {
		this.investmentInfo = investmentInfo;
	}
	public trustedContactPerson getTrustedContactPerson() {
		return trustedContactPerson;
	}
	public void settrustedContactPerson(trustedContactPerson trustedContactPerson) {
		this.trustedContactPerson = trustedContactPerson;
	}
	public List<contactChannelsV4> getContactChannels() {
		return contactChannels;
	}
	public void setcontactChannels(List<contactChannelsV4> contactChannels) {
		this.contactChannels = contactChannels;
	}
	public List<contactAddressesV4> getContactAddresses() {
		return contactAddresses;
	}
	public void setcontactAddresses(List<contactAddressesV4> contactAddresses) {
		this.contactAddresses = contactAddresses;
	}
	
	public List<userRelations> getUserRelations() {
		return userRelations;
	}
	public void setUserRelations(List<userRelations> userRelations) {
		this.userRelations = userRelations;
	}
	public List<employers> getEmployers() {
		return employers;
	}
	public void setEmployers(List<employers> employers) {
		this.employers = employers;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setssoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getCoUserId() {
		return coUserId;
	}
	public void setcoUserId(String coUserId) {
		this.coUserId = coUserId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setcontractId(String contractId) {
		this.contractId = contractId;
	}
	public String getRelationshipToAccount() {
		return relationshipToAccount;
	}
	public void setrelationshipToAccount(String relationshipToAccount) {
		this.relationshipToAccount = relationshipToAccount;
	}
	public String getminorCoUserId() {
		return minorCoUserId;
	}
	public void setminorCoUserId(String minorCoUserId) {
		this.minorCoUserId = minorCoUserId;
	}
	public String getBenefitClaimId() {
		return benefitClaimId;
	}
	public void setbenefitClaimId(String benefitClaimId) {
		this.benefitClaimId = benefitClaimId;
	}
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	public String getbURelationShip() {
		return bURelationShip;
	}
	public void setbURelationShip(String bURelationShip) {
		this.bURelationShip = bURelationShip;
	}
	
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getlineOfBusinessCode() {
		return lineOfBusinessCode;
	}
	public void setlineOfBusinessCode(String lineOfBusinessCode) {
		this.lineOfBusinessCode = lineOfBusinessCode;
	}	
	public String getuserSourceCode() {
		return userSourceCode;
	}
	public void setuserSourceCode(String userSourceCode) {
		this.userSourceCode = userSourceCode;
	}
	public String getsourceId() {
		return sourceId;
	}
	public void setsourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getSourceApplication() {
		return sourceApplication;
	}
	public void setSourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}	
	public String getproductGroup() {
		return productGroup;
	}
	public void setproductGroup(String productGroup) {
		this.productGroup = productGroup;
	}
	public String getopenBlock() {
		return openBlock;
	}
	public void setopenBlock(String openBlock) {
		this.openBlock = openBlock;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	
}
