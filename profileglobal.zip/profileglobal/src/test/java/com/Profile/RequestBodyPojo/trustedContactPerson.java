package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class trustedContactPerson {
	String trustedContactFirstName;
	String trustedContactLastName;
	String trustedContactAddress1;
	String trustedContactStreetAddress;
	String trustedContactCity;
	String trustedContactState;
	String trustedContactPostalCode;
	String trustedContactCountry;
	
	public trustedContactPerson(){}
	public trustedContactPerson( String trustedContactFirstName, String trustedContactLastName,
			String trustedContactAddress1, String trustedContactStreetAddress, String trustedContactCity,
			String trustedContactState, String trustedContactPostalCode, String trustedContactCountry) {
		this.trustedContactFirstName = trustedContactFirstName;
		this.trustedContactLastName = trustedContactLastName;
		this.trustedContactAddress1 = trustedContactAddress1;
		this.trustedContactStreetAddress = trustedContactStreetAddress;
		this.trustedContactCity = trustedContactCity;
		this.trustedContactState = trustedContactState;
		this.trustedContactPostalCode = trustedContactPostalCode;
		this.trustedContactCountry = trustedContactCountry;
	}
	public String getTrustedContactFirstName() {
		return trustedContactFirstName;
	}
	public void settrustedContactFirstName(String trustedContactFirstName) {
		this.trustedContactFirstName = trustedContactFirstName;
	}
	public String getTrustedContactLastName() {
		return trustedContactLastName;
	}
	public void settrustedContactLastName(String trustedContactLastName) {
		this.trustedContactLastName = trustedContactLastName;
	}
	public String getTrustedContactAddress1() {
		return trustedContactAddress1;
	}
	public void settrustedContactAddress1(String trustedContactAddress1) {
		this.trustedContactAddress1 = trustedContactAddress1;
	}
	public String getTrustedContactStreetAddress() {
		return trustedContactStreetAddress;
	}
	public void settrustedContactStreetAddress(String trustedContactStreetAddress) {
		this.trustedContactStreetAddress = trustedContactStreetAddress;
	}
	public String getTrustedContactCity() {
		return trustedContactCity;
	}
	public void settrustedContactCity(String trustedContactCity) {
		this.trustedContactCity = trustedContactCity;
	}
	public String getTrustedContactState() {
		return trustedContactState;
	}
	public void settrustedContactState(String trustedContactState) {
		this.trustedContactState = trustedContactState;
	}
	public String getTrustedContactPostalCode() {
		return trustedContactPostalCode;
	}
	public void settrustedContactPostalCode(String trustedContactPostalCode) {
		this.trustedContactPostalCode = trustedContactPostalCode;
	}
	public String getTrustedContactCountry() {
		return trustedContactCountry;
	}
	public void settrustedContactCountry(String trustedContactCountry) {
		this.trustedContactCountry = trustedContactCountry;
	}
	
	
}
