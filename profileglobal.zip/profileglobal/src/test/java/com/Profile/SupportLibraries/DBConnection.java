/* This Module is connect to DB and get results from DB
 * Author : Krishnapriya.vellanki@prudential.com
 * 
 */
package com.Profile.SupportLibraries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;

import com.Profile.SupportLibraries.*;

public class DBConnection {

	static Connection con = null;
	static Statement stmt = null;
	//static PreparedStatement ps = null;
	// static //static ResultSet Res = null;
	//static ResultSet Res;
	

	public static Connection getConnection() {
		
		String user = "coappuser";
		String pass ="udbq01o2";
		String db ="jdbc:oracle:thin:@paehowuw20330:1563/DSCQ";
//		System.out.println("DB is " + db);
//		System.out.println("User is" + user);
//		System.out.println("Pass is" + pass);
		return getConnection(db, user, pass);

	}
public static Connection InitConnection() {
		
	String user = "coappuser";
	String pass ="udbq01o2";
	String db ="jdbc:oracle:thin:@paehowuw20330:1563/DSCQ";

//		System.out.println("DB is " + db);
//		System.out.println("User is" + user);
//		System.out.println("Pass is" + pass);
		return getConnection(db, user, pass);

	}






	public static Connection getConnection(String db, String Username, String Pass) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(db, Username, Pass);

		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public static ResultSet execStatement(Connection conn, String query) {
		// Statement stmt;
		ResultSet Res = null;
		try {
			//System.out.println("Inside execStatement.");
			PreparedStatement ps = conn.prepareStatement(query);
			ps.getConnection();
			 Res = ps.executeQuery(query);
			//System.out.println(Res.getFetchSize());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return Res;

	}

	public static void DbConnection_close(Connection conn) {
		try {

			conn.close();
			//ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
