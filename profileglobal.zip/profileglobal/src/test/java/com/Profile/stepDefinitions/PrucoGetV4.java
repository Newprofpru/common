package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.contactAddresses;
import com.Profile.RequestBodyPojo.contactChannels;
import com.Profile.RequestBodyPojo.disclosures;
import com.Profile.RequestBodyPojo.investmentInfo;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.RequestBodyPojo.suitability;
import com.Profile.RequestBodyPojo.trustedContactPerson;
import com.Profile.SupportLibraries.DBConnection;
import com.Profile.SupportLibraries.GlobalStaticInfo;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.mapper.pojos.LiteRegistration;
import com.test.mapper.pojos.SsoId;
import com.test.mapper.utils.getEnvInfo;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PrucoGetV4 {
	
	private static Logger logger = LogManager.getLogger();
    static Properties properties = getEnvInfo.getInstance();
    private Response response = null;
    private RequestSpecification request;
    private Map<String, String> data;
    Map<String, String> cookie_Data = new HashMap<String, String>();
	Map<String, String> cookies = new HashMap<>();
	JsonObject responseObject = new JsonObject();
	profile profile = new profile();
    private Response Res1;
    private String XPruAuthJWT = null;	
	Random rand = new Random();
	String resBody=null;	
	String ssoid = null;
	String requestID = null;
	String Service_Url = getEnvInfo.getSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	ResultSet rs,rs1,rs2,rs3;
		
	@Given("^endpoint exists for \"([^\"]*)\"$")
	public void valid_endpoint_for_Profile_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
		
	@When("^the user sends a GET request to profile API with below parameters of a normal profile with PRUCO credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_sends_a_GET_request_to_profile_API_with_below_parameters_of_a_normal_prospect_profile(String userid, String password,DataTable parameters) throws IllegalAccessException, InvocationTargetException, IOException, InterruptedException, org.json.simple.parser.ParseException{
		logger.info("In Then aurora sends the GET request to profile API with below parameters for profile V4");		
    	data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "PrucoProfileGetV4" + n;
		RestAssured.baseURI = Service_Url;
        RequestSpecification request = given().log().all()
				.header("X-PruRequestId", requestID).header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0").header("X-PruPrimaryIdentity", "X223793");
		for(String paramName:paramNames){
			if(paramName.equalsIgnoreCase("Header_ssoId")||paramName.equalsIgnoreCase("ssoId")){
				request.header("X-PruImpersonatedIdentity",data.get(paramName) );
				request.param(paramName,data.get(paramName));
				}
			else if(paramName.equalsIgnoreCase("coUserId"))	{			
				request.header("X-Pru-Imp-CO-USER-ID",data.get(paramName) );
				request.param(paramName,data.get(paramName));
				}
			else
				request.param(paramName,data.get(paramName));
		}
		Res1 = request.when().get().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
	}
	
	@Then("^the user receives correct responsebody content and is verified with db$")
	public void user_receives_correct_responsebody_from_Profile_API_and_verified_in_db() throws SQLException, ParseException{
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		JsonArray profileArray = responseObject.getAsJsonArray("profiles");
		if(data.containsKey("limit")){
			int lim =Integer.parseInt(data.get("limit"));
			if(lim<=50){
				Assert.assertEquals(lim, profileArray.size(),"Number of profile returned are "+lim);
				logger.info("Number of profile returned are "+lim);
			}
			else if(lim>50){
				Assert.assertEquals(5, profileArray.size(),"Number of profile returned are "+profileArray.size());
				logger.info("Number of profile returned are "+profileArray.size());
			}
		}
		String coUserId = null,query1 = null,query2=null,query3=null,query4=null;
		for(int i=0;i<profileArray.size();i++){
			logger.info("Verifying the profile : "+(i+1));
			JsonObject profileObject = profileArray.get(i).getAsJsonObject();
			if(data.containsKey("sections")){
				String[] reqSections = data.get("sections").split(",");
				for(String sec:reqSections){
					if(!sec.equalsIgnoreCase("employers")){
					Assert.assertTrue(profileObject.has(sec),"The profile has "+sec+" section");
					logger.info("The profile has "+sec+" section");
					}
					else if(sec.equalsIgnoreCase("employers")&&profileObject.get("contractId").isJsonNull()){
						Assert.assertTrue(profileObject.has(sec),"The profile has "+sec+" section");
						logger.info("The profile has "+sec+" section");
						}
				}
			}
			coUserId = profileObject.get("coUserId").getAsString();
			JsonObject personalInfoObject = new JsonObject();
			JsonObject disclosureObject = new JsonObject();
			JsonObject suitablityObject = new JsonObject();
			JsonObject investmentObject = new JsonObject();
			JsonObject trustContObject = new JsonObject();
			JsonArray contactAddressArray = new JsonArray();
			JsonArray contactChannelArray = new JsonArray();
			JsonArray employersArray = new JsonArray();
			JsonArray userRelationsArray = new JsonArray();
			if(profileObject.has("personalInfo"))
				personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
			if(profileObject.has("disclosures"))
				disclosureObject = profileObject.get("disclosures").getAsJsonObject();
			if(profileObject.has("suitability"))
				suitablityObject = profileObject.get("suitability").getAsJsonObject();
			if(profileObject.has("investmentInfo"))
				investmentObject = profileObject.get("investmentInfo").getAsJsonObject();
			if(profileObject.has("trustedContactPerson"))
				trustContObject = profileObject.get("trustedContactPerson").getAsJsonObject();
			if(profileObject.has("contactAddresses"))
				contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
			if(profileObject.has("contactChannels"))
				contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
			if(profileObject.has("employers"))
				employersArray = profileObject.get("employers").getAsJsonArray();
			if(profileObject.has("userRelations"))
				userRelationsArray = profileObject.get("userRelations").getAsJsonArray();
			Connection con = DBConnection.InitConnection();
			query1 = "Select * from usercontractprofile where couserid = '"+coUserId+"'";
			query2 = "Select * from couser where couserid = '"+coUserId+"'";
			rs = DBConnection.execStatement(con,query1);
			rs1 = DBConnection.execStatement(con,query2);
			while(rs.next()){
				Set<String> persInfoDBUserContractSet = GlobalStaticInfo.persInfoDBUserContract.keySet();
				Set<String> trustContDBUserContractSet = GlobalStaticInfo.trustContDBUserContract.keySet();
				Set<String> suitablityDBUserContractSet = GlobalStaticInfo.suitablityDBUserContract.keySet();
				Set<String> investmentDBUserContractSet = GlobalStaticInfo.investmentDBUserContract.keySet();
				Set<String> disclosureDBUserContractSet = GlobalStaticInfo.disclosureDBUserContract.keySet();
				Set<String> discAfflDBUserAddressSet = GlobalStaticInfo.discAfflDBUserAddress.keySet();
				if(profileObject.has("personalInfo")&&!profileObject.get("contractId").isJsonNull()){
				for(String persInfoDBUserContractElement:persInfoDBUserContractSet){
					
						if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).isJsonNull()){
							if(persInfoDBUserContractElement.contains("DATE")||persInfoDBUserContractElement.equalsIgnoreCase("VISAEXPIRATION")){
								String tmp[]=rs.getString(persInfoDBUserContractElement).split(" ");
								Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
								Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString());
								Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal");
								logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
							}
							else{
								 Assert.assertEquals(rs.getString(persInfoDBUserContractElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString(),GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is Equal");
								 logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
							}
						}
						else
							logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is null");
					}
				}
				
				if(profileObject.has("trustedContactPerson")){
				for(String trustContDBUserContractElement:trustContDBUserContractSet){
					if(!trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).isJsonNull()){
					 Assert.assertEquals(rs.getString(trustContDBUserContractElement),trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString(),GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is equal,value is "+rs.getString(trustContDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is null");
					}
				}
				if(profileObject.has("suitability")&&!profileObject.get("contractId").isJsonNull()){
					for(String suitablityDBUserContractElement:suitablityDBUserContractSet){
						if(!suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).isJsonNull()){
						 Assert.assertEquals(rs.getString(suitablityDBUserContractElement),suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString(),GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is Equal");
						 logger.info(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is equal,value is "+rs.getString(suitablityDBUserContractElement));
						}
						else
							logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBUserContractElement)+" is null");
					}
				}
				if(profileObject.has("investmentInfo")&&!profileObject.get("contractId").isJsonNull()){
					for(String investmentDBUserContractElement:investmentDBUserContractSet){
						if(!investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).isJsonNull()){
						 Assert.assertEquals(rs.getString(investmentDBUserContractElement),investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString(),GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is Equal");
						 logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is equal,value is "+rs.getString(investmentDBUserContractElement));
						}
						else
							logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is null");
					}
				}
				if(profileObject.has("disclosures")&&!profileObject.get("contractId").isJsonNull()){
					for(String disclosureDBUserContractElement:disclosureDBUserContractSet){
						if(!disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).isJsonNull()){
						 Assert.assertEquals(rs.getString(disclosureDBUserContractElement),disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString(),GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is Equal");
						 logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is equal,value is "+rs.getString(disclosureDBUserContractElement));
						}
						else
							logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is null");
					}
					String que = null;
					if(!profileObject.get("contractId").isJsonNull()){
						que ="Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' and contractid = '"+profileObject.get("contractId").getAsString()+"' and AddressTypecode = 'AFFILIATED' ";
						logger.info("ContactAddressId from db for Affiliated Type where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"' are:");
					}
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						for(String discAfflDBUserAddressElement:discAfflDBUserAddressSet){
							if(!disclosureObject.get(GlobalStaticInfo.discAfflDBUserAddress.get(discAfflDBUserAddressElement)).isJsonNull()){
							 Assert.assertEquals(res.getString(discAfflDBUserAddressElement),disclosureObject.get(GlobalStaticInfo.discAfflDBUserAddress.get(discAfflDBUserAddressElement)).getAsString(),GlobalStaticInfo.discAfflDBUserAddress.get(discAfflDBUserAddressElement)+" is Equal");
							 logger.info(GlobalStaticInfo.discAfflDBUserAddress.get(discAfflDBUserAddressElement)+" is equal,value is "+res.getString(discAfflDBUserAddressElement));
							}
							else
								logger.info(GlobalStaticInfo.discAfflDBUserAddress.get(discAfflDBUserAddressElement)+" is null");
						}
					}
				}
			}
			
			while(rs1.next()){
				Set<String> persInfoDBCouserSet = GlobalStaticInfo.persInfoDBCouser.keySet();
				Set<String> disclosureDBCouserSet = GlobalStaticInfo.disclosureDBCouser.keySet();
				Set<String> suitablityDBCouserSet = GlobalStaticInfo.suitablityDBCouser.keySet();
				Set<String> investmentDBCouserSet = GlobalStaticInfo.investmentDBCouser.keySet();
				Set<String> persInfoDBCouser1Set = GlobalStaticInfo.persInfoDBCouser1.keySet();
				if(profileObject.has("personalInfo")&&profileObject.get("contractId").isJsonNull()){
				for(String persInfoDBCouserElement:persInfoDBCouserSet){
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).isJsonNull()){
					 Assert.assertEquals(rs1.getString(persInfoDBCouserElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is equal,value is "+rs1.getString(persInfoDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is null");
				}
			}
				if(profileObject.has("personalInfo")&&profileObject.get("contractId").isJsonNull()){
					for(String persInfoDBCouser1SetElement:persInfoDBCouser1Set){
						
						if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)).isJsonNull()){
							if(persInfoDBCouser1SetElement.contains("DATE")||persInfoDBCouser1SetElement.equalsIgnoreCase("VISAEXPIRATION")){
								String tmp[]=rs1.getString(persInfoDBCouser1SetElement).split(" ");
								Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
								Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)).getAsString());
								Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)+" is equal");
								logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
							}
							else{
								 Assert.assertEquals(rs1.getString(persInfoDBCouser1SetElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)).getAsString(),GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)+" is Equal");
								 logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
							}
						}
						else
							logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBCouser1SetElement)+" is null");
					}
				}
				if(profileObject.has("disclosures")&&profileObject.get("contractId").isJsonNull()){
					for(String disclosureDBCouserElement:disclosureDBCouserSet){
						if(!disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).isJsonNull()){
						 Assert.assertEquals(rs1.getString(disclosureDBCouserElement),disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString(),GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is Equal");
						 logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is equal,value is "+rs1.getString(disclosureDBCouserElement));
						}
						else
							logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is null");
					}
				}
				if(profileObject.has("suitability")&&profileObject.get("contractId").isJsonNull()){
					for(String suitablityDBCouserElement:suitablityDBCouserSet){
						if(!suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).isJsonNull()){
						 Assert.assertEquals(rs1.getString(suitablityDBCouserElement),suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString(),GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is Equal");
						 logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is equal,value is "+rs1.getString(suitablityDBCouserElement));
						}
						else
							logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is null");
					}
				}
				if(profileObject.has("investmentInfo")&&profileObject.get("contractId").isJsonNull()){
					for(String investmentDBCouserElement:investmentDBCouserSet){
						if(!investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).isJsonNull()){
						 Assert.assertEquals(rs1.getString(investmentDBCouserElement),investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString(),GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is Equal");
						 logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is equal,value is "+rs1.getString(investmentDBCouserElement));
						}
						else
							logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is null");
					}
				}
			}
			//while(rs2.next()){
				Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
				Set<String> contChannelDBUserContactSet = GlobalStaticInfo.contChannelDBUserContact.keySet();
				if(profileObject.has("contactAddresses")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("ContactAddressIds from JSON are:");
					for(int l=0;l<contactAddressArray.size();l++){
						elm = contactAddressArray.get(l).getAsJsonObject().get("contactAddressId").getAsString();
						idJsonArray.add(elm);
						logger.info(elm);
					}
					String que = null;
					if(profileObject.get("contractId").isJsonNull()){
						que ="Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' and contractid is null order by USERADDRESSID asc";
						logger.info("ContactAddressIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null are:");
					}
					else{
						que ="Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' and contractid = '"+profileObject.get("contractId").getAsString()+"' order by USERADDRESSID asc";
						logger.info("ContactAddressIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"' are:");
					}
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						if(!res.getString("ADDRESSTYPECODE").equalsIgnoreCase("AFFILIATED")){
						elm = res.getString("USERADDRESSID");
						idDbArray.add(elm);
						logger.info(elm);
						}
					}
					Collections.sort(idJsonArray);
					Assert.assertEquals(idDbArray,idJsonArray ,"ContactAddressIds is response JSON are same as in db");
					logger.info("ContactAddressIds in response JSON are same as in db");
					for(int j=0;j<contactAddressArray.size();j++){
						JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
						query3 ="Select * from useraddress where USERADDRESSID = '"+contactAddressObject.get("contactAddressId").getAsString()+"'";
						rs2 = DBConnection.execStatement(con,query3);
						while(rs2.next()){
						for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
							if(!contAddressDBUserAddressElement.equalsIgnoreCase("DELETED")){
							if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).isJsonNull()){
							 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
							 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
							}
							else
								logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
						}
						}
						Assert.assertEquals(rs2.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
						logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
						if(!profileObject.get("contractId").isJsonNull()){
							Assert.assertEquals(rs2.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
							logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
							Assert.assertEquals(rs2.getString("LINEOFBUSINESSCODE"),profileObject.get("lineOfBusinessCode").getAsString(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
							logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
						}
					}
				}
				
			}
			
				if(profileObject.has("contactChannels")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("ContactChannelIds from JSON are:");
					for(int l=0;l<contactChannelArray.size();l++){
						elm = contactChannelArray.get(l).getAsJsonObject().get("contactChannelId").getAsString();
						idJsonArray.add(elm);
						logger.info(elm);
					}
					String que = null;
					if(profileObject.get("contractId").isJsonNull()&&profileObject.get("benefitClaimId").isJsonNull()){
						que ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N'  and benefitclaimid is null and contractid is null order by usercontactid asc";
						logger.info("ContactChannelIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null are:");
					}
					else if(!profileObject.get("contractId").isJsonNull()&&profileObject.get("benefitClaimId").isJsonNull()){
						que ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N'  and benefitclaimid is null and contractid = '"+profileObject.get("contractId").getAsString()+"' order by usercontactid asc";
						logger.info("ContactChannelIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"' are:");
					}
					else if(profileObject.get("contractId").isJsonNull()&&!profileObject.get("benefitClaimId").isJsonNull()){
						que ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N'  and benefitclaimid = '"+profileObject.get("benefitClaimId").getAsString()+"' and contractid is null order by usercontactid asc";
						logger.info("ContactChannelIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and benefitclaimid = '"+profileObject.get("benefitClaimId").getAsString()+"' are:");
					}
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("USERCONTACTID");
						idDbArray.add(elm);
						logger.info(elm);
					}
					Collections.sort(idJsonArray);
					Assert.assertEquals(idDbArray,idJsonArray ,"ContactchannelIds is response JSON are same as in db");
					logger.info("ContactchannelIds in response JSON are same as in db");
					for(int k=0;k<contactChannelArray.size();k++){
						JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
						query4 ="Select * from usercontact where USERCONTACTID = '"+contactChannelObject.get("contactChannelId").getAsString()+"'";
						rs3 = DBConnection.execStatement(con,query4);
						while(rs3.next()){
						for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
							if(!contChannelDBUserContactElement.equalsIgnoreCase("DELETED")){
							if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).isJsonNull()){
							 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
							 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
							}
							else
								logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
						}
						}
						Assert.assertEquals(rs3.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
						logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
						if(!profileObject.get("contractId").isJsonNull()&&profileObject.get("benefitClaimId").isJsonNull()){
							Assert.assertEquals(rs3.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
							logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
							Assert.assertEquals(rs3.getString("LINEOFBUSINESSCODE"),profileObject.get("lineOfBusinessCode").getAsString(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
							logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
						}
						else if(profileObject.get("contractId").isJsonNull()&&!profileObject.get("benefitClaimId").isJsonNull()){
							Assert.assertEquals(rs3.getString("BENEFITCLAIMID"),profileObject.get("benefitClaimId").getAsString(),"BENEFITCLAIMID is equal, value is "+profileObject.get("benefitClaimId").getAsString());
							logger.info("CONTRACTID is equal, value is "+profileObject.get("benefitClaimId").getAsString());
						}
					}
				}
				
			}
				Set<String> employersDBCouserSet = GlobalStaticInfo.employersDBCouser.keySet();
				Set<String> userRelDbUserRelationSet = GlobalStaticInfo.userRelDbUserRelation.keySet();
				if(profileObject.has("employers")){
					for(int m=0;m<employersArray.size();m++){
						JsonObject employersObject = employersArray.get(m).getAsJsonObject();
						String qry = "Select * from couser where couserid = '"+profileObject.get("coUserId").getAsString()+"'";
						ResultSet rst = DBConnection.execStatement(con,qry);
						while(rst.next()){
						for(String employersDBCouserElement:employersDBCouserSet){
							if(!employersObject.get(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)).isJsonNull()){
								Assert.assertEquals(rst.getString(employersDBCouserElement),employersObject.get(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)).getAsString(),GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is Equal");
								 logger.info(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is equal,value is "+rst.getString(employersDBCouserElement));
								}
								else
									logger.info(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is null");	
							
						}
					}
					}
				}
				
				if(profileObject.has("userRelations")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("relationIds from JSON are:");
					for(int l=0;l<userRelationsArray.size();l++){
						elm = userRelationsArray.get(l).getAsJsonObject().get("relationId").getAsString();
						idJsonArray.add(elm);
						logger.info(elm);
					}
					
					String que = null;					
					if(profileObject.get("contractId").isJsonNull()){
						que ="Select * from userrelation where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' and contractid is null order by USERRELATIONID asc";
						logger.info("relationIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null are:");
					}
					else{
						que ="Select * from userrelation where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' and contractid = '"+profileObject.get("contractId").getAsString()+"' order by USERRELATIONID asc";
						logger.info("relationIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"' are:");
					}
					logger.info("Query input ---> "+que);
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("USERRELATIONID");
						idDbArray.add(elm);
						logger.info(elm);
					}
					Collections.sort(idJsonArray);
					Assert.assertEquals(idDbArray,idJsonArray ,"relationIds is response JSON are same as in db");
					logger.info("relationIds in response JSON are same as in db");
					for(int n=0;n<userRelationsArray.size();n++){
						JsonObject userRelationsObject = userRelationsArray.get(n).getAsJsonObject();
						String qry1 = "Select * from userrelation where USERRELATIONID = '"+userRelationsObject.get("relationId").getAsString()+"'";
						ResultSet rst1 = DBConnection.execStatement(con,qry1);
						while(rst1.next()){
						for(String userRelDbUserRelationElement:userRelDbUserRelationSet){
							if(!userRelationsObject.get(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)).isJsonNull()){
								Assert.assertEquals(rst1.getString(userRelDbUserRelationElement),userRelationsObject.get(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)).getAsString(),GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is Equal");
								 logger.info(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is equal,value is "+rst1.getString(userRelDbUserRelationElement));
								}
								else
									logger.info(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is null");	
						}
					}
					}
				}
			
		}
	}
	
	public String getJWTAuthToken(String userId, String password) {

		try {
		
			
			request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
					.formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
					.formParam("smauthreason", "").formParam("smagentname", "ssologin");


			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))				
				response = request.post("https://ssologin-stage.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();

			cookies = response.getCookies();
		
			logger.info("response-cookies :" + cookies);

			request = given().log().all().cookies(cookies);

			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.get("https://api-dev.prudential.com/.signjwt").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
				response = request.get("https://api-stage.prudential.com/.signjwt").andReturn();
			JsonPath jp = new JsonPath(response.asString());

			XPruAuthJWT = jp.getString("jwt");

			logger.info("JWT Token is :" + XPruAuthJWT);

			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return XPruAuthJWT;

	}
	

}
