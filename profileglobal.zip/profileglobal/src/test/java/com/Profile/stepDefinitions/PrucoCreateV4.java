package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.test.mapper.Mapper;
import com.test.mapper.pojos.*;
import com.test.mapper.utils.*;
import com.Profile.RequestBodyPojo.*;
import com.Profile.SupportLibraries.*;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PrucoCreateV4 {

	
	  private static Logger logger = LogManager.getLogger();
	  static Properties properties = getEnvInfo.getInstance();
	    private Response response = null;
	    private String User = "";
	    private String Password = "";
	    private LiteRegistration liteRegistration = new LiteRegistration();
		public String email = "";
		public String phone = "";
	    private Map<String, String> data;
	    private SsoId sso = new SsoId();
	    private Response Res1;
	    private String Authorizationlite;
	    
		String SSOID =null;
		String ContractID = null;
		
		String userTransactionlogID=null;
		String profileStr=null,coUserId = null;
		
		profile profile = new profile();
	    disclosures disclosures = new disclosures();
		suitability suitability = new suitability();
		investmentInfo investmentInfo = new investmentInfo();
		trustedContactPerson trustedContactPerson = new trustedContactPerson();
		List<contactChannels> contactChannels = new ArrayList<>();
		List<contactAddresses> contactAddresses = new ArrayList<>();
		JsonObject personalInfoObject = new JsonObject();
		JsonObject disclosureObject = new JsonObject();
		JsonObject suitablityObject = new JsonObject();
		JsonObject investmentObject = new JsonObject();
		JsonObject trustContObject = new JsonObject();
		JsonObject profileObject = new JsonObject();;

		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		JsonArray employersArray = new JsonArray();
		JsonArray userRelationsArray = new JsonArray();
	    private String EndpointLite;
	    
	    private RequestSpecification request;
	    private String XPruAuthJWT = null;
		Map<String, String> cookie_Data = new HashMap<String, String>();

		Map<String, String> cookies = new HashMap<>();
		Random rand = new Random();
		String resBody=null;
		JsonObject responseObject = new JsonObject();
		
		profileV4 Profile = new profileV4();
		String ssoid = null;
		String Litessoid = null;
		String profileId = null;
		String requestID = null;

		boolean isNullNeeded = false;


		
		String Service_Url = getEnvInfo.getSecureURL();
		String Authorization = getEnvInfo.getAuthorization();
		ResultSet rs,rs1,rs2,rs3;

		@Given("^a working endpoint exists for the \"([^\"]*)\" PRUCO API$")
		public void valid_endpoint_for_Profile_API(String serviceName) throws Throwable {
			logger.info("In Given");
			logger.info("testService On-------------->:" + serviceName);
			GlobalStaticInfo.loadGlobalStaticInfo();
		}
		
		
		
		@When("^the POST request is sent to profile API with below request body data of Profile with PRUCO$")
		public void the_POST_request_is_sent_to_Profile_with_below_reqeust_body_data_of_Profile_with_PRUCO(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, InterruptedException, org.json.simple.parser.ParseException, SQLException{
			logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
			logger.info("In When a POST request is sent to profile API with below request body data");
			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			requestID = "profileCreate" + n;
			RestAssured.baseURI = Service_Url;
			Map<String, String> data = parameters.asMap(String.class, String.class);
			profileId = data.get("profile_id");
			Profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
			
			Profile.setcontractId(requestID);
			ssoid = Profile.getSsoId();
			System.out.println(ssoid);
			
			 	Mapper mapper = new Mapper();
		        mapper.load("/LiteRegistration.json", liteRegistration);

		        liteRegistration.getRegistrationReq().getProfileDetails().setUserID(generateUserId());

		        User = liteRegistration.getRegistrationReq().getProfileDetails().getUserID();
		        Password = liteRegistration.getRegistrationReq().getProfileDetails().getPassword();

		        logger.info("UserId = " + liteRegistration.getRegistrationReq().getProfileDetails().getUserID());
		        response = createLiteRegistration(liteRegistration);
		        
		        logger.log(Level.INFO, "Response :" + response.prettyPrint());
		        mapper.loadJSON(response.prettyPrint(), sso);

		        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
			
			
		        XPruAuthJWT = getJWTAuthToken(User, Password);
			
			
		      
				 Litessoid = sso.getSsoid();
				Profile.setssoId(Litessoid);		

				String query2 = null;

				query2 = "Select couserID from couser where ssoid = '"+Litessoid+"'";
				Connection con = DBConnection.InitConnection();
				ResultSet resultset  = DBConnection.execStatement(con,query2);	
				while(resultset.next()) 
				{
					
					String couserId = resultset.getString(1);
					Profile.setcoUserId(couserId);	
					String couserId2 = Profile.getCoUserId();
					if(couserId.equals(couserId2))
					{
						System.out.println(" couserId2 2 is  = "+couserId);
					}
					}
				
				
				
				request = given().log().all()
						.header("X-PruRequestID", requestID)
						.header("Authorization", Authorization)
						.header("X-Forwarded-For", "0.0.0.0")
						.header("X-PruAuthJWT", XPruAuthJWT)
						;
					
			
				//request.param("ssoId",data.get("Header_ssoId"));
			Gson gson = new Gson();
			String body = gson.toJson(Profile);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			}
		
		
		
		
		public Response createLiteRegistration(LiteRegistration liteRegistration){
			if(properties.getProperty("Environment").equalsIgnoreCase("QA")) {
				Authorizationlite = "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==";
				EndpointLite = "https://api-dev.prudential.com/co/qa/public/selfservicepublic/v1/literegistration";
			}
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			{
				Authorizationlite = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";
				EndpointLite="https://api-stage.prudential.com/co/stage/public/selfservicepublic/v1/literegistration";
			}
			
			return given().log().all().header("Authorization", Authorizationlite).header("Content-Type","application/json").body(liteRegistration).post(EndpointLite).andReturn();
		}
		public String generateUserId(){
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			email = "joseph"+n;
			return email;
		}

		public String generateEmailAddress(){
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			email = "JOSEPH.WALLACE"+n+"@PRUDENTIAL.COM";
			return email;
		}

		public String generatePhoneNumber(){
			int n = rand.ints(5,111111111,999999999).findFirst().getAsInt();
			phone = "1"+n;
			return phone;
		}

		public String getJWTAuthToken(String userId, String password) {

			try {
			
				
				request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
						.formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
						.formParam("smauthreason", "").formParam("smagentname", "ssologin");


				if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
					response = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
				else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))				
					response = request.post("https://ssologin-stage.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();

				cookies = response.getCookies();
			
				logger.info("response-cookies :" + cookies);

				request = given().log().all().cookies(cookies);

				if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
					response = request.get("https://api-dev.prudential.com/.signjwt").andReturn();
				else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
					response = request.get("https://api-stage.prudential.com/.signjwt").andReturn();
				JsonPath jp = new JsonPath(response.asString());

				XPruAuthJWT = jp.getString("jwt");

				logger.info("Prospect JWT Toknen is :" + XPruAuthJWT);

				
			} catch (Exception e) {
				e.printStackTrace();
			}

			return XPruAuthJWT;

		}

		
		
}


