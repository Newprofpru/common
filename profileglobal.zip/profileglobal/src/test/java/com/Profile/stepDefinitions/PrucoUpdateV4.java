package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.contactAddresses;
import com.Profile.RequestBodyPojo.contactChannels;
import com.Profile.RequestBodyPojo.disclosures;
import com.Profile.RequestBodyPojo.investmentInfo;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.RequestBodyPojo.profileV4;
import com.Profile.RequestBodyPojo.suitability;
import com.Profile.RequestBodyPojo.trustedContactPerson;
import com.Profile.SupportLibraries.DBConnection;
import com.Profile.SupportLibraries.GlobalStaticInfo;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.LiteRegistration;
import com.test.mapper.pojos.RequestBodyPojoCreater;
import com.test.mapper.pojos.SsoId;
import com.test.mapper.utils.Util;
import com.test.mapper.utils.getEnvInfo;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PrucoUpdateV4 {
	
	 private static Logger logger = LogManager.getLogger();
	  static Properties properties = getEnvInfo.getInstance();
	    private Response response = null;
	    private String User = "";
	    private String Password = "";
	    private LiteRegistration liteRegistration = new LiteRegistration();
		public String email = "";
		public String phone = "";
	    private Map<String, String> data;
	    private SsoId sso = new SsoId();
	    private Response Res1;
	    private String Authorizationlite;
	    
		String SSOID =null;
		String ContractID = null;
		
		String userTransactionlogID=null;
		String profileStr=null,coUserId = null;
		
		profile profile = new profile();
	    disclosures disclosures = new disclosures();
		suitability suitability = new suitability();
		investmentInfo investmentInfo = new investmentInfo();
		trustedContactPerson trustedContactPerson = new trustedContactPerson();
		List<contactChannels> contactChannels = new ArrayList<>();
		List<contactAddresses> contactAddresses = new ArrayList<>();
		JsonObject personalInfoObject = new JsonObject();
		JsonObject disclosureObject = new JsonObject();
		JsonObject suitablityObject = new JsonObject();
		JsonObject investmentObject = new JsonObject();
		JsonObject trustContObject = new JsonObject();
		JsonObject profileObject = new JsonObject();;

		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		JsonArray employersArray = new JsonArray();
		JsonArray userRelationsArray = new JsonArray();
	    private String EndpointLite;
	    
	    private RequestSpecification request;
	    private String XPruAuthJWT = null;
		Map<String, String> cookie_Data = new HashMap<String, String>();

		Map<String, String> cookies = new HashMap<>();
		Random rand = new Random();
		String resBody=null;
		JsonObject responseObject = new JsonObject();
		
		profileV4 Profile = new profileV4();
		String ssoid = null;
		String Litessoid = null;
		String profileId = null;
		String requestID = null;

		boolean isNullNeeded = false;


		
		String Service_Url = getEnvInfo.getSecureURL();
		String Authorization = "Basic VEFycEdWR0R3bG1rS1JycG5BWGJCWGJIYnkwaXBTMmM6a0Y3M3A5S0dTR0FWNG5mRg==";
		ResultSet rs,rs1,rs2,rs3;
	
	@When("^the PUT request is sent to profile API with below request body data of Profile with BU PRUCO and credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_PUT_request_is_sent_to_Profile_API_with_below_reqeust_body_data_of_Profile_with_BU_PRUCO(String userid, String password,DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, InterruptedException, org.json.simple.parser.ParseException, SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		logger.info("In When a POST request is sent to profile API with below request body data");
		isNullNeeded = false;
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		Profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		
	
	        XPruAuthJWT = getJWTAuthToken(userid, password);
	
			
			request = given().log().all()
					.header("X-PruRequestID", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					;
				

		Gson gson = new Gson();
		String body = gson.toJson(Profile);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
		}
	
	
	@Then("^the data is updated correctly and success response code 200 is recieved succesfully$")
	public void the_data_is_updated_and_success_response_code_200_is_recieved_successfully(){
		try{
			logger.info("\nIn--------------------> Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@And("^the data is updated in db succesfully and verified$")
	public void the_data_is_updated_in_db_and_verified() throws SQLException, ParseException, InterruptedException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
		Thread.sleep(100);
		String query1 = null,query2=null,query3=null,query4=null;
		ResultSet rs,rs1,rs2,rs3;
		logger.info("\nIn--------------------> And the data is updated in db");
		Gson gson = new Gson();
		String profileStr = null;
		Connection con = null;
		try{
		
			profileStr = gson.toJson(Profile);
			
			
			
		
		JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
		if(profileObject.has("coUserId"))
			coUserId = profileObject.get("coUserId").getAsString();
		JsonObject personalInfoObject = new JsonObject();
		JsonObject disclosureObject = new JsonObject();
		JsonObject suitablityObject = new JsonObject();
		JsonObject investmentObject = new JsonObject();
		JsonObject trustContObject = new JsonObject();
		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		JsonArray employersArray = new JsonArray();
		JsonArray userRelationsArray = new JsonArray();
		String contractId = "";
		if(profileObject.has("contractId"))
			if(!profileObject.get("contractId").isJsonNull())
				contractId = profileObject.get("contractId").getAsString();
		if(profileObject.has("personalInfo"))
			personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("disclosures"))
			disclosureObject = profileObject.get("disclosures").getAsJsonObject();
		if(profileObject.has("suitability"))
			suitablityObject = profileObject.get("suitability").getAsJsonObject();
		if(profileObject.has("investmentInfo"))
			investmentObject = profileObject.get("investmentInfo").getAsJsonObject();
		if(profileObject.has("trustedContactPerson"))
			trustContObject = profileObject.get("trustedContactPerson").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
		if(profileObject.has("employers"))
			employersArray = profileObject.get("employers").getAsJsonArray();
		if(profileObject.has("userRelations"))
			userRelationsArray = profileObject.get("userRelations").getAsJsonArray();
		con = DBConnection.InitConnection();
		query1 = "Select * from usercontractprofile where couserid = '"+coUserId+"'";
		query2 = "Select * from couser where couserid = '"+coUserId+"'";
		rs = DBConnection.execStatement(con,query1);
		rs1 = DBConnection.execStatement(con,query2);
		while(rs.next()){
			Set<String> persInfoDBUserContractSet = GlobalStaticInfo.persInfoDBUserContract.keySet();
			Set<String> trustContDBUserContractSet = GlobalStaticInfo.trustContDBUserContract.keySet();
			Set<String> suitablityDBUserContractSet = GlobalStaticInfo.suitablityDBUserContract.keySet();
			Set<String> investmentDBUserContractSet = GlobalStaticInfo.investmentDBUserContract.keySet();
			Set<String> disclosureDBUserContractSet = GlobalStaticInfo.disclosureDBUserContract.keySet();
			if(profileObject.has("personalInfo")){
			if(!contractId.equals("")){
			for(String persInfoDBUserContractElement:persInfoDBUserContractSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement))){
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
					if(persInfoDBUserContractElement.contains("DATE")||persInfoDBUserContractElement.equalsIgnoreCase("VISAEXPIRATION")){
						String tmp[]=rs.getString(persInfoDBUserContractElement).split(" ");
						Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
						Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString());
						Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal");
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
					}
					else{
							if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
								 Assert.assertEquals(rs.getString(persInfoDBUserContractElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString(),GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is Equal");
								 logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
							}
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is blank");
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is null");
				}
			}
		}
			if(profileObject.has("trustedContactPerson")&&!contractId.equals("")){
			for(String trustContDBUserContractElement:trustContDBUserContractSet){
				if(!trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString().equals("")){
				 Assert.assertEquals(rs.getString(trustContDBUserContractElement),trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString(),GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is Equal");
				 logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is equal,value is "+rs.getString(trustContDBUserContractElement));
				}
				else
					logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&!contractId.equals("")){
				for(String suitablityDBUserContractElement:suitablityDBUserContractSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(suitablityDBUserContractElement),suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString(),GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is equal,value is "+rs.getString(suitablityDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&!contractId.equals("")){
				for(String investmentDBUserContractElement:investmentDBUserContractSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(investmentDBUserContractElement),investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString(),GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is equal,value is "+rs.getString(investmentDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("disclosures")&&!contractId.equals("")){
				for(String disclosureDBUserContractElement:disclosureDBUserContractSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(disclosureDBUserContractElement),disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString(),GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is equal,value is "+rs.getString(disclosureDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is null");
				}
			}
		}
		while(rs1.next()){
			Set<String> persInfoDBCouserSet = GlobalStaticInfo.persInfoDBCouser.keySet();
			Set<String> disclosureDBCouserSet = GlobalStaticInfo.disclosureDBCouser.keySet();
			Set<String> suitablityDBCouserSet = GlobalStaticInfo.suitablityDBCouser.keySet();
			Set<String> investmentDBCouserSet = GlobalStaticInfo.investmentDBCouser.keySet();
			Set<String> persInfoDBCouser1Set = GlobalStaticInfo.persInfoDBCouser1.keySet();
			if(profileObject.has("personalInfo")){
				if(contractId.equals("")){
			for(String persInfoDBCouserElement:persInfoDBCouserSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement))){
				if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString().equals("")){
				 Assert.assertEquals(rs1.getString(persInfoDBCouserElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is Equal");
				 logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is equal,value is "+rs1.getString(persInfoDBCouserElement));
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is null");
				}
			}
			}
		}
			if(profileObject.has("personalInfo")){
			if(contractId.equals("")){
				for(String persInfoDBCouser1SetElement:persInfoDBCouser1Set){
					if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement))){	
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString().equals("")){
						if(persInfoDBCouser1SetElement.contains("DATE")||persInfoDBCouser1SetElement.equalsIgnoreCase("VISAEXPIRATION")){
							String tmp[]=rs1.getString(persInfoDBCouser1SetElement).split(" ");
							Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
							Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString());
							Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal");
							logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
						else{
							 Assert.assertEquals(rs1.getString(persInfoDBCouser1SetElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is Equal");
							 logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
				}
			}
		}
			if(profileObject.has("disclosures")&&contractId.equals("")){
				for(String disclosureDBCouserElement:disclosureDBCouserSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(disclosureDBCouserElement),disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString(),GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is equal,value is "+rs1.getString(disclosureDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&contractId.equals("")){
				for(String suitablityDBCouserElement:suitablityDBCouserSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(suitablityDBCouserElement),suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString(),GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is equal,value is "+rs1.getString(suitablityDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&contractId.equals("")){
				for(String investmentDBCouserElement:investmentDBCouserSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(investmentDBCouserElement),investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString(),GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is equal,value is "+rs1.getString(investmentDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is null");
				}
			}
		}
		//while(rs2.next()){
			Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
			Set<String> contChannelDBUserContactSet = GlobalStaticInfo.contChannelDBUserContact.keySet();
			
			if(profileObject.has("contactAddresses")){
				
				for(int j=0;j<contactAddressArray.size();j++){
					JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
					if(!contactAddressObject.get("contactAddressId").getAsString().equals(""))
						query3 ="Select * from useraddress where USERADDRESSID = '"+contactAddressObject.get("contactAddressId").getAsString()+"'";
					else if(!profileObject.get("contractId").getAsString().equals(""))
						query3 ="Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"' and deleted = 'N' and ADDRESSTYPECODE = '"+contactAddressObject.get("addressType").getAsString()+"' ";
					else if(profileObject.get("contractId").getAsString().equals(""))
						query3 ="Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null and deleted = 'N'and ADDRESSTYPECODE = '"+contactAddressObject.get("addressType").getAsString()+"' ";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
					for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
						if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
						 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
						}
						else
							logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
					}
					
						Assert.assertEquals(rs2.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
						logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					
					
					if(!contractId.equals("")){
						Assert.assertEquals(rs2.getString("CONTRACTID"),contractId,"CONTRACTID is equal, value is "+contractId);
						logger.info("CONTRACTID is equal, value is "+contractId);
						Assert.assertEquals(rs2.getString("LINEOFBUSINESSCODE"),profileObject.get("businessUnit").getAsString().toUpperCase(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
						logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
					}
				}
					
			}
				
			
		}
			if(profileObject.has("contactChannels")){
				if(profileObject.get("benefitClaimId").getAsString().equals("")){
				for(int k=0;k<contactChannelArray.size();k++){
					JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
					if(!contactChannelObject.get("contactChannelId").getAsString().equals(""))
						query4 ="Select * from usercontact where USERCONTACTID = '"+contactChannelObject.get("contactChannelId").getAsString()+"'";
					else if(!profileObject.get("contractId").getAsString().equals(""))
						query4 ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid = '"+profileObject.get("contractId").getAsString()+"'and deleted = 'N' and CONTACTCHANNELCODE = '"+contactChannelObject.get("contactChannel").getAsString()+"' and CONTACTTYPECODE = '"+contactChannelObject.get("contactChannelType").getAsString()+"'";
					else if(profileObject.get("contractId").getAsString().equals(""))
						query4 ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null and benefitclaimid is null and deleted = 'N' and CONTACTCHANNELCODE = '"+contactChannelObject.get("contactChannel").getAsString()+"' and CONTACTTYPECODE = '"+contactChannelObject.get("contactChannelType").getAsString()+"'";
					rs3 = DBConnection.execStatement(con,query4);
					while(rs3.next()){
					for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
						if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
						 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
						}
						else
							logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
					}
					
						Assert.assertEquals(rs3.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of contact is equal, value is "+profileObject.get("coUserId").getAsString());
						logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					
					
					if(!contractId.equals("")){
						Assert.assertEquals(rs3.getString("CONTRACTID"),contractId,"CONTRACTID is equal, value is "+contractId);
						logger.info("CONTRACTID is equal, value is "+contractId);
						Assert.assertEquals(rs3.getString("LINEOFBUSINESSCODE"),profileObject.get("businessUnit").getAsString().toUpperCase(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
						logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
					}
				}
					
			}
			}
				
				else if(!profileObject.get("benefitClaimId").getAsString().equals("")){
					for(int k=0;k<contactChannelArray.size();k++){
						JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
						if(!contactChannelObject.get("contactChannelId").getAsString().equals(""))
							query4 ="Select * from usercontact where USERCONTACTID = '"+contactChannelObject.get("contactChannelId").getAsString()+"'";
						else 
							query4 ="Select * from usercontact where couserid = '"+profileObject.get("coUserId").getAsString()+"' and benefitclaimid = '"+profileObject.get("benefitClaimId").getAsString()+"' and CONTACTCHANNELCODE = '"+contactChannelObject.get("contactChannel").getAsString()+"' and CONTACTTYPECODE = '"+contactChannelObject.get("contactChannelType").getAsString()+"' and deleted = 'N'";
						rs3 = DBConnection.execStatement(con,query4);
						while(rs3.next()){
						for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
							if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
							 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
							 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
							}
							else
								logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
						}
						
							Assert.assertEquals(rs3.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of contact is equal, value is "+profileObject.get("coUserId").getAsString());
							logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
							Assert.assertEquals(rs3.getString("BENEFITCLAIMID"),profileObject.get("benefitClaimId").getAsString(),"BENEFITCLAIMID is equal, value is "+profileObject.get("benefitClaimId").getAsString());
							logger.info("benefitClaimId is equal, value is "+profileObject.get("benefitClaimId").getAsString());
							
					}
						
				}
				}
		}
			Set<String> employersDBCouserSet = GlobalStaticInfo.employersDBCouser.keySet();
			Set<String> userRelDbUserRelationSet = GlobalStaticInfo.userRelDbUserRelation.keySet();
			if(profileObject.has("employers")){
				for(int m=0;m<employersArray.size();m++){
					JsonObject employersObject = employersArray.get(m).getAsJsonObject();
					String qry = "Select * from couser where couserid = '"+profileObject.get("coUserId").getAsString()+"'";
					ResultSet rst = DBConnection.execStatement(con,qry);
					while(rst.next()){
					for(String employersDBCouserElement:employersDBCouserSet){
						if(!employersObject.get(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)).getAsString().equals("")){
							Assert.assertEquals(rst.getString(employersDBCouserElement),employersObject.get(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)).getAsString(),GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is Equal");
							 logger.info(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is equal,value is "+rst.getString(employersDBCouserElement));
							}
							else
								logger.info(GlobalStaticInfo.employersDBCouser.get(employersDBCouserElement)+" is null");	
						
					}
				}
				}
			}
			
			if(profileObject.has("userRelations")){
				boolean isrelationIdPresent = false;
				for(int p=0;p<userRelationsArray.size();p++){
					if(!userRelationsArray.get(p).getAsJsonObject().get("relationId").getAsString().equals(""))
						isrelationIdPresent = true;
				}
				if(isrelationIdPresent){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("relationIds from JSON are:");
					for(int l=0;l<userRelationsArray.size();l++){
						elm = userRelationsArray.get(l).getAsJsonObject().get("relationId").getAsString();
						idJsonArray.add(elm);
						logger.info(elm);
					}
					String que ="Select * from userrelation where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' order by USERRELATIONID asc";
					logger.info("Query input ---> "+que);
					logger.info("relationIds from db where couserid = '"+profileObject.get("coUserId").getAsString()+"' and contractid is null are:");
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("USERRELATIONID");
						idDbArray.add(elm);
						logger.info(elm);
					}
					Collections.sort(idJsonArray);
					Assert.assertEquals(idDbArray,idJsonArray ,"relationIds is response JSON are same as in db");
					logger.info("relationIds in response JSON are same as in db");
				}
				for(int n=0;n<userRelationsArray.size();n++){
					JsonObject userRelationsObject = userRelationsArray.get(n).getAsJsonObject();
					String qry1 = null;
					String relssoid=null,relcouserid=null;
					relssoid = userRelationsObject.get("relatedSSOId").getAsString();
					String que1 = "Select * from couser where ssoid = '"+relssoid+"'";
					ResultSet rst11 = DBConnection.execStatement(con,que1);
					while(rst11.next()){
						relcouserid = rst11.getString("COUSERID");
					}
					if(!userRelationsObject.get("relationId").getAsString().equals(""))
						qry1 = "Select * from userrelation where USERRELATIONID = '"+userRelationsObject.get("relationId").getAsString()+"'";
					else if(userRelationsObject.get("relationId").getAsString().equals("")){
						qry1 = "Select * from userrelation where COUSERID = '"+profileObject.get("coUserId").getAsString()+"' and RELATEDCOUSERID = '"+relcouserid+"' and deleted = 'N'";
					}
					ResultSet rst1 = DBConnection.execStatement(con,qry1);
					while(rst1.next()){
					for(String userRelDbUserRelationElement:userRelDbUserRelationSet){
						if(!userRelationsObject.get(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)).isJsonNull()){
							Assert.assertEquals(rst1.getString(userRelDbUserRelationElement),userRelationsObject.get(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)).getAsString(),GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is Equal");
							 logger.info(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is equal,value is "+rst1.getString(userRelDbUserRelationElement));
							}
							else
								logger.info(GlobalStaticInfo.userRelDbUserRelation.get(userRelDbUserRelationElement)+" is null");	
					}
				}
				}
			}
			
		}catch(Exception e){
			logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}
			}	
	
	}
	
	
		public String getJWTAuthToken(String userId, String password) {

		try {
		
			
			request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
					.formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
					.formParam("smauthreason", "").formParam("smagentname", "ssologin");


			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))				
				response = request.post("https://ssologin-stage.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();

			cookies = response.getCookies();
		
			logger.info("response-cookies :" + cookies);

			request = given().log().all().cookies(cookies);

			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.get("https://api-dev.prudential.com/.signjwt").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
				response = request.get("https://api-stage.prudential.com/.signjwt").andReturn();
			JsonPath jp = new JsonPath(response.asString());

			XPruAuthJWT = jp.getString("jwt");

			logger.info("Prospect JWT Toknen is :" + XPruAuthJWT);

			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return XPruAuthJWT;

	}

}
