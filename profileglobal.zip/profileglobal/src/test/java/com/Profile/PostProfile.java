package com.Profile;

import com.test.mapper.api.ProfileAPI;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.Profile;
import com.test.mapper.pojos.ProfileResponse;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;


public class PostProfile {

    private static Logger logger = LogManager.getLogger();
    RequestSpecification request = null;
    Response response = null;
    ProfileResponse profileResponse = null;

    @Given("^a working endpoint exists for the \"([^\"]*)\" API$")
    public void a_working_endpoint_for_Profile(String serviceName) throws Throwable {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        //GlobalStaticInfo.loadGlobalStaticInfo();
    }


    @Then("^the data is created succesfully and success response code 200 is recieved from API and verified$")
    public void the_data_is_created_succesfully_and_success_response_code_200_is_recieved() {
        try {
            logger.info("Reached here2");
            logger.info("In Then the data is updated and success response code 200 is recieved");
            Integer actualResponseCode = 200;
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
    }


    @Then("^the Profile is created succesfully and success response code 200 is recieved from API and verified$")

    public void postAutomationReq() throws IllegalAccessException, InvocationTargetException, IOException {

        Profile profileAPI = new Profile();
        Mapper mapper = new Mapper();
        mapper.load("POST/ProfileCreate.json", profileAPI);
        profileAPI.toString();

        ProfileAPI profileAPI1 = new ProfileAPI();
        response = profileAPI1.createRequest(profileAPI);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");

        profileResponse = response.getBody().as(ProfileResponse.class);
        logger.log(Level.DEBUG, "CouserId :" + profileResponse.getCoUserId());


    }

    @Then("^the Update to Profile is succesfull and success response code 200 is recieved from API and verified$")

    public void updateaProfile() throws IllegalAccessException, InvocationTargetException, IOException {

        Profile profileUpdate = new Profile();
        Mapper mapper = new Mapper();
        mapper.load("PUT/ProfileUpdate.json", profileUpdate);
        profileUpdate.setCoUserId(profileResponse.getCoUserId());


        ProfileAPI profileAPI1 = new ProfileAPI();
        response = profileAPI1.updateRequest(profileUpdate);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");


    }

    @Then("^GET for the updated Profile  recieved successfully from API and verified$")

    public void getProfile() throws IllegalAccessException, InvocationTargetException, IOException {


        ProfileAPI profileAPI1 = new ProfileAPI();
        response = profileAPI1.getRequest(profileResponse.getCoUserId());
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");


    }


    @Then("^the Profile1 is created succesfully and success response code 200 is recieved from API and verified$")

    public void printProfile() throws IllegalAccessException, InvocationTargetException, IOException {
        Profile profileAPI = new Profile();
        Mapper mapper = new Mapper();
        mapper.load("POST/Profile.json", profileAPI);
        profileAPI.toString();

        ProfileAPI profileAPI1 = new ProfileAPI();


        logger.info("Cooler ::" + profileAPI1.createRequest(profileAPI).asString());
    }

}
