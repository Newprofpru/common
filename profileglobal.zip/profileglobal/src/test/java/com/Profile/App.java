package com.Profile;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class App {

    public static void main(String[] args) throws IOException, IllegalAccessException, InvocationTargetException {

        /* code for profile POST Request */

        PostProfile postAutomation = new PostProfile();
        //	postAutomation.postAutomationReq();
        postAutomation.printProfile();
        /* code for profile GET Request */

		/*GetProfile getAutomation = new GetProfile();
		getAutomation.getAutomationReq();*/

        /* code for profile PUT Request */

		/*PutProfile putAutomation = new PutProfile();
		putAutomation.PutAutomationReq();*/

    }
}
