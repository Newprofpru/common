package com.Profile;

import com.test.mapper.Mapper;
import com.test.mapper.pojos.ProfileUpdate;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import static io.restassured.RestAssured.given;


public class PutProfile {

    private static Logger logger = LogManager.getLogger();

    public void PutAutomationReq() throws IllegalAccessException, InvocationTargetException, IOException {

        Mapper mapper = new Mapper();
        String Service_Url_PUT = "https://api-stage.prudential.com/co/stage/secure/profiles/v3/profile";
        io.restassured.response.Response responsePut = null;
        RequestSpecification request = null;
        /*Profile profile = new Profile();*/
        ProfileUpdate profileUpdate = new ProfileUpdate();
        String requestID = "UpdateProfile";

        String authorization = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";

        /*code for mapping java objects to json objects */

        mapper.load("PUT/ProfileUpdate.json", profileUpdate);
        logger.info(mapper.getAsString(profileUpdate));

        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", authorization);

        responsePut = request.log().all().body(profileUpdate).contentType(ContentType.JSON).put(Service_Url_PUT).andReturn();
        logger.info("PUT Response-->" + responsePut.prettyPrint());
    }
	
	/*public void PutRiskScoreConfigReq() throws IllegalAccessException, InvocationTargetException, IOException  {
		YamlMapper yamlMapper =new YamlMapper();
		String Service_Url_PUT = "https://api-stage.prudential.com/co/stage/secure/platform/v1/riskscoreconfig";
		io.restassured.response.Response responsePut = null;
		RequestSpecification request = null;
		RiskScoreConfigGet riskScoreConfigGetYaml = new RiskScoreConfigGet();
		String requestID = "UpdateRiskScoreConfig";
		String authorization = "Basic U0FDYVlJbzNNTlA1Q3AyQVF0YTZ3S2FaakpHS2txNlg6SkE1ZjNqMUc2S2JQZ1RBNA==";
		String resultbody = "SMSESSION=bzoo7PWPgASHlvUGfdP8+6g7bNOQcqP7/CkngN8nOSwnHvUhBhntRpTbzHq44ggJWyD0oMms/y0+sPU7oKeWrEq8K1lOnAQwaObXcSoJDF5Z7eIA5m40uP4hSvMv/XSoxxeHZWQTOuSkyNVqhtxsRueQDMgTgbutAZBJ6044dD571iSOKnBnrDiRpLlvAp51H8JIkJmkawETOtH6tx5PJw1ab7ee3SghXyhi3I3l/Wn/Kiu7tbHxmgEP2I8gfa2Svrj3lgVfF6Gvw1gy8/a+aguVcoY4QoMLi4mHAXzAz47Hh25wt5CgtgcC1OjrLib2+lVdqHc8V/TJafyhI6Ug9vkBSr9sAeQFiI/QM/H4OwBpTUwgpgmUPd/2KkxqThZJW3CB8h0nEJG1x16uYesify/5eOtWjQFpUYXySOcKYBILtqDCXGAEAF2nBgq3COy/lEsq8dKEGFlFnqbwlaOcWtCVZ44K2g75gAZ5jqUlseZWDw7owlDD/BagYoo9fFOUf4mSZbNzIHWUSy7zSe3NYR8Op3f5Oj/T0yMoU8ut7FhCGqYTrQ8d/ADNLn9xeFCAJfU5foq5kiKOm3IipMAqvsn70IMHCm8NGEJC6YF4GrKe16Bq3pnV/KQ/u/lcNBb4/8cOcamg5T6tQNtV9xEPfAYOuM1eLM5Qzm4zS6rZHRqOCULVujZAGVGc8g3W1ArZKmRetf17fY7C9SUA5HKUmts0VkdPIQG95F8v/0SmNC+h/Xb7jX62aKPklhuhBwAyT6uSbcXDx///b5Q88VusI9mnepJ4PurtCDsK4WjJ9xekN+ozKtflPqqIXVov4YpXIH/XT+1d7tfUwAnf0Os2Nzv23/Nv1JSLoeB3Yo63vCDIbWrUYLmEJBAElzgr/NAFXMsLhWbh4ECdQDNoDid95TuwwetdcVoh7pC8jcKaFGeazDPWrCNIW33pNcibKzYdKc8gSPfCU3gPDn7HRR/AZwyO+zxHXrKFVBT8KH6qHzOCJddIVWIcECzsHh7OuiHzaZp53SbbD0AA5m1Ecl9KALTKP3G75MhYxGMiFrRS3D3fxeRcpAN9aMdIX3WCShw5T7mNhuqt2IIrjf/3y3Cxl3KBN1H680ySZc/061fjmF+S2Dv+ZijlkvJAcLvwmMYstsqzTXSXJcIbj4mVvubc5RDM8pA+wq4Eu8nlOJYHiFzEPAOKfHApSdnru2VD6OSDz8X8T2dP3qKAwiAVaTRWPSCyZEfd+0B2; path=/; pojos=.prudential.com; secure";
		
		yamlMapper.load("src/main/resources/riskScoreConfigGet/PUT/" + riskScoreConfigGetYaml.getClass().getSimpleName() + ".yaml",riskScoreConfigGetYaml);
		logger.info(yamlMapper.getAsString(riskScoreConfigGetYaml));
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Cookie", resultbody)
				.header("Authorization", authorization);
		
		responsePut = request.log().all().body(riskScoreConfigGetYaml).contentType(ContentType.JSON).put(Service_Url_PUT).andReturn();
		logger.info("PUT Response of RiskScoreConfig -->" + responsePut.prettyPrint());
	}*/

}
