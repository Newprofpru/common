package com.ProfileV4;

import com.test.mapper.api.ProfileV4API;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.ProfileV4Profile;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

public class ProfileV4CoUserILI {

    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private Response response = null;
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();
    private ProfileV4API ProfileV4API1 = new ProfileV4API();

    @Given("^a working endpoint exists for CoUser \"([^\"]*)\" API$")
    public void a_working_endpoint_for_ProfileV4(String serviceName) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        //GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @Then("^GET for the updated Profile received successfully from API and then verified using CoUser \"([^\"]*)\"$")
    public void getProfileV4UsingValidCoUserILI(String coUserId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^GET for the updated Profile gives 400 from API and then verified using CoUser \"([^\"]*)\"$")
    public void getProfileV4UsingInvalidCoUserILI(String coUserId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 400, "Response code 400 verified.");
    }

    @Then("^the Update to Profile is successful and success response code 200 is received from API and is then verified using CoUser \"([^\"]*)\"$")
    public void updateProfileV4ValidCoUserILI(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactChannels(profileV4Update, 0, 0);
        response = ProfileV4API1.updateRequestWithParams(profileV4Update.getProfiles()[0], coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^the Update to Contact Addresses in Profile is successful and success response code 200 is received from API and is then verified using CoUser \"([^\"]*)\"$")
    public void updateProfileContactAddressesV4ValidCoUserILI(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactAddresses(profileV4Update,0,0);
        response = ProfileV4API1.updateRequestWithParams(profileV4Update.getProfiles()[0], coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Add in Profile using \"([^\"]*)\" and filename \"([^\"]*)\"$")
    public void addContactChannel(String coUserId, String filename) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.load("/PUT/" + filename, profileV4Update);
        response = ProfileV4API1.updateRequestWithParams(profileV4Update.getProfiles()[0], coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Delete in Profile using \"([^\"]*)\" at \"([^\"]*)\"$")
    public void deleteContactChannel(String coUserId, String index) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.deleteContactChannels(profileV4Update,0, Integer.parseInt(index));
        response = ProfileV4API1.updateRequestWithParams(profileV4Update.getProfiles()[0], coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Refresh the updated Profile to get the latest value using CoUser \"([^\"]*)\"$")
    public void updateDatabase(String coUserId) throws InterruptedException {
        ProfileV4API profileV4API1 = new ProfileV4API();
        Thread.sleep(15000);
        response = profileV4API1.getRequest(coUserId);
    }

    @Then("^GET for the updated Profile received successfully from API and then verified using CoUser \"([^\"]*)\" after update$")
    public void getProfileV4UsingValidCoUserILIUpdated(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(profileV4Update.getProfiles()[0].getContactChannels()[1].getContactChannel().equals("EMAIL")) {
            Assert.assertEquals(generateTokenUtils.email, profileV4Update.getProfiles()[0].getContactChannels()[0].getContactChannelValue());
        } else if (profileV4Update.getProfiles()[0].getContactChannels()[0].getContactChannel().equals("PHONE")){
            Assert.assertEquals(generateTokenUtils.phone, profileV4Update.getProfiles()[0].getContactChannels()[0].getContactChannelValue());
        }
    }

    @Then("^GET for the updated Contact Addresses in Profile received successfully from API and then verified using CoUser \"([^\"]*)\" after update$")
    public void getProfileContactAddressesV4UsingValidCoUserILIUpdated(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        Assert.assertEquals(generateTokenUtils.indvAddress[0], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine1());
        Assert.assertEquals(generateTokenUtils.indvAddress[1], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine2());
        Assert.assertEquals(generateTokenUtils.indvAddress[2], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine3());
        Assert.assertEquals(generateTokenUtils.indvAddress[3], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCity());
        Assert.assertEquals(generateTokenUtils.indvAddress[4], profileV4Update.getProfiles()[0].getContactAddresses()[0].getState());
        Assert.assertEquals(generateTokenUtils.indvAddress[5], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCountry());
        Assert.assertEquals(generateTokenUtils.indvAddress[6], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipCode());
        Assert.assertEquals(generateTokenUtils.indvAddress[7], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipPlus4());
    }

    @Then("^back to back GET update using \"([^\"]*)\" after update$")
    public void getProfileAssertUpdate(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        String[] dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId()).toString().split(",");

        String temp;
        for(int i = 0; i < dbResult.length/2; i++){
            temp = dbResult[i];
            dbResult[i] = dbResult[dbResult.length-i-1];
            dbResult[dbResult.length-i-1] = temp;
        }

        System.err.println(ProfileV4API1.getRequestId());
        System.err.println(dbResult[0]);
        System.err.println(dbResult[7]);
        Assert.assertTrue(dbResult[0].contains("UPDATE"));
        Assert.assertTrue(dbResult[7].contains("INIT") || dbResult[7].contains("PENDING") || dbResult[7].contains("COMPLETED"));
    }

    @Then("^back to back GET add using \"([^\"]*)\" after update$")
    public void getProfileAssertAdd(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        String[] dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId()).toString().split(",");

        String temp;
        for(int i = 0; i < dbResult.length/2; i++){
            temp = dbResult[i];
            dbResult[i] = dbResult[dbResult.length-i-1];
            dbResult[dbResult.length-i-1] = temp;
        }

        System.err.println(dbResult[0]);
        System.err.println(dbResult[7]);
        System.err.println(ProfileV4API1.getRequestId());
        Assert.assertTrue(dbResult[0].contains("ADD"));
        Assert.assertTrue(dbResult[7].contains("INIT") || dbResult[7].contains("PENDING") || dbResult[7].contains("COMPLETED"));
        Assert.assertTrue(profileV4Update.getProfiles()[0].getContactChannels().length == 5);
        Assert.assertTrue(profileV4Update.getProfiles()[1].getContactChannels()[4].getContactChannelType().equals("Secondary"));
    }

    @Then("^back to back GET delete using \"([^\"]*)\" after update$")
    public void getProfileAssertDelete(String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequest(coUserId);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        String[] dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId()).toString().split(",");

        String temp;
        for(int i = 0; i < dbResult.length/2; i++){
            temp = dbResult[i];
            dbResult[i] = dbResult[dbResult.length-i-1];
            dbResult[dbResult.length-i-1] = temp;
        }

        System.err.println(dbResult[0]);
        System.err.println(dbResult[7]);
        System.err.println(ProfileV4API1.getRequestId());
        Assert.assertTrue(dbResult[0].contains("DELETE"));
        Assert.assertTrue(dbResult[7].contains("INIT") || dbResult[7].contains("PENDING") || dbResult[7].contains("COMPLETED"));
        Assert.assertTrue(profileV4Update.getProfiles()[0].getContactChannels().length == 4);
    }
}
