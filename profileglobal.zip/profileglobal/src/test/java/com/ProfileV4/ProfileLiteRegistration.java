package com.ProfileV4;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.mapper.api.ProfileV4API;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.*;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.EnvInfo;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.lexer.Tr;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import javax.validation.constraints.AssertTrue;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;

import static io.restassured.RestAssured.given;

public class ProfileLiteRegistration {

    private static Logger logger = LogManager.getLogger();
    private EnvInfo envInfo = EnvInfo.getInstance();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private Response response = null;
    private String User = "";
    private String Password = "";
    private LiteRegistration liteRegistration = new LiteRegistration();
    private SsoId sso = new SsoId();
    private ProfileV4Profile profileV4Profile = new ProfileV4Profile();
    private ProfileV4API profileV4API = new ProfileV4API();
    private Map<String, String> data;
    private String Service_Url = envInfo.getSecureURL();
    private Response Res1;
    private String Authorization = envInfo.getAuthorization();
    private RequestSpecification request;
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();
    private String[] outString;

    @Given("^a endpoint that works exists for \"([^\"]*)\" API")
    public void a_working_endpoint_for_ProfileV4(String serviceName) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        //GlobalStaticInfo.loadGlobalStaticInfo();

    }

    @When("^Do a lite registration to create new ssoId$")
    public void doLiteRegistration() throws IllegalAccessException, IOException, InvocationTargetException {

        Mapper mapper = new Mapper();
        mapper.load("POST/LiteRegistration.json", liteRegistration);

        liteRegistration.getRegistrationReq().getProfileDetails().setUserID(generateTokenUtils.generateUserId());

        User = liteRegistration.getRegistrationReq().getProfileDetails().getUserID();
        Password = liteRegistration.getRegistrationReq().getProfileDetails().getPassword();

        logger.info("UserId = " + liteRegistration.getRegistrationReq().getProfileDetails().getUserID());
        response = generateTokenUtils.createLiteRegistration(liteRegistration);
        logger.log(Level.INFO, "Response :" + response.prettyPrint());

        mapper.loadJSON(response.prettyPrint(), sso);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Associate newly created ssoId with an existing contractId$")
    public void associateSsoIdWithContractId() throws IllegalAccessException, IOException, InvocationTargetException {

        Mapper mapper = new Mapper();
        System.err.println(User);
        System.err.println(Password);
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(sso.getSsoid(), User, Password);
        mapper.loadJSON(response.prettyPrint(), profileV4Profile);

        //System.err.println(sso.getSsoid());
        //mapper.loadJSON(response.prettyPrint(), profileV4Profile);
        //mapper.load("PUT/ProfileAddNew.json", profileV4Profile);
        //profileV4Profile.getProfiles()[0].setSsoId(sso.getSsoid());
        //response = profileV4API.updateRequestWithParamsNormal(profileV4Profile.getProfiles()[0], sso.getSsoid(), User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200 is verified.");
    }

    @Then("^Write data to file$")
    public void writeToFile() throws IOException {

        try {
            File file = new File("data.txt");
            file.delete();
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(User + "," + Password + "," + sso.getSsoid() + "," + profileV4Profile.getProfiles()[0].getCoUserId());

            bw.close();
            fw.close();

        }catch (Exception ex) {
            logger.error("Exception when writing file.");
        }
    }

    @Then("^Return the result$")
    public void getResult() throws IllegalAccessException, IOException, InvocationTargetException {

        Mapper mapper = new Mapper();
        logger.log(Level.INFO, "Response :" + response.asString());
        mapper.loadJSON(response.prettyPrint(), profileV4Profile);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200 verified.");
    }

    @Then("^a user sends the GET request to profile API with below parameters of a normal profile$")
    public void the_user_sends_a_GET_request_to_profile_API_with_below_parameters_of_a_normal_profile(DataTable parameters) throws IOException, IllegalAccessException, InvocationTargetException {

        Mapper mapper = new Mapper();
        Scanner in = new Scanner(new FileReader("data.txt"));
        StringBuilder sb = new StringBuilder();
        while(in.hasNext()) {
            sb.append(in.next());
        }
        in.close();
        outString = sb.toString().split(",");

        data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        Random rand = new Random();
        int n = rand.nextInt(00450) + 12344;
        String requestID = "ProfileV3Get" + n;
        RestAssured.baseURI = Service_Url;
        String jwt = generateTokenUtils.getJWTAuthToken(outString[0],outString[1]);
        logger.info("jwt " + jwt);
        request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0")
                .header("X-PruPrimaryIdentity",outString[2])
                .header("X-PruAuthJWT", jwt);
        for(String paramName:paramNames){
            request.param(paramName,data.get(paramName));
        }
        Res1 = request.when().get().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        logger.info(Res1.asString());
        mapper.loadJSON(Res1.prettyPrint(), profileV4Profile);
    }

    @Then("^a user sends the GET request with coUserId to profile API with below parameters of a normal profile$")
    public void the_user_sends_a_GET_request_coUserId_to_profile_API_with_below_parameters_of_a_normal_profile(DataTable parameters) throws IOException, IllegalAccessException, InvocationTargetException {

        Mapper mapper = new Mapper();
        Scanner in = new Scanner(new FileReader("data.txt"));
        StringBuilder sb = new StringBuilder();
        while(in.hasNext()) {
            sb.append(in.next());
        }
        in.close();
        outString = sb.toString().split(",");

        data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        Random rand = new Random();
        int n = rand.nextInt(00450) + 12344;
        String requestID = "ProfileV3Get" + n;
        RestAssured.baseURI = Service_Url;
        String jwt = generateTokenUtils.getJWTAuthToken(outString[0],outString[1]);
        logger.info("jwt " + jwt);
        request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0")
                .header("X-PruPrimaryIdentity",outString[2])
                .header("X-PruAuthJWT", jwt);
        for(String paramName:paramNames){
            request.param(paramName,data.get(paramName));
        }
        request.param("coUserId", outString[3]);
        Res1 = request.when().get().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        logger.info(Res1.asString());
        mapper.loadJSON(Res1.prettyPrint(), profileV4Profile);
    }

    @Then("^a user recieves correct responsebody content and is verified with db$")
    public void user_recieves_correct_responsebody_from_Profile_API_and_verified_in_db() throws SQLException, ParseException, InterruptedException {

        List<UserContractProfile> listFromUserContractProfile = applicationCommonQueries.getUserContractProfileFromCoUserId(outString[3]);
        List<COUser> listFromCoUser = applicationCommonQueries.getCoUserFromCoUserId(outString[3]);
        List<UserAddress> listFromUserAddressId = applicationCommonQueries.getUserAddressFromCoUserId(outString[3]);
        List<UserContact> listFromContactId = applicationCommonQueries.getUserContactFromCoUserId(outString[3]);

        if(!listFromUserContractProfile.isEmpty()){
            logger.info(listFromUserContractProfile);
        }
        if(!listFromCoUser.isEmpty()){
            logger.info(listFromCoUser);
            Assert.assertTrue(listFromCoUser.toString().contains(outString[2]));
            Assert.assertTrue(listFromCoUser.toString().contains(outString[3]));
        }
        if(!listFromUserAddressId.isEmpty()){
            logger.info(listFromUserAddressId);
        }
        if(!listFromContactId.isEmpty()){
            logger.info(listFromContactId);
            Assert.assertTrue(listFromContactId.get(0).getContactValue().contains("test.tester123@prudential.com"));
        }
    }

    @Then("^a user recieves correct responsebody content as No records found$")
    public void the_user_recieves_correct_responsebody_content_from_Profile_API_as_No_records_found(){
        logger.info("In Then");
        logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
        // Validate the response
        Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
        logger.info(Res1.getBody().asString());
        JsonObject responseObject = (JsonObject) new JsonParser().parse(Res1.getBody().asString());
        Assert.assertEquals(responseObject.get("responseStatus").getAsString(), "No Records Found", "responseStatus received in the Response is No Records Found");
        logger.info("responseStatus received in the Response is No Records Found");
    }

    @Then("^a BAD_REQUEST response is returned with correct error response code (\\d+)$")
    public void user_recieves_BAD_REQUEST_response_with_error_response_code(int responseCode)throws SQLException{
        try{
            logger.info("In Then");
            int actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode, responseCode, "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }
}