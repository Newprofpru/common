package com.ProfileV4;

import static io.restassured.RestAssured.given;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.EnvInfo;
import com.test.mapper.utils.GenerateTokenUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ProfileV3Get {

    private EnvInfo envInfo = EnvInfo.getInstance();
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();
    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    static RequestSpecification request;
    static Response Res1;
    String Service_Url = envInfo.getSecureURL();
    String Authorization = envInfo.getAuthorization();
    ResultSet rs,rs1,rs2,rs3;
    Map<String, String> data;
    @Given("^the valid endpoint exists for \"([^\"]*)\"$")
    public void valid_endpoint_for_Profile_API(String serviceName) throws Throwable {
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
    }

    @When("^the user sends a GET request to profile API with below parameters of a normal profile$")
    public void the_user_sends_a_GET_request_to_profile_API_with_below_parameters_of_a_normal_profile(DataTable parameters){
        data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        Random rand = new Random();
        int n = rand.nextInt(00450) + 12344;
        String requestID = "ProfileV3Get" + n;
        RestAssured.baseURI = Service_Url;
        String jwt = generateTokenUtils.getJWTAuthToken("vvere1_mig","Pru12345");
        logger.info("jwt " + jwt);
        request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-PruAuthJWT", jwt)
                .header("X-Forwarded-For", "0.0.0.0");
        for(String paramName:paramNames){
            if(paramName.equalsIgnoreCase("Header_ssoId"))
                request.header("X-PruPrimaryIdentity",data.get(paramName) );
            else
                request.param(paramName,data.get(paramName));
        }
        Res1 = request.when().get().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        logger.info(Res1.asString());
    }

    @Then("^the user recieves correct responsebody content and is verified with db$")
    public void user_recieves_correct_responsebody_from_Profile_API_and_verified_in_db() throws SQLException, ParseException{

        String coUserId = "";
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
            System.err.println(paramName);
            if(paramName.equalsIgnoreCase("coUserId")) {
                coUserId = data.get(paramName);
            }
        }
        List<?> list = applicationCommonQueries.getUserContractProfileFromCoUserId(coUserId);
        //applicationCommonQueries.getCoUserFromCoUserId(coUserId);
        //applicationCommonQueries.getUserAddressFromCoUserId(coUserId, coUserId);
        //applicationCommonQueries.getUserContactFromCoUserIdandContractId(coUserId, coUserId);
        //String query1 = "Select * from usercontractprofile where couserid = '"+coUserId+"'";
        //String query2 = "Select * from couser where couserid = '"+coUserId+"'";
            //query3 ="Select * from useraddress where USERADDRESSID = '"+contactAddressObject.get("contactAddressId").getAsString()+"'";
            //query4 ="Select * from usercontact where USERCONTACTID = '"+contactChannelObject.get("contactChannelId").getAsString()+"'";
        System.err.println(list);
    }

    @Then("^the user recieves correct responsebody content as No records found$")
    public void the_user_recieves_correct_responsebody_content_from_Profile_API_as_No_records_found(){
        logger.info("In Then");
        logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
        // Validate the response
        Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
        logger.info(Res1.getBody().asString());
        JsonObject responseObject = (JsonObject) new JsonParser().parse(Res1.getBody().asString());
        Assert.assertEquals(responseObject.get("responseStatus").getAsString(), "No Records Found", "responseStatus received in the Response is No Records Found");
        logger.info("responseStatus received in the Response is No Records Found");
    }

    @Then("^the BAD_REQUEST response is returned with correct error response code (\\d+)$")
    public void user_recieves_BAD_REQUEST_response_with_error_response_code(int responseCode)throws SQLException{
        try{
            logger.info("In Then");
            int actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode, responseCode, "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }

}
