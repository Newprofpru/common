package com.ProfileV4;

import com.test.mapper.api.ProfileV4API;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.ProfileV4Profile;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class ProfileV4ILI {

    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private Response response = null;
    private String User = "";
    private String Password = "";

    private int ContactChannelIndex;

    @Given("^a working endpoint exists for \"([^\"]*)\" API for contact channels and user \"([^\"]*)\" and password \"([^\"]*)\" and contact channel index \"(\\d+)\"$")
    public void a_working_endpoint_for_ProfileV4_Contact_Channels(String serviceName, String user, String password, int contactChannelIndex) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        //GlobalStaticInfo.loadGlobalStaticInfo();
        User = user;
        Password = password;

        ContactChannelIndex = contactChannelIndex;
    }

    @Given("^a working endpoint exists for \"([^\"]*)\" API for contact addresses and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void a_working_endpoint_for_ProfileV4_Contact_Addresses(String serviceName, String user, String password) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        //GlobalStaticInfo.loadGlobalStaticInfo();
        User = user;
        Password = password;
    }

    @Then("^GET for the updated Profile received successfully from API and then verified using \"([^\"]*)\"$")
    public void getProfileV4UsingValidSsoILI(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^GET for the updated Profile gives 400 from API and then verified using \"([^\"]*)\"$")
    public void getProfileV4UsingInvalidSsoILI(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 400, "Response code 400 verified.");
    }

    @Then("^the Update to Profile is successful and success response code 200 is received from API and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateProfileV4ValidSsoILI(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactChannels(profileV4Update, 1, ContactChannelIndex);
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^the Update to Contact Addresses in Profile is successful and success response code 200 is received from API and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateProfileContactAddressesV4ValidSsoILI(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactAddresses(profileV4Update,1,0);
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Refresh the updated Profile to get the latest value using \"([^\"]*)\"$")
    public void updateDatabase(String ssoId) throws InterruptedException {
        ProfileV4API profileV4API1 = new ProfileV4API();
        Thread.sleep(15000);
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
    }

    @Then("^GET for the updated Contact Channels in Profile received successfully from API and then verified using \"([^\"]*)\" after update$")
    public void getProfileContactChannelV4UsingValidSsoILIUpdated(String ssoId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(profileV4Update.getProfiles()[1].getContactChannels()[ContactChannelIndex].getContactChannel().equals("EMAIL")) {
            Assert.assertEquals(generateTokenUtils.email, profileV4Update.getProfiles()[1].getContactChannels()[ContactChannelIndex].getContactChannelValue());
        } else if (profileV4Update.getProfiles()[1].getContactChannels()[ContactChannelIndex].getContactChannel().equals("PHONE")){
            Assert.assertEquals(generateTokenUtils.phone, profileV4Update.getProfiles()[1].getContactChannels()[ContactChannelIndex].getContactChannelValue());
        }
    }

    @Then("^GET for the updated Contact Addresses in Profile received successfully from API and then verified using \"([^\"]*)\" after update$")
    public void getProfileContactAddressesV4UsingValidSsoILIUpdated(String ssoId) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        Assert.assertEquals(generateTokenUtils.indvAddress[0], profileV4Update.getProfiles()[1].getContactAddresses()[0].getAddressLine1());
        Assert.assertEquals(generateTokenUtils.indvAddress[1], profileV4Update.getProfiles()[1].getContactAddresses()[0].getAddressLine2());
        Assert.assertEquals(generateTokenUtils.indvAddress[2], profileV4Update.getProfiles()[1].getContactAddresses()[0].getAddressLine3());
        Assert.assertEquals(generateTokenUtils.indvAddress[3], profileV4Update.getProfiles()[1].getContactAddresses()[0].getCity());
        Assert.assertEquals(generateTokenUtils.indvAddress[4], profileV4Update.getProfiles()[1].getContactAddresses()[0].getState());
        Assert.assertEquals(generateTokenUtils.indvAddress[5], profileV4Update.getProfiles()[1].getContactAddresses()[0].getCountry());
        Assert.assertEquals(generateTokenUtils.indvAddress[6], profileV4Update.getProfiles()[1].getContactAddresses()[0].getZipCode());
        Assert.assertEquals(generateTokenUtils.indvAddress[7], profileV4Update.getProfiles()[1].getContactAddresses()[0].getZipPlus4());
    }
}
