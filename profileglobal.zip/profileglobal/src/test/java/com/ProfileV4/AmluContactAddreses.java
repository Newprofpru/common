package com.ProfileV4;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.SupportLibraries.DBConnection;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.mapper.api.ProfileAPI;
import com.test.mapper.api.ProfileV4API;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.EnvInfo;

import SupportLibraries.GlobalStaticInfo;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;


public class AmluContactAddreses {

    private static Logger logger = LogManager.getLogger();
    private Response response;
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries(); 
    private String coUserId = "";
    private String ssoId = "";
    boolean flag = false;
    private EnvInfo envInfo = EnvInfo.getInstance();
    String authorizationAmlu = envInfo.getAmluAuthorization();
    String authorization = envInfo.getAuthorization();
    ResultSet rs;

    @Given("^an endpoint that works exists for \"([^\"]*)\" API$")
    public void endpoint_that_works_exists_for_API(String serviceName) throws Throwable {
    	
    	 logger.info("Reached here");
         logger.info("In Given");
         logger.info("testService On-------------->:" + serviceName); 
         GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @Then("^an user sends the GET request to profile API with below parameters for V4$")
    public void user_sends_the_GET_request_with_coUserId_to_profile_API_with_below_parameters(DataTable parameters) throws Throwable {
       
    	logger.info("In Then");		
        
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestWithParams(parameters, authorizationAmlu);
        logger.info("Response :" + response.asString());       
	}
    
    @Then("^an user sends the GET request to profile API with below parameters for V3$")
    public void user_sends_the_GET_request_with_coUserId_to_profile_API_with_below_parameters_v3(DataTable parameters) throws Throwable {
       
    	logger.info("In Then");		
        
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileAPI ProfileAPI1 = new ProfileAPI();
        response = ProfileAPI1.getRequestWithParams(parameters,authorizationAmlu);
        logger.info("Response :" + response.asString());       
	}

    @Then("^user recieves correct response and is verified with db$")
    public void user_recieves_correct_responsebody_content_and_is_verified_with_db() throws Throwable {
		Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
		JsonObject responseObj = (JsonObject) new JsonParser().parse(response.asString());
		JsonArray profiles = responseObj.getAsJsonArray("profiles");
		for (int k = 0; k < profiles.size(); k++) {
			logger.info("Verifying the profile : "+(k+1));
			JsonObject profileObject = profiles.get(k).getAsJsonObject();
			Assert.assertTrue(profileObject.has("contactAddresses"),"Profile has contactAddresses section");
			logger.info("Profile has contactAddresses section");
			JsonArray contactAddressArray = new JsonArray();
			if(profileObject.has("contactAddresses")){
				Connection con = DBConnection.InitConnection();
				contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
				Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
				List<String> idDbArray = new ArrayList<>();
				List<String> idJsonArray = new ArrayList<>();
				String elm =null;
				logger.info("ContactAddressIds from JSON are:");
				for(int l=0;l<contactAddressArray.size();l++){
					elm = contactAddressArray.get(l).getAsJsonObject().get("contactAddressId").getAsString();
					idJsonArray.add(elm);
					logger.info(elm);
				}
				String que = "Select * from useraddress where couserid = '"+profileObject.get("coUserId").getAsString()+"' and deleted = 'N' order by USERADDRESSID asc";
				ResultSet res = DBConnection.execStatement(con,que);
				while(res.next()){
					elm = res.getString("USERADDRESSID");
					idDbArray.add(elm);
					logger.info(elm);
				}
				Collections.sort(idJsonArray);
				Assert.assertEquals(idDbArray,idJsonArray ,"ContactAddressIds is response JSON are same as in db");
				logger.info("ContactAddressIds in response JSON are same as in db");
				for(int j=0;j<contactAddressArray.size();j++){
					JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
					String query ="Select * from useraddress where USERADDRESSID = '"+contactAddressObject.get("contactAddressId").getAsString()+"'";
					rs = DBConnection.execStatement(con,query);
					while(rs.next()){
						for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
							if(!contAddressDBUserAddressElement.equalsIgnoreCase("DELETED")){
							if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).isJsonNull()){
							 Assert.assertEquals(rs.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
							 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs.getString(contAddressDBUserAddressElement));
							}
							else
								logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
							}
						}
					}
				}
			}
		}
	}
      
    @Then("^user recieves correct response without contactaddress$")
    public void user_recieves_correct_response_without_contactaddress() throws Throwable {
    	Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
		JsonObject responseObj = (JsonObject) new JsonParser().parse(response.asString());
		JsonArray profiles = responseObj.getAsJsonArray("profiles");
		for (int k = 0; k < profiles.size(); k++) {
			logger.info("Verifying the profile : "+(k+1));
			JsonObject profileObject = profiles.get(k).getAsJsonObject();
			Assert.assertFalse(profileObject.has("contactAddresses"),"Profile has no contactAddresses section");
			logger.info("Profile has no contactAddresses section");
		}
    }

}
