package com.ProfileV4;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.mapper.Mapper;
import com.test.mapper.api.ProfileAPI;
import com.test.mapper.api.ProfileV4API;
import com.test.mapper.pojos.COUser;
import com.test.mapper.pojos.ProfileV3Profile;
import com.test.mapper.pojos.ProfileV4Profile;
import com.test.mapper.pojos.UserContract;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.EnvInfo;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;


public class AmluInvestmentInfo {

    private static Logger logger = LogManager.getLogger();
    private Response response;
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries(); 
    private String coUserId = "";
    private String ssoId = "";
    boolean flag = false;
    private EnvInfo envInfo = EnvInfo.getInstance();
    String authorizationAmlu = envInfo.getAmluAuthorization();
    String authorization = envInfo.getAuthorization();

    @Given("^endpoint that works exists for \"([^\"]*)\" API$")
    public void endpoint_that_works_exists_for_API(String serviceName) throws Throwable {
    	
    	 logger.info("Reached here");
         logger.info("In Given");
         logger.info("testService On-------------->:" + serviceName);        
    }

    @Then("^user sends the GET request to profile API with below parameters for V4$")
    public void user_sends_the_GET_request_with_coUserId_to_profile_API_with_below_parameters(DataTable parameters) throws Throwable {
       
    	logger.info("In Then");		
        
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestWithParams(parameters, authorizationAmlu);
        logger.info("Response :" + response.asString());       
	}
    
    @Then("^user sends the GET request to profile API with below parameters for V3$")
    public void user_sends_the_GET_request_with_coUserId_to_profile_API_with_below_parameters_v3(DataTable parameters) throws Throwable {
       
    	logger.info("In Then");		
        
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileAPI ProfileAPI1 = new ProfileAPI();
        response = ProfileAPI1.getRequestWithParams(parameters,authorizationAmlu);
        logger.info("Response :" + response.asString());       
	}
    @Then("^user sends the GET request to profile API with below parameters for V4 with non amlu key$")
    public void user_sends_the_GET_request_to_profile_API_with_below_parameters_for_V4_with_non_amlu_key(DataTable parameters) throws Throwable {
    	
    	logger.info("In Then");		
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestWithParams(parameters, authorization);
        logger.info("Response :" + response.asString());
    }
    
    @Then("^user sends the GET request to profile API with below parameters for V3 with non amlu key$")
    public void user_sends_the_GET_request_to_profile_API_with_below_parameters_for_V3_with_non_amlu_key(DataTable parameters) throws Throwable {
    	logger.info("In Then");		
        
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        for(String paramName:paramNames){
        	if(paramName.equalsIgnoreCase("coUserId"))
        		coUserId=data.get(paramName);
        	else if(paramName.equalsIgnoreCase("ssoId")){
        		ssoId=data.get(paramName);
        		flag = true;}
        }
        ProfileAPI ProfileAPI1 = new ProfileAPI();
        response = ProfileAPI1.getRequestWithParams(parameters,authorization);
        logger.info("Response :" + response.asString());
    }

    @Then("^user recieves correct responsebody content and is verified with db for V4$")
    public void user_recieves_correct_responsebody_content_and_is_verified_with_db() throws Throwable {
    	ProfileV4Profile profileV4Get1 = new ProfileV4Profile(); 
    	Mapper mapper = new Mapper();
        mapper.loadJSON(response.prettyPrint(), profileV4Get1);
        JsonObject responseObj =  (JsonObject) new JsonParser().parse(response.asString());
        JsonArray profiles = responseObj.getAsJsonArray("profiles");
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(flag){
        	List<COUser> listFromCouser = applicationCommonQueries.getCoUserFromSsoId(ssoId);
        	coUserId = String.valueOf(listFromCouser.get(0).getCoUserId());}
    	List<UserContract> listFromUserContract = applicationCommonQueries.getUserContractFromCoUserId(coUserId);
		Assert.assertTrue(profiles.get(0).getAsJsonObject().has("amluInvestmentInfo"),"Profile has amluinvestmentInfo section");
		logger.info("Profile has amluinvestmentInfo section");
		if(listFromUserContract.isEmpty()){
			Assert.assertTrue(listFromUserContract.isEmpty(),"Usercontract table is empty");
			logger.info("Usercontract table is empty for the couserid");
		}
		else{
    		Assert.assertEquals(profileV4Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getEmployerIndustry().toString(),listFromUserContract.get(0).getEmployerIndustry().toString(),"EmployerIndustry is equal");
    		logger.info("EmployerIndustry is equal : value is " + listFromUserContract.get(0).getEmployerIndustry().toString());
    		Assert.assertEquals(profileV4Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getPaymentMethod().toString(),listFromUserContract.get(0).getCustomerPaymentMethod().toString(),"PaymentMethod is equal");
    		logger.info("PaymentMethod is equal : value is " + listFromUserContract.get(0).getCustomerPaymentMethod().toString());
    		Assert.assertEquals(profileV4Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getProductCashValue().toString(),listFromUserContract.get(0).getProductCashValue().toString(),"ProductCashValue is equal");
    		logger.info("ProductCashValue is equal : value is " + listFromUserContract.get(0).getProductCashValue().toString());
		}
    }
    
    @Then("^user recieves correct responsebody content and is verified with db for V3$")
    public void user_recieves_correct_responsebody_content_and_is_verified_with_db_for_v3() throws Throwable {
    	ProfileV3Profile profileV3Get1 = new ProfileV3Profile(); 
    	Mapper mapper = new Mapper();
        mapper.loadJSON(response.prettyPrint(), profileV3Get1);
        JsonObject responseObj =  (JsonObject) new JsonParser().parse(response.asString());
        JsonArray profiles = responseObj.getAsJsonArray("profiles");
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(flag){
        	List<COUser> listFromCouser = applicationCommonQueries.getCoUserFromSsoId(ssoId);
        	coUserId = String.valueOf(listFromCouser.get(0).getCoUserId());}
    	List<UserContract> listFromUserContract = applicationCommonQueries.getUserContractFromCoUserId(coUserId);
    	Assert.assertTrue(profiles.get(0).getAsJsonObject().has("amluInvestmentInfo"),"Profile has amluinvestmentInfo section");
		logger.info("Profile has amluinvestmentInfo section");
		if(listFromUserContract.isEmpty()){
			Assert.assertTrue(listFromUserContract.isEmpty(),"Usercontract table is empty");
			logger.info("Usercontract table is empty for the couserid");
		}
		else{    		
			Assert.assertEquals(profileV3Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getEmployerIndustry().toString(),listFromUserContract.get(0).getEmployerIndustry().toString(),"EmployerIndustry is equal");
    		logger.info("EmployerIndustry is equal : value is " + listFromUserContract.get(0).getEmployerIndustry().toString());
    		Assert.assertEquals(profileV3Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getPaymentMethod().toString(),listFromUserContract.get(0).getCustomerPaymentMethod().toString(),"PaymentMethod is equal");
    		logger.info("PaymentMethod is equal : value is " + listFromUserContract.get(0).getCustomerPaymentMethod().toString());
    		Assert.assertEquals(profileV3Get1.getProfiles()[0].getAmluInvestmentInfo()[0].getProductCashValue().toString(),listFromUserContract.get(0).getProductCashValue().toString(),"ProductCashValue is equal");
    		logger.info("ProductCashValue is equal : value is " + listFromUserContract.get(0).getProductCashValue().toString());
        }
    }
    
    @Then("^user recieves (\\d+) response code with invalid input parameters$")
    public void user_recieves_response_code_with_invalid_input_parameters(int responsecode) throws Throwable {
    	Assert.assertEquals(response.getStatusCode(), responsecode, "Response code 400  verified.");
    	Assert.assertTrue(response.getBody().asString().contains("Invalid Input Parameters"), "Error Response is verified.");
    }
    
    @Then("^user recieves responsebody content without amluinvestment for V4$")
    public void user_recieves_responsebody_content_without_amluinvestment_for_V4() throws Throwable {
    	ProfileV4Profile profileV4Get1 = new ProfileV4Profile(); 
    	Mapper mapper = new Mapper();
        mapper.loadJSON(response.prettyPrint(), profileV4Get1);
        JsonObject responseObj =  (JsonObject) new JsonParser().parse(response.asString());
        JsonArray profiles = responseObj.getAsJsonArray("profiles");
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(flag){
        	List<COUser> listFromCouser = applicationCommonQueries.getCoUserFromSsoId(ssoId);
        	coUserId = String.valueOf(listFromCouser.get(0).getCoUserId());}
        List<UserContract> listFromUserContract = applicationCommonQueries.getUserContractFromCoUserId(coUserId);
    		Assert.assertFalse(profiles.get(0).getAsJsonObject().has("amluInvestmentInfo"),"Profile has amluinvestmentInfo section");
    		logger.info("Profile has no amluinvestmentInfo section");
    		Assert.assertTrue(!listFromUserContract.isEmpty(),"Usercontract table is not empty");
    		logger.info("Usercontract table is not empty for the couserid");
    }
    
    @Then("^user recieves responsebody content without amluinvestment for V3$")
    public void user_recieves_responsebody_content_without_amluinvestment_for_V3() throws Throwable {
    	ProfileV3Profile profileV3Get1 = new ProfileV3Profile(); 
    	Mapper mapper = new Mapper();
        mapper.loadJSON(response.prettyPrint(), profileV3Get1);
        JsonObject responseObj =  (JsonObject) new JsonParser().parse(response.asString());
        JsonArray profiles = responseObj.getAsJsonArray("profiles");
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        if(flag){
        	List<COUser> listFromCouser = applicationCommonQueries.getCoUserFromSsoId(ssoId);
        	coUserId = String.valueOf(listFromCouser.get(0).getCoUserId());}
    	List<UserContract> listFromUserContract = applicationCommonQueries.getUserContractFromCoUserId(coUserId);
    	Assert.assertFalse(profiles.get(0).getAsJsonObject().has("amluInvestmentInfo"),"Profile has amluinvestmentInfo section");
		logger.info("Profile has amluinvestmentInfo section");
		Assert.assertTrue(!listFromUserContract.isEmpty(),"Usercontract table is not empty");
		logger.info("Usercontract table is not empty for the couserid");
    }


}
