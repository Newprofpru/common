package com.ProfileV4;

import com.test.mapper.api.ProfileV4API;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.*;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.EnvInfo;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import javax.validation.constraints.AssertTrue;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;

import static io.restassured.RestAssured.given;

public class ProfileProductionGet {

    private static Logger logger = LogManager.getLogger();
    private EnvInfo envInfo = EnvInfo.getInstance();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private Response response = null;
    private String User = "";
    private String Password = "";
    private LiteRegistration liteRegistration = new LiteRegistration();
    private SsoId sso = new SsoId();
    private ProfileV4Profile profileV4Profile = new ProfileV4Profile();
    private ProfileV4API profileV4API = new ProfileV4API();
    private Map<String, String> data;
    private String Service_Url = envInfo.getSecureURL();
    private Response Res1;
    private String Authorization = envInfo.getAuthorization();
    private RequestSpecification request;
    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();
    private String[] outString;

    @Given("^a endpoint that works exists for a production \"([^\"]*)\" API")
    public void a_working_endpoint_for_ProfileV4(String serviceName) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);

    }

    @Then("^a user sends the GET request with below parameters of a normal profile with user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void the_user_sends_a_GET_request_coUserId_to_profile_API_with_below_parameters_of_a_production_profile(String user, String password, DataTable parameters) throws IOException, IllegalAccessException, InvocationTargetException {

        Mapper mapper = new Mapper();
        data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        Random rand = new Random();
        int n = rand.nextInt(00450) + 12344;
        String requestID = "ProfileV4Get" + n;
        RestAssured.baseURI = Service_Url;
        String jwt = generateTokenUtils.getJWTAuthToken(user,password);
        logger.info("jwt " + jwt);
        request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0")
                .header("X-PruAuthJWT", jwt);
        for(String paramName:paramNames){
            request.param(paramName,data.get(paramName));
        }
        Res1 = request.when().get().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        logger.info(Res1.asString());
        mapper.loadJSON(Res1.prettyPrint(), profileV4Profile);
        Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
    }

}
