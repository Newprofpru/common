package com.ProfileV4;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.test.mapper.pojos.*;
import com.test.mapper.utils.EnvInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
public class ProfileV3Update {

    private static Logger logger = LogManager.getLogger();
    private EnvInfo envInfo = EnvInfo.getInstance();
    static RequestSpecification request;
    static String query=null;
    static String query2=null;
    static String contactChannelId=null;
    static Response Res1;
    String Service_Url = envInfo.getSecureURL();
    String Authorization = envInfo.getAuthorization();
    static String coUserId = null;
    static String contractId = null;
    String ssoid = null;
    String profileId = null;
    String requestID = null;

    boolean isNullNeeded = false;
    ProfileV4Profile profile = new ProfileV4Profile();
    PersonalInfo personalInfo = new PersonalInfo();
    Disclosures disclosures = new Disclosures();
    Suitability suitability = new Suitability();
    InvestmentInfo investmentInfo = new InvestmentInfo();
    TrustedContactPerson trustedContactPerson = new TrustedContactPerson();
    List<ContactChannels> contactChannels = new ArrayList<>();
    List<ContactAddresses> contactAddresses = new ArrayList<>();

    @Given("^a working valid endpoint exists for \"([^\"]*)\" API$")
    public void valid_endpoint_for_Profile_API(String serviceName) throws Throwable {
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);

    }

    @When("^the PUT request is sent to profile API with below request body data of Profile$")
    public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile(DataTable parameters) throws NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded = false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");

        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");

        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }


    @When("^the PUT request is sent to profile API with below request body data of Profile and with the authentication$")
    public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile_and_with_the_authentication(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded = false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("X-Forwarded-For", "0.0.0.0")
                .auth().basic(data.get("username"), data.get("password"));

        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @When("^the PUT request is sent to profile API with below request body data of Profile \"([^\"]*)\"$")
    public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details(String profileid) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded = false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        profileId = profileid;
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @When("^the PUT request is sent to profile API with below request body data of Profile by passing null for blank fields$")
    public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile_by_passing_null_for_blank_fields(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        isNullNeeded = true;
        Random rand = new Random();
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        GsonBuilder builder = new GsonBuilder();
        gson = builder.serializeNulls().create();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @When("^the PUT request is sent to profile API with below request body data of Profile by not passing blank fields$")
    public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile_by_not_passing_blank_fields(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        isNullNeeded = true;
        Random rand = new Random();
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }



    @When("^a PUT request is sent to profile API with below request body data to delete phone of Profile$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_phone_of_profile(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        List<ContactChannels> contactChannelsTest = new ArrayList<>();
        List<ContactChannels> contactChannelsTest1 = new ArrayList<>();
        List<String> contactChannelTypes = new ArrayList<>();
        String couserid=null,contractid=null;
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        Thread.sleep(1000);
    }

    @When("^a PUT request is sent to profile API with below request body data to delete phone of benefitclaim$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_phone_of_benefitclaim(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        Thread.sleep(1000);
    }

    @When("^a PUT request is sent to profile API with below request body data to delete email of Profile$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_email_of_profile(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @When("^a PUT request is sent to profile API with below request body data to delete email of benefitclaim$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_email_of_benefitclaim(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }


    @When("^a PUT request is sent to profile API with below request body data to delete address of Profile$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_address_of_profile(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @When("^a PUT request is sent to profile API with below request body data to delete userRelation of Profile$")
    public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_userRelation_of_profile(DataTable parameters) throws  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
        logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
        Random rand = new Random();
        isNullNeeded=false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "ProfileV3Update" + n;
        RestAssured.baseURI = Service_Url;
        Map<String, String> data = parameters.asMap(String.class, String.class);
        profileId = data.get("profile_id");
        request = given()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization)
                .header("X-Forwarded-For", "0.0.0.0");
        Gson gson = new Gson();
        String body = gson.toJson(profile);
        logger.info("body ----> "+body);
        Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
    }


    @Then("^the data is updated correctly and success response code 200 is recieved succesfully$")
    public void the_data_is_updated_and_success_response_code_200_is_recieved_successfully(){
        try{
            logger.info("\nIn--------------------> Then the data is updated and success response code 200 is recieved");
            Integer actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }

    @And("^the data is updated in db succesfully and verified$")
    public void the_data_is_updated_in_db_and_verified() throws SQLException, ParseException, InterruptedException,  NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
        Thread.sleep(100);
        logger.info("\nIn--------------------> And the data is updated in db");
    }

    @Then("^the user recieves the BAD_REQUEST response with correct error response code (\\d+)$")
    public void user_recieves_BAD_REQUEST_response_with_error_response_code(int responseCode)throws SQLException{
        try{
            logger.info("In Then");
            int actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode, responseCode, "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }

    @And("^a success message is logged in audit table for \"([^\"]*)\"$")
    public void The_success_message_is_logged_in_audit_table(String User) throws Throwable{
        logger.info("In -----> The success message is logged in audit table");
        String typeCode = "updateProfile";
        String Message = "Success";
    }

    @After
    public void afterScenarioExecution(Scenario scenario) {
        logger.info("Scenario: '" + scenario.getName() + "' has status " + scenario.getStatus());
    }


}
