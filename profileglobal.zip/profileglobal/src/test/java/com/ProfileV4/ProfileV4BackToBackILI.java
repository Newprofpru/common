package com.ProfileV4;

import com.test.mapper.Mapper;
import com.test.mapper.api.ProfileV4API;
import com.test.mapper.pojos.ProfileV4Profile;
import com.test.mapper.pojos.UserEventStatus;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

public class ProfileV4BackToBackILI {
    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private ProfileV4API ProfileV4API1 = new ProfileV4API();
    private Response response = null;

    private String User = "";
    private String Password = "";

    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();

    @Given("^back to back a working endpoint exists for \"([^\"]*)\" APIs and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void getWorkingEndpoint(String serviceName, String user, String password) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        User = user;
        Password = password;
        //GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @Then("^back to back GET for the updated Profile received successfully from APIs and then verified using \"([^\"]*)\"$")
    public void getProfileValidSso(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^back to back GET for the updated Profile gives 400 from APIs and then verified using \"([^\"]*)\"$")
    public void getProfileInvalidSso(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 400, "Response code 400 verified.");
    }

    @Then("^back to back Update to Profile is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateContactChannels(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactChannels(profileV4Update, 1, 0);
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^back to back Update to Contact Addresses in Profile is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateContactAddresses(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactAddresses(profileV4Update,1,0);
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^back to back Add in Profile is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\" and filename \"([^\"]*)\"$")
    public void addContactChannel(String ssoId, String user, String password, String filename) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.load("/PUT/" + filename, profileV4Update);
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^back to back Delete in Profile is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\" at \"([^\"]*)\"$")
    public void deleteContactChannel(String ssoId, String user, String password, String index) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        if(profileV4Update.getProfiles()[1].getContactChannels()[Integer.parseInt(index)].getContactChannelType().equals("Secondary")) {
            generateTokenUtils.deleteContactChannels(profileV4Update, 1, Integer.parseInt(index));
        }
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[1], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^back to back Refresh the updated Profile to get the latest values using \"([^\"]*)\"$")
    public void updateDatabase(String ssoId) throws InterruptedException {
        ProfileV4API profileV4API1 = new ProfileV4API();
        Thread.sleep(5000);
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
    }

    @Then("^back to back GET update using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileAssertUpdate(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        List<UserEventStatus> dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId());

        logger.info(dbResult);

        logger.info(ProfileV4API1.getRequestId());
        Assert.assertTrue(dbResult.get(0).getAction().equals("UPDATE"));
        Assert.assertTrue(dbResult.get(0).getEventStatusDescription().equals("INIT") || dbResult.get(0).getEventStatusDescription().equals("PENDING") || dbResult.get(0).getEventStatusDescription().equals("COMPLETED"));
    }

    @Then("^back to back GET add using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileAssertAdd(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        List<UserEventStatus> dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId());

        Assert.assertTrue(dbResult.get(0).getAction().equals("ADD"));
        Assert.assertTrue(dbResult.get(0).getEventStatusDescription().equals("INIT") || dbResult.get(0).getEventStatusDescription().equals("PENDING") || dbResult.get(0).getEventStatusDescription().equals("COMPLETED"));
    }

    @Then("^back to back GET delete using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileAssertDelete(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        List<UserEventStatus> dbResult = applicationCommonQueries.getUserEventStatus(ProfileV4API1.getRequestId());

        Assert.assertTrue(dbResult.get(0).getAction().equals("DELETE"));
        Assert.assertTrue(dbResult.get(0).getEventStatusDescription().equals("INIT") || dbResult.get(0).getEventStatusDescription().equals("PENDING") || dbResult.get(0).getEventStatusDescription().equals("COMPLETED"));
    }
}
