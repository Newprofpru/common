package com.ProfileV4;

import com.test.mapper.api.ProfileV4API;
import com.test.mapper.Mapper;
import com.test.mapper.pojos.ProfileV4Profile;
import com.test.mapper.pojos.UserAddress;
import com.test.mapper.pojos.UserContact;
import com.test.mapper.utils.ApplicationCommonQueries;
import com.test.mapper.utils.GenerateTokenUtils;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

public class ProfileV4Normal {

    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private Response response = null;

    private String User = "";
    private String Password = "";

    private int ContactChannelIndex;

    private ApplicationCommonQueries applicationCommonQueries = new ApplicationCommonQueries();

    @Given("^a working endpoint exists for \"([^\"]*)\" APIs for Contact Addresses and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void a_working_endpoint_for_ProfileV4_Contact_Address(String serviceName, String user, String password) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        User = user;
        Password = password;
        //GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @Given("^a working endpoint exists for \"([^\"]*)\" APIs for Contact Channels and user \"([^\"]*)\" and password \"([^\"]*)\" and contact channel index \"(\\d+)\"$")
    public void a_working_endpoint_for_ProfileV4_Contact_Channel(String serviceName, String user, String password, int contactChannelIndex) {

        logger.info("Reached here");
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        User = user;
        Password = password;
        ContactChannelIndex = contactChannelIndex;
        //GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @Then("^GET for the updated Profile received successfully from APIs and then verified using \"([^\"]*)\"$")
    public void getProfileV4UsingValidSsoILI(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^GET for the updated Profile gives 400 from APIs and then verified using \"([^\"]*)\"$")
    public void getProfileV4UsingInvalidSsoILI(String ssoId) {

        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 400, "Response code 400 verified.");
    }

    @Then("^the Update to Contact Channels is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateProfileV4ValidSsoILI(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactChannels(profileV4Update, 0, ContactChannelIndex);
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[0], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        response.prettyPrint();
        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^the Update to Contact Addresses in Profile is successful and success response code 200 is received from APIs and is then verified using \"([^\"]*)\" and user \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void updateProfileContactAddressesV4ValidSsoILI(String ssoId, String user, String password) throws IllegalAccessException, InvocationTargetException, IOException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);
        generateTokenUtils.updateContactAddresses(profileV4Update,0,0);
        ProfileV4API ProfileV4API1 = new ProfileV4API();
        response = ProfileV4API1.updateRequestWithParamsNormal(profileV4Update.getProfiles()[0], ssoId, user, password);
        logger.log(Level.INFO, "Response :" + response.asString());

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
    }

    @Then("^Refresh the updated Profile to get the latest values using \"([^\"]*)\"$")
    public void updateDatabase(String ssoId) throws InterruptedException {
        ProfileV4API profileV4API1 = new ProfileV4API();
        Thread.sleep(15000);
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
    }

    @Then("^GET for the updated Contact Channels received successfully from APIs and then verified using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileV4UsingValidSsoILIUpdated(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");
        String dbResult = applicationCommonQueries.getUserContactFromCoUserId(coUserId).toString();
        if(profileV4Update.getProfiles()[0].getContactChannels()[ContactChannelIndex].getContactChannel().equals("EMAIL")) {
            Assert.assertEquals(generateTokenUtils.email, profileV4Update.getProfiles()[0].getContactChannels()[ContactChannelIndex].getContactChannelValue());
            Assert.assertTrue(dbResult.contains(generateTokenUtils.email));
        } else if (profileV4Update.getProfiles()[0].getContactChannels()[ContactChannelIndex].getContactChannel().equals("PHONE")){
            Assert.assertEquals(generateTokenUtils.phone, profileV4Update.getProfiles()[0].getContactChannels()[ContactChannelIndex].getContactChannelValue());
            Assert.assertTrue(dbResult.contains(generateTokenUtils.phone));
        }
    }

    @Then("^GET for the updated Contact Addresses in Profile received successfully from APIs and then verified using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileContactAddressesV4UsingValidSsoILIUpdated(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");

        List<UserAddress> dbResult = applicationCommonQueries.getUserAddressFromCoUserId(coUserId);

        Assert.assertEquals(generateTokenUtils.indvAddress[0], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine1());
        Assert.assertEquals(generateTokenUtils.indvAddress[1], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine2());
        Assert.assertEquals(generateTokenUtils.indvAddress[2], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine3());
        Assert.assertEquals(generateTokenUtils.indvAddress[3], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCity());
        Assert.assertEquals(generateTokenUtils.indvAddress[4], profileV4Update.getProfiles()[0].getContactAddresses()[0].getState());
        Assert.assertEquals(generateTokenUtils.indvAddress[5], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCountry());
        Assert.assertEquals(generateTokenUtils.indvAddress[6], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipCode());
        Assert.assertEquals(generateTokenUtils.indvAddress[7], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipPlus4());

        Assert.assertTrue(dbResult.get(0).getAddressLine1().contains(generateTokenUtils.indvAddress[0]));
        Assert.assertTrue(dbResult.get(0).getAddressLine2().contains(generateTokenUtils.indvAddress[1]));
        Assert.assertTrue(dbResult.get(0).getAddressLine3().contains(generateTokenUtils.indvAddress[2]));
        Assert.assertTrue(dbResult.get(0).getCity().contains(generateTokenUtils.indvAddress[3]));
        Assert.assertTrue(dbResult.get(0).getState().contains(generateTokenUtils.indvAddress[4]));
        Assert.assertTrue(dbResult.get(0).getCountry().contains(generateTokenUtils.indvAddress[5]));
        Assert.assertTrue(dbResult.get(0).getZipCode().contains(generateTokenUtils.indvAddress[6]));
        Assert.assertTrue(dbResult.get(0).getZipCodeExtension().contains(generateTokenUtils.indvAddress[7]));
    }

    @Then("^GET for the updated Contact Addresses in Profile received successfully from APIs and then verified with requestID from db using \"([^\"]*)\" and \"([^\"]*)\" after update$")
    public void getProfileContactAddressesV4UsingValidSsoILIUpdatedRequestId(String ssoId, String coUserId) throws IllegalAccessException, InvocationTargetException, IOException, SQLException {
        ProfileV4Profile profileV4Update = new ProfileV4Profile();
        ProfileV4API profileV4API1 = new ProfileV4API();
        response = profileV4API1.getRequestSsoId(ssoId, User, Password);
        logger.log(Level.INFO, "Response :" + response.asString());
        Mapper mapper = new Mapper();

        mapper.loadJSON(response.prettyPrint(), profileV4Update);

        Assert.assertEquals(response.getStatusCode(), 200, "Response code 200  verified.");

        List<UserAddress> dbResult = applicationCommonQueries.getUserAddressFromCoUserId(coUserId);

        Assert.assertEquals(generateTokenUtils.indvAddress[0], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine1());
        Assert.assertEquals(generateTokenUtils.indvAddress[1], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine2());
        Assert.assertEquals(generateTokenUtils.indvAddress[2], profileV4Update.getProfiles()[0].getContactAddresses()[0].getAddressLine3());
        Assert.assertEquals(generateTokenUtils.indvAddress[3], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCity());
        Assert.assertEquals(generateTokenUtils.indvAddress[4], profileV4Update.getProfiles()[0].getContactAddresses()[0].getState());
        Assert.assertEquals(generateTokenUtils.indvAddress[5], profileV4Update.getProfiles()[0].getContactAddresses()[0].getCountry());
        Assert.assertEquals(generateTokenUtils.indvAddress[6], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipCode());
        Assert.assertEquals(generateTokenUtils.indvAddress[7], profileV4Update.getProfiles()[0].getContactAddresses()[0].getZipPlus4());

        Assert.assertTrue(dbResult.get(0).getAddressLine1().contains(generateTokenUtils.indvAddress[0]));
        Assert.assertTrue(dbResult.get(0).getAddressLine2().contains(generateTokenUtils.indvAddress[1]));
        Assert.assertTrue(dbResult.get(0).getAddressLine3().contains(generateTokenUtils.indvAddress[2]));
        Assert.assertTrue(dbResult.get(0).getCity().contains(generateTokenUtils.indvAddress[3]));
        Assert.assertTrue(dbResult.get(0).getState().contains(generateTokenUtils.indvAddress[4]));
        Assert.assertTrue(dbResult.get(0).getCountry().contains(generateTokenUtils.indvAddress[5]));
        Assert.assertTrue(dbResult.get(0).getZipCode().contains(generateTokenUtils.indvAddress[6]));
        Assert.assertTrue(dbResult.get(0).getZipCodeExtension().contains(generateTokenUtils.indvAddress[7]));
    }
}
