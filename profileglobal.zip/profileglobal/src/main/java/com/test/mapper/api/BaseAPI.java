package com.test.mapper.api;


import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * @author Aditya Jamwal
 */

abstract class BaseAPI<I> {

    private static String basePath = "";
    private static String port = "";
    private static String host = "";
    private static String protocol = "";

    public static String getBaseURI() {
        //return RestAssured.baseURI = "https://api-stage.prudential.com/co/stage/secure";
        return RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure";


    }

    abstract Response createRequest(I  inputRequest);
    abstract Response getRequest(String inputId);
    abstract Response updateRequest(I inputObject);
    


}

