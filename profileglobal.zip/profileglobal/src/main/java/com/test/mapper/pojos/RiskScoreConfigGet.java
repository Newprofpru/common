package com.test.mapper.pojos;

public class RiskScoreConfigGet {

    private RiskScoreConfig riskScoreConfig;

    public RiskScoreConfig getRiskScoreConfig() {
        return riskScoreConfig;
    }

    public void setRiskScoreConfig(RiskScoreConfig riskScoreConfig) {
        this.riskScoreConfig = riskScoreConfig;
    }

    @Override
    public String toString() {
        return "RiskScoreConfigGet [riskScoreConfig=" + riskScoreConfig + "]";
    }

}
