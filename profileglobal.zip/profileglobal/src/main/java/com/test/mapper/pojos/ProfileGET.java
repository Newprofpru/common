package com.test.mapper.pojos;

import java.util.Arrays;

public class ProfileGET {

    private String totalNumberOfProfiles;

    private Profiles[] profiles;

    private String responseStatus;

    private String responseCode;

    public String getTotalNumberOfProfiles() {
        return totalNumberOfProfiles;
    }

    public void setTotalNumberOfProfiles(String totalNumberOfProfiles) {
        this.totalNumberOfProfiles = totalNumberOfProfiles;
    }

    public Profiles[] getProfiles() {
        return profiles;
    }

    public void setProfiles(Profiles[] profiles) {
        this.profiles = profiles;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String toString() {
        return "Profile_GET [totalNumberOfProfiles=" + totalNumberOfProfiles + ", profiles=" + Arrays.toString(profiles)
                + ", responseStatus=" + responseStatus + ", responseCode=" + responseCode + "]";
    }

}
