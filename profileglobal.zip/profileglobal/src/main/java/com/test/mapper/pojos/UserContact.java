package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.COUser;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERCONTACT"
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class UserContact implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERCONTACTID",
            unique = true,
            nullable = false
    )
    private long userContactId;
    @Column(
            name = "BENEFITCLAIMID",
            length = 50
    )
    private String benefitClaimId;
    @Column(
            name = "BUCREATEDBY",
            length = 100
    )
    private String buCreatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "BUCREATEDDATE"
    )
    private Date buCreatedDate;
    @Column(
            name = "CONTACTCHANNELCODE",
            length = 20
    )
    private String contactChannelCode;
    @Column(
            name = "CONTACTSTATUSCODE",
            length = 20
    )
    private String contactStatusCode;
    @Column(
            name = "CONTACTTYPECODE",
            length = 20
    )
    private String contactTypeCode;
    @Column(
            name = "CONTACTVALUE",
            nullable = false,
            length = 250
    )
    private String contactValue;
    @Column(
            name = "CONTACTVERIFICATIONCD",
            length = 250
    )
    private String contactVerificationCd;
    @Column(
            name = "CONTRACTID",
            length = 30
    )
    private String contractId;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "EDELIVERYIND",
            nullable = false,
            length = 1
    )
    private String eDeliveryInd;
    @Column(
            name = "EMAILASUSERNAME",
            nullable = false,
            length = 1
    )
    private String emailAsUsername;
    @Column(
            name = "FILESETID"
    )
    private Long filesetId;
    @Column(
            name = "LINEOFBUSINESSCODE",
            length = 30
    )
    private String lineOfBusinessCode;
    @Column(
            name = "MARKETINGIND",
            nullable = false,
            length = 1
    )
    private String marketingInd;
    @Column(
            name = "MESSAGEFORMATCODE",
            length = 20
    )
    private String messageFormatCode;
    @Column(
            name = "PHONEEXTENSION",
            length = 10
    )
    private String phoneExtension;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @Column(
            name = "USERSOURCECODE",
            length = 20
    )
    private String userSourceCode;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser coUser;

    public UserContact() {
    }

    public long getUserContactId() {
        return this.userContactId;
    }

    public void setUserContactId(long userContactId) {
        this.userContactId = userContactId;
    }

    public String getBenefitClaimId() {
        return this.benefitClaimId;
    }

    public void setBenefitClaimId(String benefitClaimId) {
        this.benefitClaimId = benefitClaimId;
    }

    public String getBuCreatedBy() {
        return this.buCreatedBy;
    }

    public void setBuCreatedBy(String buCreatedBy) {
        this.buCreatedBy = buCreatedBy;
    }

    public Date getBuCreatedDate() {
        return this.buCreatedDate;
    }

    public void setBuCreatedDate(Date buCreatedDate) {
        this.buCreatedDate = buCreatedDate;
    }

    public String getContactChannelCode() {
        return this.contactChannelCode;
    }

    public void setContactChannelCode(String contactChannelCode) {
        this.contactChannelCode = contactChannelCode;
    }

    public String getContactStatusCode() {
        return this.contactStatusCode;
    }

    public void setContactStatusCode(String contactStatusCode) {
        this.contactStatusCode = contactStatusCode;
    }

    public String getContactTypeCode() {
        return this.contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getContactValue() {
        return this.contactValue;
    }

    public void setContactValue(String contactValue) {
        this.contactValue = contactValue;
    }

    public String getContactVerificationCd() {
        return this.contactVerificationCd;
    }

    public void setContactVerificationCd(String contactVerificationCd) {
        this.contactVerificationCd = contactVerificationCd;
    }

    public String getContractId() {
        return this.contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String geteDeliveryInd() {
        return this.eDeliveryInd;
    }

    public void seteDeliveryInd(String eDeliveryInd) {
        this.eDeliveryInd = eDeliveryInd;
    }

    public String getEmailAsUsername() {
        return this.emailAsUsername;
    }

    public void setEmailAsUsername(String emailAsUsername) {
        this.emailAsUsername = emailAsUsername;
    }

    public Long getFilesetId() {
        return this.filesetId;
    }

    public void setFilesetId(Long filesetId) {
        this.filesetId = filesetId;
    }

    public String getLineOfBusinessCode() {
        return this.lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getMarketingInd() {
        return this.marketingInd;
    }

    public void setMarketingInd(String marketingInd) {
        this.marketingInd = marketingInd;
    }

    public String getMessageFormatCode() {
        return this.messageFormatCode;
    }

    public void setMessageFormatCode(String messageFormatCode) {
        this.messageFormatCode = messageFormatCode;
    }

    public String getPhoneExtension() {
        return this.phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUserSourceCode() {
        return this.userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public com.test.mapper.pojos.COUser getCoUser() {
        return this.coUser;
    }

    public void setCoUser(COUser coUser) {
        this.coUser = coUser;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
