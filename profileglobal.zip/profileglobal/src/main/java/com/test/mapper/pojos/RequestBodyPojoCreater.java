package com.test.mapper.pojos;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;


import com.Profile.RequestBodyPojo.contactAddresses;
import com.Profile.RequestBodyPojo.contactAddressesV4;
import com.Profile.RequestBodyPojo.contactChannels;
import com.Profile.RequestBodyPojo.contactChannelsV4;
import com.Profile.RequestBodyPojo.disclosures;
import com.Profile.RequestBodyPojo.employers;
import com.Profile.RequestBodyPojo.investmentInfo;
import com.Profile.RequestBodyPojo.personalInfo;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.RequestBodyPojo.profileV4;
import com.Profile.RequestBodyPojo.suitability;
import com.Profile.RequestBodyPojo.trustedContactPerson;
import com.Profile.RequestBodyPojo.userRelations;
import com.test.mapper.pojos.*;
import com.test.mapper.utils.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class RequestBodyPojoCreater {
	static String path = System.getProperty("user.dir")+Util.getFileSeparator()+"src"+Util.getFileSeparator()+"test"+Util.getFileSeparator()+"java"+Util.getFileSeparator()+"com"+Util.getFileSeparator()+"Profile"+Util.getFileSeparator()+"RequestBodyPojo"+Util.getFileSeparator()+"TestData.xlsx";
	static String Service_Url = getEnvInfo.getSecureURL();
	public static String contact;
	public static String Email;
	public static profileV4 getProfile(String profile_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		
		Method method;
		profileV4 profile1 = new profileV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("profileV4");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("profile_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(profile_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("profile_id")&&!(cellValue2.isEmpty())){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("profile_id")){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
		
			if((cellValue1.equalsIgnoreCase("personalInfo"))&&!(cellValue2.isEmpty())){
				profile1.setpersonalInfo(getpersonalInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("disclosures"))&&!(cellValue2.isEmpty())){
				profile1.setdisclosures(getdisclosures(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("suitability"))&&!(cellValue2.isEmpty())){
				profile1.setsuitability(getsuitability(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("investmentInfo"))&&!(cellValue2.isEmpty())){
				profile1.setinvestmentInfo(getinvestmentInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("trustedContactPerson"))&&!(cellValue2.isEmpty())){
				profile1.settrustedContactPerson(gettrustedContactPerson(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("contactAddresses"))&&!(cellValue2.isEmpty())){
				String[] addrList = cellValue2.split(",");
				List<contactAddressesV4> temp = new ArrayList<>();
				for(String addr : addrList){
					temp.add(getcontactAddresses(addr,isNullNeeded));
				}
				profile1.setcontactAddresses(temp);
			}
			if((cellValue1.equalsIgnoreCase("contactChannels"))&&!(cellValue2.isEmpty())){
				String[] contList = cellValue2.split(",");
				List<contactChannelsV4> temp = new ArrayList<>();
				for(String cont : contList){
					temp.add(getcontactChannels(cont,isNullNeeded));
				}
				profile1.setcontactChannels(temp);
			}
			
		}
		return profile1;
	}
	

	
	
public static personalInfo getpersonalInfo(String personalInfo_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		personalInfo personalInfo1 = new personalInfo();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("personalInfo");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("personalInfo_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(personalInfo_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("personalInfo_id")&&!(cellValue2.isEmpty())){
					method = personalInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(personalInfo1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("personalInfo_id")){
					method = personalInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(personalInfo1, cellValue2);
				}
			}
		}
		return personalInfo1;
	}
	
	public static suitability getsuitability(String suitability_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		suitability suitability1 = new suitability();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("suitability");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("suitability_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(suitability_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
					if(!cellValue1.equalsIgnoreCase("suitability_id")&&!(cellValue2.isEmpty())){
					method = suitability1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(suitability1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("suitability_id")){
				method = suitability1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
				method.invoke(suitability1, cellValue2);
			}
		}
		}
		return suitability1;
	}
	
	public static trustedContactPerson gettrustedContactPerson(String trustedContactPerson_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		trustedContactPerson trustedContactPerson1 = new trustedContactPerson();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("trustedContactPerson");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("trustedContactPerson_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(trustedContactPerson_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("trustedContactPerson_id")&&!(cellValue2.isEmpty())){
					method = trustedContactPerson1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(trustedContactPerson1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("trustedContactPerson_id")){
					method = trustedContactPerson1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(trustedContactPerson1, cellValue2);
				}
			}
		}
		return trustedContactPerson1;
	}
	
	public static disclosures getdisclosures(String disclosures_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		disclosures disclosures1 = new disclosures();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("disclosures");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("disclosures_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(disclosures_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("disclosures_id")&&!(cellValue2.isEmpty())){
					method = disclosures1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(disclosures1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("disclosures_id")){
					method = disclosures1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(disclosures1, cellValue2);
				}
			}
		}
		return disclosures1;
	}
	
	public static investmentInfo getinvestmentInfo(String investmentInfo_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		investmentInfo investmentInfo1 = new investmentInfo();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("investmentInfo");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("investmentInfo_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(investmentInfo_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("investmentInfo_id")&&!(cellValue2.isEmpty())){
					method = investmentInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(investmentInfo1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("investmentInfo_id")){
					method = investmentInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(investmentInfo1, cellValue2);
				}
			}
		}
		return investmentInfo1;
	}
	
	public static contactAddressesV4 getcontactAddresses(String contactAddresses_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		Method method;
		contactAddressesV4 contactAddresses1 = new contactAddressesV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactAddressesV4");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("contactAddresses_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(contactAddresses_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			List<String> boolean_fields = new ArrayList() {{
		        add("isUpdated");
		        add("isDeleted");
		        add("isEditable");
		    }};
		if(boolean_fields.contains(cellValue1)&&!(cellValue2.isEmpty())){
			
			method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, boolean.class);
			method.invoke(contactAddresses1, Boolean.parseBoolean(cellValue2));
		}
			if(isNullNeeded&&!boolean_fields.contains(cellValue1)){
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")&&!(cellValue2.isEmpty())){
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")&&!boolean_fields.contains(cellValue1)){
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
		}
		return contactAddresses1;
	}
	
	
	
	public static contactChannelsV4 getcontactChannels(String contactChannels_id, boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Method method;
		contactChannelsV4 contactChannels1 = new contactChannelsV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactChannelsV4");
		int rownum = 0, colnum = 0, i = -1, j = -1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			i++;
			if (i == 0) {
				while (cellIterator.hasNext()) {
					j++;
					Cell cell = cellIterator.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					if (cellValue.equalsIgnoreCase("contactChannels_id"))
						colnum = j;
				}
			} else {
				Cell cell = row.getCell(colnum);
				String temp = dataFormatter.formatCellValue(cell);
				if (temp.equalsIgnoreCase(contactChannels_id)) {
					rownum = i;
				}
			}
		}
		Row row1 = sheet.getRow(0);
		Row row2 = sheet.getRow(rownum);
		for (int k = 1; k < row1.getLastCellNum(); k++) {
			Cell cell1 = row1.getCell(k);
			Cell cell2 = row2.getCell(k);
			String cellValue1 = dataFormatter.formatCellValue(cell1);
			String cellValue2 = dataFormatter.formatCellValue(cell2);
			List<String> boolean_fields = new ArrayList() {
				{
					add("isUpdated");
					add("isDeleted");
					add("isEditable");
				}
			};

			if (!cellValue1.equalsIgnoreCase("contactChannels_id")) {

				if (boolean_fields.contains(cellValue1) && !(cellValue2.isEmpty())) {

					method = contactChannels1.getClass().getDeclaredMethod("set" + cellValue1, boolean.class);
					method.invoke(contactChannels1, Boolean.parseBoolean(cellValue2));
				}

				if (isNullNeeded && !boolean_fields.contains(cellValue1)) {
					if (!cellValue1.equalsIgnoreCase("contactChannels_id") && !(cellValue2.isEmpty())) {
						Random rand = new Random();
						if (cellValue2.equalsIgnoreCase("RandomEmail")) {
							cellValue2 = "testEmail" + rand.ints(10, 111111, 999999).findFirst().getAsInt() + "@test.com";
						} else if (cellValue2.equalsIgnoreCase("RandomPhone")) {
							cellValue2 = "" + rand.longs(10, 1111111111L, 9999999999L).findFirst().getAsLong();
						}
						method = contactChannels1.getClass().getDeclaredMethod("set" + cellValue1, String.class);
						method.invoke(contactChannels1, cellValue2);
					}
				} else {
					if (!cellValue1.equalsIgnoreCase("contactChannels_id") && !boolean_fields.contains(cellValue1)) {
						Random rand = new Random();
						if (cellValue2.equalsIgnoreCase("RandomEmail")) {
							cellValue2 = "testEmail" + rand.ints(10, 111111, 999999).findFirst().getAsInt() + "@test.com";

						} else if (cellValue2.equalsIgnoreCase("RandomPhone")) {
							cellValue2 = "" + rand.longs(10, 1111111111L, 9999999999L).findFirst().getAsLong();
						}
						method = contactChannels1.getClass().getDeclaredMethod("set" + cellValue1, String.class);
						method.invoke(contactChannels1, cellValue2);
					}
				}
			}

		}
		return contactChannels1;
	}
	
public static userRelations getuserRelations(String userRelations_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		userRelations userRelations1 = new userRelations();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("userRelations");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("userRelations_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(userRelations_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("userRelations_id")&&!(cellValue2.isEmpty())){
					method = userRelations1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(userRelations1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("userRelations_id")){
					method = userRelations1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(userRelations1, cellValue2);
				}
			}
		}
		return userRelations1;
	}
	
	public static employers getemployers(String employers_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		employers employers1 = new employers();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("employers");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("employers_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(employers_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("employers_id")&&!(cellValue2.isEmpty())){
					method = employers1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(employers1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("employers_id")){
					method = employers1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(employers1, cellValue2);
				}
			}
		}
		return employers1;
	}

}

