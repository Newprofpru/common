package com.test.mapper.pojos;

import java.util.List;

public class Profile {

    private List<ContactAddresses> contactAddresses;

    private String ssoId;

    private PersonalInfo personalInfo;
    
    private String deleted;

    private String businessUnit;

    private Suitability suitability;

    private String contractId;

    private String relationshipToAccount;

    private List<ContactChannels> contactChannels;

    private String coUserId;

    private String responseStatus;

    private String responseCode;
    
    private AmluInvestmentInfo[] amluInvestmentInfo;    

	public List<ContactAddresses> getContactAddresses() {
        return contactAddresses;
    }

    public void setContactAddresses(List<ContactAddresses> contactAddresses) {
        this.contactAddresses = contactAddresses;
    }

    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    public PersonalInfo getPersonalInfo() {
        return personalInfo;
    }

    public void setPersonalInfo(PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public Suitability getSuitability() {
        return suitability;
    }

    public void setSuitability(Suitability suitability) {
        this.suitability = suitability;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getRelationshipToAccount() {
        return relationshipToAccount;
    }

    public void setRelationshipToAccount(String relationshipToAccount) {
        this.relationshipToAccount = relationshipToAccount;
    }

    public List<ContactChannels> getContactChannels() {
        return contactChannels;
    }

    public void setContactChannels(List<ContactChannels> contactChannels) {
        this.contactChannels = contactChannels;
    }

    public String getCoUserId() {
        return coUserId;
    }

    public void setCoUserId(String coUserId) {
        this.coUserId = coUserId;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    } 
    
    public AmluInvestmentInfo[] getAmluInvestmentInfo() {
		return amluInvestmentInfo;
	}

	public void setAmluInvestmentInfo(AmluInvestmentInfo[] amluInvestmentInfo) {
		this.amluInvestmentInfo = amluInvestmentInfo;
	}
    
    @Override
    public String toString() {
        return "Profile [contactAddresses=" + contactAddresses + ", ssoId=" + ssoId + ", personalInfo="
                + personalInfo + ", deleted=" + deleted + ", businessUnit=" + businessUnit + ", suitability="
                + suitability + ", contractId=" + contractId + ", relationshipToAccount=" + relationshipToAccount
                + ", contactChannels=" + contactChannels + ", coUserId=" + coUserId + ", responseStatus="
                + responseStatus + ", responseCode=" + responseCode + ", amluInvestmentInfo=" + amluInvestmentInfo + "]";
    }


}
