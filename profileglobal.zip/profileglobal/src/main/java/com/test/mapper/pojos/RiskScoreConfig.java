package com.test.mapper.pojos;

public class RiskScoreConfig {

    private Product product;

    private Demography demography;

    private HighRiskThreshold highRiskThreshold;

    private Reputation reputation;

    private SourceOfFunds sourceOfFunds;

    private String type;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Demography getDemography() {
        return demography;
    }

    public void setDemography(Demography demography) {
        this.demography = demography;
    }

    public HighRiskThreshold getHighRiskThreshold() {
        return highRiskThreshold;
    }

    public void setHighRiskThreshold(HighRiskThreshold highRiskThreshold) {
        this.highRiskThreshold = highRiskThreshold;
    }

    public Reputation getReputation() {
        return reputation;
    }

    public void setReputation(Reputation reputation) {
        this.reputation = reputation;
    }

    public SourceOfFunds getSourceOfFunds() {
        return sourceOfFunds;
    }

    public void setSourceOfFunds(SourceOfFunds sourceOfFunds) {
        this.sourceOfFunds = sourceOfFunds;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "RiskScoreConfig [product=" + product + ", demography=" + demography + ", highRiskThreshold="
                + highRiskThreshold + ", reputation=" + reputation + ", sourceOfFunds=" + sourceOfFunds + ", type="
                + type + "]";
    }


}
