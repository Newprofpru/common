package com.test.mapper.pojos;

import java.util.List;
import java.util.Map;

public class Demography {

    private Map<String, String> beneOwnersPercent;

    private List<Industry> industry;

    private Map<String, String> beneOwnersNameAddress;

    private Map<String, String> typeCode;

    public Map<String, String> getBeneOwnersPercent() {
        return beneOwnersPercent;
    }

    public void setBeneOwnersPercent(Map<String, String> beneOwnersPercent) {
        this.beneOwnersPercent = beneOwnersPercent;
    }

    public List<Industry> getIndustry() {
        return industry;
    }

    public void setIndustry(List<Industry> industry) {
        this.industry = industry;
    }

    public Map<String, String> getBeneOwnersNameAddress() {
        return beneOwnersNameAddress;
    }

    public void setBeneOwnersNameAddress(Map<String, String> beneOwnersNameAddress) {
        this.beneOwnersNameAddress = beneOwnersNameAddress;
    }

    public Map<String, String> getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(Map<String, String> typeCode) {
        this.typeCode = typeCode;
    }

    @Override
    public String toString() {
        return "Demography [beneOwnersPercent=" + beneOwnersPercent + ", industry=" + industry
                + ", beneOwnersNameAddress=" + beneOwnersNameAddress + ", typeCode=" + typeCode + "]";
    }
}
