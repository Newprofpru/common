package com.test.mapper.pojos;

public class AmluInvestmentInfo {

	private String employerIndustry;

    private String paymentMethod;

    private String productCashValue;

    public String getEmployerIndustry() {
		return employerIndustry;
	}

	public void setEmployerIndustry(String employerIndustry) {
		this.employerIndustry = employerIndustry;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getProductCashValue() {
		return productCashValue;
	}

	public void setProductCashValue(String productCashValue) {
		this.productCashValue = productCashValue;
	}

	@Override
    public String toString() {
        return "AmluInvestmentInfo [employerIndustry=" + employerIndustry + ", paymentMethod=" + paymentMethod + ", productCashValue=" + productCashValue + "]";
    }


}
