package com.test.mapper.pojos;

import java.util.Map;

public class Reputation {

    private Map<String, String> beneMarijuana;

    private Map<String, String> beneOFAC;

    private Map<String, String> transactionMedia;

    private Map<String, String> adverseMedia;

    private Map<String, String> sar;

    private Map<String, String> beneAdverseMedia;

    private Map<String, String> marijuana;

    private Map<String, String> benePFC;

    private Map<String, String> localSanctions;

    private Map<String, String> pfc;

    private Map<String, String> ofac;

    public Map<String, String> getBeneMarijuana() {
        return beneMarijuana;
    }

    public void setBeneMarijuana(Map<String, String> beneMarijuana) {
        this.beneMarijuana = beneMarijuana;
    }

    public Map<String, String> getBeneOFAC() {
        return beneOFAC;
    }

    public void setBeneOFAC(Map<String, String> beneOFAC) {
        this.beneOFAC = beneOFAC;
    }

    public Map<String, String> getTransactionMedia() {
        return transactionMedia;
    }

    public void setTransactionMedia(Map<String, String> transactionMedia) {
        this.transactionMedia = transactionMedia;
    }

    public Map<String, String> getAdverseMedia() {
        return adverseMedia;
    }

    public void setAdverseMedia(Map<String, String> adverseMedia) {
        this.adverseMedia = adverseMedia;
    }

    public Map<String, String> getSar() {
        return sar;
    }

    public void setSar(Map<String, String> sar) {
        this.sar = sar;
    }

    public Map<String, String> getBeneAdverseMedia() {
        return beneAdverseMedia;
    }

    public void setBeneAdverseMedia(Map<String, String> beneAdverseMedia) {
        this.beneAdverseMedia = beneAdverseMedia;
    }

    public Map<String, String> getMarijuana() {
        return marijuana;
    }

    public void setMarijuana(Map<String, String> marijuana) {
        this.marijuana = marijuana;
    }

    public Map<String, String> getBenePFC() {
        return benePFC;
    }

    public void setBenePFC(Map<String, String> benePFC) {
        this.benePFC = benePFC;
    }

    public Map<String, String> getLocalSanctions() {
        return localSanctions;
    }

    public void setLocalSanctions(Map<String, String> localSanctions) {
        this.localSanctions = localSanctions;
    }

    public Map<String, String> getPfc() {
        return pfc;
    }

    public void setPfc(Map<String, String> pfc) {
        this.pfc = pfc;
    }

    public Map<String, String> getOfac() {
        return ofac;
    }

    public void setOfac(Map<String, String> ofac) {
        this.ofac = ofac;
    }

    @Override
    public String toString() {
        return "Reputation [beneMarijuana=" + beneMarijuana + ", beneOFAC=" + beneOFAC + ", transactionMedia="
                + transactionMedia + ", adverseMedia=" + adverseMedia + ", sar=" + sar + ", beneAdverseMedia="
                + beneAdverseMedia + ", marijuana=" + marijuana + ", benePFC=" + benePFC + ", localSanctions="
                + localSanctions + ", pfc=" + pfc + ", ofac=" + ofac + "]";
    }
}
