package com.test.mapper.pojos;

public class ContactChannels {

    private String contactChannel;

    private String editableReasonCode;

    private String contactChannelType;

    private String contactStatus;

    private String isEditable;

    private String isDeleted;

    private String editableReasonDescription;

    private String phoneExtension;

    private String eventStatus;

    private String isUpdated;

    private String contactChannelValue;

    private String contactChannelId;

    public String getContactChannel() {
        return contactChannel;
    }

    public void setContactChannel(String contactChannel) {
        this.contactChannel = contactChannel;
    }

    public String getEditableReasonCode() {
        return editableReasonCode;
    }

    public void setEditableReasonCode(String editableReasonCode) {
        this.editableReasonCode = editableReasonCode;
    }

    public String getContactChannelType() {
        return contactChannelType;
    }

    public void setContactChannelType(String contactChannelType) {
        this.contactChannelType = contactChannelType;
    }

    public String getContactStatus() {
        return contactStatus;
    }

    public void setContactStatus(String contactStatus) {
        this.contactStatus = contactStatus;
    }

    public String getIsEditable() {
        return isEditable;
    }

    public void setIsEditable(String isEditable) {
        this.isEditable = isEditable;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getEditableReasonDescription() {
        return editableReasonDescription;
    }

    public void setEditableReasonDescription(String editableReasonDescription) {
        this.editableReasonDescription = editableReasonDescription;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(String eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getIsUpdated() {
        return isUpdated;
    }

    public void setIsUpdated(String isUpdated) {
        this.isUpdated = isUpdated;
    }

    public String getContactChannelValue() {
        return contactChannelValue;
    }

    public void setContactChannelValue(String contactChannelValue) {
        this.contactChannelValue = contactChannelValue;
    }

    public String getContactChannelId() {
        return contactChannelId;
    }

    public void setContactChannelId(String contactChannelId) {
        this.contactChannelId = contactChannelId;
    }

    @Override
    public String toString() {
        return "ContactChannels [contactChannel=" + contactChannel + ", editableReasonCode=" + editableReasonCode
                + ", contactChannelType=" + contactChannelType + ", contactStatus=" + contactStatus + ", isEditable="
                + isEditable + ", isDeleted=" + isDeleted + ", editableReasonDescription=" + editableReasonDescription
                + ", phoneExtension=" + phoneExtension + ", eventStatus=" + eventStatus + ", isUpdated=" + isUpdated
                + ", contactChannelValue=" + contactChannelValue + ", contactChannelId=" + contactChannelId + "]";
    }

}
