package com.test.mapper.utils;

import static io.restassured.RestAssured.given;

import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.test.mapper.pojos.LiteRegistration;
import com.test.mapper.pojos.ProfileV4Profile;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GenerateTokenUtils {

	private Logger logger = LogManager.getLogger();

	private EnvInfo envInfo = EnvInfo.getInstance();

	String URL = envInfo.getSecureUrlSMSession();
	String LiteRegistrationUrl = envInfo.getLiteRegistrationUrl();
	String authorization = envInfo.getAuthorizationSMSESSION();
	String authorizationLite = envInfo.getAuthorizationLiteRegistration();
	public String email = "";
	public String phone = "";
	public String indvAddress[];
	RequestSpecification request1;
	String payload1;
	Response Res1;
	protected Response response;
	String resultbody = "";
	private String XPruAuthJWT = null;
	Map<String, String> cookie_Data = new HashMap<String, String>();
	protected RequestSpecification request;
	Map<String, String> cookies = new HashMap<>();
	Random rand = new Random();

	public String generateSmsessionToken(String userid, String password) {

		try {
			request1 = given().log().all().header("Authorization", authorization).header("Content-Type",
					"application/json");
			cookie_Data.put("userid", userid);
			cookie_Data.put("password", password);
			cookie_Data.put("buidtype", "INDV");
			ObjectMapper mapper = new ObjectMapper();

			//payload1 = mapper.writeValueAsString(Reputation_payload(cookie_Data));
			Res1 = request1.log().all().body(payload1).contentType(ContentType.JSON).post(URL).andReturn();

			JsonPath sessionres = new JsonPath(Res1.asString());

			resultbody = sessionres.getString("message");
			logger.info("SMSESSION Token ======>" + resultbody);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultbody;
	}

	public Response createLiteRegistration(LiteRegistration liteRegistration){
		return given().log().all().header("Authorization", authorizationLite).header("Content-Type","application/json").body(liteRegistration).post(LiteRegistrationUrl).andReturn();
	}

	public String getJWTAuthToken(String userId, String password) {

		try {
			request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
					.formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
					.formParam("smauthreason", "").formParam("smagentname", "ssologin");

			response = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();

			cookies = response.getCookies();
			logAllure("Cookies", cookies.toString());
			logger.info("response-cookies :" + cookies);

			request = given().log().all().cookies(cookies);

			response = request.get("https://api-dev.prudential.com/.signjwt").andReturn();

			JsonPath jp = new JsonPath(response.asString());

			XPruAuthJWT = jp.getString("jwt");

			logger.info("Prospect JWT Toknen is :" + XPruAuthJWT);

			logAllure("UserId", userId);

			logAllure("JWT", XPruAuthJWT);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return XPruAuthJWT;

	}

	public String generateUserId(){
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		email = "joseph"+n;
		return email;
	}

	public String generateEmailAddress(){
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		email = "JOSEPH.WALLACE"+n+"@PRUDENTIAL.COM";
		return email;
	}

	public String generatePhoneNumber(){
		int n = rand.ints(5,111111111,999999999).findFirst().getAsInt();
		phone = "1"+n;
		return phone;
	}

	public String[] generateAddressLine(){

		String fullAddress[] = {"7836,TALBOT,AVE,RIDGEWOOD,NJ,USA,07450,1111", "69,S MAIN,AVE,CLAYTON,NC,USA,27520,2222",
				"57,NORTH HALL,ROAD,FLUSHING,NY,USA,11354,3333", "8883,WOODSMAN,AVENUE,WATERLOO,IA,USA,50701,4444",
				"877,NICHOLS,DR,GAITHERSBURG,MD,USA,20877,5555", "280,EAST,THEATRE AVE,COLUMBUS,GA,USA,31904,6666"};

		int n = rand.ints(2, 0, 5).findFirst().getAsInt();

		indvAddress = fullAddress[n].split(",");
		return indvAddress;
	}

	public void deleteContactChannels(ProfileV4Profile profile, int getProfileIndex, int getContactChannelsIndex){
		profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setIsDeleted("true");
	}

	public void updateContactChannels(ProfileV4Profile profile, int getProfileIndex, int getContactChannelsIndex){
		if(profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].getContactChannel().equals("EMAIL")) {
			if(profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].getContactChannelValue().equals("aravind.sambamoorthy@prudential.com")) {
				profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setContactChannelValue("deepak.kapdi001@prudential.com");
				email = "deepak.kapdi001@prudential.com";
			} else {
				profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setContactChannelValue("aravind.sambamoorthy@prudential.com");
				email = "aravind.sambamoorthy@prudential.com";
			}
			profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setIsUpdated("true");
		} else if (profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].getContactChannel().equals("PHONE")){
			profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setContactChannelValue(generatePhoneNumber());
			profile.getProfiles()[getProfileIndex].getContactChannels()[getContactChannelsIndex].setIsUpdated("true");
		}
	}

	public void updateContactAddresses(ProfileV4Profile profile, int getProfileIndex, int getContactAddressesIndex){
		String[]individualAddress = generateAddressLine();
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setAddressLine1(individualAddress[0]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setAddressLine2(individualAddress[1]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setAddressLine3(individualAddress[2]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setCity(individualAddress[3]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setState(individualAddress[4]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setCountry(individualAddress[5]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setZipCode(individualAddress[6]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setZipPlus4(individualAddress[7]);
		profile.getProfiles()[getProfileIndex].getContactAddresses()[getContactAddressesIndex].setIsUpdated("true");
	}

	public void logAllure(String name, String content) {

		// Allure.addAttachment(name, content);
	}
}