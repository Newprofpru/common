package com.test.mapper.pojos;

public class Tractor {
    private int modelYear;
    private int maxSpeed;
    private int noOfwheels;
    private String tractor;

    public int getModelYear() {
        return modelYear;
    }

    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getNoOfwheels() {
        return noOfwheels;
    }

    public void setNoOfwheels(int noOfwheels) {
        this.noOfwheels = noOfwheels;
    }

    public String getTractor() {
        return tractor;
    }

    public void setTractor(String tractor) {
        this.tractor = tractor;
    }

    @Override
    public String toString() {
        return "Tractor [modelYear=" + modelYear + ", maxSpeed=" + maxSpeed + ", noOfwheels=" + noOfwheels
                + ", tractor=" + tractor + "]";
    }
}
