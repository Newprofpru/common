package com.test.mapper.pojos;

public class ContactAddresses {

    private String country;

    private String zipCode;

    private String city;

    private String addressType;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String state;

    private String addressLine4;

    private String contactAddressId;

    private String zipPlus4;

    private String isUpdated;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getContactAddressId() {
        return contactAddressId;
    }

    public void setContactAddressId(String contactAddressId) {
        this.contactAddressId = contactAddressId;
    }

    public String getZipPlus4() {
        return zipPlus4;
    }

    public void setZipPlus4(String zipPlus4) {
        this.zipPlus4 = zipPlus4;
    }

    public String getIsUpdated() {
        return isUpdated;
    }

    public void setIsUpdated(String isUpdated) {
        this.isUpdated = isUpdated;
    }

    @Override
    public String toString() {
        return "ContactAddresses [country=" + country + ", zipCode=" + zipCode + ", city=" + city + ", addressType="
                + addressType + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", addressLine3="
                + addressLine3 + ", state=" + state + ", addressLine4=" + addressLine4 + ", contactAddressId="
                + contactAddressId + ", zipPlus4=" + zipPlus4 + "]";
    }

}
