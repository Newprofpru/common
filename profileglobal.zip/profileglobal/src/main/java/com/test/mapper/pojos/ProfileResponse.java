package com.test.mapper.pojos;

public class ProfileResponse {


    private String ssoId;

    private String coUserId;

    private String responseStatus;

    private String responseCode;

    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    public String getCoUserId() {
        return coUserId;
    }

    public void setCoUserId(String coUserId) {
        this.coUserId = coUserId;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String toString() {
        return "ClassPojo [ssoId = " + ssoId + ", coUserId = " + coUserId + ", responseStatus = " + responseStatus + ", responseCode = " + responseCode + "]";
    }
}


