package com.test.mapper.utils;

import java.sql.SQLException;
import java.util.List;

import com.test.mapper.pojos.COUser;
import com.test.mapper.pojos.UserAddress;
import com.test.mapper.pojos.UserContact;
import com.test.mapper.pojos.UserContract;
import com.test.mapper.pojos.UserContractProfile;
import com.test.mapper.pojos.UserEventStatus;
import com.test.mapper.pojos.UserRelation;

public class ApplicationCommonQueries {

	private static final String COUSER_FROM_COUSERID = "select * from couser where couserid = ?";
	private static final String COUSER_FROM_SSOID = "select * from couser where ssoId = ?";
	private static final String USERADDRESS_FROM_COUSERID = "select * from useraddress where couserid = ?";
	private static final String USERADDRESS_FROM_COUSERID_ADDRESSTYPECODE = "select * from useraddress where couserid = ? and ADDRESSTYPECODE ?";
	private static final String USERADDRESS_FROM_COUSERID_CONTACTID_CONTACTADDRESSTYPE = "select * from useraddress where couserid = ? and contractid = ? and ADDRESSTYPECODE = ? and deleted = 'N'";

	private static final String USERADDRESS_FROM_COUSERID_CONTACTADDRESSTYPE = "select * from useraddress where couserid = ? and ADDRESSTYPECODE = ? and deleted = 'N'";
	private static final String USERADDRESS_FROM_COUSERID_CONTRACTID_ADDRESSTYPECODE = "select * from useraddress where couserid = ? and contractid = ? and deleted = 'N' and ADDRESSTYPECODE = ?";
	private static final String USERADDRESS_FROM_COUSERID_ADDRESSTYPECODE_NULL = "select * from useraddress where couserid = ? and contractid is null and deleted = 'N'and ADDRESSTYPECODE = ?";
	private static final String USEREVENT_STATUS = "select * from usereventstatus where requestID = ?";
	private static final String USERCONTACT_FROM_USERADDRESSID = "select * from usercontact where useraddressid = ?";

	private static final String UPDATE_USERCONTACT_WITH_COUSER_CONTRACT_CONTACTCHANNELID = "update usercontact set DELETED='Y' where couserid= ? and contractid= ? and deleted='N' and CONTACTTYPECODE = ?";
	private static final String UPDATE_USERCONTACT_WITH_COUSER_CONTACTCHANNELCODETYPE = "update usercontact set DELETED='Y' where couserid = ? and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ?";
	private static final String USERCONTACT_FROM_COUSERID = "select * from usercontact where couserid = ?";
	private static final String USERCONTACT_FROM_USERCONTACTID = "select * from usercontact where usercontact = ?";
	private static final String USERCONTACT_FROM_COUSERID_CHANNEL = "select * from usercontact where couserid = ? and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ?";

	private static final String USERCONTACT_FROM_COUSERID_CONTRACTID_NULL = "select * from usercontact where couserid = ? and deleted = 'N' and benefitclaimid is null and contractid is null order by usercontactid asc";
	private static final String USERCONTACT_FROM_COUSERID_AND_CONTRACTID = "select * from usercontact where couserid = ? and deleted = 'N' and benefitclaimid is null and contractid = ? order by usercontactid asc";
	private static final String USERCONTACT_FROM_COUSERID_AND_BENEFITCLAIMID = "select * from usercontact where couserid = ? and deleted = 'N' and benefitclaimid = ? and contractid is null order by usercontactid asc";
	private static final String USERCONTACT_FROM_USER_COUSERID_CONTRACTID_CONTRACTCHANNELTYPE = "select * from usercontact where couserid = ? and contractid = ? and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTACT_FROM_USER_COUSERID_CONTACTCHANNELCODE = "Select * from usercontact where couserid = ? and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ? and deleted = 'N'";

	private static final String USERCONTACT_FROM_USERCONTACTCHANNELCODE_PHONE = "select * from usercontact where couserid = ? and CONTACTCHANNELCODE = 'PHONE' and benefitclaimid = ? and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTACT_FROM_USERCONTRACTID = "select * from usercontact where couserid = ? and contractid = ? and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTACT_FROM_USERCONTACTCHANNELCODE_EMAIL = "select * from usercontact where couserid = ? and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTACT_FROM_USERBENEFITCLAIMID = "select * from usercontact where couserid = ? and benefitclaimid = ? and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTACT_FROM_USER_COUSER_CONTACTCHANNELCODETYPECODE = "select * from usercontact where couserid = ? and contractid = '"+"contractId"+"'and deleted = 'N' and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ?";

	private static final String USERCONTACT_FROM_USERCONTACTCHANNELCODE_CONTACTCHANNELTYPE = "select * from usercontact where couserid = ? and contractid is null and benefitclaimid is null and deleted = 'N' and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ?";
	private static final String USERCONTACT_FROM_USERCONTACT_COUSERID = "select * from usercontact where couserid = ? and benefitclaimid = ? and CONTACTCHANNELCODE = ? and CONTACTTYPECODE = ? and deleted = 'N'";
	private static final String USERCONTRACT_PROFILE_FROM_COUSERID = "select * from usercontractprofile where couserid = ?";
	private static final String USERCONTRACT_PROFILE_FROM_CONTRACTID = "select * from usercontractprofile where contractid = ?";
	private static final String USERRELATION_FROM_COUSERID_DELETED_USERRELATION_ASC = "select  * from userrelation where couserid = ? and deleted = 'N' order by USERRELATIONID asc";

	private static final String USERRELATION_FROM_COUSERID_DELETEDN_USERRELATION_ASC = "select  * from userrelation where couserid = ? and contractid = ? order by USERRELATIONID asc";
	private static final String USERRELATION_FROMCOUSERID_RELATEDCOUSERID_DELETEDN = "select  * from userrelation where couserid = ? and RELATEDCOUSERID = ? and deleted = 'N'";
	private static final String USERRELATION_FROM_COUSERID_USERRELATIONID_ASC = "select  * from userrelation where couserid = ? and deleted = 'N' and contractid is null order by USERRELATIONID asc";
	private static final String USERRELATION_FROM_USERRELATIONID = "select  * from userrelation where couserid = ?";
	private static final String USERRELATION_FROM_USERCOUSERID_RELATEDCOUSERID_DELETEDN = "select * from userrelation where COUSERID = ? and RELATEDCOUSERID = ? and deleted ='N'";
	
	private static final String USERCONTRACT_FROM_COUSERID = "select * from usercontract where couserid = ? and deleted = 'N' order by updateddate desc";

	//**ApplicationCommonQueries**//
	//General ApplicationCommonQueries
	public List<COUser> getResultFromQueryCoUser(String query) throws SQLException {
		return DBUtil.executeQuery(query, COUser.class);
	}

	public List<UserAddress> getResultFromQueryUserAddress(String query) throws SQLException {
		return DBUtil.executeQuery(query, UserAddress.class);
	}

	public List<UserContact> getResultFromQueryUserContact(String query) throws SQLException {
		return DBUtil.executeQuery(query, UserContact.class);
	}

	public List<UserContractProfile> getResultFromQueryUserContractProfile(String query) throws SQLException {
		return DBUtil.executeQuery(query, UserContractProfile.class);
	}

	//COUser specific query
	public List<COUser> getCoUserFromCoUserId(String coUserId) throws SQLException {
		return DBUtil.executeQuery(COUSER_FROM_COUSERID, COUser.class, coUserId);
	}

	public List<COUser> getCoUserFromSsoId(String ssoId) throws SQLException {
		return DBUtil.executeQuery(COUSER_FROM_SSOID, COUser.class, ssoId);
	}

	//UserAddress specific query
	public List<UserAddress> getUserAddressFromCoUserId(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID, UserAddress.class, coUserId);
	}

	public List<UserAddress> getUserAddressFromCoUserId(String coUserId, String addressTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID_ADDRESSTYPECODE, UserAddress.class, coUserId, addressTypeCode);
	}

	public List<UserAddress> getUserAddressFromCoUserIdContactIdContactAddressType(String coUserId, String contractId, String contactAddressType) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID_CONTACTID_CONTACTADDRESSTYPE, UserAddress.class, coUserId, contractId, contactAddressType);
	}

	public List<UserAddress> getUserAddressFromCoUserIdContactAddressType(String coUserId, String contactAddressType) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID_CONTACTADDRESSTYPE, UserAddress.class, coUserId, contactAddressType);
	}

	public List<UserAddress> getUserAddressFromCoUserIdContractIdAddressTypeCode(String coUserId, String contractId, String addressTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID_CONTRACTID_ADDRESSTYPECODE, UserAddress.class, coUserId, contractId, addressTypeCode);
	}

	public List<UserAddress> getUserAddressFromCoUserIdAddressTypeCode(String coUserId, String addressTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERADDRESS_FROM_COUSERID_ADDRESSTYPECODE_NULL, UserAddress.class, addressTypeCode);
	}

	public List<UserEventStatus> getUserEventStatus(String requestID) throws SQLException {
		return DBUtil.executeQuery(USEREVENT_STATUS, UserEventStatus.class, requestID);
	}

	//UserContact specific query
	public List<UserContact> getUserContactFromUserAddressId(String userAddressId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERADDRESSID, UserContact.class, userAddressId);
	}

	public List<UserContact> updateUserContactWithCoUserContractContactChannelId(String coUserId, String contractId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(UPDATE_USERCONTACT_WITH_COUSER_CONTRACT_CONTACTCHANNELID, UserContact.class, coUserId, contractId, contactChannelType);
	}

	public List<UserContact> updateUserContactWithCoUserContactChannelCodeType(String coUserId, String contactChannelCode, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(UPDATE_USERCONTACT_WITH_COUSER_CONTACTCHANNELCODETYPE, UserContact.class, coUserId, contactChannelCode, contactChannelType);
	}

	public List<UserContact> getUserContactFromCoUserId(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_COUSERID, UserContact.class, coUserId);
	}

	public List<UserContact> getUserContactFromUserContactId(String userContactId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTACTID, UserContact.class, userContactId);
	}

	public List<UserContact> getUserContactFromCoUserId(String coUserId, String contactChannelCode, String contactTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_COUSERID_CHANNEL, UserContact.class, coUserId, contactChannelCode, contactTypeCode);
	}

	public List<UserContact> getUserContactFromCoUserIdContractIdNull(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_COUSERID_CONTRACTID_NULL, UserContact.class, coUserId);
	}

	public List<UserContact> getUserContactFromCoUserIdandContractId(String coUserId, String contractId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_COUSERID_AND_CONTRACTID, UserContact.class, coUserId, contractId);
	}

	public List<UserContact> getUserContactFromCoUserIdandBenefitClaimId(String coUserId, String benefitClaimId) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_COUSERID_AND_BENEFITCLAIMID, UserContact.class, coUserId, benefitClaimId);
	}

	public List<UserContact> getUserContactFromUserCoUserIdContractIdContractChannelType(String coUserId, String contractId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USER_COUSERID_CONTRACTID_CONTRACTCHANNELTYPE, UserContact.class, coUserId, contractId, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserCoUserIdContactChannelCode(String coUserId, String contactChannelCode, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USER_COUSERID_CONTACTCHANNELCODE, UserContact.class, coUserId, contactChannelCode, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserContactChannelCodePhone(String coUserId, String contractId, String benefitClaimId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTACTCHANNELCODE_PHONE, UserContact.class, coUserId, contractId, benefitClaimId, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserContractId(String coUserId, String contractId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTRACTID, UserContact.class, coUserId, contractId, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserContactChannelCodeEmail(String coUserId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTACTCHANNELCODE_EMAIL, UserContact.class, coUserId, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserBenefitClaimId(String coUserId, String benefitClaimId, String contactChannelType) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERBENEFITCLAIMID, UserContact.class, coUserId, benefitClaimId, contactChannelType);
	}

	public List<UserContact> getUserContactFromUserCoUserContactChannelCodeTypeCode(String coUserId, String contactChannelCode, String contactChannelTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USER_COUSER_CONTACTCHANNELCODETYPECODE, UserContact.class, coUserId, contactChannelCode, contactChannelTypeCode);
	}


	public List<UserContact> getUserContactFromUserContactChannelCodeContactChannelType(String coUserId, String contactChannelCode, String contactTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTACTCHANNELCODE_CONTACTCHANNELTYPE, UserContact.class, coUserId, contactChannelCode, contactTypeCode);
	}


	public List<UserContact> getUserContactFromUserContactCoUserIdBenefitClaimIdContactChannelCodeContactChannelTypeCode(String coUserId, String benefitClaimId, String contactChannelCode, String contactChannelTypeCode) throws SQLException {
		return DBUtil.executeQuery(USERCONTACT_FROM_USERCONTACT_COUSERID, UserContact.class, coUserId, benefitClaimId, contactChannelCode, contactChannelTypeCode);
	}

	//UserContractProfile specific query
	public List<UserContractProfile> getUserContractProfileFromCoUserId(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERCONTRACT_PROFILE_FROM_COUSERID, UserContractProfile.class, coUserId);
	}

	public List<UserContractProfile> getUserContractProfileFromContractId(String contractId) throws SQLException {
		return DBUtil.executeQuery(USERCONTRACT_PROFILE_FROM_CONTRACTID, UserContractProfile.class, contractId);
	}

	//UserRelation specific query
	public List<UserRelation> getUserRelationFromCoUserIdDeletedNUserRelationAsc(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROM_COUSERID_DELETED_USERRELATION_ASC, UserRelation.class, coUserId);
	}

	public List<UserRelation> getUserRelationFromCoUserIdDeletedNUserRelationAsc(String coUserId, String contractId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROM_COUSERID_DELETEDN_USERRELATION_ASC, UserRelation.class, coUserId, contractId);
	}

	public List<UserRelation> getUserRelationFromCoUserIdRelatedCouserIdDeletedN(String coUserId, String relatedCouserId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROMCOUSERID_RELATEDCOUSERID_DELETEDN, UserRelation.class, coUserId, relatedCouserId);
	}

	public List<UserRelation> getUserRelationFromCoUserIdUserRelationIdAsc(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROM_COUSERID_USERRELATIONID_ASC, UserRelation.class, coUserId);
	}

	public List<UserRelation> getUserRelationFromUserRelationId(String userRelationId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROM_USERRELATIONID, UserRelation.class, userRelationId);
	}

	public List<UserRelation> getUserRelationFromUserCoUserIdRelatedCoUserIdDeletedN(String coUserId, String relCoUserId) throws SQLException {
		return DBUtil.executeQuery(USERRELATION_FROM_USERCOUSERID_RELATEDCOUSERID_DELETEDN, UserRelation.class, coUserId, relCoUserId);
	}
	
	public List<UserContract> getUserContractFromCoUserId(String coUserId) throws SQLException {
		return DBUtil.executeQuery(USERCONTRACT_FROM_COUSERID, UserContract.class, coUserId);
	}
}

