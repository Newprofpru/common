package com.test.mapper.pojos;

public class ResponseHeader
{
    private String responseStatus;

    private String responseCode;

    public String getResponseStatus ()
    {
        return responseStatus;
    }

    public void setResponseStatus (String responseStatus)
    {
        this.responseStatus = responseStatus;
    }

    public String getResponseCode ()
    {
        return responseCode;
    }

    public void setResponseCode (String responseCode)
    {
        this.responseCode = responseCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [responseStatus = "+responseStatus+", responseCode = "+responseCode+"]";
    }
}