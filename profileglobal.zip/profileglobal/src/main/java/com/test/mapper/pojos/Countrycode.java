package com.test.mapper.pojos;

public class Countrycode {


    private String countryCode;

    private String pointVal;

    private String numericalCode;

    private String countryName;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPointVal() {
        return pointVal;
    }

    public void setPointVal(String pointVal) {
        this.pointVal = pointVal;
    }

    public String getNumericalCode() {
        return numericalCode;
    }

    public void setNumericalCode(String numericalCode) {
        this.numericalCode = numericalCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    @Override
    public String toString() {
        return "ClassPojo [countryCode = " + countryCode + ", pointVal = " + pointVal + ", numericalCode = " + numericalCode + ", countryName = " + countryName + "]";
    }
}
