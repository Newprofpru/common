package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.COUser;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERADDRESS"
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class UserAddress implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERADDRESSID",
            unique = true,
            nullable = false
    )
    private long userAddressId;
    @Column(
            name = "ADDRESSLINE1",
            length = 250
    )
    private String addressLine1;
    @Column(
            name = "ADDRESSLINE2",
            length = 250
    )
    private String addressLine2;
    @Column(
            name = "ADDRESSLINE3",
            length = 250
    )
    private String addressLine3;
    @Column(
            name = "ADDRESSLINE4",
            length = 250
    )
    private String addressLine4;
    @Column(
            name = "ADDRESSSTATUSCODE",
            length = 20
    )
    private String addressStatusCode;
    @Column(
            name = "ADDRESSTYPECODE",
            length = 20
    )
    private String addressTypeCode;
    @Column(
            name = "BUCREATEDBY",
            length = 100
    )
    private String buCreatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "BUCREATEDDATE"
    )
    private Date buCreatedDate;
    @Column(
            name = "BUUPDATEDBY",
            length = 100
    )
    private String buUpdatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "BUUPDATEDDATE"
    )
    private Date buUpdatedDate;
    @Column(
            name = "CITY",
            length = 100
    )
    private String city;
    @Column(
            name = "CONTRACTID",
            length = 30
    )
    private String contractId;
    @Column(
            name = "COUNTRY",
            length = 50
    )
    private String country;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "FILESETID"
    )
    private BigDecimal filesetId;
    @Column(
            name = "LINEOFBUSINESSCODE",
            length = 50
    )
    private String lineOfBusinessCode;
    @Column(
            name = "STATE",
            length = 50
    )
    private String state;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @Column(
            name = "USERSOURCECODE",
            length = 20
    )
    private String userSourceCode;
    @Column(
            name = "ZIPCODE",
            length = 20
    )
    private String zipCode;
    @Column(
            name = "ZIPCODEEXTENSION",
            length = 20
    )
    private String zipCodeExtension;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser coUser;

    public UserAddress() {
    }

    public long getUserAddressId() {
        return this.userAddressId;
    }

    public void setUserAddressId(long userAddressId) {
        this.userAddressId = userAddressId;
    }

    public String getAddressLine1() {
        return this.addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return this.addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return this.addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return this.addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getAddressStatusCode() {
        return this.addressStatusCode;
    }

    public void setAddressStatusCode(String addressStatusCode) {
        this.addressStatusCode = addressStatusCode;
    }

    public String getAddressTypeCode() {
        return this.addressTypeCode;
    }

    public void setAddressTypeCode(String addressTypeCode) {
        this.addressTypeCode = addressTypeCode;
    }

    public String getBuCreatedBy() {
        return this.buCreatedBy;
    }

    public void setBuCreatedBy(String buCreatedBy) {
        this.buCreatedBy = buCreatedBy;
    }

    public Date getBuCreatedDate() {
        return this.buCreatedDate;
    }

    public void setBuCreatedDate(Date buCreatedDate) {
        this.buCreatedDate = buCreatedDate;
    }

    public String getBuUpdatedBy() {
        return this.buUpdatedBy;
    }

    public void setBuUpdatedBy(String buUpdatedBy) {
        this.buUpdatedBy = buUpdatedBy;
    }

    public Date getBuUpdatedDate() {
        return this.buUpdatedDate;
    }

    public void setBuUpdatedDate(Date buUpdatedDate) {
        this.buUpdatedDate = buUpdatedDate;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContractId() {
        return this.contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public BigDecimal getFilesetId() {
        return this.filesetId;
    }

    public void setFilesetId(BigDecimal filesetId) {
        this.filesetId = filesetId;
    }

    public String getLineOfBusinessCode() {
        return this.lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUserSourceCode() {
        return this.userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public String getZipCode() {
        return this.zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getZipCodeExtension() {
        return this.zipCodeExtension;
    }

    public void setZipCodeExtension(String zipCodeExtension) {
        this.zipCodeExtension = zipCodeExtension;
    }

    public com.test.mapper.pojos.COUser getCoUser() {
        return this.coUser;
    }

    public void setCoUser(COUser coUser) {
        this.coUser = coUser;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
