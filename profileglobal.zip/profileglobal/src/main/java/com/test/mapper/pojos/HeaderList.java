package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.restassured.http.Header;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Aditya Jamwal
 * 4/23/19
 */



public class HeaderList  {


    public Map<String, Object> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, Object> headers) {
        this.headers = headers;
    }

    private Map<String, Object> headers = new HashMap<>();

    @JsonAnySetter
    public void set(String fieldName, Object value){
        this.headers.put(fieldName, value);
    }

    public Object get(String fieldName){
        return this.headers.get(fieldName);
    }


}
