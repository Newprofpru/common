package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.COUser;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERSSO"
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class UserSSO implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERSSOID",
            unique = true,
            nullable = false
    )
    private long userSSOId;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "FILESETID"
    )
    private Long filesetId;
    @Column(
            name = "LEGACYLOGINNAME",
            length = 250
    )
    private String legacyLoginName;
    @Column(
            name = "LEGACYSSOID"
    )
    private Long legacySSOId;
    @Column(
            name = "SSOTYPECODE",
            length = 20
    )
    private String ssoTypeCode;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @Column(
            name = "USERSOURCECODE",
            length = 20
    )
    private String userSourceCode;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser coUser;

    public UserSSO() {
    }

    public long getUserSSOId() {
        return this.userSSOId;
    }

    public void setUserSSOId(long userSSOId) {
        this.userSSOId = userSSOId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public Long getFilesetId() {
        return this.filesetId;
    }

    public void setFilesetId(Long filesetId) {
        this.filesetId = filesetId;
    }

    public String getLegacyLoginName() {
        return this.legacyLoginName;
    }

    public void setLegacyLoginName(String legacyLoginName) {
        this.legacyLoginName = legacyLoginName;
    }

    public Long getLegacySSOId() {
        return this.legacySSOId;
    }

    public void setLegacySSOId(Long legacySSOId) {
        this.legacySSOId = legacySSOId;
    }

    public String getSsoTypeCode() {
        return this.ssoTypeCode;
    }

    public void setSsoTypeCode(String ssoTypeCode) {
        this.ssoTypeCode = ssoTypeCode;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUserSourceCode() {
        return this.userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public com.test.mapper.pojos.COUser getCouser() {
        return this.coUser;
    }

    public void setCouser(COUser coUser) {
        this.coUser = coUser;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
