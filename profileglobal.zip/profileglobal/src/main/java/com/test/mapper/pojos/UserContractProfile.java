package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.COUser;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERCONTRACTPROFILE"
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class UserContractProfile implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERCONTRACTPROFILEID",
            nullable = false
    )
    private long userContractProfileId;
    @Column(
            name = "ANNUALINCOME",
            length = 50
    )
    private String annualIncome;
    @Column(
            name = "COAPPLICANT",
            length = 50
    )
    private String coApplicant;
    @Column(
            name = "COMPANYSYMBOL",
            length = 30
    )
    private String companySymbol;
    @Column(
            name = "CONTRACTID",
            nullable = false,
            length = 30
    )
    private String contractId;
    @Column(
            name = "CONTROLPERSON",
            length = 150
    )
    private String controlPerson;
    @Column(
            name = "COUNTRYOFBIRTH",
            length = 50
    )
    private String countryOfBirth;
    @Column(
            name = "COUNTRYOFCITIZENSHIP",
            length = 3
    )
    private String countryOfCitizenship;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Temporal(TemporalType.DATE)
    @Column(
            name = "DATEOFBIRTH"
    )
    private Date dateOfBirth;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "EMPLOYERNAME",
            length = 50
    )
    private String employerName;
    @Column(
            name = "EMPLOYMENTPOSITION",
            length = 50
    )
    private String employmentPosition;
    @Column(
            name = "EMPLOYMENTSTATUSCODE",
            length = 50
    )
    private String employmentStatusCode;
    @Column(
            name = "FINRAAFFILIATED",
            length = 1
    )
    private String finraAffiliated;
    @Column(
            name = "FIRMNAME",
            length = 20
    )
    private String firmName;
    @Column(
            name = "FIRSTNAME",
            length = 100
    )
    private String firstName;
    @Column(
            name = "GENDERCODE",
            length = 20
    )
    private String genderCode;
    @Column(
            name = "INVESTMENTEXPERIENCE",
            length = 30
    )
    private String investmentExperience;
    @Column(
            name = "INVESTMENTOBJECTIVE",
            length = 100
    )
    private String investmentObjective;
    @Column(
            name = "LAST4SSN",
            length = 4
    )
    private String last4SSN;
    @Column(
            name = "LASTNAME",
            length = 100
    )
    private String lastName;
    @Column(
            name = "LINEOFBUSINESSCODE",
            nullable = false,
            length = 20
    )
    private String lineOfBusinessCode;
    @Column(
            name = "LIQUIDITYNEEDS",
            length = 50
    )
    private String liquidityNeeds;
    @Column(
            name = "LIQUIDNETWORTH",
            length = 50
    )
    private String liquidNetWorth;
    @Column(
            name = "MARITALSTATUSCODE",
            length = 20
    )
    private String maritalStatusCode;
    @Column(
            name = "MIDDLENAME",
            length = 100
    )
    private String middleName;
    @Column(
            name = "ORGANIZATION",
            length = 100
    )
    private String organization;
    @Column(
            name = "ORGANIZATIONCOUNTRYCODE",
            length = 30
    )
    private String organizationCountryCode;
    @Column(
            name = "PERMANANTRESIDENT",
            length = 1
    )
    private String permanantResident;
    @Column(
            name = "POLITICALAFFILIATEDRELTYPECODE",
            length = 30
    )
    private String politicalAffiliatedRelTypeCode;
    @Column(
            name = "POLITICALLYEXPOSED",
            length = 1
    )
    private String politicallyExposed;
    @Column(
            name = "PREFIXNAME",
            length = 100
    )
    private String prefixName;
    @Column(
            name = "RELATIONSHIPTYPECODE",
            length = 20
    )
    private String relationshipTypeCode;
    @Column(
            name = "RISKTOLERANCE",
            length = 50
    )
    private String riskTolerance;
    @Column(
            name = "SOCIALSECURITYNUMBER"
    )
    private byte[] socialSecurityNumber;
    @Column(
            name = "SSNHASH"
    )
    private byte[] ssnHash;
    @Column(
            name = "SUFFIXNAME",
            length = 100
    )
    private String suffixName;
    @Column(
            name = "TAXBRACKET",
            length = 30
    )
    private String taxBracket;
    @Column(
            name = "TIMEHORIZON",
            length = 30
    )
    private String timeHorizon;
    @Column(
            name = "TOTALNETWORTH",
            length = 50
    )
    private String totalNetWorth;
    @Column(
            name = "TRUSTEDCONTACTPERSON",
            length = 5
    )
    private String trustedContactPerson;
    @Column(
            name = "TRUSTEDCONTACTPERSONEMAIL",
            length = 100
    )
    private String trustedContactPersonEmail;
    @Column(
            length = 20
    )
    private String trustedContactPersonPhone;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @Column(
            name = "USCITIZENSHIP",
            length = 1
    )
    private String usCitizenship;
    @Column(
            name = "USERSOURCECODE",
            length = 20
    )
    private String userSourceCode;
    @Column(
            name = "USERTYPECODE",
            length = 20
    )
    private String userTypeCode;
    @Temporal(TemporalType.DATE)
    @Column(
            name = "VISAEXPIRATION"
    )
    private Date visaExpiration;
    @Column(
            name = "VISATYPECODE",
            length = 20
    )
    private String visaTypeCode;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser coUser;
    @Column(
            name = "AFFILIATEDAPPROVALID",
            length = 150
    )
    private String affiliatedApprovalId;
    @Column(
            name = "TRUSTEDCONTACTFIRSTNAME",
            length = 100
    )
    private String trustedContactFirstName;
    @Column(
            name = "TRUSTEDCONTACTLASTNAME",
            length = 100
    )
    private String trustedContactLastName;
    @Column(
            name = "TRUSTEDCONTACTADDRESS1",
            length = 250
    )
    private String trustedContactAddress1;
    @Column(
            name = "TRUSTEDCONTACTSTREETADDRESS",
            length = 250
    )
    private String trustedContactStreetAddress;
    @Column(
            name = "TRUSTEDCONTACTCITY",
            length = 100
    )
    private String trustedContactCity;
    @Column(
            name = "TRUSTEDCONTACTSTATE",
            length = 50
    )
    private String trustedContactState;
    @Column(
            name = "TRUSTEDCONTACTPOSTALCODE",
            length = 20
    )
    private String trustedContactPostalCode;
    @Column(
            name = "TRUSTEDCONTACTCOUNTRY",
            length = 50
    )
    private String trustedContactCountry;

    public String getTrustedContactFirstName() {
        return this.trustedContactFirstName;
    }

    public void setTrustedContactFirstName(String trustedContactFirstName) {
        this.trustedContactFirstName = trustedContactFirstName;
    }

    public String getTrustedContactLastName() {
        return this.trustedContactLastName;
    }

    public void setTrustedContactLastName(String trustedContactLastName) {
        this.trustedContactLastName = trustedContactLastName;
    }

    public String getTrustedContactAddress1() {
        return this.trustedContactAddress1;
    }

    public void setTrustedContactAddress1(String trustedContactAddress1) {
        this.trustedContactAddress1 = trustedContactAddress1;
    }

    public String getTrustedContactStreetAddress() {
        return this.trustedContactStreetAddress;
    }

    public void setTrustedContactStreetAddress(String trustedContactStreetAddress) {
        this.trustedContactStreetAddress = trustedContactStreetAddress;
    }

    public String getTrustedContactCity() {
        return this.trustedContactCity;
    }

    public void setTrustedContactCity(String trustedContactCity) {
        this.trustedContactCity = trustedContactCity;
    }

    public String getTrustedContactState() {
        return this.trustedContactState;
    }

    public void setTrustedContactState(String trustedContactState) {
        this.trustedContactState = trustedContactState;
    }

    public String getTrustedContactPostalCode() {
        return this.trustedContactPostalCode;
    }

    public void setTrustedContactPostalCode(String trustedContactPostalCode) {
        this.trustedContactPostalCode = trustedContactPostalCode;
    }

    public String getTrustedContactCountry() {
        return this.trustedContactCountry;
    }

    public void setTrustedContactCountry(String trustedContactCountry) {
        this.trustedContactCountry = trustedContactCountry;
    }

    public String getAffiliatedApprovalId() {
        return this.affiliatedApprovalId;
    }

    public void setAffiliatedApprovalId(String affiliatedApprovalId) {
        this.affiliatedApprovalId = affiliatedApprovalId;
    }

    public UserContractProfile() {
    }

    public String getAnnualIncome() {
        return this.annualIncome;
    }

    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getCoApplicant() {
        return this.coApplicant;
    }

    public void setCoApplicant(String coApplicant) {
        this.coApplicant = coApplicant;
    }

    public String getCompanySymbol() {
        return this.companySymbol;
    }

    public void setCompanySymbol(String companySymbol) {
        this.companySymbol = companySymbol;
    }

    public String getContractId() {
        return this.contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getControlPerson() {
        return this.controlPerson;
    }

    public void setControlPerson(String controlPerson) {
        this.controlPerson = controlPerson;
    }

    public String getCountryOfBirth() {
        return this.countryOfBirth;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public String getCountryOfCitizenship() {
        return this.countryOfCitizenship;
    }

    public void setCountryOfCitizenship(String countryOfCitizenship) {
        this.countryOfCitizenship = countryOfCitizenship;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getEmployerName() {
        return this.employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getEmploymentPosition() {
        return this.employmentPosition;
    }

    public void setEmploymentPosition(String employmentPosition) {
        this.employmentPosition = employmentPosition;
    }

    public String getEmploymentStatusCode() {
        return this.employmentStatusCode;
    }

    public void setEmploymentStatusCode(String employmentStatusCode) {
        this.employmentStatusCode = employmentStatusCode;
    }

    public String getFinraAffiliated() {
        return this.finraAffiliated;
    }

    public void setFinraAffiliated(String finraAffiliated) {
        this.finraAffiliated = finraAffiliated;
    }

    public String getFirmName() {
        return this.firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGenderCode() {
        return this.genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    public String getInvestmentExperience() {
        return this.investmentExperience;
    }

    public void setInvestmentExperience(String investmentExperience) {
        this.investmentExperience = investmentExperience;
    }

    public String getInvestmentObjective() {
        return this.investmentObjective;
    }

    public void setInvestmentObjective(String investmentObjective) {
        this.investmentObjective = investmentObjective;
    }

    public String getLast4SSN() {
        return this.last4SSN;
    }

    public void setLast4SSN(String last4ssn) {
        this.last4SSN = last4ssn;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLineOfBusinessCode() {
        return this.lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getLiquidityNeeds() {
        return this.liquidityNeeds;
    }

    public void setLiquidityNeeds(String liquidityNeeds) {
        this.liquidityNeeds = liquidityNeeds;
    }

    public String getLiquidNetWorth() {
        return this.liquidNetWorth;
    }

    public void setLiquidNetWorth(String liquidNetWorth) {
        this.liquidNetWorth = liquidNetWorth;
    }

    public String getMaritalStatusCode() {
        return this.maritalStatusCode;
    }

    public void setMaritalStatusCode(String maritalStatusCode) {
        this.maritalStatusCode = maritalStatusCode;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getOrganization() {
        return this.organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getOrganizationCountryCode() {
        return this.organizationCountryCode;
    }

    public void setOrganizationCountryCode(String organizationCountryCode) {
        this.organizationCountryCode = organizationCountryCode;
    }

    public String getPermanantResident() {
        return this.permanantResident;
    }

    public void setPermanantResident(String permanantResident) {
        this.permanantResident = permanantResident;
    }

    public String getPoliticalAffiliatedRelTypeCode() {
        return this.politicalAffiliatedRelTypeCode;
    }

    public void setPoliticalAffiliatedRelTypeCode(String politicalAffiliatedRelTypeCode) {
        this.politicalAffiliatedRelTypeCode = politicalAffiliatedRelTypeCode;
    }

    public String getPoliticallyExposed() {
        return this.politicallyExposed;
    }

    public void setPoliticallyExposed(String politicallyExposed) {
        this.politicallyExposed = politicallyExposed;
    }

    public String getPrefixName() {
        return this.prefixName;
    }

    public void setPrefixName(String prefixName) {
        this.prefixName = prefixName;
    }

    public String getRelationshipTypeCode() {
        return this.relationshipTypeCode;
    }

    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }

    public String getRiskTolerance() {
        return this.riskTolerance;
    }

    public void setRiskTolerance(String riskTolerance) {
        this.riskTolerance = riskTolerance;
    }

    public byte[] getSocialSecurityNumber() {
        return this.socialSecurityNumber;
    }

    public void setSocialSecurityNumber(byte[] socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    public byte[] getSsnHash() {
        return this.ssnHash;
    }

    public void setSsnHash(byte[] ssnHash) {
        this.ssnHash = ssnHash;
    }

    public String getSuffixName() {
        return this.suffixName;
    }

    public void setSuffixName(String suffixName) {
        this.suffixName = suffixName;
    }

    public String getTaxBracket() {
        return this.taxBracket;
    }

    public void setTaxBracket(String taxBracket) {
        this.taxBracket = taxBracket;
    }

    public String getTimeHorizon() {
        return this.timeHorizon;
    }

    public void setTimeHorizon(String timeHorizon) {
        this.timeHorizon = timeHorizon;
    }

    public String getTotalNetWorth() {
        return this.totalNetWorth;
    }

    public void setTotalNetWorth(String totalNetWorth) {
        this.totalNetWorth = totalNetWorth;
    }

    public String getTrustedContactPerson() {
        return this.trustedContactPerson;
    }

    public void setTrustedContactPerson(String trustedContactPerson) {
        this.trustedContactPerson = trustedContactPerson;
    }

    public String getTrustedContactPersonEmail() {
        return this.trustedContactPersonEmail;
    }

    public void setTrustedContactPersonEmail(String trustedContactPersonEmail) {
        this.trustedContactPersonEmail = trustedContactPersonEmail;
    }

    public String getTrustedContactPersonPhone() {
        return this.trustedContactPersonPhone;
    }

    public void setTrustedContactPersonPhone(String trustedContactPersonPhone) {
        this.trustedContactPersonPhone = trustedContactPersonPhone;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUsCitizenship() {
        return this.usCitizenship;
    }

    public void setUsCitizenship(String usCitizenship) {
        this.usCitizenship = usCitizenship;
    }

    public long getUserContractProfileId() {
        return this.userContractProfileId;
    }

    public void setUserContractProfileId(long userContractProfileId) {
        this.userContractProfileId = userContractProfileId;
    }

    public String getUserSourceCode() {
        return this.userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public String getUserTypeCode() {
        return this.userTypeCode;
    }

    public void setUserTypeCode(String userTypeCode) {
        this.userTypeCode = userTypeCode;
    }

    public Date getVisaExpiration() {
        return this.visaExpiration;
    }

    public void setVisaExpiration(Date visaExpiration) {
        this.visaExpiration = visaExpiration;
    }

    public String getVisaTypeCode() {
        return this.visaTypeCode;
    }

    public void setVisaTypeCode(String visaTypeCode) {
        this.visaTypeCode = visaTypeCode;
    }

    public com.test.mapper.pojos.COUser getCoUser() {
        return this.coUser;
    }

    public void setCoUser(COUser coUser) {
        this.coUser = coUser;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
