package com.test.mapper.utils;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class HikariCustomDataConfig {

    private EnvInfo envInfo = EnvInfo.getInstance();

    public HikariDataSource dataSource() {

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(envInfo.getDriver());
        hikariConfig.setJdbcUrl(envInfo.getdb());
        hikariConfig.setUsername(envInfo.getdbUserName());
        hikariConfig.setPassword(envInfo.getdbPass());
        hikariConfig.setConnectionTimeout(envInfo.getConnectionTimeout());
        hikariConfig.setLeakDetectionThreshold(envInfo.getLeakDetectionThreshold());
        hikariConfig.setMaximumPoolSize(envInfo.getMaximumPoolSize());
        hikariConfig.setPoolName(envInfo.getPoolName());
        hikariConfig.addDataSourceProperty(envInfo.getDataSourceProperty1(), envInfo.getCachePrepStmts());
        hikariConfig.addDataSourceProperty(envInfo.getDataSourceProperty2(), envInfo.getStmtCacheSize());
        hikariConfig.addDataSourceProperty(envInfo.getDataSourceProperty3(), envInfo.getStmtCacheSqlLimit());
        hikariConfig.addDataSourceProperty(envInfo.getDataSourceProperty4(), envInfo.getServerPrepStmts());
        hikariConfig.addDataSourceProperty(envInfo.getDataSourceProperty5(), envInfo.getSuites());

        HikariDataSource dataSource = new HikariDataSource(hikariConfig);
        return dataSource;
    }
}
