package com.test.mapper.api;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.test.mapper.pojos.Profile;
import com.test.mapper.utils.EnvInfo;
import com.test.mapper.utils.GenerateTokenUtils;

import cucumber.api.DataTable;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * @author Aditya Jamwal
 */
public class ProfileAPI extends BaseAPI<Profile> {

    public static final String PATH = "/profiles/v3/profile";


    RequestSpecification requestSpecification = null;

    String requestID = "CreateProfile";

    String authorization = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";
    private static Logger logger = LogManager.getLogger();
    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();
    private EnvInfo envInfo = EnvInfo.getInstance();
    String authorizationAmlu = envInfo.getAmluAuthorization();

    public Response createRequest(Profile profileCreate) {

        Map<String, Object> headerMap = new HashMap<String, Object>();

        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);


        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).headers(headers).contentType(ContentType.JSON).body(profileCreate).post(getBaseURI() + PATH).andReturn();


    }

    public Response updateRequest(Profile profileUpdate) {

        Map<String, Object> headerMap = new HashMap<String, Object>();


        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);


        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).headers(headers).contentType(ContentType.JSON).body(profileUpdate).put(getBaseURI() + PATH).andReturn();


    }

    public Response getRequest(String profileId) {

        Map<String, Object> headerMap = new HashMap<String, Object>();

        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);


        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).contentType(ContentType.JSON).get(getBaseURI() + PATH + "?coUserId=" + profileId).andReturn();


    }
    
    public Response getRequestWithParams(DataTable parameters, String authorization){
    	RequestSpecification request = null;
    	Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        if(authorization.contains("YjROQjRK")){
        	request = given().log().all()
				.header("X-PruRequestId", requestID)
				.header("Authorization", authorization)
				.header("X-Forwarded-For", "0.0.0.0")
				.header("X-PruPrimaryIdentity", "X223793");}
        else if(authorization.contains("R2pRd0NOU2")){
        	request = given().log().all()
    				.header("X-PruRequestId", requestID)
    				.header("Authorization", authorization)
    				.header("X-Forwarded-For", "0.0.0.0");}
		for(String paramName:paramNames){
			if(paramName.equalsIgnoreCase("ssoId"))
				request.header("X-PruImpersonatedIdentity",data.get(paramName) );			
			else
				request.param(paramName,data.get(paramName));
		}
		
		Response Res1 = request.when().contentType(ContentType.JSON).get(getBaseURI() + PATH ).andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
        return Res1;
    }

}
