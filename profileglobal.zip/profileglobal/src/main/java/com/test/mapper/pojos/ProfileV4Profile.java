package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileV4Profile
{
    private String totalNumberOfProfiles;

    private ProfileV4[] profiles;

    private String responseStatus;

    private String responseCode;

    public String getTotalNumberOfProfiles ()
    {
        return totalNumberOfProfiles;
    }

    public void setTotalNumberOfProfiles (String totalNumberOfProfiles)
    {
        this.totalNumberOfProfiles = totalNumberOfProfiles;
    }

    public ProfileV4[] getProfiles ()
    {
        return profiles;
    }

    public void setProfiles (ProfileV4[] profiles)
    {
        this.profiles = profiles;
    }

    public String getResponseStatus ()
    {
        return responseStatus;
    }

    public void setResponseStatus (String responseStatus)
    {
        this.responseStatus = responseStatus;
    }

    public String getResponseCode ()
    {
        return responseCode;
    }

    public void setResponseCode (String responseCode)
    {
        this.responseCode = responseCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [totalNumberOfProfiles = "+totalNumberOfProfiles+", profiles = "+profiles+", responseStatus = "+responseStatus+", responseCode = "+responseCode+"]";
    }
}