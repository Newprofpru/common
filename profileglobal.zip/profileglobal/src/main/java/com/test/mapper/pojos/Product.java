package com.test.mapper.pojos;

import java.util.Map;

public class Product {
    private Map<String, String> productCashvalue;

    private Map<String, String> multipleProductCashvalue;

    public Map<String, String> getProductCashvalue() {
        return productCashvalue;
    }

    public void setProductCashvalue(Map<String, String> productCashvalue) {
        this.productCashvalue = productCashvalue;
    }

    public Map<String, String> getMultipleProductCashvalue() {
        return multipleProductCashvalue;
    }

    public void setMultipleProductCashvalue(Map<String, String> multipleProductCashvalue) {
        this.multipleProductCashvalue = multipleProductCashvalue;
    }
}
