package com.test.mapper.pojos;

public class TermsAcceptance{
    private String dateAccepted;

    private String documentId;

    private String documentName;

    public String getDateAccepted ()
    {
        return dateAccepted;
    }

    public void setDateAccepted (String dateAccepted)
    {
        this.dateAccepted = dateAccepted;
    }

    public String getDocumentId ()
    {
        return documentId;
    }

    public void setDocumentId (String documentId)
    {
        this.documentId = documentId;
    }

    public String getDocumentName ()
    {
        return documentName;
    }

    public void setDocumentName (String documentName)
    {
        this.documentName = documentName;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [dateAccepted = "+dateAccepted+", documentId = "+documentId+", documentName = "+documentName+"]";
    }
}