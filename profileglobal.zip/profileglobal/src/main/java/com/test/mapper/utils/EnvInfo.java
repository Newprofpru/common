package com.test.mapper.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

public class EnvInfo {

    private static EnvInfo instance = null;
    private Properties properties;
    private Logger log = Logger.getLogger(EnvInfo.class);

    private EnvInfo(){
    	//set env
        System.setProperty("ENV","QA");
        if(System.getProperty("ENV").equalsIgnoreCase("Stage")){
            properties = loadFromPropFile("application-stage.properties");
        }
        else if(System.getProperty("ENV").equalsIgnoreCase("Prod")){
            properties = loadFromPropFile("application-prod.properties");
        }
        else {
            properties = loadFromPropFile("application-qa.properties");
        }
    }

    public static EnvInfo getInstance(){
        if(instance == null)
            instance = new EnvInfo();
        return instance;
    }

    public String getURL() {
        return properties.getProperty("URL");
    }
    public String getPublicURL() {
        return properties.getProperty("PublicUrl");
    }
    public String getSecureURL() {
        return properties.getProperty("SecureUrl");
    }

    public String getAccountsSecureURL() {
        return properties.getProperty("SecureUrlAccounts");
    }

    public String getAuditTrailSecureURL() {
        return properties.getProperty("SecureUrlAuditTrail");
    }

    public String getAuditTrailGetRequestGetRecordsURL() {
        return properties.getProperty("SecureUrlGetRecordsAuditAmlu");
    }
    public String getAuditTrailGetRequestViewRecordsURL() {
        return properties.getProperty("SecureUrlViewRecordsAuditAmlu");
    }

    public String getSecureURLIndvRep() {
        return properties.getProperty("SecureUrlIndvRep");
    }

    public String getSecureURLBeneRep() {
        return properties.getProperty("SecureUrlBeneRep");
    }

    public String getSecureUrlSMSession() {
        return properties.getProperty("SecureUrlSMSession");
    }
    public String getSecureUrlILIParty() {
        return properties.getProperty("SecureUrlILIParty");
    }

    public String getAuthorization() {
        return properties.getProperty("Authorization");
    }

    public String getRepAuthorization() {
        return properties.getProperty("AuthorizationRep");
    }
    
    public String getAmluAuthorization() {
        return properties.getProperty("AuthorizationAmlu");
    }
    
    public String getILIPartyAuthorization() {
        return properties.getProperty("AuthorisationILIParty");
    }

    public String getIVuser() {
        return properties.getProperty("IVuserRep");
    }
    public String getdb() {
        return properties.getProperty("DB");
    }

    public String getdbUserName() {
        return properties.getProperty("dbUserName");
    }
    public String getdbPass() {
        return properties.getProperty("dbPass");
    }

    public String getaccountsdb() {
        return properties.getProperty("AccountsDB");
    }

    public String getAuthorizationSMSESSION(){
        log.info(properties.getProperty("AuthorizationSMSESSION"));
        return properties.getProperty("AuthorizationSMSESSION");
    }

    public String getAuthorizationLiteRegistration(){
        return properties.getProperty("AuthorizationLiteRegistration");
    }

    public String getLiteRegistrationUrl(){
        return properties.getProperty("LiteRegistrationUrl");
    }

    public String getaccountsdbUserName() {
        log.info(properties.getProperty("AccountsdbUserName"));
        return properties.getProperty("AccountsdbUserName");
    }
    public String getaccountsdbPass() {
        log.info(properties.getProperty("AccountsdbPass"));
        return properties.getProperty("AccountsdbPass");
    }

    public int getConnectionTimeout() {
        return Integer.parseInt(properties.getProperty("ConnectionTimeout"));
    }

    public int getLeakDetectionThreshold() {
        return Integer.parseInt(properties.getProperty("LeakDetectionThreshold"));
    }

    public int getMaximumPoolSize() {
        return Integer.parseInt(properties.getProperty("MaximumPoolSize"));
    }

    public String getPoolName() {
        return properties.getProperty("PoolName");
    }

    public String getEnvironment() {
        return properties.getProperty("Environment");
    }

    public String getDriver() {
        return properties.getProperty("dbOracleDriver");}

    public String getAuthUrl() {
        return properties.getProperty("AuthUrl");
    }

    public String getCSRUrl() {
        return properties.getProperty("CSRUrl");
    }

    public String getDataSourceProperty1() {
        return properties.getProperty("DataSourceProperty1");
    }

    public String getDataSourceProperty2() {
        return properties.getProperty("DataSourceProperty2");
    }

    public String getDataSourceProperty3() {
        return properties.getProperty("DataSourceProperty3");
    }

    public String getDataSourceProperty4() {
        return properties.getProperty("DataSourceProperty4");
    }

    public String getDataSourceProperty5() {
        return properties.getProperty("DataSourceProperty5");
    }

    public String getCachePrepStmts() {
        return properties.getProperty("cachePrepStmts");
    }

    public String getStmtCacheSize() {
        return properties.getProperty("StmtCacheSize");
    }

    public String getStmtCacheSqlLimit() {
        return properties.getProperty("StmtCacheSqlLimit");
    }

    public String getServerPrepStmts() {
        return properties.getProperty("ServerPrepStmts");
    }

    public String getSuites() {
        return properties.getProperty("suites");
    }

    public Properties getProperties() {
        return properties;
    }

    private Properties loadFromPropFile(String property) {
        Properties properties = new Properties();
        try {
            properties.load(EnvInfo.class.getClassLoader().getResourceAsStream(property));
        } catch (FileNotFoundException e) {
            log.error(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            log.error(e.getMessage());
            e.printStackTrace();
        }
        return properties;
    }
}
