package com.test.mapper.pojos;

import java.util.Arrays;

public class Profiles {

    private String ssoId;

    private String sourceId;

    private PersonalInfo personalInfo;

    private String bURelationShip;

    private String userSourceCode;

    private String coUserId;

    private String relationshipToAccount;

    private String productName;

    private ContactChannels[] contactChannels;

    private String isEditable;

    private String productGroup;

    private String eventStatus;

    private String contractId;

    private String benefitClaimId;

    private String userType;

    private String lineOfBusinessCode;

    private String sourceApplication;

    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public PersonalInfo getPersonalInfo() {
        return personalInfo;
    }

    public void setPersonalInfo(PersonalInfo personalInfo) {
        this.personalInfo = personalInfo;
    }

    public String getbURelationShip() {
        return bURelationShip;
    }

    public void setbURelationShip(String bURelationShip) {
        this.bURelationShip = bURelationShip;
    }

    public String getUserSourceCode() {
        return userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public String getCoUserId() {
        return coUserId;
    }

    public void setCoUserId(String coUserId) {
        this.coUserId = coUserId;
    }

    public String getRelationshipToAccount() {
        return relationshipToAccount;
    }

    public void setRelationshipToAccount(String relationshipToAccount) {
        this.relationshipToAccount = relationshipToAccount;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public ContactChannels[] getContactChannels() {
        return contactChannels;
    }

    public void setContactChannels(ContactChannels[] contactChannels) {
        this.contactChannels = contactChannels;
    }

    public String getIsEditable() {
        return isEditable;
    }

    public void setIsEditable(String isEditable) {
        this.isEditable = isEditable;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(String eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getBenefitClaimId() {
        return benefitClaimId;
    }

    public void setBenefitClaimId(String benefitClaimId) {
        this.benefitClaimId = benefitClaimId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getLineOfBusinessCode() {
        return lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getSourceApplication() {
        return sourceApplication;
    }

    public void setSourceApplication(String sourceApplication) {
        this.sourceApplication = sourceApplication;
    }

    @Override
    public String toString() {
        return "Profiles [ssoId=" + ssoId + ", sourceId=" + sourceId + ", personalInfo=" + personalInfo
                + ", bURelationShip=" + bURelationShip + ", userSourceCode=" + userSourceCode + ", coUserId=" + coUserId
                + ", relationshipToAccount=" + relationshipToAccount + ", productName=" + productName
                + ", contactChannels=" + Arrays.toString(contactChannels) + ", isEditable=" + isEditable
                + ", productGroup=" + productGroup + ", eventStatus=" + eventStatus + ", contractId=" + contractId
                + ", benefitClaimId=" + benefitClaimId + ", userType=" + userType + ", lineOfBusinessCode="
                + lineOfBusinessCode + ", sourceApplication=" + sourceApplication + "]";
    }

}
