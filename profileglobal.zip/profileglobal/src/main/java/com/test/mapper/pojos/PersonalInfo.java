package com.test.mapper.pojos;

public class PersonalInfo {

    private String sourceId;

    private String lastName;

    private String occupation;

    private String userStatus;

    private String gender;

    private String visaExpiration;

    private String prefix;

    private String employerName;

    private String ownerCoUserId;

    private String suffix;

    private String salary;

    private String employmentStatus;

    private String ssn;

    private String poaCoUserId;

    private String countryOfBirth;

    private String preferredName;

    private String last4Ssn;

    private String userSource;

    private String citizenship;

    private String userType;

    private String dateOfBirth;

    private String visaType;

    private String permanentResident;

    private String firstName;

    private String deleted;

    private String profilePhotoLink;

    private String middleName;

    private String position;

    private String euResidentFlag;

    private String maritalStatus;

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getVisaExpiration() {
        return visaExpiration;
    }

    public void setVisaExpiration(String visaExpiration) {
        this.visaExpiration = visaExpiration;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getOwnerCoUserId() {
        return ownerCoUserId;
    }

    public void setOwnerCoUserId(String ownerCoUserId) {
        this.ownerCoUserId = ownerCoUserId;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getPoaCoUserId() {
        return poaCoUserId;
    }

    public void setPoaCoUserId(String poaCoUserId) {
        this.poaCoUserId = poaCoUserId;
    }

    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public String getLast4Ssn() {
        return last4Ssn;
    }

    public void setLast4Ssn(String last4Ssn) {
        this.last4Ssn = last4Ssn;
    }

    public String getUserSource() {
        return userSource;
    }

    public void setUserSource(String userSource) {
        this.userSource = userSource;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getVisaType() {
        return visaType;
    }

    public void setVisaType(String visaType) {
        this.visaType = visaType;
    }

    public String getPermanentResident() {
        return permanentResident;
    }

    public void setPermanentResident(String permanentResident) {
        this.permanentResident = permanentResident;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getProfilePhotoLink() {
        return profilePhotoLink;
    }

    public void setProfilePhotoLink(String profilePhotoLink) {
        this.profilePhotoLink = profilePhotoLink;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getEuResidentFlag() {
        return euResidentFlag;
    }

    public void setEuResidentFlag(String euResidentFlag) {
        this.euResidentFlag = euResidentFlag;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    @Override
    public String toString() {
        return "PersonalInfo [sourceId=" + sourceId + ", lastName=" + lastName + ", occupation=" + occupation
                + ", userStatus=" + userStatus + ", gender=" + gender + ", visaExpiration=" + visaExpiration
                + ", prefix=" + prefix + ", employerName=" + employerName + ", ownerCoUserId=" + ownerCoUserId
                + ", suffix=" + suffix + ", salary=" + salary + ", employmentStatus=" + employmentStatus + ", ssn="
                + ssn + ", poaCoUserId=" + poaCoUserId + ", countryOfBirth=" + countryOfBirth + ", preferredName="
                + preferredName + ", last4Ssn=" + last4Ssn + ", userSource=" + userSource + ", citizenship="
                + citizenship + ", userType=" + userType + ", dateOfBirth=" + dateOfBirth + ", visaType=" + visaType
                + ", permanentResident=" + permanentResident + ", firstName=" + firstName + ", deleted=" + deleted
                + ", profilePhotoLink=" + profilePhotoLink + ", middleName=" + middleName + ", position=" + position
                + ", euResidentFlag=" + euResidentFlag + ", maritalStatus=" + maritalStatus + "]";
    }


}
