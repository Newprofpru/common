package com.test.mapper.pojos;

public class TypeCode {

}
