package com.test.mapper.pojos;

import com.test.mapper.pojos.COUser;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERPREFERENCE"
)
public class UserPreference implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERPREFERENCEID",
            unique = true,
            nullable = false
    )
    private long userPreferenceId;
    @Column(
            name = "CONTRACTID",
            length = 30
    )
    private String contractId;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "LINEOFBUSINESSCODE",
            length = 30
    )
    private String lineOfBusinessCode;
    @Column(
            name = "PREFERENCECONTEXTCODE",
            length = 100
    )
    private String preferenceContextCode;
    @Column(
            name = "PREFERENCEKEY",
            length = 250
    )
    private String preferenceKey;
    @Column(
            name = "PREFERENCETYPECODE",
            length = 100
    )
    private String preferenceTypeCode;
    @Column(
            name = "PREFERENCEVALUE",
            length = 250
    )
    private String preferenceValue;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser couser;

    public UserPreference() {
    }

    public long getUserPreferenceId() {
        return this.userPreferenceId;
    }

    public void setUserPreferenceId(long userPreferenceId) {
        this.userPreferenceId = userPreferenceId;
    }

    public String getContractId() {
        return this.contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getLineOfBusinessCode() {
        return this.lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getPreferenceContextCode() {
        return this.preferenceContextCode;
    }

    public void setPreferenceContextCode(String preferenceContextCode) {
        this.preferenceContextCode = preferenceContextCode;
    }

    public String getPreferenceKey() {
        return this.preferenceKey;
    }

    public void setPreferenceKey(String preferenceKey) {
        this.preferenceKey = preferenceKey;
    }

    public String getPreferenceTypeCode() {
        return this.preferenceTypeCode;
    }

    public void setPreferenceTypeCode(String preferenceTypeCode) {
        this.preferenceTypeCode = preferenceTypeCode;
    }

    public String getPreferenceValue() {
        return this.preferenceValue;
    }

    public void setPreferenceValue(String preferenceValue) {
        this.preferenceValue = preferenceValue;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public com.test.mapper.pojos.COUser getCouser() {
        return this.couser;
    }

    public void setCouser(COUser couser) {
        this.couser = couser;
    }
}
