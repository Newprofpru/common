package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.UserAddress;
import com.test.mapper.pojos.UserContact;
import com.test.mapper.pojos.UserContractProfile;
import com.test.mapper.pojos.UserPreference;
import com.test.mapper.pojos.UserRelation;
import com.test.mapper.pojos.UserSSO;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "COUSER"
)
@JsonIgnoreProperties(
        ignoreUnknown = true,
        value = {"last4SSN", "employeeId", "loginName", "socialSecurityNumber", "ssnHash", "taxpayerId"}
)
public class COUser implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "COUSERID",
            unique = true,
            nullable = false
    )
    private long coUserId;
    @Lob
    @Column(
            name = "ADDITIONALINFO"
    )
    private String additionalInfo;
    @Column(
            name = "ANNUALINCOME",
            length = 50
    )
    private String annualIncome;
    @Column(
            name = "COAPPLICANT",
            length = 50
    )
    private String coApplicant;
    @Column(
            name = "COMPANYSYMBOL",
            length = 30
    )
    private String companySymbol;
    @Column(
            name = "CONTROLPERSON",
            length = 150
    )
    private String controlPerson;
    @Column(
            name = "COUNTRYOFBIRTH",
            length = 50
    )
    private String countryOfBirth;
    @Column(
            name = "COUNTRYOFCITIZENSHIPCODE",
            length = 3
    )
    private String countryOfCitizenshipCode;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "CURRENCYCODE",
            length = 10
    )
    private String currencyCode;
    @Column(
            name = "DATEOFBIRTH"
    )
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Column(
            name = "DECEASEDDATE"
    )
    @Temporal(TemporalType.TIMESTAMP)
    private Date deceasedDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "EMPLOYEEID",
            length = 100
    )
    private String employeeId;
    @Column(
            name = "EMPLOYER",
            length = 200
    )
    private String employer;
    @Column(
            name = "EMPLOYERNAME",
            length = 100
    )
    private String employerName;
    @Column(
            name = "EMPLOYMENTPOSITION",
            length = 50
    )
    private String employmentPosition;
    @Column(
            name = "EMPLOYMENTSTATUSCODE",
            length = 50
    )
    private String employmentStatusCode;
    @Column(
            name = "EURESIDENTFLAG",
            length = 20
    )
    private String euResidentFlag;
    @Column(
            name = "FILESETID"
    )
    private Long filesetId;
    @Column(
            name = "FINRAAFFILIATED",
            length = 1
    )
    private String finraAffiliated;
    @Column(
            name = "FIRMNAME",
            length = 20
    )
    private String firmName;
    @Column(
            name = "FIRSTNAME",
            length = 100
    )
    private String firstName;
    @Column(
            name = "GENDERCODE",
            length = 20
    )
    private String genderCode;
    @Column(
            name = "INVESTMENTEXPERIENCE",
            length = 30
    )
    private String investmentExperience;
    @Column(
            name = "INVESTMENTOBJECTIVE",
            length = 100
    )
    private String investmentObjective;
    @Transient
    @Column(
            name = "LAST4SSN",
            length = 4
    )
    private String last4SSN;
    @Column(
            name = "LASTNAME",
            length = 100
    )
    private String lastName;
    @Column(
            name = "LIQUIDITYNEEDS",
            length = 50
    )
    private String liquidityNeeds;
    @Column(
            name = "LIQUIDNETWORTH",
            length = 50
    )
    private String liquidNetWorth;
    @Column(
            name = "LOGINNAME",
            length = 200
    )
    private String loginName;
    @Column(
            name = "LONGTERMCARE",
            length = 1
    )
    private String longTermCare;
    @Column(
            name = "MARITALSTATUSCODE",
            length = 20
    )
    private String maritalStatusCode;
    @Column(
            name = "MIDDLENAME",
            length = 100
    )
    private String middleName;
    @Column(
            name = "NONRESIDENTALIEN",
            length = 1
    )
    private String nonResidentAlien;
    @Column(
            name = "OCCUPATION",
            length = 50
    )
    private String occupation;
    @Column(
            name = "ORGANIZATION",
            length = 100
    )
    private String organization;
    @Column(
            name = "ORGANIZATIONCOUNTRYCODE",
            length = 5
    )
    private String organizationCountryCode;
    @Column(
            name = "PERMANANTRESIDENT",
            length = 1
    )
    private String permanantResident;
    @Column(
            name = "POLITICALAFFILIATEDRELTYPECODE",
            length = 10
    )
    private String politicalAffiliatedRelTypeCode;
    @Column(
            name = "POLITICALLYEXPOSED",
            length = 1
    )
    private String politicallyExposed;
    @Column(
            name = "PREFERREDLANGUAGECODE",
            length = 20
    )
    private String preferredLanguageCode;
    @Column(
            name = "PREFFEREDNAME",
            length = 100
    )
    private String prefferedName;
    @Column(
            name = "PREFIXNAME",
            length = 100
    )
    private String prefixName;
    @Temporal(TemporalType.DATE)
    @Column(
            name = "PRIVACYNOTICEDATE"
    )
    private Date privacyNoticeDate;
    @Column(
            name = "PROFDESIG",
            length = 100
    )
    private String profDesig;
    @Column(
            name = "PROFILEPHOTOLOCATION",
            length = 500
    )
    private String profilePhotoLocation;
    @Column(
            name = "RAWNAME",
            length = 250
    )
    private String rawName;
    @Column(
            name = "RELATIONSHIPTYPECODE",
            length = 20
    )
    private String relationshipTypeCode;
    @Column(
            name = "RISKTOLERANCE",
            length = 50
    )
    private String riskTolerance;
    @Column(
            name = "SINCEDATE"
    )
    @Temporal(TemporalType.TIMESTAMP)
    private Date sinceDate;
    @Transient
    @Basic(
            fetch = FetchType.LAZY
    )
    @Column(
            name = "SOCIALSECURITYNUMBER"
    )
    private byte[] socialSecurityNumber;
    @Column(
            name = "SOURCEID",
            length = 50
    )
    private String sourceId;
    @Transient
    @Basic(
            fetch = FetchType.LAZY
    )
    @Column(
            name = "SSNHASH"
    )
    private byte[] ssnHash;
    @Column(
            name = "SSOID"
    )
    private Long ssoId;
    @Column(
            name = "SUFFIXNAME",
            length = 100
    )
    private String suffixName;
    @Column(
            name = "TAXBRACKET",
            length = 30
    )
    private String taxBracket;
    @Transient
    @Basic(
            fetch = FetchType.LAZY
    )
    @Column(
            name = "TAXPAYERID"
    )
    private byte[] taxpayerId;
    @Column(
            name = "TIMEHORIZON",
            length = 30
    )
    private String timeHorizon;
    @Column(
            name = "TOTALNETWORTH",
            length = 50
    )
    private String totalNetWorth;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Column(
            name = "USCITIZENSHIP",
            length = 1
    )
    private String usCitizenship;
    @Column(
            name = "USERSOURCECODE",
            nullable = false,
            length = 20
    )
    private String userSourceCode;
    @Column(
            name = "USERSTATUSCODE",
            length = 20
    )
    private String userStatusCode;
    @Column(
            name = "USERTYPECODE",
            length = 20
    )
    private String userTypeCode;
    @Temporal(TemporalType.DATE)
    @Column(
            name = "VISAEXPIRATION"
    )
    private Date visaExpiration;
    @Column(
            name = "VISATYPECODE",
            length = 20
    )
    private String visaTypeCode;
    @ManyToOne
    @JoinColumn(
            name = "LINKEDUSERID"
    )
    private com.test.mapper.pojos.COUser couser;
    @OneToMany(
            mappedBy = "couser"
    )
    private List<UserPreference> userPreferences;
    @OneToMany(
            mappedBy = "coUser"
    )
    private List<UserSSO> userSSOs;
    @OneToMany(
            mappedBy = "coUser"
    )
    private List<com.test.mapper.pojos.UserContact> userContacts;
    @OneToMany(
            mappedBy = "coUser"
    )
    private List<UserRelation> userRelations;
    @OneToMany(
            mappedBy = "coUser"
    )
    private List<UserAddress> userAddresses;
    @OneToMany(
            mappedBy = "coUser"
    )
    private List<UserContractProfile> userContractProfiles;

    public COUser() {
    }

    public String getAdditionalInfo() {
        return this.additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getAnnualIncome() {
        return this.annualIncome;
    }

    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getCoApplicant() {
        return this.coApplicant;
    }

    public void setCoApplicant(String coApplicant) {
        this.coApplicant = coApplicant;
    }

    public String getCompanySymbol() {
        return this.companySymbol;
    }

    public void setCompanySymbol(String companySymbol) {
        this.companySymbol = companySymbol;
    }

    public String getControlPerson() {
        return this.controlPerson;
    }

    public void setControlPerson(String controlPerson) {
        this.controlPerson = controlPerson;
    }

    public String getCountryOfBirth() {
        return this.countryOfBirth;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public String getCountryOfCitizenshipCode() {
        return this.countryOfCitizenshipCode;
    }

    public void setCountryOfCitizenshipCode(String countryOfCitizenshipCode) {
        this.countryOfCitizenshipCode = countryOfCitizenshipCode;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Date getDeceasedDate() {
        return this.deceasedDate;
    }

    public void setDeceasedDate(Date deceasedDate) {
        this.deceasedDate = deceasedDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getEmployeeId() {
        return this.employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployer() {
        return this.employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public String getEmployerName() {
        return this.employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getEmploymentPosition() {
        return this.employmentPosition;
    }

    public void setEmploymentPosition(String employmentPosition) {
        this.employmentPosition = employmentPosition;
    }

    public String getEmploymentStatusCode() {
        return this.employmentStatusCode;
    }

    public void setEmploymentStatusCode(String employmentStatusCode) {
        this.employmentStatusCode = employmentStatusCode;
    }

    public String getEuResidentFlag() {
        return this.euResidentFlag;
    }

    public void setEuResidentFlag(String euResidentFlag) {
        this.euResidentFlag = euResidentFlag;
    }

    public Long getFilesetId() {
        return this.filesetId;
    }

    public void setFilesetId(Long filesetId) {
        this.filesetId = filesetId;
    }

    public String getFinraAffiliated() {
        return this.finraAffiliated;
    }

    public void setFinraAffiliated(String finraAffiliated) {
        this.finraAffiliated = finraAffiliated;
    }

    public String getFirmName() {
        return this.firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGenderCode() {
        return this.genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    public String getInvestmentExperience() {
        return this.investmentExperience;
    }

    public void setInvestmentExperience(String investmentExperience) {
        this.investmentExperience = investmentExperience;
    }

    public String getInvestmentObjective() {
        return this.investmentObjective;
    }

    public void setInvestmentObjective(String investmentObjective) {
        this.investmentObjective = investmentObjective;
    }

    public String getLast4SSN() {
        return this.last4SSN;
    }

    public void setLast4SSN(String last4ssn) {
        this.last4SSN = last4ssn;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLiquidityNeeds() {
        return this.liquidityNeeds;
    }

    public void setLiquidityNeeds(String liquidityNeeds) {
        this.liquidityNeeds = liquidityNeeds;
    }

    public String getLiquidNetWorth() {
        return this.liquidNetWorth;
    }

    public void setLiquidNetWorth(String liquidNetWorth) {
        this.liquidNetWorth = liquidNetWorth;
    }

    public String getLoginName() {
        return this.loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getLongTermCare() {
        return this.longTermCare;
    }

    public void setLongTermCare(String longTermCare) {
        this.longTermCare = longTermCare;
    }

    public String getMaritalStatusCode() {
        return this.maritalStatusCode;
    }

    public void setMaritalStatusCode(String maritalStatusCode) {
        this.maritalStatusCode = maritalStatusCode;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getNonResidentAlien() {
        return this.nonResidentAlien;
    }

    public void setNonResidentAlien(String nonResidentAlien) {
        this.nonResidentAlien = nonResidentAlien;
    }

    public String getOccupation() {
        return this.occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getOrganization() {
        return this.organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getOrganizationCountryCode() {
        return this.organizationCountryCode;
    }

    public void setOrganizationCountryCode(String organizationCountryCode) {
        this.organizationCountryCode = organizationCountryCode;
    }

    public String getPermanantResident() {
        return this.permanantResident;
    }

    public void setPermanantResident(String permanantResident) {
        this.permanantResident = permanantResident;
    }

    public String getPoliticalAffiliatedRelTypeCode() {
        return this.politicalAffiliatedRelTypeCode;
    }

    public void setPoliticalAffiliatedRelTypeCode(String politicalAffiliatedRelTypeCode) {
        this.politicalAffiliatedRelTypeCode = politicalAffiliatedRelTypeCode;
    }

    public String getPoliticallyExposed() {
        return this.politicallyExposed;
    }

    public void setPoliticallyExposed(String politicallyExposed) {
        this.politicallyExposed = politicallyExposed;
    }

    public String getPreferredLanguageCode() {
        return this.preferredLanguageCode;
    }

    public void setPreferredLanguageCode(String preferredLanguageCode) {
        this.preferredLanguageCode = preferredLanguageCode;
    }

    public String getPrefferedName() {
        return this.prefferedName;
    }

    public void setPrefferedName(String prefferedName) {
        this.prefferedName = prefferedName;
    }

    public String getPrefixName() {
        return this.prefixName;
    }

    public void setPrefixName(String prefixName) {
        this.prefixName = prefixName;
    }

    public Date getPrivacyNoticeDate() {
        return this.privacyNoticeDate;
    }

    public void setPrivacyNoticeDate(Date privacyNoticeDate) {
        this.privacyNoticeDate = privacyNoticeDate;
    }

    public String getProfDesig() {
        return this.profDesig;
    }

    public void setProfDesig(String profDesig) {
        this.profDesig = profDesig;
    }

    public String getProfilePhotoLocation() {
        return this.profilePhotoLocation;
    }

    public void setProfilePhotoLocation(String profilePhotoLocation) {
        this.profilePhotoLocation = profilePhotoLocation;
    }

    public String getRawName() {
        return this.rawName;
    }

    public void setRawName(String rawName) {
        this.rawName = rawName;
    }

    public String getRelationshipTypeCode() {
        return this.relationshipTypeCode;
    }

    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }

    public String getRiskTolerance() {
        return this.riskTolerance;
    }

    public void setRiskTolerance(String riskTolerance) {
        this.riskTolerance = riskTolerance;
    }

    public Date getSinceDate() {
        return this.sinceDate;
    }

    public void setSinceDate(Date sinceDate) {
        this.sinceDate = sinceDate;
    }

    public byte[] getSocialSecurityNumber() {
        return this.socialSecurityNumber;
    }

    public void setSocialSecurityNumber(byte[] socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    public String getSourceId() {
        return this.sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public byte[] getSsnHash() {
        return this.ssnHash;
    }

    public void setSsnHash(byte[] ssnHash) {
        this.ssnHash = ssnHash;
    }

    public Long getSsoId() {
        return this.ssoId;
    }

    public void setSsoId(Long ssoId) {
        this.ssoId = ssoId;
    }

    public String getSuffixName() {
        return this.suffixName;
    }

    public void setSuffixName(String suffixName) {
        this.suffixName = suffixName;
    }

    public String getTaxBracket() {
        return this.taxBracket;
    }

    public void setTaxBracket(String taxBracket) {
        this.taxBracket = taxBracket;
    }

    public byte[] getTaxpayerId() {
        return this.taxpayerId;
    }

    public void setTaxpayerId(byte[] taxpayerId) {
        this.taxpayerId = taxpayerId;
    }

    public String getTimeHorizon() {
        return this.timeHorizon;
    }

    public void setTimeHorizon(String timeHorizon) {
        this.timeHorizon = timeHorizon;
    }

    public String getTotalNetWorth() {
        return this.totalNetWorth;
    }

    public void setTotalNetWorth(String totalNetWorth) {
        this.totalNetWorth = totalNetWorth;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUsCitizenship() {
        return this.usCitizenship;
    }

    public void setUsCitizenship(String usCitizenship) {
        this.usCitizenship = usCitizenship;
    }

    public String getUserSourceCode() {
        return this.userSourceCode;
    }

    public void setUserSourceCode(String userSourceCode) {
        this.userSourceCode = userSourceCode;
    }

    public String getUserStatusCode() {
        return this.userStatusCode;
    }

    public void setUserStatusCode(String userStatusCode) {
        this.userStatusCode = userStatusCode;
    }

    public String getUserTypeCode() {
        return this.userTypeCode;
    }

    public void setUserTypeCode(String userTypeCode) {
        this.userTypeCode = userTypeCode;
    }

    public Date getVisaExpiration() {
        return this.visaExpiration;
    }

    public void setVisaExpiration(Date visaExpiration) {
        this.visaExpiration = visaExpiration;
    }

    public String getVisaTypeCode() {
        return this.visaTypeCode;
    }

    public void setVisaTypeCode(String visaTypeCode) {
        this.visaTypeCode = visaTypeCode;
    }

    public com.test.mapper.pojos.COUser getCouser() {
        return this.couser;
    }

    public void setCouser(com.test.mapper.pojos.COUser couser) {
        this.couser = couser;
    }

    public List<UserPreference> getUserpreferences() {
        return this.userPreferences;
    }

    public void setUserpreferences(List<UserPreference> userpreferences) {
        this.userPreferences = userpreferences;
    }

    public List<UserSSO> getUserssos() {
        return this.userSSOs;
    }

    public void setUserssos(List<UserSSO> userSSOs) {
        this.userSSOs = userSSOs;
    }

    public long getCoUserId() {
        return this.coUserId;
    }

    public void setCoUserId(long coUserId) {
        this.coUserId = coUserId;
    }

    public List<UserSSO> getUserSSOs() {
        return this.userSSOs;
    }

    public void setUserSSOs(List<UserSSO> userSSOs) {
        this.userSSOs = userSSOs;
    }

    public List<com.test.mapper.pojos.UserContact> getUsercontacts() {
        return this.userContacts;
    }

    public void setUsercontacts(List<UserContact> userContacts) {
        this.userContacts = userContacts;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
