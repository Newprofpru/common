package com.test.mapper.pojos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.pojos.COUser;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(
        schema = "CUSTOMERDB",
        name = "USERRELATION"
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class UserRelation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(
            name = "USERRELATIONID",
            unique = true,
            nullable = false
    )
    private long userRelationId;
    @Column(
            name = "CONTRACTID",
            length = 30
    )
    private String contractId;
    @Column(
            name = "CREATEDBY",
            length = 100
    )
    private String createdBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "CREATEDDATE",
            nullable = false
    )
    private Date createdDate;
    @Column(
            name = "DELETED",
            nullable = false,
            length = 1
    )
    private String deleted;
    @Column(
            name = "LINEOFBUSINESSCODE",
            length = 30
    )
    private String lineOfBusinessCode;
    @Column(
            name = "RELATEDCOUSERID",
            nullable = false
    )
    private long relatedCOUserId;
    @Column(
            name = "RELATIONSHIPTYPECODE",
            length = 20
    )
    private String relationshipTypeCode;
    @Column(
            name = "UPDATEDBY",
            length = 100
    )
    private String updatedBy;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "UPDATEDDATE",
            nullable = false
    )
    private Date updatedDate;
    @ManyToOne
    @JoinColumn(
            name = "COUSERID",
            nullable = false
    )
    private com.test.mapper.pojos.COUser coUser;

    public UserRelation() {
    }

    public long getUserRelationId() {
        return this.userRelationId;
    }

    public void setUserRelationId(long userRelationId) {
        this.userRelationId = userRelationId;
    }

    public String getContractId() {
        return this.contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleted() {
        return this.deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getLineOfBusinessCode() {
        return this.lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public long getRelatedCOUserId() {
        return this.relatedCOUserId;
    }

    public void setRelatedCOUserId(long relatedCOUserId) {
        this.relatedCOUserId = relatedCOUserId;
    }

    public String getRelationshipTypeCode() {
        return this.relationshipTypeCode;
    }

    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public com.test.mapper.pojos.COUser getCoUser() {
        return this.coUser;
    }

    public void setCoUser(COUser coUser) {
        this.coUser = coUser;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
