package com.test.mapper.utils;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import java.sql.SQLException;
import java.util.List;

public class DBUtil {

    private static HikariCustomDataConfig dataConfig = new HikariCustomDataConfig();
    static {
        System.getProperties().setProperty("oracle.jdbc.J2EE13Compliant", "true");
    }
    static QueryRunner runner = new QueryRunner(dataConfig.dataSource());
    public static <T> List<T> executeQuery(String query, Class cl, String ... param) throws SQLException {
        ResultSetHandler<List<T>> rsh = new BeanListHandler<T>(cl);
        return runner.query(query, rsh, param);
    }
}


