package com.test.mapper.api;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.test.mapper.pojos.HeaderList;
import com.test.mapper.pojos.ProfileV4;
import com.test.mapper.utils.EnvInfo;
import com.test.mapper.utils.GenerateTokenUtils;

import cucumber.api.DataTable;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * @author Aditya Jamwal
 */
public class ProfileV4API extends BaseAPI<ProfileV4> {

    public static final String PATH = "/profiles/v4/profile";

    private Random rand = new Random();

    private static Logger logger = LogManager.getLogger();
    private EnvInfo envInfo = EnvInfo.getInstance();

    String request;

    RequestSpecification requestSpecification = null;

    String requestID = "CreateProfile";
    
    String authorization = "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==";
    
    String authorizationAmlu = envInfo.getAmluAuthorization();

    private GenerateTokenUtils generateTokenUtils = new GenerateTokenUtils();

    public Response createRequest(ProfileV4 profileCreate) {

        Map<String, Object> headerMap = new HashMap<String, Object>();

        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);


        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).headers(headers).contentType(ContentType.JSON).body(profileCreate).post(getBaseURI() + PATH).andReturn();
    }

    public Response updateRequest(ProfileV4 profileUpdate) {

        Map<String, Object> headerMap = new HashMap<String, Object>();


        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);


        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).headers(headers).contentType(ContentType.JSON).body(profileUpdate).put(getBaseURI() + PATH).andReturn();
    }

    public Response getRequest(String coUserId) {

        Map<String, Object> headerMap = new HashMap<String, Object>();

        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);

        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).header("X-Pru-Imp-CO-USER-ID", coUserId).header("X-PruPrimaryIdentity", "X221432").contentType(ContentType.JSON).get(getBaseURI() + PATH + "?coUserId=" + coUserId + "&profileType=all&sections=contactChannels,contactAddresses").andReturn();
    }

    public Response getRequestSsoId(String ssoId, String user, String password) {

        Map<String, Object> headerMap = new HashMap<String, Object>();

        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);

        String jwt = generateTokenUtils.getJWTAuthToken(user,password);
        logger.info("jwt " + jwt);
        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).header("X-PruPrimaryIdentity",ssoId).header("X-PruAuthJWT", jwt).contentType(ContentType.JSON).get(getBaseURI() + PATH + "?ssoId=" + ssoId + "&profileType=all&sections=personalInfo,contactChannels,contactAddresses,disclosures,suitability,investmentInfo,trustedContactPerson,employers,userRelations").andReturn();
    }

    public Response getRequestIdWithParams(String ssoId, String user, String password, DataTable parameters){
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        String jwt = generateTokenUtils.getJWTAuthToken(user,password);
        RequestSpecification request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", authorization)
                .header("X-Forwarded-For", "0.0.0.0")
                .header("X-PruAuthJWT", jwt);
        for(String paramName:paramNames){
            if(paramName.equalsIgnoreCase("Header_ssoId"))
                request.header("X-PruPrimaryIdentity",data.get(paramName) );
            else
                request.param(paramName,data.get(paramName));
        }
        Response Res1 = request.when().get().andReturn();
        logger.info("Response----->:" + Res1.prettyPrint());
        logger.info(Res1.asString());
        return Res1;
    }
    
    public Response getRequestWithParams(DataTable parameters, String authorization){
        Map<String, String>data = parameters.asMap(String.class, String.class);
        Set<String> paramNames=data.keySet();
        logger.info("In When");
        RequestSpecification request = given().log().all()
				.header("X-PruRequestId", requestID)
				.header("Authorization", authorization)
				.header("X-Forwarded-For", "0.0.0.0")
				.header("X-PruPrimaryIdentity", "X223793");
		for(String paramName:paramNames){
			if(paramName.equalsIgnoreCase("ssoId")){
				request.header("X-PruImpersonatedIdentity",data.get(paramName));
				request.param(paramName,data.get(paramName));}
			else if(paramName.equalsIgnoreCase("coUserId"))	{			
				request.header("X-Pru-Imp-CO-USER-ID",data.get(paramName) );
				request.param(paramName,data.get(paramName));}
			else
				request.param(paramName,data.get(paramName));
		}
		
		Response Res1 = request.when().contentType(ContentType.JSON).get(getBaseURI() + PATH ).andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
        return Res1;
    }

    public Response updateRequest(ProfileV4 profileUpdate, HeaderList headerList) {
        return given().log().all().headers(headerList.getHeaders()).contentType(ContentType.JSON).body(profileUpdate).put(getBaseURI() + PATH).andReturn();
    }

    public Response updateRequestWithParams(ProfileV4 profileUpdate, String coUserId) {

        Map<String, Object> headerMap = new HashMap<String, Object>();


        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);

        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();

        String requestID = "V2_Update_Prof" + n;
        setRequestId(requestID);
        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).header("X-Pru-Imp-CO-USER-ID", coUserId).header("X-PruPrimaryIdentity", "X221432").headers(headers).contentType(ContentType.JSON).body(profileUpdate).put(getBaseURI() + PATH).andReturn();
    }

    public Response updateRequestWithParamsNormal(ProfileV4 profileUpdate, String ssoId, String user, String password) {

        Map<String, Object> headerMap = new HashMap<String, Object>();


        List<Header> headerList = new ArrayList<>();
        Headers headers = new Headers(headerList);

        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();

        String requestID = "V2_Update_Prof" + n;
        setRequestId(requestID);
        logger.info("user23" + user);
        logger.info("pass23" + password);
        String jwt = generateTokenUtils.getJWTAuthToken(user,password);

        logger.info("jwt23" + jwt);
        return given().log().all().header("X-PruRequestId", requestID)
                .header("Authorization", authorization).header("X-PruPrimaryIdentity",ssoId).header("X-PruAuthJWT", jwt).headers(headers).contentType(ContentType.JSON).body(profileUpdate).put(getBaseURI() + PATH).andReturn();
    }

    public String getRequestId(){
        return request;
    }

    public void setRequestId(String request){
        this.request = request;
    }
}
