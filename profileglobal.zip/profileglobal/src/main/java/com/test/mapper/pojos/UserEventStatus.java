package com.test.mapper.pojos;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;

public class UserEventStatus implements Serializable {
    private static final long serialVersionUID = 1L;

    private long userEventStatusId;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    private String deleted;

    private String caseId;

    private String transactionId;

    private Long coUserId;

    private String lifeOfBusinessCode;

    private String lineOfBusinessCodeDescription;

    private String contractId;

    private String eventType;

    private String eventData;

    private Long eventStatusCode;

    private String eventStatusDescription;

    private String transactionTypeCode;

    private String transactionMessage;

    private String eventSubType;

    private String groupTransactionId;

    private String transactionDescription;

    private String requestId;

    private String action;

    public UserEventStatus() { }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public long getUserEventStatusId() {
        return userEventStatusId;
    }

    public void setUserEventStatusId(long userEventStatusId) {
        this.userEventStatusId = userEventStatusId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Long getCoUserId() {
        return coUserId;
    }

    public void setCoUserId(Long coUserId) {
        this.coUserId = coUserId;
    }

    public String getLifeOfBusinessCode() {
        return lifeOfBusinessCode;
    }

    public void setLifeOfBusinessCode(String lifeOfBusinessCode) {
        this.lifeOfBusinessCode = lifeOfBusinessCode;
    }

    public String getLineOfBusinessCodeDescription() {
        return lineOfBusinessCodeDescription;
    }

    public void setLineOfBusinessCodeDescription(String lineOfBusinessCodeDescription) {
        this.lineOfBusinessCodeDescription = lineOfBusinessCodeDescription;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventData() {
        return eventData;
    }

    public void setEventData(String eventData) {
        this.eventData = eventData;
    }

    public Long getEventStatusCode() {
        return eventStatusCode;
    }

    public void setEventStatusCode(Long eventStatusCode) {
        this.eventStatusCode = eventStatusCode;
    }

    public String getEventStatusDescription() {
        return eventStatusDescription;
    }

    public void setEventStatusDescription(String eventStatusDescription) {
        this.eventStatusDescription = eventStatusDescription;
    }

    public String getTransactionTypeCode() {
        return transactionTypeCode;
    }

    public void setTransactionTypeCode(String transactionTypeCode) {
        this.transactionTypeCode = transactionTypeCode;
    }

    public String getTransactionMessage() {
        return transactionMessage;
    }

    public void setTransactionMessage(String transactionMessage) {
        this.transactionMessage = transactionMessage;
    }

    public String getEventSubType() {
        return eventSubType;
    }

    public void setEventSubType(String eventSubType) {
        this.eventSubType = eventSubType;
    }

    public String getGroupTransactionId() {
        return groupTransactionId;
    }

    public void setGroupTransactionId(String groupTransactionId) {
        this.groupTransactionId = groupTransactionId;
    }

    public String getTransactionDescription() {
        return transactionDescription;
    }

    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (IOException var2) {
            var2.printStackTrace();
            return super.toString();
        }
    }
}
