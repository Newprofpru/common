package com.DocuVault.stepDefinitions;

import com.DocuVault.RequestBodyPojo.PostDocumentMetaDataPojo;
import com.DocuVault.CommonComponent.Payload.CreateDocumentMetaDataPayload;
import com.DocuVault.supportLibraries.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import io.restassured.specification.RequestSpecification;
import org.junit.Assert;


public class PostDocumentMetaData {
    static String requestId;
    static String SecureUrlQAPostDocumentMetaDatURL = getEnvInfo.SecureUrlPostDocumentMetaData();
    static RequestSpecification request;
    String authorization = getEnvInfo.getAuthorization();
    static Response response;
    static String userDocumentId;
    static String docName;
    static int docId;


    @Given("^The UserShould be able to upload the Document in the Metadata$")
    public void the_UserShould_be_able_to_upload_the_Document_in_the_Metadata() throws Throwable {
        requestId = PruRequestId.pruRequestId();
        System.out.println("URL:" + SecureUrlQAPostDocumentMetaDatURL);
    }

    @When("^The User send the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void the_User_send_the(String documentName,
                                  String documentCategoryName,
                                  String documentLink,
                                  String contractId,
                                  String documentDescription,
                                  String documentSourceCode,
                                  String documentSourceId,
                                  String lineOfBusinessCode,
                                  String expirationDate,
                                  String processedDate,
                                  String effectiveDate) throws Throwable {


        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        RestAssured.baseURI = SecureUrlQAPostDocumentMetaDatURL;
        requestId = PruRequestId.pruRequestId();
        ObjectMapper mapper = new ObjectMapper();
        String payload = null;
        PostDocumentMetaDataPojo postDocumentMetaDataPojo = new PostDocumentMetaDataPojo();
        postDocumentMetaDataPojo.setDocumentSourceId(requestId);
        documentSourceId = postDocumentMetaDataPojo.getDocumentSourceId();
        postDocumentMetaDataPojo.setDocumentName(requestId+documentName);
        documentName = postDocumentMetaDataPojo.getDocumentName();
        docName = documentName;
        payload = mapper.writeValueAsString(CreateDocumentMetaDataPayload.CreateDocumentMetaDataPayload(documentName, documentCategoryName, documentLink, contractId, documentDescription, null, documentSourceId, lineOfBusinessCode, expirationDate, processedDate, effectiveDate));
        System.out.println("Payload:" + payload);
        request = given().log().all().contentType("application/json")
                .header("Authorization", authorization)
                .header("X-PruRequestID", requestId)
                .header("X-Pru-Imp-CO-USER-ID", getEnvInfo.getXPruImpCOUSERID())
                .header("X-PruAuthJWT", XPruAuthJWT);
        response = request.log().all().body(payload.toString()).contentType("application/json").post().andReturn();
        System.out.println("Response---->:" + response.prettyPrint());
    }

    @Then("^Validate the responseStatusCode should be \"([^\"]*)\"$")
    public void validate_the_responseStatusCode_should_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + status);
        Assert.assertEquals(status, response.getStatusCode());
    }

    @Then("^Validate the responseStatusCode should not be \"([^\"]*)\"$")
    public void validate_the_responseStatusCode_should_not_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + status);
        Assert.assertNotEquals(status, response.getStatusCode());
    }

    @Then("^Verify in the USERDOCUMENT Table and compare the Uploaded metadata$")
    public void verify_in_the_USERDOCUMENT_Table_and_compare_the_Uploaded_metadata() throws Throwable {
        JsonPath jsonPathEvaluator = response.jsonPath();
        userDocumentId = jsonPathEvaluator.getString("userDocumentId");
        System.out.println("userDocumentId---->:" + userDocumentId);
        EventDB.VerifyEventGetDocumentWithId(userDocumentId, docName);
    }

}

