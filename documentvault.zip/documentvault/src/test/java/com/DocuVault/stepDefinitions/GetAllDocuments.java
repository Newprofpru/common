package com.DocuVault.stepDefinitions;

import com.DocuVault.supportLibraries.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;

import static io.restassured.RestAssured.given;

public class GetAllDocuments {
    private static String getAlldocumentURL = getEnvInfo.SecureUrlQGetDocuments();
    static String XPruImpCOUSERID = getEnvInfo.getXPruImpCOUSERID();
    String authorization = getEnvInfo.getAuthorization();
    static RequestSpecification request;
    static Response response;
    static String requestId;
    static String userDocumentId;
    static String docName;
    static String Resbody;
    private static Logger logger = LogManager.getLogger();
    Connection con2;

    @Given("^User should be able to find the document with \"([^\"]*)\"$")
    public void user_should_be_able_to_find_the_document_with(String arg1) throws Throwable {
        System.out.println("In Given- The Test Case is:" + arg1);
    }

    @When("^User pass documentId to get the document$")
    public void user_pass_documentId_to_get_the_document() throws Throwable {
        RestAssured.baseURI = getAlldocumentURL;
        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        requestId = PruRequestId.pruRequestId();
        request = given().log().all().
                header("X-PruRequestID", requestId).
                header("Authorization", authorization).
                header("X-Pru-Imp-CO-USER-ID", XPruImpCOUSERID).
                header("X-PruAuthJWT", XPruAuthJWT);
        ;
        response = request.contentType("application/json")
                .get().andReturn();
        Resbody = response.getBody().asString();
    }

    @Then("^User should get success response \"([^\"]*)\"$")
    public void user_should_get_success_response(String responsecode) throws Throwable {
        String statusCode = Integer.toString(response.getStatusCode());
        Assert.assertEquals(responsecode, statusCode);
    }

    @And("^User Verify in the USERDOCUMENT Table and compare the given \"([^\"]*)\",\"([^\"]*)\"$")
    public void user_Verify_in_the_USERDOCUMENT_Table_and_compare_the_given(String documentId, String documentName) throws Throwable {
        JsonElement responseObject = new JsonParser().parse(Resbody);
        JsonArray documenDataArray = responseObject.getAsJsonArray();
        for (int i = 0; i < documenDataArray.size(); i++) {
            JsonObject returnDocuments = documenDataArray.get(i).getAsJsonObject();
            System.out.println("returnDocuments" + returnDocuments);
            userDocumentId = returnDocuments.get("userDocumentId").getAsString();
            System.out.println("userDocumentId " + userDocumentId);
            docName = returnDocuments.get("documentName").getAsString();
            if (userDocumentId == documentId) {
                EventDB.VerifyEventGetDocumentWithId(userDocumentId, docName);
            }
            break;
        }
    }
}
