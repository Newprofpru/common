package com.DocuVault.stepDefinitions;
import com.DocuVault.supportLibraries.DBConnection;
import com.DocuVault.supportLibraries.PruRequestId;
import com.DocuVault.supportLibraries.getEnvInfo;
import com.google.gson.JsonElement;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;

import static io.restassured.RestAssured.given;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GetDocumentCategories {
    static String SecureUrlQAGetDocumentCategories;
    static String documentCategoryURL = getEnvInfo.SecureUrlGetDocumentCategories();
    String authorization = getEnvInfo.getAuthorization();
    static RequestSpecification request;
    static Response response;
    static String requestId;
    private static Logger logger = LogManager.getLogger();
    Connection con2;

    @Given("^User retrieve document category with \"([^\"]*)\"$")
    public void want_to_retrieve_document_with(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("In Given- The Test Case is:" + arg1);
    }

    @When("^Makes the request to documentCategory-Api$")
    public void makes_the_request_to_documentCategoryd() throws Throwable {
        RestAssured.baseURI = documentCategoryURL;
        requestId = PruRequestId.pruRequestId();
        request = given().log().all().header("X-PruRequestID", requestId).header("Authorization", authorization);
        response = request.contentType("application/json")
                .get().andReturn();
    }

    @Then("^Success Response \"([^\"]*)\" should be received$")
    public void success_Response_should_be_received(String arg1) throws Throwable {
        String statusCode = Integer.toString(response.getStatusCode());

        Assert.assertEquals(arg1, statusCode);
    }

    @Then("^Retreived Values should be compared and validated with the database$")
    public void retreived_Values_should_be_compared_and_validated_with_the_database() throws Throwable {
        String Resbody = response.getBody().asString();
        String categoryName = null;
        JsonElement responseObject = new JsonParser().parse(Resbody);
        JsonArray documenDataArray = responseObject.getAsJsonArray();
        for (int i = 0; i < documenDataArray.size(); i++) {
            if (i == 0) {
                JsonObject returnDocuments = documenDataArray.get(i).getAsJsonObject();
                System.out.println("returnDocuments" + returnDocuments);
                categoryName = returnDocuments.get("documentCategoryName").getAsString();
            }
        }
        String query = "Select distinct categoryname from documentcategory";
        try {
            con2 = DBConnection.InitConnection();
            ResultSet rs = DBConnection.execStatement(con2, query);
            Assert.assertEquals(rs.getString("CategoryName"), categoryName);
        } catch (Exception e) {
            logger.info(e.getMessage());
            System.out.println("error" + e.getMessage());
        } finally {
            if (con2 != null) {
                con2.close();
            }
        }
    }
}

