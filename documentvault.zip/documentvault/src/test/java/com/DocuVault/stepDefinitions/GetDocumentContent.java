package com.DocuVault.stepDefinitions;

import com.DocuVault.supportLibraries.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import static io.restassured.RestAssured.given;

public class GetDocumentContent {
    static String requestId;
    private static String getAlldocumentURL = getEnvInfo.SecureUrlQGetDocuments();
    static RequestSpecification request;
    String authorization = getEnvInfo.getAuthorization();
    static Response response;
    static String GetDocumentContentUrl = "https://coapiaws-dev.prudential.com/co/qa/secure/documentvault/v2/document/documents/{id}/content?";

    @Given("^User Should be able to access the GetDocumentContentUrl$")
    public void User_Should_be_able_to_access_the_GetDocumentContentUrl() throws Throwable {
        requestId = PruRequestId.pruRequestId();
        System.out.println("Url---->:" + GetDocumentContentUrl);
    }

    @When("^Access the document using \"([^\"]*)\"$")
    public void Access_the_document_using(String userDocumentId)throws Throwable {
        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        RestAssured.baseURI = getAlldocumentURL + "/"+ userDocumentId + "/content?";
        request = given().header("Authorization", authorization)
                .header("X-PruRequestID", requestId)
                .header("Accept", "application/json")
                .header("context", "application/json")
                .header("X-Pru-Imp-CO-USER-ID", getEnvInfo.getXPruImpCOUSERID())
                .header("X-PruAuthJWT", XPruAuthJWT);
      response = request.get().andReturn();
        System.out.println("Response---->:" + response.prettyPrint());
    }

    @Then("^Verify the responseStatusCode should be valid \"([^\"]*)\"$")
    public void Check_the_responseStatusCode_should_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertEquals(status, response.getStatusCode());
    }

    @Then("^Verify the responseStatusCode should not be valid \"([^\"]*)\"$")
    public void Check_the_responseStatusCode_should_not_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertNotEquals(status, response.getStatusCode());
    }

    @And("^Verify in the USERDOCUMENT Table and compare the document with \"([^\"]*)\" and coUserId$")
    public void Check_in_the_USERDOCUMENT_Table_and_compare_the_Uploaded_Content(String userDocumentId) throws Throwable {
    EventDB.VerifyEventGetDocumentContent(getEnvInfo.getXPruImpCOUSERID(), userDocumentId);
    }
}
