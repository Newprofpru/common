package com.DocuVault.stepDefinitions;
import com.DocuVault.supportLibraries.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.io.FilenameUtils;
import org.junit.Assert;
import java.io.File;
import static io.restassured.RestAssured.given;


public class PostDocumentContent {
    static String requestId, documentlinkBeforePost, documentlinkAfterPost;
    static String SecureUrlQAPostDocumentMetaData = getEnvInfo.SecureUrlPostDocumentMetaData();
    static RequestSpecification request;
    String authorization = getEnvInfo.getAuthorization();
    static Response response;

    @Given("^User Should be able to get the documentLink of Document from db using \"([^\"]*)\"$")
    public void the_UserShould_be_able_to_upload_the_Document_in_the_Metadata(String userDocumentId) throws Throwable {
        requestId = PruRequestId.pruRequestId();
        documentlinkBeforePost = EventDB.VerifyEventGetDocumentContent(getEnvInfo.getXPruImpCOUSERID(),userDocumentId);
        System.out.println("documentlinkBeforePost---->:" + documentlinkBeforePost);

    }

    @When("^To upload file user send \"([^\"]*)\" and \"([^\"]*)\"$")
    public void To_Upload_file_user_send(String userDocumentId , String documentName)throws Throwable {
        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        RestAssured.baseURI = SecureUrlQAPostDocumentMetaData + userDocumentId + "/content?";
        String path = System.getProperty("user.dir")+ Util.getFileSeparator()+"src"+Util.getFileSeparator()+"test"+Util.getFileSeparator()+"java"+Util.getFileSeparator()+"com"+Util.getFileSeparator()+"DocuVault"+Util.getFileSeparator()+"CommonComponent"+Util.getFileSeparator()+ documentName;
        File file = new File(path);
        String fileExtension = FilenameUtils.getExtension(path);
        System.out.println("fileExtension---->:" + fileExtension);

        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        switch (fileExtension) {
            case "jpg":
            case "jpeg":
                requestSpecBuilder.addMultiPart("file", file, "image/jpeg");
                break;
            case "pdf":
                requestSpecBuilder.addMultiPart("file", file, "application/pdf");
                break;
            case "docx":
                requestSpecBuilder.addMultiPart("file", file, "application/msword");
                break;
            case "txt":
                requestSpecBuilder.addMultiPart("file", file, "text/plain");
                break;
        }
        RequestSpecification requestSpecification = requestSpecBuilder.build();
        request = given().header("Authorization", authorization)
                    .header("X-PruRequestID", requestId)
                    .header("Accept", "application/octet-stream")
                    .header("X-Pru-Imp-CO-USER-ID", getEnvInfo.getXPruImpCOUSERID())
                    .header("X-PruAuthJWT", XPruAuthJWT)
                    .param("file", path)
                    .formParam("file", path);

           response = request.spec(requestSpecification).post().andReturn();
       System.out.println("Response---->:" + response.prettyPrint());
    }

    @Then("^Check the responseStatusCode should be valid \"([^\"]*)\"$")
    public void Check_the_responseStatusCode_should_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertEquals(status, response.getStatusCode());
    }

    @Then("^Check the responseStatusCode should not be valid \"([^\"]*)\"$")
    public void Check_the_responseStatusCode_should_not_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertNotEquals(status, response.getStatusCode());
    }

    @And("^Check in the USERDOCUMENT Table and compare the Uploaded Content with \"([^\"]*)\" and coUserId$")
    public void Check_in_the_USERDOCUMENT_Table_and_compare_the_Uploaded_Content(String userDocumentId) throws Throwable {
        documentlinkAfterPost = EventDB.VerifyEventGetDocumentContent(getEnvInfo.getXPruImpCOUSERID(), userDocumentId);
        System.out.println("documentlinkAfterPost---->:" + documentlinkAfterPost);
        Assert.assertNotEquals(documentlinkAfterPost, documentlinkBeforePost);
    }

}
