package com.DocuVault.stepDefinitions;

import com.DocuVault.supportLibraries.EventDB;
import com.DocuVault.supportLibraries.GetJwtToken;
import com.DocuVault.supportLibraries.PruRequestId;
import com.DocuVault.supportLibraries.getEnvInfo;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.sql.Connection;
import static io.restassured.RestAssured.given;

public class GetDocumentList {

    private static String getAlldocumentURL = getEnvInfo.SecureUrlQGetDocuments();
    private static String XPruImpCOUSERID = getEnvInfo.getXPruImpCOUSERID();
    private String authorization = getEnvInfo.getAuthorization();
    private static Response response;
    private static String Resbody;
    private static Logger logger = LogManager.getLogger();
    Connection con2;

    @Given("^User should be able to pass \"([^\"]*)\",\"([^\"]*)\" along with API$")
    public void user_should_be_able_to_pass(String param, String value) throws Throwable {
        System.out.println("In Given- The Test Case is:" + getAlldocumentURL + "/?"+ param + "=" + value);
    }

    @When("^User Should be able to access the document with \"([^\"]*)\",\"([^\"]*)\"$")
    public void user_should_be_able_to_access_the_document_with(String param, String value) throws Throwable {
        RestAssured.baseURI = getAlldocumentURL + "/?"+ param + "=" + value;
        System.out.println(RestAssured.baseURI + "RestAssured.baseURI");
        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        String requestId = PruRequestId.pruRequestId();
        RequestSpecification request = given().log().all().
                header("X-PruRequestID", requestId).
                header("Authorization", authorization).
                header("X-Pru-Imp-CO-USER-ID", XPruImpCOUSERID).
                header("X-PruAuthJWT", XPruAuthJWT);
        ;
        response = request.contentType("application/json")
                .get().andReturn();
        Resbody = response.getBody().asString();
    }

    @Then("^Validate success response \"([^\"]*)\"$")
    public void validate_success_response(String responsecode) throws Throwable {
        String statusCode = Integer.toString(response.getStatusCode());
        Assert.assertEquals(responsecode, statusCode);
    }

    @Then("^Validate success response not \"([^\"]*)\" with all list of documents$")
    public void validate_success_response_should_not_be(String responsecode) throws Throwable {
        String statusCode = Integer.toString(response.getStatusCode());
        System.out.println("statusCode" + statusCode);
        Assert.assertNotEquals(responsecode, statusCode);
    }

    @And("^Compare USERDOCUMENT Table with given \"([^\"]*)\",\"([^\"]*)\"$")
    public void compare_userdocument_table_with_given(String param, String value) throws Throwable {
        JsonElement responseObject = new JsonParser().parse(Resbody);
        JsonArray documenDataArray = responseObject.getAsJsonArray();
        for (int i = 0; i < documenDataArray.size(); i++) {
            JsonObject returnDocuments = documenDataArray.get(i).getAsJsonObject();
            System.out.println("returnDocuments" + returnDocuments);
            String docId = returnDocuments.get("userDocumentId").getAsString();
            String docName = returnDocuments.get("documentName").getAsString();
                EventDB.VerifyEventGetDocumentWithId(docId, docName);
            break;
        }
    }
}
