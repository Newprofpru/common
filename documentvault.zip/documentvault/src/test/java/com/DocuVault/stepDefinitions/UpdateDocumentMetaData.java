package com.DocuVault.stepDefinitions;

import com.DocuVault.CommonComponent.Payload.UpdateDocumentMetaDataPayload;
import com.DocuVault.RequestBodyPojo.PostDocumentMetaDataPojo;
import com.DocuVault.CommonComponent.Payload.CreateDocumentMetaDataPayload;
import com.DocuVault.RequestBodyPojo.UpdateDocumentMetaDataPojo;
import com.DocuVault.supportLibraries.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import io.restassured.specification.RequestSpecification;
import org.junit.Assert;


public class UpdateDocumentMetaData {
    static String requestId;
    static String SecureUrlQAPostDocumentMetaData;
    static String SecureUrlQAPostDocumentMetaDatURL = getEnvInfo.SecureUrlPostDocumentMetaData();
    static RequestSpecification request;
    String authorization = getEnvInfo.getAuthorization();
    static Response response;
    static String userDocumentId;
    static String docName;
    static int docId;


    @Given("^Put- User should be able to update metadata$")
    public void the_UserShould_be_able_to_upload_the_Document_in_the_Metadata() throws Throwable {
        requestId = PruRequestId.pruRequestId();
        System.out.println("URL:" + SecureUrlQAPostDocumentMetaDatURL);
    }

    @When("^Put- User send the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void User_send_the(String documentName,
                                  String documentCategoryName,
                                  String documentLink,
                                  String contractId,
                                  String documentDescription,
                                  String documentSourceCode,
                                  String documentSourceId,
                                  String lineOfBusinessCode,
                                  String expirationDate,
                                  String processedDate,
                                  String effectiveDate,
                                  String subCategory) throws Throwable {


        String XPruAuthJWT = GetJwtToken.getJWTAuthToken(getEnvInfo.getUserID(), getEnvInfo.getPassword());
        RestAssured.baseURI = SecureUrlQAPostDocumentMetaDatURL + documentSourceId;
        requestId = PruRequestId.pruRequestId();
        ObjectMapper mapper = new ObjectMapper();
        String payload = null;
        payload = mapper.writeValueAsString(UpdateDocumentMetaDataPayload.updateDocMetaDataPayload(documentName, documentCategoryName, documentLink, contractId, documentDescription,documentSourceCode , documentSourceId, lineOfBusinessCode, expirationDate, processedDate, effectiveDate, subCategory));
        System.out.println("Payload:" + payload);
        request = given().log().all().contentType("application/json")
                .header("Authorization", authorization)
                .header("X-PruRequestID", requestId)
                .header("X-Pru-Imp-CO-USER-ID", getEnvInfo.getXPruImpCOUSERID())
                .header("X-PruAuthJWT", XPruAuthJWT);
        response = request.log().all().body(payload).put().andReturn();
        System.out.println("Response---->:" + response.prettyPrint());
        System.out.println("Response-sat--->:" + response.getStatusCode());
    }

    @Then("^Put- Validate the responseStatusCode should be \"([^\"]*)\"$")
    public void validate_the_responseStatusCode_should_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertEquals(status, response.getStatusCode());
    }

    @Then("^Put- Validate the responseStatusCode should not be \"([^\"]*)\"$")
    public void validate_the_responseStatusCode_should_not_be(int status) throws Throwable {
        System.out.println("responseStatusCode is:" + response.getStatusCode());
        Assert.assertNotEquals(status, response.getStatusCode());
    }

    @Then("^Put- Verify in the USERDOCUMENT Table and compare the Uploaded metadata$")
    public void verify_in_the_USERDOCUMENT_Table_and_compare_the_Uploaded_metadata() throws Throwable {
        JsonPath jsonPathEvaluator = response.jsonPath();
        userDocumentId = jsonPathEvaluator.getString("userDocumentId");
        docName = jsonPathEvaluator.getString("documentName");
        System.out.println("userDocumentId---->:" + userDocumentId);
        EventDB.VerifyEventGetDocumentWithId(userDocumentId, docName);
    }

}

