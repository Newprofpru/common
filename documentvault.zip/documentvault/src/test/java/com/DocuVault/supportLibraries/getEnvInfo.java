package com.DocuVault.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;



 public class getEnvInfo {
	
	//static Properties properties = Settings.getInstance();
	static Properties properties = loadFromPropFile();
	static Logger log = Logger.getLogger(getEnvInfo.class);
	static String Url;
	static String userId;
	public static String getURL() {
		return properties.getProperty("URL");
	}
	
	public static String getAPIGEEqaURL() {
		return properties.getProperty("URL_inUse");
	}

	public static String getQAauth() {
		return properties.getProperty("Auth_inUse");
	}

	 public static String SecureUrlPostDocumentMetaData() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAPostDocumentMetaData");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStagePostDocumentMetaData");
		 return null;
	 }

	 public static String SecureUrlPostDocumentContent() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAPostDocumentContent");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStagePostDocumentContent");
		 return null;
	 }

	 public static String getSecureURL() {
		 if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			 return properties.getProperty("SecureUrlQA");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			 return properties.getProperty("SecureUrlSTAGE");
		 return null;

	 }

	 public static String SecureUrlGetDocumentCategories() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAGetDocumentCategories");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageGetDocumentCategories");
		 return null;
	 }

     public static String SecureUrlQGetDocuments() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAGetDocuments");
 		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageGetDocuments");
         return null;
     }

	public static String getAuthorization() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AuthorizationQA");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AuthorizationSTAGE");
		return null;
	}

	public static String getdb() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("DBqa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("DBstage");
		return null;
	}
	
	public static String getdbUserName() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("dbUserNameQa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("dbUserNameStage");
		return null;
	}

	public static String getdbPass() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("dbPassQa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("dbPassStage");
		return null;
	}
	
	public static String getaccountsdb() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AccountsDBqa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AccountsDBstg");
		return null;
	}

	public static String getaccountsdbUserName() {
		System.out.println(properties.getProperty("AccountsdbUserName"));
		return properties.getProperty("AccountsdbUserName");
	}
	public static String getaccountsdbPass() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
		 return properties.getProperty("AccountsdbPassqa");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AccountsdbPassstg");
		return null;
	}
	
	public static String getEnvironment() {
		return properties.getProperty("Environment");
	}

	
	public static Properties getInstance() {
		return properties;
	}

	public static Properties loadFromPropFile() {
		Properties properties = new Properties();
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();
		relativePath = relativePath + Util.getFileSeparator() + "src"
				+ Util.getFileSeparator() + "test" + Util.getFileSeparator()
				+ "resources" ;

		try {
			properties.load(new FileInputStream(relativePath
					+ Util.getFileSeparator() + "GlobalSettings.properties"));
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}

		return properties;
	}

	 public static String getAuthorizationSMSESSION(){
		 if(properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			 System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
			 return properties.getProperty("AuthorizationSMSESSIONQA");
		 }
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
		 {
			 System.out.println(properties.getProperty("AuthorizationSMSESSIONSTAGE"));
			 return properties.getProperty("AuthorizationSMSESSIONSTAGE");
		 }
		 System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
		 return properties.getProperty("AuthorizationSMSESSIONQA");
	 }

	 public static String getCSRUrl() {
		 return properties.getProperty("CSRUrl");
	 }

	
	public static String getXPruImpCOUSERID() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("X-Pru-Imp-CO-USER-ID");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("X-Pru-Imp-CO-USER-ID_STAGE");
		return null;
	}

	public static String getXPruRequestId() {
		return properties.getProperty("X-PruRequestId");
	}

	 public static String build() {
		 return properties.getProperty("BUIDTYPE");
	 }

	public static String getUserID() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("QAUsername");
		if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("StageUsername");
		return null;
	}

	 public static String getPassword() {
		 if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			 return properties.getProperty("QAPassword");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			 return properties.getProperty("StagePassword");
		 return null;
	 }
}
