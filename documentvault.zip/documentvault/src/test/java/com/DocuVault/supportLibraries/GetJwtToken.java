package com.DocuVault.supportLibraries;

import com.DocuVault.supportLibraries.*;

import static com.DocuVault.supportLibraries.getEnvInfo.loadFromPropFile;
import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetJwtToken {


    static Properties properties = getEnvInfo.getInstance();
    static Properties property = loadFromPropFile();
    static RequestSpecification request;
    static Response Res;
    static Map<String, String> cookie_Data = new HashMap<String, String>();
    static Map<String, String> cookies = new HashMap<>();
    static String XPruAuthJWT;

    public static String getAuthJwtToken(String UserName, String Password, String BUType) throws InterruptedException, ParseException {

        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("useAutomationExtension", false);
        options.addArguments("start-maximized");

        System.setProperty("webdriver.chrome.driver",
                properties.getProperty("ChromeDriverPath"));
        WebDriver driver = new ChromeDriver(options);


        //driver.navigate().to(getEnvInfo.getAuthUrl());
        //driver.get(getEnvInfo.getAuthUrl());


        driver.get("https://ssologin-dev.prudential.com/app/ssologin/AuthLogin.fcc");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[contains(@name,'USER')]")).sendKeys(UserName);
        driver.findElement(By.xpath("//input[contains(@name,'USER')]")).sendKeys(UserName);
        driver.findElement(By.xpath("//input[contains(@name,'PASSWORD')]")).sendKeys(Password);
        driver.findElement(By.xpath("//input[contains(@name,'BUIDTYPE')]")).sendKeys(BUType);
        driver.findElement(By.xpath("//form/table/tbody/tr[5]/td/input[contains(@value,'Login')]")).click();
        Thread.sleep(3000);

        //driver.get(properties.getProperty("JWTUrl"));
        driver.get("https://api-dev.prudential.com/.signjwt");
        Thread.sleep(3000);

        JSONParser parser = new JSONParser();
        String responsenew = driver.findElement(By.xpath("/html//body")).getText();

        JSONObject obj = (JSONObject) parser.parse(responsenew.toString());

        String jwtToken = (String) obj.get("jwt");
        driver.quit();
        return jwtToken;

    }

    public static String getCSRJwtToken() throws ParseException {

        DesiredCapabilities handleCert = DesiredCapabilities.chrome();
        handleCert.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        handleCert.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
        //handleCert.
        //	desiredCapabilities.setCapability(CapabilityType.

        System.setProperty("webdriver.chrome.driver", properties.getProperty("ChromeDriverPath"));

        WebDriver driver = new ChromeDriver(handleCert);
        driver.get(getEnvInfo.getCSRUrl());


        ;
        driver.get(properties.getProperty("JWTUrl"));
				/*
				do{
					if (driver.getTitle().contains("Select a certificate")) {
						Thread.sleep(1000);
						driver.get("javascript:document.getElementById('overridelink').click()");
					}
					
					}while(driver.getTitle().contains("Select a certificate"));
					*/

        //Thread.sleep(10000);
        JSONParser parser = new JSONParser();
        String responsenew = driver.findElement(By.xpath("/html//body")).getText();

        JSONObject obj = (JSONObject) parser.parse(responsenew.toString());

        String jwtToken = (String) obj.get("jwt");
        driver.quit();
        return jwtToken;

    }

    //This function is to login and get Session cookies from login
    public static Map<String, String> login(String UserName, String Password, String BUType) {

        Response httpResponse = given().log().all().formParam("USER", UserName).formParam("PASSWORD", Password)
                .formParam("BUIDTYPE", BUType).formParam("target", "/auth/login/").formParam("smquerydata", "")
                .formParam("smauthreason", "").formParam("smagentname", "ssologin")
                .post("https://ssologin-dev.prudential.com/app/ssologin/AuthLogin.fcc");
        Map<String, String> cookies = httpResponse.getCookies();
        return cookies;
    }

    public static String createJWTFromService(String UserName, String Password, String BUType) {
        Map<String, String> cookies = login(UserName, Password, BUType);

        Response Res1 = given().log().all().cookies(cookies).get("https://api-dev.prudential.com/.signjwt");
        System.err.println(Res1.asString());
        //JWTResponseJSON jwtResponse = httpResponse2.as(JWTResponseJSON.class);
        JSONParser parser = new JSONParser();

        JsonPath jp = new JsonPath(Res1.asString());

        System.out.println(jp.getString("jwt"));

        return jp.getString("jwt");
    }

    public static String createCSRFromService() {
        RestAssured.useRelaxedHTTPSValidation();
        Response httpResponse = given().log().all()
                .post("https://csrawssw1-qa.prudential.com");
        Map<String, String> cookies = httpResponse.getCookies();
        Response Res1 = given().log().all().cookies(cookies).get("https://api-dev.prudential.com/.signjwt");
        System.err.println(Res1.asString());
        //JWTResponseJSON jwtResponse = httpResponse2.as(JWTResponseJSON.class);
        JSONParser parser = new JSONParser();

        JsonPath jp = new JsonPath(Res1.asString());

        System.out.println(jp.getString("jwt"));

        return jp.getString("jwt");
    }

    public static String getJWTAuthToken(String userId, String password) {

        try {
            request = given().log().all()
                    .formParam("USER", userId)
                    .formParam("PASSWORD", password)
                    .formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
                    .formParam("smauthreason", "").formParam("smagentname", "ssologin");
            if(property.getProperty("Environment").equalsIgnoreCase("QA")){
                Res = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
            }
            else if(property.getProperty("Environment").equalsIgnoreCase("STAGE")){
                Res = request.post("https://ssologin-stage.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
            }
            cookies = Res.getCookies();

            System.out.println("response-cookies :" + cookies);

            request = given().log().all().cookies(cookies);
            if(property.getProperty("Environment").equalsIgnoreCase("QA")) {
                Res = request.get("https://api-dev.prudential.com/.signjwt").andReturn();
            }
            else if(property.getProperty("Environment").equalsIgnoreCase("STAGE")){
                Res = request.get("https://api-stage.prudential.com/.signjwt").andReturn();
            }
            JsonPath jp = new JsonPath(Res.asString());

            XPruAuthJWT = jp.getString("jwt");

            System.out.println("Prospect JWT Toknen is :" + XPruAuthJWT);


        } catch (Exception e) {
            e.printStackTrace();
        }

        return XPruAuthJWT;

    }


}
