package com.DocuVault.supportLibraries;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Random;

public class PruRequestId {
    static String reqId;
    public static String pruRequestId() {
        Random rand = new Random();
        int n = rand.ints(5, 11111111, 99999999).findFirst().getAsInt();

        Random random = new Random();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
        LocalDate localDate = LocalDate.now();
        Calendar now = Calendar.getInstance();
        int h = now.get(Calendar.HOUR_OF_DAY);
        int m = now.get(Calendar.MINUTE);
        int s = now.get(Calendar.SECOND);
        reqId = "docVault" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
        System.out.println(reqId);
        return reqId;
    }
}
