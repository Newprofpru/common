/* This Module is generate dynamic Array list based on number columns returned from DB
 * Author : Krishnapriya.vellanki@prudential.com
 */
package com.DocuVault.supportLibraries;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class GenericEvent {

	public ArrayList<String> event_cols= new ArrayList<>();

	public GenericEvent(ResultSet res) {
		ResultSetMetaData rs_md;
		try {
			rs_md = res.getMetaData();
			int n = rs_md.getColumnCount();

			for (int i = 0; i < n; i++) {
				event_cols.add(res.getString(i+1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public ArrayList<String> getEvent_cols() {
		return event_cols;
	}

	public void setEvent_cols(ArrayList<String> event_cols) {
		this.event_cols = event_cols;
	}

	
}
