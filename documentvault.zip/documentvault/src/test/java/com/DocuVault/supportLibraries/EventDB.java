package com.DocuVault.supportLibraries;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Assert;

public class EventDB {

    static String DocumentName;
    static String DocumentDescription;
    static String DocumentLink;
    static String ContractId;
    static String documentSourceCode;
    static String documentSourceId;
    static String lineOfBusinessCode;

    public static void VerifyEventDB(String input, String documentNam) throws InterruptedException, SQLException {
        Connection con2 = null;
        try {
            System.out.println("Running testcase for audit [EventDB]");
                con2 = DBConnection.getConnection();
                String query = "select  DOCUMENTNAME,DOCUMENTDESCRIPTION,DOCUMENTLINK,contractId,documentSourceCode,documentSourceId,lineOfBusinessCode from userdocument WHERE userDocumentId = '"
                    + input + "' order by createddate desc";
            Thread.sleep(3000);
            ResultSet rs = DBConnection.execStatement(con2, query);
            System.out.println("Query Input : " + query);
            ArrayList<GenericEvent> db_res = new ArrayList<>();
            System.out.println("ResultSet is: " + rs);
            System.out.println("Row COunt:" + db_res.size());

            if (rs != null) {

                try {
                    while (rs.next()) {
                        // System.out.println(rs.getString(1));
                        db_res.add(new GenericEvent(rs));
                        // System.out.println(rs.getString(1));

                    }
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else {

                System.out.println("RS is null!");
            }

            if (db_res.isEmpty()) {
                System.out.println("DB Result is empty!");

            } else {

                for (GenericEvent gev : db_res) {

                    for (int i = 0; i < gev.event_cols.size(); i++) {
                        System.out.print(gev.event_cols.get(i) + " ");

                    }
                    System.out.println();
                }
                DocumentName = db_res.get(0).event_cols.get(0);
                System.out.println("DocumentName From Database is" + DocumentName);
                DocumentDescription = db_res.get(0).event_cols.get(1);
                DocumentLink = db_res.get(0).event_cols.get(2);
                ContractId = db_res.get(0).event_cols.get(3);
                documentSourceCode = db_res.get(0).event_cols.get(4);
                documentSourceId = db_res.get(0).event_cols.get(5);
                lineOfBusinessCode = db_res.get(0).event_cols.get(6);
                Assert.assertEquals(DocumentName, DocumentName);
                String documentName = db_res.get(0).event_cols.get(0);
                System.out.println("DocName:" + documentName);
                System.out.println("DocumentDescription");
                Assert.assertEquals(documentName, documentNam);
            }
        } finally {
            if (con2 != null) {
                //con2.close();
            }
        }
    }




    public static void VerifyEventGetDocumentWithId(String docId, String DocName) throws InterruptedException, SQLException {
        Connection con2 = null;
        try {
            System.out.println("Running testcase for audit [EventDB]");
            String query = "select * from USERDOCUMENT WHERE userDocumentId = '"
                    + docId + "' order by createddate desc";
            System.out.println("Query For Execution:" + query);
            Thread.sleep(3000);
            con2 = DBConnection.getConnection();
            System.out.println("Query Input1 : " + "Query Input1 : ");
            assert con2 != null;
            ResultSet rs = DBConnection.execStatement(con2, query);
            System.out.println("Query Input : " + query);
            ArrayList<GenericEvent> db_res = new ArrayList<>();
            System.out.println("ResultSet is: " + rs);
            System.out.println("Row COunt:" + db_res.size());

            if (rs != null) {

                try {
                    while (rs.next()) {
                        db_res.add(new GenericEvent(rs));

                    }
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else {

                System.out.println("RS is null!");
            }

            if (db_res.isEmpty()) {
                System.out.println("DB Result is empty!");

            } else {

                for (GenericEvent gev : db_res) {

                    for (int i = 0; i < gev.event_cols.size(); i++) {
                        System.out.print(gev.event_cols.get(i) + " ");
                    }
                    System.out.println();
                }
                DocumentName = db_res.get(0).event_cols.get(7);
                System.out.print(DocumentName+ "DocumentName ");
                System.out.print(DocName+ "DocName");
                Assert.assertEquals(DocumentName, DocName);
                System.out.print("successfully assert");
            }
        } finally {
            if (con2 != null) {
                //con2.close();
            }
        }
    }

    public static String VerifyEventGetDocumentContent(String coUserId, String userDocumentId) throws InterruptedException, SQLException {
        Connection con2 = null;
        try {
            System.out.println("Running testcase for audit [EventDB]");
                con2 = DBConnection.getConnection();
            String query = "select * from USERDOCUMENT WHERE userDocumentId = '"
                    + userDocumentId + "' and couserid = '" + coUserId + "'order by createddate desc";
            System.out.println("Query For Execution:" + query);
            Thread.sleep(3000);
            ResultSet rs = DBConnection.execStatement(con2, query);
            System.out.println("Query Input : " + query);
            ArrayList<GenericEvent> db_res = new ArrayList<>();
            System.out.println("ResultSet is: " + rs);
            System.out.println("Row COunt:" + db_res.size());

            if (rs != null) {

                try {
                    while (rs.next()) {
                        db_res.add(new GenericEvent(rs));

                    }
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else {

                System.out.println("RS is null!");
            }

            if (db_res.isEmpty()) {
                System.out.println("DB Result is empty!");

            } else {

                for (GenericEvent gev : db_res) {

                    for (int i = 0; i < gev.event_cols.size(); i++) {
                        System.out.print(gev.event_cols.get(i) + " ");
                    }
                    System.out.println();
                }
                DocumentLink = db_res.get(0).event_cols.get(12);
                Assert.assertNotEquals(null,DocumentLink);
            }
        } finally {
            if (con2 != null) {
                //con2.close();
            }
        }
        return DocumentLink;
    }


}