package com.DocuVault.supportLibraries;

import java.util.HashMap;

public class GlobalStaticInfo {
	public static HashMap<String,String> persInfoDBUserContract = new HashMap<>();
	public static HashMap<String,String> persInfoDBCouser = new HashMap<>();
	public static HashMap<String,String> persInfoDBCouser1 = new HashMap<>();
	public static HashMap<String,String> disclosureDBCouser = new HashMap<>();
	public static HashMap<String,String> disclosureDBUserContract = new HashMap<>();
	public static HashMap<String,String> suitablityDBCouser = new HashMap<>();
	public static HashMap<String,String> suitablityDBUserContract = new HashMap<>();
	public static HashMap<String,String> investmentDBCouser = new HashMap<>();
	public static HashMap<String,String> investmentDBUserContract = new HashMap<>();
	public static HashMap<String,String> trustContDBUserContract = new HashMap<>();
	public static HashMap<String,String> contAddressDBUserAddress = new HashMap<>();
	public static HashMap<String,String> contChannelDBUserContact = new HashMap<>();
	public static HashMap<String,String> employersDBCouser = new HashMap<>();
	public static HashMap<String,String> userRelDbUserRelation = new HashMap<>();
	public static HashMap<String,String> persInfoUserTranlogdtl = new HashMap<>();
	public static HashMap<String,String> contAddUserTranslogdtl = new HashMap<>();
	public static HashMap<String,String> contChannelUserTranslogdtl = new HashMap<>();
	public static HashMap<String,String> addrTypeUserTranslogdtl = new HashMap<>();
	public static HashMap<String,String> emailTypeUserTranslogdtl = new HashMap<>();
	public static HashMap<String,String> phoneTypeUserTranslogdtl = new HashMap<>();
	public static HashMap<String,String> accountsDBHolding = new HashMap<>();
	public static HashMap<String,String> amluUserTransLog = new HashMap<>();
	public static HashMap<String,String> amluUserTransLogDtl = new HashMap<>();
	public static HashMap<String, String> PersInUserTranUpddtl = new HashMap<>();
	public static HashMap<String,String> contChanUserTranUpddtl = new HashMap<>();
	public static HashMap<String,String> contAddrUserTranUpddtl = new HashMap<>();
	public static HashMap<String,String> amluUserTransLogPartyType = new HashMap<>();
	public static HashMap<String,String> accountsPartyHoldingMap = new HashMap<>();
	public static HashMap<String,String> accountsHoldingSummary = new HashMap<>();
	public static HashMap<String,String> accountsHolding= new HashMap<>();
	public static HashMap<String,String> reputationAmlu = new HashMap<>();
	public static HashMap<String,String> accountsHoldingSummary2 = new HashMap<>();
	public static HashMap<String,String> accountsHolding2= new HashMap<>();
	
	public static void loadGlobalStaticInfo(){
		persInfoDBUserContract.put("FIRSTNAME", "firstName");
		persInfoDBUserContract.put("MIDDLENAME", "middleName");
		persInfoDBUserContract.put("LASTNAME", "lastName");
		persInfoDBUserContract.put("PREFIXNAME", "prefix");
		persInfoDBUserContract.put("SUFFIXNAME", "suffix");
		persInfoDBUserContract.put("MARITALSTATUSCODE", "maritalStatus");
		persInfoDBUserContract.put("DATEOFBIRTH", "dateOfBirth");
		persInfoDBUserContract.put("GENDERCODE", "gender");
		persInfoDBUserContract.put("PERMANANTRESIDENT", "permanentResident");
		persInfoDBUserContract.put("VISATYPECODE", "visaType");
		persInfoDBUserContract.put("VISAEXPIRATION", "visaExpiration");
		persInfoDBUserContract.put("COUNTRYOFBIRTH", "countryOfBirth");
		persInfoDBUserContract.put("EMPLOYMENTSTATUSCODE", "employmentStatus");
		persInfoDBUserContract.put("EMPLOYERNAME", "employerName");
		persInfoDBUserContract.put("LAST4SSN", "last4Ssn");
		
		persInfoDBCouser1.put("FIRSTNAME", "firstName");
		persInfoDBCouser1.put("MIDDLENAME", "middleName");
		persInfoDBCouser1.put("LASTNAME", "lastName");
		persInfoDBCouser1.put("PREFIXNAME", "prefix");
		persInfoDBCouser1.put("SUFFIXNAME", "suffix");
		persInfoDBCouser1.put("MARITALSTATUSCODE", "maritalStatus");
		persInfoDBCouser1.put("DATEOFBIRTH", "dateOfBirth");
		persInfoDBCouser1.put("GENDERCODE", "gender");
		persInfoDBCouser1.put("PERMANANTRESIDENT", "permanentResident");
		persInfoDBCouser1.put("VISATYPECODE", "visaType");
		persInfoDBCouser1.put("VISAEXPIRATION", "visaExpiration");
		persInfoDBCouser1.put("COUNTRYOFBIRTH", "countryOfBirth");
		persInfoDBCouser1.put("EMPLOYMENTSTATUSCODE", "employmentStatus");
		persInfoDBCouser1.put("EMPLOYERNAME", "employerName");
		persInfoDBCouser1.put("LAST4SSN", "last4Ssn");

		persInfoDBCouser.put("PREFFEREDNAME", "preferredName");
		persInfoDBCouser.put("USERSOURCECODE", "userSource");
		persInfoDBCouser.put("COUNTRYOFCITIZENSHIPCODE", "citizenship");
		persInfoDBCouser.put("OCCUPATION", "occupation");
		persInfoDBCouser.put("ANNUALSALARY", "salary");
		persInfoDBCouser.put("USERSTATUSCODE", "userStatus");
		persInfoDBCouser.put("EMPLOYMENTPOSITION", "position");
		persInfoDBCouser.put("PROFILEPHOTOLOCATION", "profilePhotoLink");
		persInfoDBCouser.put("EURESIDENTFLAG", "euResidentFlag");
		persInfoDBCouser.put("SOURCEID", "sourceId");
		
		disclosureDBCouser.put("CONTROLPERSON", "controlPerson");
		disclosureDBCouser.put("COMPANYSYMBOL", "companySymbols");
		disclosureDBCouser.put("POLITICALLYEXPOSED", "politicallyExposed");
		disclosureDBCouser.put("ORGANIZATIONCOUNTRYCODE", "organization");
		disclosureDBCouser.put("POLITICALAFFILIATEDRELTYPECODE", "relationship");
		disclosureDBCouser.put("FINRAAFFILIATED", "finraAffiliated");
		disclosureDBCouser.put("FIRMNAME", "firmName");
		disclosureDBCouser.put("AFFILIATEDAPPROVALID", "affliatedApprovalID");
		
		disclosureDBUserContract.put("CONTROLPERSON", "controlPerson");
		disclosureDBUserContract.put("COMPANYSYMBOL", "companySymbols");
		disclosureDBUserContract.put("POLITICALLYEXPOSED", "politicallyExposed");
		disclosureDBUserContract.put("ORGANIZATIONCOUNTRYCODE", "organization");
		disclosureDBUserContract.put("POLITICALAFFILIATEDRELTYPECODE", "relationship");
		disclosureDBUserContract.put("FINRAAFFILIATED", "finraAffiliated");
		disclosureDBUserContract.put("FIRMNAME", "firmName");
		disclosureDBUserContract.put("AFFILIATEDAPPROVALID", "affliatedApprovalID");
		
		suitablityDBCouser.put("TIMEHORIZON", "timeHorizon");
		suitablityDBCouser.put("LIQUIDITYNEEDS", "liquidityNeeds");
		suitablityDBCouser.put("INVESTMENTOBJECTIVE", "investmentObjective");
		suitablityDBCouser.put("RISKTOLERANCE", "riskTolerance");
		
		suitablityDBUserContract.put("TIMEHORIZON", "timeHorizon");
		suitablityDBUserContract.put("LIQUIDITYNEEDS", "liquidityNeeds");
		suitablityDBUserContract.put("INVESTMENTOBJECTIVE", "investmentObjective");
		suitablityDBUserContract.put("RISKTOLERANCE", "riskTolerance");
		
		investmentDBCouser.put("INVESTMENTEXPERIENCE", "investmentExperience");
		investmentDBCouser.put("TAXBRACKET", "taxBracket");
		investmentDBCouser.put("ANNUALINCOME", "annualIncome");
		investmentDBCouser.put("LIQUIDNETWORTH", "liquidNetWorth");
		investmentDBCouser.put("TOTALNETWORTH", "totalNetWorth");
		
		investmentDBUserContract.put("INVESTMENTEXPERIENCE", "investmentExperience");
		investmentDBUserContract.put("TAXBRACKET", "taxBracket");
		investmentDBUserContract.put("ANNUALINCOME", "annualIncome");
		investmentDBUserContract.put("LIQUIDNETWORTH", "liquidNetWorth");
		investmentDBUserContract.put("TOTALNETWORTH", "totalNetWorth");
		
		trustContDBUserContract.put("TRUSTEDCONTACTFIRSTNAME", "trustedContactFirstName");
		trustContDBUserContract.put("TRUSTEDCONTACTLASTNAME", "trustedContactLastName");
		trustContDBUserContract.put("TRUSTEDCONTACTADDRESS1", "trustedContactAddress1");
		trustContDBUserContract.put("TRUSTEDCONTACTSTREETADDRESS", "trustedContactStreetAddress");
		trustContDBUserContract.put("TRUSTEDCONTACTCITY", "trustedContactCity");
		trustContDBUserContract.put("TRUSTEDCONTACTSTATE", "trustedContactState");
		trustContDBUserContract.put("TRUSTEDCONTACTPOSTALCODE", "trustedContactPostalCode");
		trustContDBUserContract.put("TRUSTEDCONTACTCOUNTRY", "trustedContactCountry");
		
		contAddressDBUserAddress.put("USERADDRESSID", "contactAddressId");
		contAddressDBUserAddress.put("ADDRESSTYPECODE", "addressType");
		contAddressDBUserAddress.put("ADDRESSLINE1", "addressLine1");
		contAddressDBUserAddress.put("ADDRESSLINE2", "addressLine2");
		contAddressDBUserAddress.put("ADDRESSLINE3", "addressLine3");
		contAddressDBUserAddress.put("ADDRESSLINE4", "addressLine4");
		contAddressDBUserAddress.put("CITY", "city");
		contAddressDBUserAddress.put("STATE", "state");
		contAddressDBUserAddress.put("COUNTRY", "country");
		contAddressDBUserAddress.put("ZIPCODE", "zipCode");
		contAddressDBUserAddress.put("ZIPCODEEXTENSION", "zipPlus4");
		contAddressDBUserAddress.put("ADDRESSSTATUSCODE", "addressStatus");
		contAddressDBUserAddress.put("DELETED", "deleted");
		
		contChannelDBUserContact.put("USERCONTACTID", "contactChannelId");
		contChannelDBUserContact.put("CONTACTCHANNELCODE", "contactChannel");
		contChannelDBUserContact.put("CONTACTTYPECODE", "contactChannelType");
		contChannelDBUserContact.put("CONTACTVALUE", "contactChannelValue");
		contChannelDBUserContact.put("PHONEEXTENSION", "phoneExtension");
		contChannelDBUserContact.put("CONTACTSTATUSCODE", "contactStatus");
		contChannelDBUserContact.put("DELETED", "deleted");
		
		employersDBCouser.put("EMPLOYEEID","employeeId");
		employersDBCouser.put("EMPLOYER","employer");
		
		userRelDbUserRelation.put("USERRELATIONID", "relationId");
		userRelDbUserRelation.put("RELATIONSHIPTYPECODE", "relationshipType");
		userRelDbUserRelation.put("RELATEDCOUSERID", "relatedCoUserId");
		
//		persInfoUserTranlogdtl.put("User ID", "firstName");		
		persInfoUserTranlogdtl.put("Employer Name", "employerName");
		persInfoUserTranlogdtl.put("Employment Status", "employmentStatus");
		persInfoUserTranlogdtl.put("First Name", "firstName");
		persInfoUserTranlogdtl.put("Middle Name", "middleName");
		persInfoUserTranlogdtl.put("Last Name", "lastName");
		persInfoUserTranlogdtl.put("Prefix", "prefix");
		persInfoUserTranlogdtl.put("Suffix", "suffix");
		persInfoUserTranlogdtl.put("Preffered Name", "preferredName");
		persInfoUserTranlogdtl.put("Marital Status", "maritalStatus");
		persInfoUserTranlogdtl.put("Date Of Birth", "dateOfBirth");
		persInfoUserTranlogdtl.put("Gender", "gender");
		persInfoUserTranlogdtl.put("Citizenship", "citizenship");
		persInfoUserTranlogdtl.put("Country Of Birth", "countryOfBirth");
		persInfoUserTranlogdtl.put("Position", "position");
		persInfoUserTranlogdtl.put("Salary", "salary");
		persInfoUserTranlogdtl.put("Occupation", "occupation");
		persInfoUserTranlogdtl.put("Profile Photo Link", "profilePhotoLink");
		persInfoUserTranlogdtl.put("Last4SSN", "last4Ssn");
		persInfoUserTranlogdtl.put("Permanent Resident", "permanentResident");		
		persInfoUserTranlogdtl.put("Visa Expiration", "visaExpiration");
		persInfoUserTranlogdtl.put("Visa Type", "visaType");
		
		contAddUserTranslogdtl.put("Address Type", "addressType");
		contAddUserTranslogdtl.put("Address Line1", "addressLine1");
		contAddUserTranslogdtl.put("Address Line2", "addressLine2");
		contAddUserTranslogdtl.put("Address Line3", "addressLine3");
		contAddUserTranslogdtl.put("Address Line4", "addressLine4");
		contAddUserTranslogdtl.put("City", "city");
		contAddUserTranslogdtl.put("State", "state");
		contAddUserTranslogdtl.put("ZipCode", "zipCode");
		contAddUserTranslogdtl.put("ZipPlus4", "zipPlus4");
		contAddUserTranslogdtl.put("Country", "country");
		contAddUserTranslogdtl.put("Address Status", "addressStatus");
		
		contChannelUserTranslogdtl.put("Contact Channel", "contactChannel");
		contChannelUserTranslogdtl.put("Contact Channel Type", "contactChannelType");
		contChannelUserTranslogdtl.put("Contact Channel Value", "contactChannelValue");
		contChannelUserTranslogdtl.put("Phone Extension", "phoneExtension");
		contChannelUserTranslogdtl.put("Contact Status", "contactStatus");

		addrTypeUserTranslogdtl.put("HOME", "Home");
		addrTypeUserTranslogdtl.put("WORK", "Work");
		addrTypeUserTranslogdtl.put("ADDRESSOFRECORD", "Address of Record");
		addrTypeUserTranslogdtl.put("CORRESPONDENCE", "Correspondence");
		addrTypeUserTranslogdtl.put("SNOW", "Snow");
		addrTypeUserTranslogdtl.put("MILITARY", "Military");
		addrTypeUserTranslogdtl.put("OTHER","Other");
		
		emailTypeUserTranslogdtl.put("PERSONAL", "Personal");
		emailTypeUserTranslogdtl.put("PRIMARY", "Primary");
		emailTypeUserTranslogdtl.put("WORK", "Work");
		emailTypeUserTranslogdtl.put("HOME", "Home");
		emailTypeUserTranslogdtl.put("ALTERNATE1", "Alternate 1");
		emailTypeUserTranslogdtl.put("ALTERNATE2", "Alternate 2");
		emailTypeUserTranslogdtl.put("ALTERNATE3","Alternate 3");
		emailTypeUserTranslogdtl.put("SECONDARY","Secondary");
		emailTypeUserTranslogdtl.put("OTHER","Other");
		emailTypeUserTranslogdtl.put("EMAILOFRECORD","Email Of Record");
		
		phoneTypeUserTranslogdtl.put("PERSONAL", "Personal");
		phoneTypeUserTranslogdtl.put("OTHER","Other");
		phoneTypeUserTranslogdtl.put("PRIMARY", "Primary");
		phoneTypeUserTranslogdtl.put("WORK", "Work");
		phoneTypeUserTranslogdtl.put("HOME", "Home");
		phoneTypeUserTranslogdtl.put("ALTERNATE", "Alternate");
		phoneTypeUserTranslogdtl.put("NIGHT","Night");
		phoneTypeUserTranslogdtl.put("MOBILE", "Mobile");
		phoneTypeUserTranslogdtl.put("BUSINESS","Business");
		phoneTypeUserTranslogdtl.put("PHONEOFRECORD","Phone Of Record");
		
		amluUserTransLog.put("ROLECODE", "role");	
		amluUserTransLog.put("LINKEDCONTEXTCODE", "linkedcontextcode");	
		amluUserTransLog.put("SOURCEIPADDRESS", "sourceIPAddress");
		amluUserTransLog.put("LINKEDCONTEXTREFID", "linkedcontextrefid");
		amluUserTransLog.put("PARTYID", "partyId");
		amluUserTransLog.put("COUSERID", "coUserId");	
		amluUserTransLog.put("LINKEDCONTEXTREFID", "linkedcontextrefid");		
		amluUserTransLog.put("TRANSACTIONTYPECODE", "transactionTypeCode");
		amluUserTransLog.put("SOURCEAPPLICATION", "sourceApplication");
		amluUserTransLog.put("TRANSACTIONMESSAGE", "transactionMsg");
		amluUserTransLog.put("TRANSACTIONCATEGORYCODE", "transactioncategorycode");

		
		amluUserTransLogDtl.put("FIELDNAME", "fieldName");
		amluUserTransLogDtl.put("NEWVALUE", "newValue");
		amluUserTransLogDtl.put("OLDVALUE", "oldValue");
		
		
		amluUserTransLogPartyType.put("PARTYTYPE", "partyType");
		
		PersInUserTranUpddtl.put("Employer Name", "employerName");
		PersInUserTranUpddtl.put("Employment Status", "employmentStatus");
		PersInUserTranUpddtl.put("First Name", "firstName");
		PersInUserTranUpddtl.put("Last Name", "lastName");
		PersInUserTranUpddtl.put("Suffix", "suffix");
		PersInUserTranUpddtl.put("Preffered Name", "preferredName");
		PersInUserTranUpddtl.put("Marital Status", "maritalStatus");
		PersInUserTranUpddtl.put("Date Of Birth", "dateOfBirth");
		PersInUserTranUpddtl.put("Gender", "gender");
		PersInUserTranUpddtl.put("Visa Type", "visaType");
		
		contChanUserTranUpddtl.put("Contact Channel Value", "contactChannelValue");
		
		contAddrUserTranUpddtl.put("Address Line1", "addressLine1");
		contAddrUserTranUpddtl.put("Address Line2", "addressLine2");
		contAddrUserTranUpddtl.put("Address Line3", "addressLine3");
		contAddrUserTranUpddtl.put("Address Line4", "addressLine4");
		contAddrUserTranUpddtl.put("ZipPlus4", "zipPlus4");
		
		
		
		reputationAmlu.put("POLITICALLYEXPOSED", "Politically Exposed");
		reputationAmlu.put("ADVERSEMEDIA", "Adverse Media or Known Reputational Issues");
		reputationAmlu.put("SARORSTRIND", "SAR/CTR filed in last 5 years");
		reputationAmlu.put("AML", "More than 5 transaction alerts in past year");
		reputationAmlu.put("OFAC", "Identified as an SDN by OFAC");
		reputationAmlu.put("LOCALSANCTIONS", "Identified as a Sanctioned Entity on a Local Sanctions List");
		reputationAmlu.put("PLM", "PFC/PLM");
		reputationAmlu.put("MARIJUANA","Affiliated with Marijuana Organization");
		
		accountsPartyHoldingMap.put("ACCOUNTID", "accountID");

		accountsHoldingSummary.put("HOLDINGSOURCETYPECODEDESC", "sourceTypeCode");
		accountsHoldingSummary.put("HOLDINGTYPECODEDESC", "typeCode");
		accountsHoldingSummary.put("FINANCIALINSTITUTION", "financialInstitution");
		accountsHoldingSummary.put("ASSETVALUE", "assetValue");
		accountsHoldingSummary.put("POLICYSTATUS", "policyStatus");
		accountsHoldingSummary.put("PRODUCTTYPE", "productType");
		accountsHoldingSummary.put("PRODUCTSUBTYPE", "productSubtype");
		accountsHoldingSummary.put("PRODUCTFULLNAME", "productFullName");
		accountsHoldingSummary.put("PERIODMODE", "periodMode");
		accountsHoldingSummary.put("ACCOUNTID", "accountID");
		accountsHoldingSummary.put("PROVIDERACCOUNTID", "providerAccountID");
		accountsHoldingSummary.put("ACCOUNTNUMBER", "accountNumber");
		accountsHoldingSummary.put("POLNUMBER", "policyNumber");
		accountsHoldingSummary.put("HOLDINGCATEGORY", "category");
		accountsHoldingSummary.put("SOURCENAME", "sourceName");
		accountsHoldingSummary.put("STATUSCODE", "statusCode");
		accountsHoldingSummary.put("STATUSMESSAGE", "statusMessage");
		accountsHoldingSummary.put("FINANCIALINSTITUTIONID", "financialInstituionID");
		
		
		accountsHolding.put("ACCOUNTID", "accountID");
		
		accountsHoldingSummary2.put("HOLDINGSOURCETYPECODEDESC", "sourceTypeCode");
		accountsHoldingSummary2.put("HOLDINGTYPECODEDESC", "typeCode");
		accountsHoldingSummary2.put("FINANCIALINSTITUTION", "financialInstitution");
		accountsHoldingSummary2.put("ASSETVALUE", "assetValue");
		accountsHoldingSummary2.put("POLICYSTATUS", "policyStatus");
		accountsHoldingSummary2.put("PRODUCTTYPE", "productType");
		accountsHoldingSummary2.put("PRODUCTSUBTYPE", "productSubtype");
		accountsHoldingSummary2.put("PRODUCTFULLNAME", "productFullName");
		accountsHoldingSummary2.put("PERIODMODE", "periodMode");
		accountsHoldingSummary2.put("HOLDINGSUMMARYID", "id");
		accountsHoldingSummary2.put("PROVIDERACCOUNTID", "providerAccountID");
		accountsHoldingSummary2.put("POLNUMBER", "policyNumber");
		accountsHoldingSummary2.put("HOLDINGCATEGORY", "category");
		accountsHoldingSummary2.put("SOURCENAME", "sourceName");
		accountsHoldingSummary2.put("STATUSCODE", "statusCode");
		accountsHoldingSummary2.put("STATUSMESSAGE", "statusMessage");
		accountsHoldingSummary2.put("FINANCIALINSTITUTIONID", "financialInstituionID");
		
		accountsHolding2.put("HOLDINGID", "id");
	
	}

}