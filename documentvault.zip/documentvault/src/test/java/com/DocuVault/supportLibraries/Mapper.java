package com.DocuVault.supportLibraries;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.beanutils.BeanUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Mapper {
    protected ObjectMapper mapper;
    private String pathStatic = "src/main/resources";

    public Mapper() {
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public String getAsString(Object obj) throws JsonProcessingException {
        return mapper.writeValueAsString(obj);
    }

    public void loadJSON(String s, Object obj)
            throws IOException, IllegalAccessException, InvocationTargetException {

        BeanUtils.copyProperties(obj, mapper.readValue(s, obj.getClass()));

    }

    public void load(String fileName, Object obj)
            throws IOException, IllegalAccessException, InvocationTargetException {

        String filePath = pathStatic;

        switch (obj.getClass().getSimpleName()) {

            case "PostDocumentMetaData":
                filePath = pathStatic + "/post/";
                break;
        }

        BeanUtils.copyProperties(obj, mapper.readValue(new File(filePath + (fileName)), obj.getClass()));


    }
}
