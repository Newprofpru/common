
package com.DocuVault.supportLibraries;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;

/**
 * Servlet implementation class PruISLogin
 */
@WebServlet("/PruISLogin")
public class PruISLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PruISLogin() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
					
		String uid = request.getParameter("u") == null ? "" : request
				.getParameter("u");
		String pwd = request.getParameter("p") == null ? "" : request
				.getParameter("p");		
		String buid = request.getParameter("b") == null ? "" : request
				.getParameter("b").toUpperCase();
		String tier = request.getParameter("e") == null ? "" : request
				.getParameter("e").toLowerCase();
		String aurl = "https://ssologin"
				+ (tier.equals("prod") ? "" : "-" + tier)
				+ ".prudential.com/app/prulogin/Login.fcc";
				//Added URL Encoding for UID and PWD, the encoding used is same as Retirement.
		 uid = URLEncoder.encode(uid,"ISO-8859-1");
		 pwd = URLEncoder.encode(pwd,"ISO-8859-1");
		 
		String data = "SMENC=ISO-8859-1&SMLOCALE=US-EN&USER="
				+uid
				+ "&PASSWORD="
				+ pwd
				+ "&BUIDTYPE="
				+ buid
				+ "&target=/auth/login/&smquerydata=&smauthreason=&smagentname=ssologin";
				

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//System.out.println("PruISLogin calling template  :[" + aurl + "] data ["  + data + "]");
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
			@Override
			public boolean verify(String h, SSLSession s) {
				return true;
			}
		});

		// safety check
		if (!tier.equals("test") && !tier.equals("dev") && !tier.equals("int")
				&& !tier.equals("qa") && !tier.equals("stage")
				&& !tier.equals("prod")) {
			out.write("INVALID TIER!!");
			out.flush();
			out.close();
			return;
		}
		//Adding buid test condition
		/* Mehul commented
		if (buid.equalsIgnoreCase("RSPAR"))
		{ 
			out.write("INVALID OU!!"); 
			out.flush(); 
			out.close(); 
			return; 
		} 

		*/

		try {
			URL url = new URL(aurl);
			URLConnection conn = url.openConnection();
			conn.setUseCaches(false);
			((HttpURLConnection) conn).setFollowRedirects(false);
			((HttpURLConnection) conn).setInstanceFollowRedirects(false);
			((HttpURLConnection) conn).setRequestMethod("POST");
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Length",
					String.valueOf(data.length()));
			conn.setRequestProperty("Connection", "close");
			conn.setDoOutput(true);
			conn.setDoInput(true);

			PrintWriter pw = new PrintWriter(conn.getOutputStream());
			pw.write(data);
			pw.close();
			
			int responseCode = ((HttpURLConnection)conn).getResponseCode();
			System.out.println("PruISLogin Response Code with header :" + responseCode+" : Response Message :"+((HttpURLConnection)conn).getResponseMessage());
			//printHeaderInfo(conn);

			Map reshdrs = conn.getHeaderFields();
			if (reshdrs.containsKey("Location")) {
				String LOCATION = reshdrs.get("Location").toString();
				String SMSESSIONCK = "";
				String SSOEVENTCK = "";
				String hdr;
				String cookie;
				for (int i = 1; (hdr = conn.getHeaderFieldKey(i)) != null; i++) {
					if (hdr.equals("Set-Cookie")) {
						cookie = conn.getHeaderField(i);
						cookie = cookie.substring(0, cookie.indexOf(";"));
						if (cookie.substring(0, cookie.indexOf("=")).equals(
								"SMSESSION")) {
							SMSESSIONCK = cookie.substring(
									cookie.indexOf("=") + 1, cookie.length());
						}
						if (cookie.substring(0, cookie.indexOf("=")).equals(
								"SSOEVENT")) {
							SSOEVENTCK = cookie.substring(
									cookie.indexOf("=") + 1, cookie.length());
						}
					}
				}

				if (!SMSESSIONCK.equals("")) {
					response.setHeader("Set-Cookie", "SMSESSION=" + SMSESSIONCK
							+ "; path=/; domain=.prudential.com; secure");
					out.write("SMSESSION");
				} else if (!SSOEVENTCK.equals("")) {
					if (LOCATION.toUpperCase().contains("SMAUTHREASON")) {
						String[] fields = LOCATION.toUpperCase().split("&");
						for (int i = 0; i < fields.length; i++) {
							if (fields[i].startsWith("SMAUTHREASON=")) {
								if (!fields[i].equals("SMAUTHREASON=0")) {
									String[] smAuthStr = fields[i].split("=");
									SSOEVENTCK = smAuthStr[1];
									if ((smAuthStr[1].equals("1"))
											|| (smAuthStr[1].equals("19"))
											|| (smAuthStr[1].equals("20"))) {
										SSOEVENTCK = "CHANGEPASSWORD";
									}
								}
							}
						}
					}
					out.write("SSOEVENT|" + SSOEVENTCK);
				} else {
					out.write("FATAL_ERROR_3");
				}
			} else {
				out.write("FATAL_ERROR_2");
			}
		} catch (Exception e) {
			out.write("FATAL_ERROR_1");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response); 
	}

	
	public void printHeaderInfo(URLConnection connection){
		Map<String, List<String>> headers = connection.getHeaderFields();
        Set<Map.Entry<String, List<String>>> entrySet = headers.entrySet();
        for (Map.Entry<String, List<String>> entry : entrySet) {
            String headerName = entry.getKey();

            List<String> headerValues = entry.getValue();
            for (String value : headerValues) {
                System.out.println("PruISLogin Header Name[:" + headerName+" :: "+"]Header value[:" + value +"]");
            }
            
        }
    } 
}
