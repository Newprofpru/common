package com.DocuVault.CommonComponent.Payload;

import com.DocuVault.RequestBodyPojo.UpdateDocumentMetaDataPojo;

public class UpdateDocumentMetaDataPayload {
    public static UpdateDocumentMetaDataPojo updateDocMetaDataPayload(String documentName, String documentCategoryName, String documentLink, String contractId, String documentDescription, String documentSourceCode, String documentSourceId, String lineOfBusinessCode, String expirationDate, String processedDate, String effectiveDate, String subCategory) {

        UpdateDocumentMetaDataPojo request = new UpdateDocumentMetaDataPojo();

        request.setDocumentName(documentName);
        request.setDocumentCategoryName(documentCategoryName);
        request.setDocumentLink(documentLink);
        request.setContractId(contractId);
        request.setDocumentDescription(documentDescription);
        request.setDocumentSourceCode(documentSourceCode);
        request.setDocumentSourceId(documentSourceId);
        request.setLineOfBusinessCode(lineOfBusinessCode);
        request.setExpirationDate(expirationDate);
        request.setProcessDate(processedDate);
        request.setEffectiveDate(effectiveDate);
        request.setDocumentSubCategoryName(subCategory);

        return request;
    }
}
