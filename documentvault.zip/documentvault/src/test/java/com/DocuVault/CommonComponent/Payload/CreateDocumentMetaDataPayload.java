package com.DocuVault.CommonComponent.Payload;

import com.DocuVault.RequestBodyPojo.PostDocumentMetaDataPojo;

public class CreateDocumentMetaDataPayload {

    public static PostDocumentMetaDataPojo CreateDocumentMetaDataPayload(String documentName, String documentCategoryName, String documentLink, String contractId, String documentDescription, String documentSourceCode, String documentSourceId, String lineOfBusinessCode, String expirationDate, String processedDate, String effectiveDate) {

        PostDocumentMetaDataPojo request = new PostDocumentMetaDataPojo();

        request.setDocumentName(documentName);
        request.setDocumentCategoryName(documentCategoryName);
        request.setDocumentLink(documentLink);
        request.setContractId(contractId);
        request.setDocumentDescription(documentDescription);
        request.setDocumentSourceCode(documentSourceCode);
        request.setDocumentSourceId(documentSourceId);
        request.setLineOfBusinessCode(lineOfBusinessCode);
        request.setExpirationDate(expirationDate);
        request.setProcessDate(processedDate);
        request.setEffectiveDate(effectiveDate);

        return request;


    }

}
