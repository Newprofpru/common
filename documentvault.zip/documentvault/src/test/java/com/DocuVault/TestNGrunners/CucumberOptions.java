package com.DocuVault.TestNGrunners;

public @interface CucumberOptions {

}
