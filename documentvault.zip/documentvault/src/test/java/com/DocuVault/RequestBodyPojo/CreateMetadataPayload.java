package com.DocuVault.RequestBodyPojo;

public class CreateMetadataPayload {
	
	public static POSTDocumentWithMetaData createMetaDataPayload(String documentName,String documentCategoryName,String documentLink,String contractId,String documentDescription,String documentSourceCode,String documentSourceId,String lineOfBusinessCode,String expirationDate,String processedDate,String effectiveDate) {
		
		POSTDocumentWithMetaData request = new POSTDocumentWithMetaData();
		 
		request.setDocumentName(documentName);
		request.setDocumentCategoryName(documentCategoryName);
		request.setDocumentLink(documentLink);
		request.setContractId(contractId);
		request.setDocumentDescription(documentDescription);
		request.setDocumentSourceCode(documentSourceCode);
		request.setDocumentSourceId(documentSourceId);
		request.setLineOfBusinessCode(lineOfBusinessCode);
		request.setExpirationDate(expirationDate);
		request.setProcessedDate(processedDate);
		request.setEffectiveDate(effectiveDate);
		
		return request;
		
		
	}

}
