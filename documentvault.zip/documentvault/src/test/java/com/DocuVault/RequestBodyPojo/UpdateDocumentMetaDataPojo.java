package com.DocuVault.RequestBodyPojo;

public class UpdateDocumentMetaDataPojo {

        private String documentDescription;

        private String documentSourceId;

        private String documentSourceCode;

        private String processDate;

        private String contractId;

        private String documentLink;

        private String documentCategoryName;

        private String documentName;

        private String documentSubCategoryName;

        private String lineOfBusinessCode;

        private String effectiveDate;

        private String expirationDate;

        public String getDocumentDescription ()
        {
            return documentDescription;
        }

        public void setDocumentDescription (String documentDescription)
        {
            this.documentDescription = documentDescription;
        }

        public String getDocumentSourceId ()
        {
            return documentSourceId;
        }

        public void setDocumentSourceId (String documentSourceId)
        {
            this.documentSourceId = documentSourceId;
        }

        public String getDocumentSourceCode ()
        {
            return documentSourceCode;
        }

        public void setDocumentSourceCode (String documentSourceCode)
        {
            this.documentSourceCode = documentSourceCode;
        }

        public String getProcessDate ()
        {
            return processDate;
        }

        public void setProcessDate (String processDate)
        {
            this.processDate = processDate;
        }

        public String getContractId ()
        {
            return contractId;
        }

        public void setContractId (String contractId)
        {
            this.contractId = contractId;
        }

        public String getDocumentLink ()
        {
            return documentLink;
        }

        public void setDocumentLink (String documentLink)
        {
            this.documentLink = documentLink;
        }

        public String getDocumentCategoryName ()
        {
            return documentCategoryName;
        }

        public void setDocumentCategoryName (String documentCategoryName)
        {
            this.documentCategoryName = documentCategoryName;
        }

        public String getDocumentName ()
        {
            return documentName;
        }

        public void setDocumentName (String documentName)
        {
            this.documentName = documentName;
        }

        public String getDocumentSubCategoryName ()
        {
            return documentSubCategoryName;
        }

        public void setDocumentSubCategoryName (String documentSubCategoryName)
        {
            this.documentSubCategoryName = documentSubCategoryName;
        }

        public String getLineOfBusinessCode ()
        {
            return lineOfBusinessCode;
        }

        public void setLineOfBusinessCode (String lineOfBusinessCode)
        {
            this.lineOfBusinessCode = lineOfBusinessCode;
        }

        public String getEffectiveDate ()
        {
            return effectiveDate;
        }

        public void setEffectiveDate (String effectiveDate)
        {
            this.effectiveDate = effectiveDate;
        }

        public String getExpirationDate ()
        {
            return expirationDate;
        }

        public void setExpirationDate (String expirationDate)
        {
            this.expirationDate = expirationDate;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [documentDescription = "+documentDescription+", documentSourceId = "+documentSourceId+", documentSourceCode = "+documentSourceCode+", processDate = "+processDate+", contractId = "+contractId+", documentLink = "+documentLink+", documentCategoryName = "+documentCategoryName+", documentName = "+documentName+", documentSubCategoryName = "+documentSubCategoryName+", lineOfBusinessCode = "+lineOfBusinessCode+", effectiveDate = "+effectiveDate+", expirationDate = "+expirationDate+"]";
        }
}
