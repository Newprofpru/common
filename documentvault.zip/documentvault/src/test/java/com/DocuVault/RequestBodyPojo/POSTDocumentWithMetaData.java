package com.DocuVault.RequestBodyPojo;

public class POSTDocumentWithMetaData {
	
	private String documentName;
	private String documentCategoryName;
	private String documentLink;
	private String contractId;
	private String documentDescription;
	private String documentSourceCode;
	private String  documentSourceId;
	private String lineOfBusinessCode;
	private String expirationDate;
	private String processedDate;
	private String effectiveDate;
	
	
	
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentCategoryName() {
		return documentCategoryName;
	}
	public void setDocumentCategoryName(String documentCategoryName) {
		this.documentCategoryName = documentCategoryName;
	}
	public String getDocumentLink() {
		return documentLink;
	}
	public void setDocumentLink(String documentLink) {
		this.documentLink = documentLink;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getDocumentDescription() {
		return documentDescription;
	}
	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}
	public String getDocumentSourceCode() {
		return documentSourceCode;
	}
	public void setDocumentSourceCode(String documentSourceCode) {
		this.documentSourceCode = documentSourceCode;
	}
	public String getDocumentSourceId() {
		return documentSourceId;
	}
	public void setDocumentSourceId(String documentSourceId) {
		this.documentSourceId = documentSourceId;
	}
	public String getLineOfBusinessCode() {
		return lineOfBusinessCode;
	}
	public void setLineOfBusinessCode(String lineOfBusinessCode) {
		this.lineOfBusinessCode = lineOfBusinessCode;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getProcessedDate() {
		return processedDate;
	}
	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	

}
