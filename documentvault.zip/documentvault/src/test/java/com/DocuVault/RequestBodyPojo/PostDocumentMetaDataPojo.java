package com.DocuVault.RequestBodyPojo;

public class PostDocumentMetaDataPojo {
    private String documentDescription;

    private String documentSourceId;

    private String documentSourceCode;

    private String processDate;

    private String contractId;

    private String documentCategoryName;

    private String documentLink;

    private String documentName;

    private String lineOfBusinessCode;

    private String effectiveDate;

    private String expirationDate;

    public String getDocumentDescription() {
        return documentDescription;
    }

    public void setDocumentDescription(String documentDescription) {
        this.documentDescription = documentDescription;
    }

    public String getDocumentSourceId() {
        return documentSourceId;
    }

    public void setDocumentSourceId(String documentSourceId) {
        this.documentSourceId = documentSourceId;
    }

    public String getDocumentSourceCode() {
        return documentSourceCode;
    }

    public void setDocumentSourceCode(String documentSourceCode) {
        this.documentSourceCode = documentSourceCode;
    }

    public String getProcessDate() {
        return processDate;
    }

    public void setProcessDate(String processDate) {
        this.processDate = processDate;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getDocumentCategoryName() {
        return documentCategoryName;
    }

    public void setDocumentCategoryName(String documentCategoryName) {
        this.documentCategoryName = documentCategoryName;
    }

    public String getDocumentLink() {
        return documentLink;
    }

    public void setDocumentLink(String documentLink) {
        this.documentLink = documentLink;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getLineOfBusinessCode() {
        return lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return "ClassPojo [documentDescription = " + documentDescription + ", documentSourceId = " + documentSourceId + ", documentSourceCode = " + documentSourceCode + ", processDate = " + processDate + ", contractId = " + contractId + ", documentCategoryName = " + documentCategoryName + ", documentLink = " + documentLink + ", documentName = " + documentName + ", lineOfBusinessCode = " + lineOfBusinessCode + ", effectiveDate = " + effectiveDate + ", expirationDate = " + expirationDate + "]";
    }
}
