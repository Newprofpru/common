package com.DocuVault;

import static io.restassured.RestAssured.given;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.http.HttpResponse;
import org.testng.Assert;


import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lowagie.text.pdf.OcspClient;



import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.specification.RequestSpecification;

public class SampleGetValidation {
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static Response Res1;
	static Map<String, String> data;
	//static Set<String> paramNames=data.keySet();
	public static void main(String[] args) {
		
		
//		RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/0851724951";
//		request = given().log().all()
//				.header("Content-Type", "application/x-www-form-urlencoded")
//				  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
//				  .header("cache-control", "no-cache")
//				  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
//			
//		Res1 = request.when().get().andReturn();
//		logger.info("Response----->:" + Res1.prettyPrint());
//		logger.info(Res1.asString());
		
		
		
		//profile1.setcontactAddresses(temp);
		String resBody="{\r\n" + 
				"    \"partyID\": 653927973,\r\n" + 
				"    \"phoneNumbers\": [\r\n" + 
				"        {\r\n" + 
				"            \"phoneNumberID\": \"5d2836be7a9a7b00277cbb16\",\r\n" + 
				"            \"countryCallingCode\": \"\",\r\n" + 
				"            \"localAreaCode\": \"739\",\r\n" + 
				"           \"localPhoneNumber\": \"6756086\",\r\n" + 
				"            \"extension\": \"\",\r\n" + 
				"            \"type\": \"Home\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            }\r\n" + 
				"        },\r\n" + 
				"        {\r\n" + 
				"            \"phoneNumberID\": \"5d283719211e52004b8ca4b9\",\r\n" + 
				"            \"countryCallingCode\": \"\",\r\n" + 
				"            \"localAreaCode\": \"242\",\r\n" + 
				"            \"localPhoneNumber\": \"2561650\",\r\n" + 
				"            \"extension\": \"\",\r\n" + 
				"            \"type\": \"Work\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            }\r\n" + 
				"        },\r\n" + 
				"        {\r\n" + 
				"            \"phoneNumberID\": \"5d2837a33960d3002e394f50\",\r\n" + 
				"            \"countryCallingCode\": \"\",\r\n" + 
				"            \"localAreaCode\": \"803\",\r\n" + 
				"            \"localPhoneNumber\": \"4922802\",\r\n" + 
				"            \"extension\": \"\",\r\n" + 
				"            \"type\": \"Mobile\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            }\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"policies\": [\r\n" + 
				"        {\r\n" + 
				"            \"policyNumber\": \" L9153367\",\r\n" + 
				"            \"productName\": \"LEVEL TERM\",\r\n" + 
				"            \"lobType\": \"LIFEPRO\",\r\n" + 
				"            \"adminSystemType\": \"LIFEPRO\",\r\n" + 
				"            \"productGroup\": \"LIFE\",\r\n" + 
				"            \"policyStatus\": \"Active\",\r\n" + 
				"            \"issueCompany\": \"Pruco Life of Arizona\",\r\n" + 
				"            \"policyDetail\": \"\",\r\n" + 
				"            \"growthInd\": true\r\n" + 
				"        },\r\n" + 
				"        {\r\n" + 
				"            \"policyNumber\": \" V4664410\",\r\n" + 
				"            \"productName\": \"UNIVERSAL Life\",\r\n" + 
				"            \"lobType\": \"VANTAGE\",\r\n" + 
				"            \"adminSystemType\": \"VANTAGE\",\r\n" + 
				"            \"productGroup\": \"LIFE\",\r\n" + 
				"            \"policyStatus\": \"Active\",\r\n" + 
				"            \"issueCompany\": \"Pruco Life of New Jersey\",\r\n" + 
				"            \"policyDetail\": \"\",\r\n" + 
				"            \"growthInd\": true\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"emailAddresses\": [\r\n" + 
				"        {\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            },\r\n" + 
				"            \"emailAddressID\": \"171812127\",\r\n" + 
				"            \"emailAddress\": \"TESTEMAIL853231@TEST.COM\",\r\n" + 
				"            \"type\": \"Primary\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"postalAddresses\": [\r\n" + 
				"        {\r\n" + 
				"            \"appliedPolicies\": [],\r\n" + 
				"            \"postalAddressID\": \"890663371\",\r\n" + 
				"           \"street1\": \"9604 57TH AVE\",\r\n" + 
				"            \"street2\": \"\",\r\n" + 
				"            \"street3\": \"\",\r\n" + 
				"            \"city\": \"CORONA\",\r\n" + 
				"            \"country\": \"USA\",\r\n" + 
				"            \"postalCode\": \"113683414\",\r\n" + 
				"            \"addressType\": \"Primary\",\r\n" + 
				"            \"effectiveDate\": \"\",\r\n" + 
				"            \"state\": \"NY\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            },\r\n" + 
				"            \"validation\": true\r\n" + 
				"        },\r\n" + 
				"        {\r\n" + 
				"            \"appliedPolicies\": [\r\n" + 
				"                \"https://api.prudential.com/v1/policies/L9153367\"\r\n" + 
				"            ],\r\n" + 
				"            \"postalAddressID\": \"950872861\",\r\n" + 
				"            \"street1\": \"213 WASHINGTON STREET\",\r\n" + 
				"            \"street2\": \"\",\r\n" + 
				"            \"street3\": \"\",\r\n" + 
				"            \"city\": \"NEWARK\",\r\n" + 
				"            \"country\": \"USA\",\r\n" + 
				"            \"postalCode\": \"071022917\",\r\n" + 
				"            \"addressType\": \"Mailing\",\r\n" + 
				"            \"effectiveDate\": \"2019-07-11\",\r\n" + 
				"            \"state\": \"NJ\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            },\r\n" + 
				"            \"validation\": true\r\n" + 
				"        },\r\n" + 
				"        {\r\n" + 
				"            \"appliedPolicies\": [\r\n" + 
				"                \"https://api.prudential.com/v1/policies/V4664410\"\r\n" + 
				"            ],\r\n" + 
				"            \"postalAddressID\": \"988802397\",\r\n" + 
				"            \"street1\": \"9608 57TH AVE\",\r\n" + 
				"            \"street2\": \"\",\r\n" + 
				"            \"street3\": \"\",\r\n" + 
				"            \"city\": \"CORONA\",\r\n" + 
				"            \"country\": \"USA\",\r\n" + 
				"            \"postalCode\": \"113683401\",\r\n" + 
				"            \"addressType\": \"Mailing\",\r\n" + 
				"            \"effectiveDate\": \"2019-07-11\",\r\n" + 
				"            \"state\": \"NY\",\r\n" + 
				"            \"editability\": {\r\n" + 
				"                \"status\": true,\r\n" + 
				"                \"reasonCode\": \"\",\r\n" + 
				"                \"reasonDescription\": \"\"\r\n" + 
				"            },\r\n" + 
				"            \"validation\": true\r\n" + 
				"        }\r\n" + 
				"    ]\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"";
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		JsonArray phoneNumbersArray = new JsonArray();
		JsonArray emailAddressesArray = new JsonArray();
		JsonArray postalAddressesArray = new JsonArray();
		JsonArray appliedPoliciesArray = new JsonArray();
	
		
		JsonArray editabilityArray = new JsonArray();
//		if(responseObject.has("phoneNumbers")){
//		phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
//System.out.println(phoneNumbersArray.size());
////		}
//		for (JsonElement eachphoneNumbersArray : phoneNumbersArray) {
//			
//		
//			String ContactChannelID=eachphoneNumbersArray.getAsJsonObject().get("phoneNumberID").getAsString();
//			String type=eachphoneNumbersArray.getAsJsonObject().get("type").getAsString();
//			String PhoneNo=eachphoneNumbersArray.getAsJsonObject().get("localAreaCode").getAsString()+eachphoneNumbersArray.getAsJsonObject().get("localPhoneNumber").getAsString();
//			System.out.println("ContactChannelID "+ContactChannelID);
//			System.out.println("type "+type);
//			System.out.println("PhoneNo "+PhoneNo);
//			
//			
//		}
		if(responseObject.has("emailAddresses")){
			emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
			
			
			
			
			
				
		
	
			}
			for (JsonElement eachemailAddressesArray : emailAddressesArray) {
				
			
				String emailAddressID=eachemailAddressesArray.getAsJsonObject().get("emailAddressID").getAsString();
				String type=eachemailAddressesArray.getAsJsonObject().get("type").getAsString();
				String emailAddress=eachemailAddressesArray.getAsJsonObject().get("emailAddress").getAsString();
				JsonObject editability = eachemailAddressesArray.getAsJsonObject().get("editability").getAsJsonObject();
				boolean status = editability.getAsJsonObject().get("status").getAsBoolean();
				if(status == true) {
					System.out.println("Compl;eted");
				
				}
				System.out.println("type "+type);
//				System.out.println("emailAddress "+emailAddress);
			}
//	
//	if(responseObject.has("postalAddresses")){
//		postalAddressesArray=responseObject.get("postalAddresses").getAsJsonArray();
//
//		}
//		for (JsonElement eachpostalAddressesArray : postalAddressesArray) {
//			
//			
//			String postalAddressID=eachpostalAddressesArray.getAsJsonObject().get("postalAddressID").getAsString();
//			String addressType=eachpostalAddressesArray.getAsJsonObject().get("addressType").getAsString();
//			String street1=eachpostalAddressesArray.getAsJsonObject().get("street1").getAsString();
//			String street2=eachpostalAddressesArray.getAsJsonObject().get("street2").getAsString();
//			String street3=eachpostalAddressesArray.getAsJsonObject().get("street3").getAsString();
//			String city=eachpostalAddressesArray.getAsJsonObject().get("city").getAsString();
//			String country=eachpostalAddressesArray.getAsJsonObject().get("country").getAsString();
//			String postalCode=eachpostalAddressesArray.getAsJsonObject().get("postalCode").getAsString();
//			String state=eachpostalAddressesArray.getAsJsonObject().get("state").getAsString();
//			System.out.println("postalAddressID "+postalAddressID);
//			System.out.println("addressType "+addressType);
//			System.out.println("street1 "+street1);
//			System.out.println("street2 "+street2);
//			System.out.println("street3 "+street3);
//			System.out.println("city "+city);
//			System.out.println("country "+country);
//			System.out.println("postalCode "+postalCode);
//			System.out.println("state "+state);
//		}
}

}
