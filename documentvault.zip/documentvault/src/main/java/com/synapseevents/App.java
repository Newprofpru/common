package com.synapseevents;

import java.io.FileNotFoundException;
import java.io.IOException;

//import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
		System.out.println("Hello World!");


		// logger.debug("If resetcode is valid,generate JWToken with ssoid ");

		/*String encodingCharSet = "UTF-8";
		String signingAlgorithm = "HS256";
		long expirationTimeMillis = 15778476000L;
		String securityKey = "generateJWT_asdasfqwfsas23123guijg2w78dwugediqdwq";
		Map<String, String> map = new HashMap<String, String>();
		map.put("ssoid", "25151608");
		
		try {
			String jwtTocken = JWTHelper.createJWT(map, expirationTimeMillis, securityKey, encodingCharSet,
					signingAlgorithm);
			System.out.println(jwtTocken);
		} catch (Exception e) {
			// logger.error("Error while calling Siteminder findSSOID
			// method"+e);
		}*/
		
		
				
					   
					
					   //Headers headders =response.getHeaders();
					   
/*JSONParser parser = new JSONParser();
		
		Map response = null;
				//JSONObject  jsonObject = (JSONObject) parser.parse(new
				//  FileReader("C:\\Users\\X214090\\Desktop\\Events.json"));
				  //JSONObject jsonObject = new JSONObject(response);
		//JSONArray Test_Ar = jsonObject.getJSONArray("Test");
				   
				  
				   String XPruRequestID="ResetSecurity26112344";
				   //ArrayList<String> TransactionLog = new ArrayList<String>(
						   // Arrays.asList("activate account","Success"));
				   String[] TransactionLog ={"activate account","Success"};

				   
				 for(int j = 0;j < 4;j++)
				 {
				    	Connection con2 = DBConnection.getConnection();
				   	    String query = "select transactiontypecode,transactionmessage,transactionstatus from usertransactionlog where TRANSACTIONREQUESTID='"+XPruRequestID+"'";

				   		System.out.println(query);
				   		ResultSet rs = DBConnection.execStatement(con2, query);
				   		System.out.println("DB Results is " + rs);
				   		
				   			 
				   		GenericEvent db_res = null;	
				   		//GenericEvent db_res = new GenericEvent(rs);
				   		//db_res.add(new GenericEvent(rs));

						if (rs != null) {

							try {
								while (rs.next()) {
									// System.out.println(rs.getString(1));
									db_res = new GenericEvent(rs);
									// System.out.println(rs.getString(1));

								}
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} 

						} else {

							System.out.println("RS is null!");
						}

						if (db_res.event_cols.isEmpty()) {
							System.out.println("DB Result is empty!");

						} else {

							//for (GenericEvent gev : db_res) {

								for (int i = 0; i < db_res.event_cols.size(); i++) {
									System.out.print(db_res.event_cols.get(i) + " ");
									System.out.println(db_res.event_cols.get(0));

								}
								System.out.println();
							

					}
	}*/
	}

	}
