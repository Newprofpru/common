package com.scripted.dataload;

import com.scripted.generic.RandomTestdataHelper;
import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveOAuth2HeaderScheme;
import io.restassured.response.Response;

import org.testng.Assert;

import javax.sound.midi.Soundbank;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import static com.scripted.generic.RandomTestdataHelper.Category.RANDOM_NUMERIC;
import static io.restassured.RestAssured.given;

public class GenerateTestData {

    static String baseURL = "https://ontrack3-qa.hilti.com";
    static String apiBaseURL = "https://hc-apigw-q.hilti.com";
    JsonTestData testData;
    private HashMap<String,String> map = new HashMap();
    static String date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

    static String futuredate = ZonedDateTime.now().plusDays(2).withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


    public static void main(String[] args) {
        HashMap<String,String> map = new HashMap();
        GenerateTestData data = new GenerateTestData();
        GenerateTestData data2 = new GenerateTestData();
      data.createTestData("CREATE_ASSET");

        data.deleteGeneratedData();
    }



    public HashMap<String,String> createTestData(String name) {

        if (!map.containsKey("TIMESTAMP")){
            generateTimeStamp();
        }

        switch (name){
            case "CREATE_USER":
                createUser();
                break;
            case "USER_PASSWORD":
                createPassword();
                break;
            case "CREATE_ASSET":
                createAsset();
                break;
            case "CREATE_ASSET_FLEET":
                createAssetFleet();
                break;
            case "CREATE_ASSET_LOANED":
                createAssetLoaned();
                break;
            case "CREATE_ASSET_RENTED":
                createAssetRented();
                break;
            case "CREATE_ASSET_OWNED":
                createAssetOwned();
                break;
            case "CREATE_STORAGE_ASSET_CONTAINER":
                createStorageAsset("CONTAINER");
                break;
            case "CREATE_WORKER":
                createWorker();
                break;
            case "CREATE_LOCATION":
                createLocation();
                break;
            case "CREATE_MANUFACTURER":
                createManufacturer();
                break;
            case "CREATE_ASSET_GROUP":
                createAssetGroup();
                break;
            case "CREATE_QUANTITY_ITEM":
                createQuantityItem();
                break;
            case "CREATE_ALLOCATION":
                createAllocation();
                break;
            case "CREATE_ALLOCATION_<_MIN_STOCK":
                createAllocationMinStockGreaterThanStockQty();
                break;
            case "REMOVE_ALL_CERTIFICATES":
                removeAllExistingCertificates();
                break;

            default:
                Assert.fail("Not Implemented - Create test data with name '" + name + "'");

        }

        return map;

    }

    public HashMap<String,String> createTestData(String name, HashMap<String,String> existingMap) {

        if (!map.containsKey("TIMESTAMP")){
            generateTimeStamp();
        }

        switch (name){
            case "CREATE_SERVICE":
                createService(existingMap);
                break;
            case "SUBSCRIBE_SERVICE_FOR_ALERT":
                subscribeServiceForAlert(existingMap);
                break;

            case "ADD_SERVICE_TO_ASSET":
                associateServiceToAsset(existingMap);
                break;
            case "CREATE_LOCATION":
                if (existingMap.containsKey("login_ot_ready_user"))
                    getAuthTokenForOtReadyUser();
                createLocation();
                break;
            default:
                Assert.fail("Not Implemented - Create test data with name '" + name + "'");

        }

        return map;

    }

    public  void deleteAllocation(){

        String allocation_id = map.get("allocation_id");
        String quantity_items_id = map.get("quantity_items_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body("{ \"stockQuantity\": \"0\", \"reason\": \"Test\" }")
                .patch(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/" + quantity_items_id + "/allocations/" + allocation_id + "/stock-correction");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call patch allocation " + response.prettyPrint());
        }


        response = given().relaxedHTTPSValidation()
                .when()
                .delete(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/allocation/" + allocation_id);

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete allocation " + response.prettyPrint());
        }

        System.out.println("Deleted Allocation " + allocation_id);

    }

    public  void deleteQuantityItems(){

        String quantity_items_id = map.get("quantity_items_id");
        String body = "{ \"excludedIds\": null, \"filter\": [\"allocationStatus:in=AVAILABLE\"], \"isSelectAll\": false, \"query\": \"\"," +
                " \"qtyIds\": [" + quantity_items_id + "] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/quantity-items");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete allocation " + response.prettyPrint());
        }

        System.out.println("Deleted Quantity Item " + quantity_items_id);

    }



    public HashMap<String, String> updateTestData(String name, HashMap<String, String> existingMap) {

        if (!map.containsKey("TIMESTAMP")) {
            generateTimeStamp();
        }

        switch (name) {
            case "UPDATE_LOCATION":
                updateLocation(existingMap);
                break;

            case "STORAGE_ASSET_ADD_ASSET":
                createAssetWithParentId(existingMap);
                break;

            case "STORAGE_ASSET_ADD_QTY_ITEM":
                transferQtyItemToStorageAsset(existingMap);
                break;

            case "UPDATE_FIELD_REQUEST":
                updateFieldRequest(existingMap);
                break;
            case "ASSET_TRANSFER_TO_NEW_LOCATION":
                transferAssetToNewLocation(existingMap);
                break;

            case "ASSET_UPDATE_STATUS":
                updateAssetStatus(existingMap);
                break;

            case "ASSET_DELETE":
                deleteAsset(existingMap);
                break;

            case "TRANSFER_CONFIRMATION_SETTING":
                updateTransferConfirmationSetting(existingMap);
                break;

            case "UPDATE_PERMISSION":
                updatePermission(existingMap);
                break;

            case "ASSIGN_PERMISSION":
                assignPermission(existingMap);
                break;
            case "ASSET_TRANSFER_TO_NEW_LOCATION_WITH_RETURN_DATE":
                transferAssetToNewLocationWithReturndate(existingMap);
                break;
            case "REMOVE_CERTIFICATE_FROM_USER":
                removeCertificate(existingMap);
                break;
            case "DELETE_CERTIFICATE_TEMPLATE":
                deleteCertificateTemplate(existingMap);
                break;
            case "DELETE_MODEL_TEMPLATE":
                deleteTemplate(existingMap);
                break;
            case "UPDATE_MANUAL_CHECK":
                updateManualcheck(existingMap);
                break;
            case "UPDATE_ASSET_TRACKING":
                updateTracking(existingMap);
                break;
            case "UPDATE_CERTIFICATE":
                updateCertificate(existingMap);
                break;
            case "UPDATE_CERTIFICATE_FOR_ALERT":
                assignCertificateForAlert(existingMap);
                break;
            case "ADD_CERTIFICATE_TO_USER":
                assignCertificate(existingMap);
                break;
            case "DELETE_WORKER":
                deleteWorker(existingMap);
                break;
            case "CREATE_ASSET_WITH_SERVICE_TEMPLATE":
               createAssetwithAssignserviceInTemplate(existingMap);
                break;
            case "UPDATE_FIELD_REQUEST_SETTING":
                updateFieldRequestSetting(existingMap);
                break;
            case "DELETE_Location":
                deleteLocation(existingMap);
                break;
            case "ADD_PURCHASE_TO_QTY_ITEM":
                addPurchaseDetailstoQtyItem(existingMap);
                break;


            default:
                Assert.fail("Not Implemented - Update test data with name '" + name + "'");

        }

        return map;

    }



    private void generateTimeStamp() {
        final String dateFormat = "ddMMHHmmssSS";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
        String timestamp = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(formatter);
        map.put("TIMESTAMP", timestamp);
    }


    public void getAuthToken() {
        String username = "mobautomationuser@user.com", password = "H!lti@1234", tenantId = "588";
        getAuthToken(username,password,tenantId);
    }

    public void getAuthTokenForFieldRequest() {
        String username = "mobileautomationuser1@gmail.com", password = "Test1234", tenantId = "588";
        getAuthToken(username,password,tenantId);
    }

    private void getAuthTokenForOtReadyUser() {
        String username = "mobautomationuser_OTReady@user.com", password = "Test1234", tenantId = "2109";
        getAuthToken(username,password,tenantId);
    }
    private void getAuthTokenForUserParent() {
        String username = "parent@daniel.com", password = "Test1234", tenantId = "2304";
        getAuthToken(username,password,tenantId);
    }
    public void getAuthToken(String username, String password, String tenantId) {


        if (!map.containsKey("TIMESTAMP")){
            generateTimeStamp();
        }


        Response response = given().relaxedHTTPSValidation()
                .auth().preemptive()
                .basic(username, password)
                .when()
                .post(baseURL + "/auth/web/signin?tenant_id=" + tenantId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call nonce " + response.prettyPrint());
        }

        String nonce = response.jsonPath().get("authenticationNonce").toString();

        response = given().relaxedHTTPSValidation()
                .queryParam("authenticationNonce", nonce)
                .get(baseURL + "/auth/web/context");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call get token" + response.prettyPrint());
        }

        String token = response.jsonPath().get("access_token").toString();


        PreemptiveOAuth2HeaderScheme auth = new PreemptiveOAuth2HeaderScheme();
        auth.setAccessToken(token);
        map.put("access_token", token);
        RestAssured.authentication = auth;

    }





    public  void createWorker() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String firstName = "FN" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_NUMERIC,3);
        String lastName = "LN" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_NUMERIC,3);

        String body = "{ \"firstName\": \"" + firstName + "\", \"lastName\": \"" + lastName + "\", \"workerType\": \"PERMANENT\", \"responsibilityType\": \"LOCATION_MANAGER\"," +
                " \"badgeId\": \"" + map.get("TIMESTAMP") + "\"," +
                " \"scanCode\": \"69879808\", \"mobileContactNumber\": { \"countryCode\": \"91\", \"phoneNumber\": \"69898789799\", \"isPublic\": true }, \"officeContactNumber\": { \"phoneNumber\": \"7988989\", \"countryCode\": \"91\", \"isPublic\": true }, \"language\": \"en-US\", \"isUser\": false, \"userRole\": \"EVERYONE\", \"workerState\": \"ACTIVE\", \"jobFunctionId\": null, \"contactId\": null, \"isExtendAccess\": false, \"isDomainUser\": false, \"costCenter\": \"79080\", \"description\": \"Test employee\", \"workerCertificateRequestList\": [], \"origin\": \"ON!Track\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/um/v1/workers");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create worker" + response.prettyPrint());
        }


        String workerId = response.jsonPath().get("id").toString();

        map.put("worker_id", workerId);
        map.put("worker_firstname", firstName);
        map.put("worker_lastname", lastName);

        System.out.println(firstName + " " + lastName);

        System.out.println("Created Worker " + workerId);

    }

    public  void createLocation() {

        if (!map.containsKey("worker_id")) {
            createWorker();
        }

        String locationName = "AutoLoc_" + map.get("TIMESTAMP");
        String body = "{ \"description\": \"test location\", \"latitude\": null, " +
                "\"locationManager\": \" " + map.get("worker_id") + "\", " +
                "\"locationState\": \"ACTIVE\", \"longitude\": null, " +
                "\"name\": \"  " + locationName + " \", \"type\": \"WAREHOUSE\", \"parentLocation\": null }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/om/v1/locations");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create location" + response.prettyPrint());
        }


        String locationId = response.jsonPath().get("id").toString();
        map.put("location_id", locationId);
        map.put("location_name", locationName);
        System.out.println("Created Location " + locationId);

    }

    public  void createManufacturer() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String body = "{ \"manufacturerName\": \"" + map.get("TIMESTAMP") + "\", \"manufacturerNotes\": \"Notes\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/manufacturers");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create manufacturer " + response.prettyPrint());
        }

        String manufacturerId = response.jsonPath().get("id").toString();
        String manufacturerName = response.jsonPath().get("manufacturerName").toString();
        map.put("manufacturer_id", manufacturerId);
        map.put("manufacturer_name", manufacturerName);
        System.out.println("Created Manufacturer " + manufacturerId);


    }

    public  void createAssetGroup() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String body = "{ \"id\": 0, \"parentGroupId\": null," +
                " \"groupName\": \"" + map.get("TIMESTAMP") + "\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/group");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset group " + response.prettyPrint());
        }

        String groupId = response.jsonPath().get("groupId").toString();
        String groupName = response.jsonPath().get("groupName").toString();
        map.put("group_id", groupId);
        map.put("group_name", groupName);
        System.out.println("Created Asset Group " + groupId);


    }

    public  void createAsset() {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));
        String model = "auto_model :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));
        String body = "{ \"manufacturerId\": \"" + map.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + map.get("manufacturer_name") + "\", " +
                "\"groupId\": \"" + map.get("group_id") + "\", \"storageLocation\": \"StorageAsset001\"," +
                " \"ownerId\": " + map.get("worker_id") + "," +
//                " \"assetUsageConditionDate\": \"" + date + "\", " +
                "\"inventoryNumber\": \"" + "TAIN " + map.get("TIMESTAMP") + "\", \"responsibleEmployeePhone\": [], \"model\": \"" + model + "\", \"assetId\": null," +
                " \"serialNumber\": \"" + "TASN" + map.get("TIMESTAMP") + "\"," +" \"costCode\": \"" + "CostCode_" + map.get("TIMESTAMP") + "\"," +
                " \"responsibleEmployeeId\": " + map.get("worker_id") + ", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseDate\": null }, " +
                "\"groupName\": \"" + map.get("group_name") + "\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"TestName\", \"loanedAssetDetails\": {}," +
                " \"costCode\": \"" + map.get("TIMESTAMP") + "\", \"currentLocationId\": \"" + map.get("location_id") + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"--Allocation\", \"ownerShipType\": \"OWNED\", \"ownerName\": \"Kelvin Dsouza\", \"defaultLocationName\": \"--Allocation\", \"rentedAssetDetails\": {}," +
                " \"defaultLocationId\": \"" + map.get("location_id") + "\", \"usageStateCode\": \"ACT\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + "TASC" + map.get("TIMESTAMP") + "\", \"responsibleEmployeeName\": \"Kelvin Dsouza\", \"scanCodeType\": \"BAC\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("serial_number", response.jsonPath().get("serialNumber").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());
        map.put("cost_code", response.jsonPath().get("costCode").toString());
        map.put("model_name", model);
        map.put("notes",notes);
        map.put("asset_name", response.jsonPath().get("name").toString());
        map.put("defaultLocation_Id", response.jsonPath().get("defaultLocationId").toString());
        map.put("currentLocation_Name", response.jsonPath().get("currentLocationName").toString());
        map.put("storage_Location", response.jsonPath().get("storageLocation").toString());
        map.put("owner_Name", response.jsonPath().get("ownerName").toString());
        map.put("responsibleEmployee_Name", response.jsonPath().get("responsibleEmployeeName").toString());
       // map.put("ownerShip_Type", response.jsonPath().get("ownerShipType").toString());
        map.put("group_Name", response.jsonPath().get("groupName").toString());

        System.out.println("Created Asset " + assetId);
        System.out.println("Created scancode " + map.get("scan_code"));
    }

    public  void createAssetwithAssignserviceInTemplate(HashMap<String, String> existingMap) {

        String model = "auto_model :" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_ALPHANUMERIC_5);
        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }
        if(!map.containsKey("service_id")){
            createService(existingMap);
        }
        map.put("model_Name",model);
        assignTemplateWithService();

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));

        String body = "{ \"manufacturerId\": \"" + map.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + map.get("manufacturer_name") + "\", " +
                "\"groupId\": \"" + map.get("group_id") + "\", \"storageLocation\": \"StorageAsset001\"," +
                " \"ownerId\": " + map.get("worker_id") + "," +
//                " \"assetUsageConditionDate\": \"" + date + "\", " +
                "\"inventoryNumber\": \"" + "TAIN " + map.get("TIMESTAMP") + "\", \"responsibleEmployeePhone\": [], \"model\": \"" + model + "\", \"assetId\": null," +
                " \"serialNumber\": \"" + "TASN" + map.get("TIMESTAMP") + "\"," +
                " \"responsibleEmployeeId\": " + map.get("worker_id") + ", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseDate\": null }, " +
                "\"groupName\": \"" + map.get("group_name") + "\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"TestName\", \"loanedAssetDetails\": {}," +
                " \"currentLocationId\": \"" + map.get("location_id") + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"--Allocation\", \"ownerShipType\": \"OWNED\", \"ownerName\": \"Kelvin Dsouza\", \"defaultLocationName\": \"--Allocation\", \"rentedAssetDetails\": {}," +
                " \"defaultLocationId\": \"" + map.get("location_id") + "\", \"usageStateCode\": \"ACT\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + "TASC" + map.get("TIMESTAMP") + "\", \"responsibleEmployeeName\": \"Kelvin Dsouza\", \"scanCodeType\": \"BAC\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("serial_number", response.jsonPath().get("serialNumber").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Asset " + assetId);
        System.out.println("Created scancode " + map.get("scan_code"));


    }


    public  void createAssetFleet() {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

//        if (!map.containsKey("group_id")) {
//            createAssetGroup();
//        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));

        String manfId = map.get("manufacturer_id");
        String manfName = map.get("manufacturer_name");
        String groupId = "0";
        String workerId = map.get("worker_id");
        String invNumber = "TAIN " + map.get("TIMESTAMP");
        String locationId = map.get("location_id");
        String scanCode = "TASC" + map.get("TIMESTAMP");

        String body1 = "{ \"assetImageId\": null, \"notes\": { \"assetImageId\": null, \"notes\": \"" + notes + "\", " +
                "\"manufacturerId\": " + manfId + ", \"" + manfName + "\": \"010206043676\", \"groupId\": 0, \"storageLocation\": \"StorageLoca1\", \"ownerId\": " + workerId + "," +
                " \"inventoryNumber\": \"" + invNumber + "\", \"responsibleEmployeePhone\": [], \"model\": \"1222\", \"assetId\": null, \"currentLocationState\": { \"value\": \"Active\", \"code\": \"ACTIVE\" }, \"serialNumber\": \"\", \"previousSerialNumber\": null, \"replacementSerialNumber\": null, \"responsibleEmployeeId\": " + workerId + ", \"assetTemplateId\": null, \"ownedAssetDetails\": { \"purchaseCurrencyCode\": null, \"purchaseDate\": null, \"purchaseOrderNumber\": null, \"purchasePrice\": null, \"vendor\": null, \"warrantyExpirationDate\": null }, \"groupName\": \"Ungrouped\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": { \"fleetCostCenter\": \"55434\", \"fleetCurrencyCode\": \"DZD\", \"fleetDeliveryDate\": \"2023-02-08\", \"fleetExchangeOrWarrantyDate\": \"2023-02-08\", \"fleetInventoryNumber\": \"IN6790\", \"fleetOrganizationReferenceNumber\": \"FLON69789\", \"fleetPurchaseOrderNumber\": \"IN7989\", \"loanToolClaim\": true, \"monthlyFleetRate\": \"790\", \"theftInsurance\": true }, \"name\": \"test name\", \"loanedAssetDetails\": { \"loanEndDate\": null, \"loanStartDate\": null }," +
                " \"currentLocationId\": " + locationId + ", \"statusCode\": \"OPR\", \"assetStateCode\": \"WARE\", \"assetTemplateName\": \"1222-010206043676\", \"currentLocationName\": \"130114015223\", \"ownerShipType\": \"FLEET\", \"ownerName\": \"Test1 Employee (130114015223)\", \"defaultLocationName\": \"130114015223\", \"rentedAssetDetails\": { \"rentalReturnDate\": null, \"rentalStartDate\": null, \"rentalToolClaim\": null }," +
                " \"defaultLocationId\": " + locationId + ", \"responsibleEmployeeLanguage\": \"English\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + scanCode + "\", \"tenantId\": 588, \"responsibleEmployeeName\": \"Test1 Employee (130114015223)\", \"scanCodeType\": \"BAC\", \"replacementCost\": \"689\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"hiltiIntegratedAsset\": false, \"hiltiAssetOwnerName\": null, \"isSapAsset\": false, \"defaultParentName\": null, \"defaultLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }, \"manufacturerId\": 204703," +
                " \"manufacturerName\": \"010206043676\", \"groupId\": " + groupId + ", \"storageLocation\": \"StorageLoca1\"," +
                " \"ownerId\":" + workerId + " , \"inventoryNumber\": \"" + invNumber + "\", \"responsibleEmployeePhone\": [], \"model\": \"1222\"," +
                " \"assetId\": null, \"currentLocationState\": { \"value\": \"Active\", \"code\": \"ACTIVE\" }," +
                " \"serialNumber\": \"\", \"previousSerialNumber\": null, \"replacementSerialNumber\": null, " +
                "\"responsibleEmployeeId\": " + workerId + ", \"assetTemplateId\": null, \"ownedAssetDetails\": { \"purchaseCurrencyCode\": null, \"purchaseDate\": null, \"purchaseOrderNumber\": null, \"purchasePrice\": null, \"vendor\": null, \"warrantyExpirationDate\": null }, \"groupName\": \"Ungrouped\", \"labelNames\": [\"Label12\"], " +
                "\"fleetAssetDetails\": { \"fleetCostCenter\": \"55434\", \"fleetCurrencyCode\": \"DZD\", \"fleetDeliveryDate\": \"2023-02-08\"," +
                " \"fleetExchangeOrWarrantyDate\": \"2023-02-08\", \"fleetInventoryNumber\": \"IN6790\", \"fleetOrganizationReferenceNumber\": \"FLON69789\", \"fleetPurchaseOrderNumber\": \"IN7989\", \"loanToolClaim\": true, \"monthlyFleetRate\": \"790\", \"theftInsurance\": true }, \"name\": \"test name\", \"loanedAssetDetails\": { \"loanEndDate\": null, \"loanStartDate\": null }, \"currentLocationId\": " + locationId + ", \"statusCode\": \"OPR\"," +
                " \"assetStateCode\": \"WARE\", \"assetTemplateName\": \"1222-010206043676\", \"currentLocationName\": \"130114015223\", \"ownerShipType\": \"FLEET\", \"ownerName\": \"Test1 Employee (130114015223)\", \"defaultLocationName\": \"130114015223\", \"rentedAssetDetails\": { \"rentalReturnDate\": null, \"rentalStartDate\": null, \"rentalToolClaim\": null }, \"defaultLocationId\": " + locationId + ", \"responsibleEmployeeLanguage\": \"English\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"FleetToolSC2\", \"tenantId\": 588, \"responsibleEmployeeName\": \"Test1 Employee (130114015223)\", \"scanCodeType\": \"BAC\", \"replacementCost\": \"689\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"hiltiIntegratedAsset\": false, \"hiltiAssetOwnerName\": null, \"isSapAsset\": false, \"defaultParentName\": null, \"defaultLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body1)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Fleet Asset " + assetId);


    }

    public  void createAssetLoaned() {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));
        String body = "{ \"manufacturerId\": \"" + map.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + map.get("manufacturer_name") + "\", " +
                "\"groupId\": \"" + map.get("group_id") + "\", \"storageLocation\": \"StorageAsset001\"," +
                " \"ownerId\": " + map.get("worker_id") + "," +
//                " \"assetUsageConditionDate\": \"" + date + "\", " +
                "\"inventoryNumber\": \"" + "TAIN " + map.get("TIMESTAMP") + "\", \"responsibleEmployeePhone\": [], \"model\": \"" + notes + "\", \"assetId\": null," +
                " \"serialNumber\": \"" + "TASN" + map.get("TIMESTAMP") + "\"," +
                " \"responsibleEmployeeId\": " + map.get("worker_id") + ", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseDate\": null }, " +
                "\"groupName\": \"" + map.get("group_name") + "\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"TestName\", \"loanedAssetDetails\": {}," +
                " \"currentLocationId\": \"" + map.get("location_id") + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"--Allocation\", \"ownerShipType\": \"OWNED\", \"ownerName\": \"Kelvin Dsouza\", \"defaultLocationName\": \"--Allocation\", \"rentedAssetDetails\": {}," +
                " \"defaultLocationId\": \"" + map.get("location_id") + "\", \"usageStateCode\": \"ACT\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + "TASC" + map.get("TIMESTAMP") + "\", \"responsibleEmployeeName\": \"Kelvin Dsouza\", \"scanCodeType\": \"BAC\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";


        String manfId = map.get("manufacturer_id");
        String manfName = map.get("manufacturer_name");
        String groupId = "0";
        String workerId = map.get("worker_id");
        String invNumber = "TAIN " + map.get("TIMESTAMP");
        String locationId = map.get("location_id");
        String scanCode = "TASC" + map.get("TIMESTAMP");

        String body1 = "{ \"manufacturerId\": \"" + manfId + "\", \"manufacturerName\": \"" + manfName + "\"," +
                " \"groupId\": \"0\", \"storageLocation\": \"StorageLocat1\", \"ownerId\": " + workerId + "," +
                " \"inventoryNumber\": \"" + invNumber + "\", \"responsibleEmployeePhone\": [], \"model\": \"12538\", \"assetId\": null," +
                " \"responsibleEmployeeId\": "+workerId+", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": null, \"purchaseDate\": null, \"purchaseOrderNumber\": null, \"purchasePrice\": null, \"vendor\": null, \"warrantyExpirationDate\": null }, \"groupName\": \"Ungrouped\", \"fleetAssetDetails\": { \"fleetCostCenter\": null, \"fleetCurrencyCode\": null, \"fleetDeliveryDate\": null, \"fleetExchangeOrWarrantyDate\": null, \"fleetInventoryNumber\": null, \"fleetOrganizationReferenceNumber\": null, \"fleetPurchaseOrderNumber\": null, \"loanToolClaim\": null, \"monthlyFleetRate\": null, \"theftInsurance\": null }, \"name\": \"Name of the tool\"," +
                " \"loanedAssetDetails\": { \"loanEndDate\": \"2023-02-08\", \"loanStartDate\": \"2023-02-08\" }," +
                " \"currentLocationId\": \"" + locationId + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"130114015223\"," +
                " \"ownerShipType\": \"LOAN\", \"ownerName\": \"Test1 Employee\", \"defaultLocationName\": \"130114015223\", \"rentedAssetDetails\": { \"rentalReturnDate\": null, \"rentalStartDate\": null, \"rentalToolClaim\": null }," +
                " \"defaultLocationId\": \"" + locationId + "\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + scanCode + "\", \"responsibleEmployeeName\": \"Test1 Employee\", \"scanCodeType\": \"BAC\", \"replacementCost\": \"799\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body1)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
      //  map.put("serial_number", response.jsonPath().get("serialNumber").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Asset " + assetId);


    }

    public  void createAssetRented() {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));

        String manfId = map.get("manufacturer_id");
        String manfName = map.get("manufacturer_name");
        String groupId = "0";
        String workerId = map.get("worker_id");
        String invNumber = "TAIN " + map.get("TIMESTAMP");
        String locationId = map.get("location_id");
        String scanCode = "TASC" + map.get("TIMESTAMP");

        String body = "{ \"assetImageId\": null, \"manufacturerId\": " + manfId + ", \"manufacturerName\": \"" + manfName + "\"," +
                " \"groupId\": 0, \"storageLocation\": \"StorageLocat1\", \"ownerId\": " + workerId + "," +
                " \"inventoryNumber\": \"" + invNumber + "\", \"responsibleEmployeePhone\": [], \"model\": \"12538\", \"assetId\": null, \"currentLocationState\": { \"value\": \"Active\", \"code\": \"ACTIVE\" }, \"serialNumber\": \"\", \"previousSerialNumber\": null, \"replacementSerialNumber\": null," +
                " \"responsibleEmployeeId\": " + workerId + ", \"assetTemplateId\": null, \"ownedAssetDetails\": { \"purchaseCurrencyCode\": null, \"purchaseDate\": null, \"purchaseOrderNumber\": null, \"purchasePrice\": null, \"vendor\": null, \"warrantyExpirationDate\": null }, \"groupName\": \"Ungrouped\", \"fleetAssetDetails\": { \"fleetCostCenter\": null, \"fleetCurrencyCode\": null, \"fleetDeliveryDate\": null, \"fleetExchangeOrWarrantyDate\": null, \"fleetInventoryNumber\": null, \"fleetOrganizationReferenceNumber\": null, \"fleetPurchaseOrderNumber\": null, \"loanToolClaim\": null, \"monthlyFleetRate\": null, \"theftInsurance\": null }, \"name\": \"Name of the tool\", \"loanedAssetDetails\": { \"loanEndDate\": null, \"loanStartDate\": null }," +
                " \"currentLocationId\": " + locationId + ", \"statusCode\": \"OPR\", \"assetStateCode\": \"WARE\", \"assetTemplateName\": \"12538-010206563185\"," +
                " \"currentLocationName\": \"130114015223\", \"ownerShipType\": \"RENT\", \"ownerName\": \"Test1 Employee (130114015223)\", \"defaultLocationName\": \"130114015223\", " +
                "\"rentedAssetDetails\": { \"rentalReturnDate\": \"2023-02-08\", \"rentalStartDate\": \"2023-02-08\", \"rentalToolClaim\": \"TUIO\" }," +
                " \"defaultLocationId\": " + locationId + ", \"responsibleEmployeeLanguage\": \"English\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + scanCode + "\", \"tenantId\": 588, \"responsibleEmployeeName\": \"Test1 Employee (130114015223)\", \"scanCodeType\": \"BAC\", \"replacementCost\": \"799\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"hiltiIntegratedAsset\": false, \"hiltiAssetOwnerName\": null, \"isSapAsset\": false, \"defaultParentName\": null, \"defaultLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Rented Asset " + assetId);


    }

    public  void createAssetOwned() {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));

        String manfId = map.get("manufacturer_id");
        String manfName = map.get("manufacturer_name");
        String groupId = "0";
        String workerId = map.get("worker_id");
        String invNumber = "TAIN " + map.get("TIMESTAMP");
        String locationId = map.get("location_id");
        String scanCode = "TASC" + map.get("TIMESTAMP");

        String body = "{ \"notes\": \"" + notes + "\", \"manufacturerId\": " + manfId + "," +
                " \"manufacturerName\": \"" + manfName + "\", \"groupId\": \"" + groupId + "\", \"storageLocation\": \"StorageLoca1\"," +
                " \"ownerId\": " + workerId + ", \"inventoryNumber\": \"" + invNumber + "\", \"responsibleEmployeePhone\": []," +
                " \"model\": \"1222\", \"assetId\": null, \"responsibleEmployeeId\": "+workerId+"," +
                " \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"EUR\", \"purchaseDate\": \"2023-02-08\"," +
                " \"purchaseOrderNumber\": \"SC780989\", \"purchasePrice\": \"787\", \"vendor\": \"Hilti\"," +
                " \"warrantyExpirationDate\": \"2023-02-08\" }, \"groupName\": \"Ungrouped\"," +
                " \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"test name\", \"loanedAssetDetails\": {}," +
                " \"currentLocationId\": \"" + locationId + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"130114015223\"," +
                " \"ownerShipType\": \"OWNED\", \"ownerName\": \"Test1 Employee\", \"defaultLocationName\": \"130114015223\"," +
                " \"rentedAssetDetails\": {}, \"defaultLocationId\": " + locationId + ", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + scanCode + "\", \"responsibleEmployeeName\": \"Test1 Employee\", \"scanCodeType\": \"BAC\"," +
                " \"replacementCost\": \"689\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": []," +
                " \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, " +
                "\"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null," +
                " \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset" + response.prettyPrint());
        }

        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Owned Asset " + assetId);


    }

    public  void createStorageAsset(String assetStorageType) {

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!map.containsKey("group_id")) {
            createAssetGroup();
        }

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        String storageType = assetStorageType ;
        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));
        String body = "{ \"manufacturerId\": \"" + map.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + map.get("manufacturer_name") + "\", " +
                "\"groupId\": \"" + map.get("group_id") + "\", \"storageLocation\": \"StorageAsset001\"," +
                " \"ownerId\": " + map.get("worker_id") + "," +
//                " \"assetUsageConditionDate\": \"" + date + "\", " +
                "\"inventoryNumber\": \"" + "TAIN " + map.get("TIMESTAMP") + "\", \"responsibleEmployeePhone\": [], \"model\": \"" + notes + "\", \"assetId\": null," +
                " \"serialNumber\": \"" + "TASN" + map.get("TIMESTAMP") + "\"," +
                " \"responsibleEmployeeId\": " + map.get("worker_id") + ", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseDate\": null }, " +
                "\"groupName\": \"" + map.get("group_name") + "\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"TestName\", \"loanedAssetDetails\": {}," +
                " \"currentLocationId\": \"" + map.get("location_id") + "\", \"statusCode\": \"OPR\", \"currentLocationName\": \"--Allocation\", \"ownerShipType\": \"OWNED\", \"ownerName\": \"Kelvin Dsouza\", \"defaultLocationName\": \"--Allocation\", \"rentedAssetDetails\": {}," +
                " \"defaultLocationId\": \"" + map.get("location_id") + "\", \"usageStateCode\": \"ACT\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + "TASC" + map.get("TIMESTAMP") + "\", \"responsibleEmployeeName\": \"Kelvin Dsouza\", \"scanCodeType\": \"BAC\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"STORAGE\"," +
                " \"assetSubTypeCode\": \"" + storageType + "\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create storage asset " + response.prettyPrint());
        }


        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("serial_number", response.jsonPath().get("serialNumber").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());

        System.out.println("Created Storage Asset " + assetId);

    }

    public  void createAssetWithParentId(HashMap<String,String> existingMap) {


        if (!existingMap.containsKey("location_id")) {
            createLocation();
        }

        if (!existingMap.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        if (!existingMap.containsKey("group_id")) {
            createAssetGroup();
        }

        generateTimeStamp();

        LocalDate now = LocalDate.now();
//        date = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        String _parentId = existingMap.get("asset_id");
        String notes = "Created via automation at :" + ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1"));
        String body = "{ \"manufacturerId\": \"" + existingMap.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + existingMap.get("manufacturer_name") + "\", " +
                "\"groupId\": \"" + existingMap.get("group_id") + "\", \"storageLocation\": \"StorageAsset001\"," +
                " \"ownerId\": " + existingMap.get("worker_id") + "," +
//                " \"assetUsageConditionDate\": \"" + date + "\", " +
                "\"inventoryNumber\": \"" + "TAIN " + map.get("TIMESTAMP") + "\", \"responsibleEmployeePhone\": [], \"model\": \"" + notes + "\", \"assetId\": null," +
                " \"serialNumber\": \"" + "TASN" + map.get("TIMESTAMP") + "\"," +
                " \"responsibleEmployeeId\": " + existingMap.get("worker_id") + ", \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseDate\": null }, " +
                "\"groupName\": \"" + existingMap.get("group_name") + "\", \"labelNames\": [\"Label12\"], \"fleetAssetDetails\": {}, \"name\": \"TestName\", \"loanedAssetDetails\": {}," +
                "  \"statusCode\": \"OPR\", \"currentLocationName\": \"--Allocation\", \"ownerShipType\": \"OWNED\", \"ownerName\": \"Kelvin Dsouza\", \"defaultLocationName\": \"--Allocation\", \"rentedAssetDetails\": {}," +
                " \"defaultLocationId\": \"" + existingMap.get("location_id") + "\", \"usageStateCode\": \"ACT\", \"categoryCode\": \"UNQAST\"," +
                " \"scanCode\": \"" + "TASC" + map.get("TIMESTAMP") + "\", \"responsibleEmployeeName\": \"Kelvin Dsouza\", \"scanCodeType\": \"BAC\", \"assetAttachments\": [], \"openServices\": [], \"historyServices\": [], \"assetTypeCode\": \"NORMAL\", \"assetSubTypeCode\": \"UNIQUE\", \"defaultParentName\": null, \"currentLocationTypeDetails\": { \"code\": \"LOCATION\", \"value\": \"Location\" }, \"parentName\": null, " +
                " \"parentId\": " + _parentId + ", \"telematicDetails\": null, \"scanCodeSource\": \"MANUAL\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create asset with parent id" + response.prettyPrint());
        }


        String assetId = response.jsonPath().get("assetId").toString();
        map.put("asset_id", assetId);
        map.put("tenant_id", response.jsonPath().get("tenantId").toString());
        map.put("asset_template_id", response.jsonPath().get("assetTemplateId").toString());
        map.put("scan_code", response.jsonPath().get("scanCode").toString());
        map.put("serial_number", response.jsonPath().get("serialNumber").toString());
        map.put("inventory_number", response.jsonPath().get("inventoryNumber").toString());


        System.out.println("Created Asset " + assetId + " with parent id " + _parentId);


    }


    public  void createQuantityItem() {

        if (!map.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        String body = "{ \"manufacturerId\": \"" + map.get("manufacturer_id") + "\"," +
                " \"manufacturerName\": \"" + map.get("manufacturer_name") + "\", \"groupId\": 0," +
                " \"inventoryNumber\": \""+ "TQIIN" + map.get("TIMESTAMP") +
                "\", \"model\": \"test\", \"id\": null, \"ownedAssetDetails\": { \"purchaseCurrencyCode\": \"GBP\", \"purchaseUnitId\": \"2\" }, \"groupName\": \"Ungrouped\", \"name\": \"ToolName_" + map.get("TIMESTAMP") +"\", \"stockUnitName\": \"can\", \"description\": \"ToolDescription_"+ map.get("TIMESTAMP") +"\"," +
                " \"scanCode\": \"" + "TQISC" + map.get("TIMESTAMP") + "\", \"scanCodeType\": \"BAC\", \"qtyAttachments\": [], \"stockUnitId\": \"2\", \"currencyCode\": \"GBP\" , \"labelNames\": [\"test_qty\"]}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/quantity-items");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create qunatity item" + response.prettyPrint());
        }

        String id = response.jsonPath().get("id").toString();
        map.put("quantity_items_id", id);
        map.put("quantity_items_scancode", response.jsonPath().get("scanCode").toString());
        map.put("quantity_items_manufacturer_name", response.jsonPath().get("manufacturerName").toString());
        map.put("quantity_items_model", response.jsonPath().get("model").toString());
        map.put("quantity_items_stockUnitName", response.jsonPath().get("stockUnitName").toString());
        map.put("quantity_items_canConsume", response.jsonPath().get("canConsume").toString());
        map.put("quantity_items_groupName", response.jsonPath().get("groupName").toString());
        map.put("quantity_items_name", response.jsonPath().get("name").toString());
        map.put("quantity_items_description", response.jsonPath().get("description").toString());
        map.put("quantity_items_inventoryNumber", response.jsonPath().get("inventoryNumber").toString());
        System.out.println("Created Quantity item  " + id);


    }

    public  void transferQtyItemToStorageAsset(HashMap<String,String> existingMap) {

        if (!existingMap.containsKey("manufacturer_id")) {
            createManufacturer();
        }

        createAllocation();

        String uuid = UUID.randomUUID().toString();
        String storageAssetId = existingMap.get("asset_id");
        String dateTime = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).toString().replaceAll("\\..*","Z");
        String allocationId = map.get("allocation_id");
        String locationId = map.get("location_id");
        String fromWorkerId = map.get("worker_id");
        String toWorkerId = map.get("worker_id");
        String body = "{ \"toLocationId\": null, \"toStorageAssetId\": " + storageAssetId + ", " +
                "\"toWorkerId\": "+toWorkerId+", \"timeZoneAwareTransferDateTime\": \"" + dateTime + "\"," +
                " \"assets\": [{ \"assetId\": " + allocationId + ", " +
                "\"fromLocationId\": " + locationId + ", " +
                "\"fromWorkerId\": " + fromWorkerId + ", \"transferAssetType\": \"ALLOCATION\", \"transferQuantity\": 5, \"toAllocationStatus\": \"AVAILABLE\" }]," +
                " \"transferUUID\": \"" + uuid + "==\" }";


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/assets/transfers?transferOrigin=MOBILE");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call transfer qty_itm to storage asset" + response.prettyPrint());
        }

        String id = response.jsonPath().get("transferId").toString();
        map.put("transfer_id", id);
        System.out.println("Transfer succesful. trasnfer id  " + id);


    }

    private void createAllocation() {

        if (!map.containsKey("worker_id")) {
            createWorker();
        }

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("quantity_items_id")) {
            createQuantityItem();
        }

        String locationId = map.get("location_id");
        String employeeId = map.get("worker_id");
        String body = "{ \"allocationStatus\": \"AVAILABLE\", \"locationId\": \"" + locationId + "\"," +
                " \"mainAllocation\": true, \"responsibleEmployeeId\": " + employeeId + ", \"" +
                "stockAlertEnabled\": true, \"stockMaxQuantity\": \"67\", \"stockMinQuantity\": \"4\", \"stockQuantity\": \"45\", \"storageLocation\": \"54\", \"type\": \"LOCATION\", \"workerId\": null }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/"+map.get("quantity_items_id")+"/allocation");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create allocation" + response.prettyPrint());
        }


        map.put("allocation_id", response.jsonPath().get("id").toString());
        System.out.println("Created allocation id " + response.jsonPath().get("id").toString() );

    }

    public  void deleteWorker(){

        String workerId = map.get("worker_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("workerIdList", workerId)
                .delete(apiBaseURL + "/ts/ontrack/um/v1/worker-users/bulk-delete");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete worker" + response.prettyPrint());
        }

        System.out.println("Deleted worker " + workerId);

    }

    public  void deleteWorker(HashMap<String,String> existingMap){
        String workerId = existingMap.get("worker_id");
        map.put("worker_id", workerId);
        deleteWorker();
    }

    public  void deleteLocation(){

        String locationId = map.get("location_id");

        String body = "{ \"excludedIds\": null, \"filter\": []," +
                " \"locationIds\": ["+locationId+"], \"q\": \"\", \"selectAll\": false }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/om/v1/locations");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete location " + response.prettyPrint());
        }

        System.out.println("Deleted Location " + locationId);

    }

    public  void deleteLocation(HashMap<String,String> existingMap){

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        String locationId = existingMap.get("location_id");
        map.put("location_id", locationId);
        deleteLocation();
    }

    public  void deleteManufacturer(){

        String manufacturerId = map.get("manufacturer_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("assetManufacturerIds", manufacturerId)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/manufacturers");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete manufacturer" + response.prettyPrint());
        }

        System.out.println("Deleted Manufacturer " + manufacturerId);

    }

    public  void deleteAssetGroups(){

        String groupId = map.get("group_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("groupIds", groupId)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/group");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset groups " + response.prettyPrint());
        }

        System.out.println("Deleted Asset group " + groupId);

    }

    public  void deleteAssetTemplate(){

        String assetTemplateId = map.get("asset_template_id");

        String body = "{ \"isSelectAll\": false, \"templateIds\": ["+ assetTemplateId +"] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset template" + response.prettyPrint());
        }

        System.out.println("Deleted Asset Template " + assetTemplateId);

    }

    public  void deleteAsset(HashMap<String,String> existingMap) {


        if (existingMap.containsKey("login_ot_ready_user")){
            getAuthTokenForOtReadyUser();
        }else if (existingMap.containsKey("login_parent_user")){
            getAuthTokenForUserParent();
        }
        else if (!map.containsKey("access_token")){
            getAuthToken();
        }

        String scanCode = existingMap.get("scan_code");
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/unique-asset?q=" + scanCode + "&fields=scanCode");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call get asset " + response.prettyPrint());
        }

        String assetId = response.jsonPath().getString("response[0].assetId");
        map.put("asset_id", assetId);
        deleteAsset();
    }




    public  void deleteAsset(){

        String assetId = map.get("asset_id");

        String body = "{ \"filters\": [], \"isSelectAll\": false, \"query\": \"TestAssetSC1101\", \"view\": null, " +
                "\"assetIds\": ["+assetId+"], \"excludedAssetIds\": [], \"storageAsset\": [] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset" + response.prettyPrint());
        }

        System.out.println("Deleted Asset " + assetId);

    }

    public void updateLocation(HashMap<String, String> locationValues) {
        String locationType ="WAREHOUSE";
        String locationId = locationValues.get("location_id");
        String locationManager = locationValues.get("worker_id");
        String locationName = locationValues.get("locationName");
        String locationStateType = locationValues.get("location_state");
        if(locationValues.containsKey("location_type")) {
            locationType = locationValues.get("location_type");
        }

        String body = "{ \"description\": \"test location\", \"latitude\": null, " +
                "\"locationManager\": \" " + locationManager + "\", " +
                "\"locationState\": \" " + locationStateType + "\", \"longitude\": null, " +
                "\"name\": \"  " + locationName + " \", \"type\": \""+locationType+"\", \"parentLocation\": null }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/om/v1/locations/" + locationId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update location " + response.prettyPrint());
        }

        System.out.println("Updated Location State as >>>> " + locationStateType);
        System.out.println("Updated Location State Name >>>> " + locationName);
    }

    public void updateTransferConfirmationSetting(HashMap<String, String> existingMap) {

        String status = existingMap.get("transferConfirmationPolicy");
        String body = "{ \"transferConfirmationPolicy\": \"" + status + "\", \"isDeliveryNoteEmailEnabled\": false }";

        getAuthToken();

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/om/v1/company/transfer-confirmation-setting");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update transfer confirmation " + response.prettyPrint());
        }

        if (response.statusCode()==200){
            System.out.println("Updated transfer confirmation setting status as "+ status);
        } else {
            Assert.fail("Exception in api call " + response.prettyPrint());
        }

    }

    public void updatePermission(HashMap<String, String> existingMap) {
        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        String permissionGroupId = existingMap.get("permissionGroupId");
        String role = existingMap.get("role")+RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_ALPHASTRING_5);
        String body = "{ \"permissionGroupId\": " + permissionGroupId + "," +
                " \"role\": \"" + role + "\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/um/v1/custom-roles/");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update permission " + response.prettyPrint());
        }

        if (response.statusCode()<=205){
            System.out.println("Updated permission. Id "+ response.jsonPath().getString("id"));
            String userRoleId = response.jsonPath().get("id").toString();
            map.put("user_role_id", userRoleId);
            map.put("role",role);

        } else {
            Assert.fail("Exception in api call update permission " + response.prettyPrint());
        }

    }

    public void assignPermission(HashMap<String, String> existingMap) {

        if (!map.containsKey("user_role_id")) {
            updatePermission(existingMap);
        }

        String userId = map.get("user_role_id");
        String role = map.get("role");
        String body = "{\"firstName\":\"MobileAutomation\",\"lastName\":\"PermissionUser\",\"responsibilityType\":\"NONE\",\"language\":\"en-US\",\"isUser\":true,\"email\":\"mobileautomationuser2@gmail.com\"," +
                "\"userRole\":\""+role+"_588"+"\",\"workerState\":\"ACTIVE\",\"assetsAssignedCount\":0,\"jobFunctionId\":null,\"contactId\":null,\"isExtendAccess\":false,\"isDomainUser\":false,\"id\":1112668," +
                "\"userId\":"+userId+"," + "\"tenantId\":588}";
        getAuthToken();

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/um/v1/worker-users/1112668");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update permission " + response.prettyPrint());
        }

        if (response.statusCode()<=205){
            System.out.println("Assigned permission role name is  "+ role+ " and success message is "+  response.jsonPath().getString("message"));

        } else {
            Assert.fail("Exception in api call update permission " + response.prettyPrint());
        }

    }

    public void createUser() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        String firstName = "FN" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_NUMERIC, 3);
        String lastName = "LN" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_NUMERIC, 3);
        String UserEmail = firstName + "@28MayCheck.com";
        String body = "{ \"firstName\": \"" + firstName + "\", \"lastName\": \"" + lastName + "\", " +
                "\"isUser\": true, \"email\": \"" + UserEmail + "\",\"userRole\": \"EVERYONE\"," +
                " \"workerState\": \"ACTIVE\",\"jobFunctionId\": null,\"contactId\": null," +
                " \"isExtendAccess\": false, \"isDomainUser\": true,\"workerCertificateRequestList\": [], " +
                "\"origin\": \"ON!Track\" }";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/um/v1/worker-users/");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create user " + response.prettyPrint());
        }

        //System.out.println(response.jsonPath());
        // String userIdValue = response.jsonPath().get("ids.id").toString();
        // userIdValue  = userIdValue.replaceAll("[\\[\\](){}]","");
        String userIdValue = response.jsonPath().get("userId").toString();
        map.put("userId", userIdValue);
        map.put("userEmail", UserEmail);
        System.out.println("Created User Id ---" + " ---------" + userIdValue);
        System.out.println("Created User Name" + " ---------" + UserEmail);

    }

    public void createPassword() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        if (!map.containsKey("userEmail")) {
            createUser();
        }
        String userId = map.get("userId");
        String userEmail = map.get("userEmail");
        String userPassword = "Test1234";

        String body = "{ \"email\": \"" + userEmail + "\", \"newPassword\": \"" + userPassword + "\"}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .patch(apiBaseURL + "/ts/ontrack/um/v1/users/" + userId + "/changePassword");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call crete password " + response.prettyPrint());
        }

        map.put("userPwd", userPassword);
        System.out.println("Password Updated for  User Id ----- " + userId);
        System.out.println("Password Updated for  User Email -----" + userEmail);
        System.out.println("User Updated Password ---- " + userPassword);
    }

    private void updateFieldRequest(HashMap<String, String> existingMap) {
        if (!map.containsKey("access_token")) {
            getAuthTokenForFieldRequest();
        }
        if(!existingMap.containsKey("request_id")){
            getFieldRequestId();
            existingMap.put("request_id",map.get("request_id"));
        }

        String requestId = existingMap.get("request_id");
        String action = existingMap.get("action");
        String notes = existingMap.get("note");
        String body = "{ \"requestId\": " + requestId + ", \"notes\": \""+notes+"\", \"action\": \"" + action + "\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .patch(apiBaseURL + "/ts/ontrack/am/v1/field-request");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update field location " + response.prettyPrint());
        }

        if (response.statusCode()==200){
            System.out.println("Field request update -"+ action+" successful");
        } else {
            Assert.fail("Field transfer failed " + response.prettyPrint());
        }



    }
    private void createAllocationMinStockGreaterThanStockQty() {

        if (!map.containsKey("worker_id")) {
            createWorker();
        }

        if (!map.containsKey("location_id")) {
            createLocation();
        }

        if (!map.containsKey("quantity_items_id")) {
            createQuantityItem();
        }

        String locationId = map.get("location_id");
        String employeeId = map.get("worker_id");
        String body = "{ \"allocationStatus\": \"AVAILABLE\", \"locationId\": \"" + locationId + "\"," +
                " \"mainAllocation\": true, \"responsibleEmployeeId\": " + employeeId + ", \"" +
                "stockAlertEnabled\": true, \"stockMaxQuantity\": \"157\", \"stockMinQuantity\": \"100\", \"stockQuantity\": \"45\", \"storageLocation\": \"54\", \"type\": \"LOCATION\", \"workerId\": null }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/"+map.get("quantity_items_id")+"/allocation");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create allocation > minstock " + response.prettyPrint());
        }


        map.put("allocation_id_with_alert", response.jsonPath().get("id").toString());
        System.out.println("Created allocation_with_alert  id " + response.jsonPath().get("id").toString() );

    }

    public void createService(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String isCritical = existingMap.get("is_critical");
        String recurrent = existingMap.get("service_type_code");
        String period = existingMap.get("based_on");
        String weeks = existingMap.get("service_period_code");
        String serviceINterval = existingMap.get("service_interval");
        String notificationPeriodCode = existingMap.get("notification_period_code");
        String sendNotification = existingMap.get("send_notification");
        String description = existingMap.get("description");
        String serviceTemplateName = "ST_" + map.get("TIMESTAMP");

        String body = "{\"isCritical\": " + isCritical + ",\n" +
                "\"serviceTypeCode\": \"" + recurrent + "\",\n" +
                "\"basedOn\": \"" + period + "\",\n" +
                "\"servicePeriodCode\": \"" + weeks + "\",\n" +
                "\"name\": \"" + serviceTemplateName + "\",\n" +
                "  \"description\": \""+description +"\",\n" +
                "\"serviceInterval\": \"" + serviceINterval + "\",\n" +
                "\"notificationPeriodCode\": \"" + notificationPeriodCode + "\",\n" +
                "\"sendNotification\": " + sendNotification + ",\n" +
                "\"notificationNumber\": null}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/services-template");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }

        String serviceId = response.jsonPath().get("id").toString();
        map.put("service_template_name",serviceTemplateName);
        map.put("service_id",serviceId);
        System.out.println("servicename"+ serviceTemplateName);

    }

    public void associateServiceToAsset(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String serviceId = existingMap.get("service_id");
        String serviceStatus = existingMap.get("serviceStatus");
        String scheduleDate = existingMap.get("scheduleDate");
        scheduleDate = scheduleDate==null ? null : "\"" + scheduleDate + "\"";
        String scheduleAt = existingMap.get("scheduleAt");
        String assetId = existingMap.get("asset_id");

        String body = "{\"openService\": {" +
                "\"serviceId\": \"" + serviceId + "\"," +
                "\"serviceStatus\": \"" + serviceStatus + "\"," +
                "\"scheduleDate\": " + scheduleDate + "," +
                "\"scheduleAt\": \"" + scheduleAt + "\"" +
                "}}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .patch(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/" + assetId + "/service-association");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }

//        String serviceId = response.jsonPath().get("id").toString();
//        map.put("service_template_name",serviceTemplateName);
//        map.put("service_id",serviceId);

    }

    public void subscribeServiceForAlert(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String serviceId = existingMap.get("service_id");


        String body = "{\"settings\":[{\"id\":"+serviceId+",\"responsibilityTypes\":[{\"id\":4,\"isSubscribed\":true},{\"id\":5,\"isSubscribed\":true},{\"id\":6,\"isSubscribed\":true}],\"subscribedAdditionalWorkers\":[921835,1112668],\"showError\":false}]}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/an/v1/tenant/alerts/settings/1");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            System.out.println("request completed successfully");
        }

    }

    public void createCertificate() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String certificateName = "New_certificate" + RandomTestdataHelper.get(RandomTestdataHelper.Category.RANDOM_NUMERIC, 5);



        String body = "{\n    \"name\": \""+certificateName+"\"," +
                "\n    \"description\": \"Certificate to access the app\"," +
                "\n    \"isNotificationAllow\": true,\n   " +
                " \"templateNotification\": {\n        \"number\": 10,\n        \"period\": \"DAY\"\n    }\n}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/um/v1/worker-certificate-templates");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==201){
            String certifcateTemplateId = response.jsonPath().get("id").toString();
            map.put("certifcate_TemplateId",certifcateTemplateId);
            map.put("certificate_Name",certificateName);
            System.out.println("Certificate created");
        }

    }
    public void assignCertificate(HashMap<String,String> existingMap) {
        String workerId = "921835";
        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        if (!map.containsKey("certifcate_TemplateId")) {
            createCertificate();
        }
        if(existingMap.containsKey("worker_id")){
            workerId = existingMap.get("worker_id");
        }

        String certificateName = map.get("certificate_Name");
        String certifcateTemplateId=map.get("certifcate_TemplateId");



        String body = "{\n\t\"status\": \"ACTIVE\",\n\t\"certificateTemplateId\": " +
                certifcateTemplateId+","+"\n\t\"certificateTemplateName\": \""+certificateName+"\",\n\t\"certificateNo\": \"TN6789\",\n\t\"issueDate\": \"2023-02-08\",\n\t\"lifeLong\": false,\n\t\"expirationDate\": \""+futuredate+"\",\n\t\"comments\": \"COmments here\"\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/um/v1/workers/"+workerId+"/worker-certificates");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==201){
            String certifcateId = response.jsonPath().get("id").toString();
            map.put("certifcate_Id",certifcateId);
            System.out.println("Certificate assigned");
        }

    }
    public  void transferAssetToNewLocation(HashMap<String,String> existingMap) {


        createLocation();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String uuid = UUID.randomUUID().toString();
        String dateTime = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).toString().replaceAll("\\..*","Z");
        String assetId = existingMap.get("asset_id");
        String fromLocationId = existingMap.get("location_id");
        String toLocationId = map.get("location_id");
        String fromWorkerId = existingMap.get("worker_id");
        String toWorkerId = existingMap.get("worker_id");

        String body = "{ \"toLocationId\": " + toLocationId + ", \"toStorageAssetId\": null, " +
                "\"toWorkerId\":" +toWorkerId+", \"timeZoneAwareTransferDateTime\": \"" + dateTime + "\"," +
                " \"assets\": [{ \"assetId\": " + assetId + ", " +
                "\"fromLocationId\": " + fromLocationId + ", " +
                "\"fromWorkerId\": " + fromWorkerId + ", \"transferAssetType\": \"ASSET\", \"transferQuantity\": 1, \"toAllocationStatus\": \"AVAILABLE\" }]," +
                " \"transferUUID\": \"" + uuid + "==\" }";


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/assets/transfers?transferOrigin=MOBILE");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call transfer asset to new location " + response.prettyPrint());
        }


        String id = response.jsonPath().get("transferId").toString();
        map.put("transfer_id", id);
        System.out.println("Transfer succesful. trasnfer id  " + id);


    }

    public void removeCertificate(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String certificateId = existingMap.get("certifcate_Id").replaceAll("\\[", "").replaceAll("\\]","");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .delete(apiBaseURL + "/ts/ontrack/um/v1/workers/921835/worker-certificates/"+certificateId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            System.out.println("Certificate removed Successfully");
            map.remove("certifcate_Id");
        }

    }

    public void updateCertificate(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }



        String certificateId = existingMap.get("certifcate_Id").replaceAll("\\[", "").replaceAll("\\]","");
        String certificateTemplateId = existingMap.get("certifcate_TemplateId").replaceAll("\\[", "").replaceAll("\\]","");
        String certificateName = existingMap.get("certificate_Name").replaceAll("\\[", "").replaceAll("\\]","");
        String expiryDate =existingMap.get("expiry_Date").replaceAll("\\[", "").replaceAll("\\]","");

        String body ="{\n\t\"certificateNo\": \"TN6789\",\n\t\"certificateTemplateId\": "+certificateTemplateId+",\n\t\"certificateTemplateName\": \""+certificateName+"\",\n\t\"comments\": \"COmments here\",\n\t\"expirationDate\": \""+expiryDate+"\",\n\t\"issueDate\": \"2023-01-01\",\n\t\"lifeLong\": false,\n\t\"id\": "+certificateId+",\n\t\"presenceOfAttachment\": false,\n\t\"status\": \"DUE_TO_EXPIRE\"\n}\n" ;

        Response response = given().relaxedHTTPSValidation()
                .when()
                .body(body)
                .header("Content-Type", "application/json")
                .put(apiBaseURL + "/ts/ontrack/um/v1/workers/921835/worker-certificates/"+certificateId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            System.out.println("Certificate expiry date update");
        }

    }

    public void assignCertificateForAlert(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }



        String certificateTemplateId = existingMap.get("certifcate_TemplateId").replaceAll("\\[", "").replaceAll("\\]","");


        String body = "{\n\t\"settings\": [ {\n\t\t\"id\":"+certificateTemplateId+",\n\t\t\"responsibilityTypes\": [{\n\t\t\t\"id\": 7,\n\t\t\t\"isSubscribed\": true\n\t\t}],\n\t\t\"subscribedAdditionalWorkers\": [921835]\n\t}]\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .body(body)
                .header("Content-Type", "application/json")
                .put(apiBaseURL + "/ts/ontrack/an/v1/tenant/alerts/settings/2");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            System.out.println("Certificate assigned for Alert");
        }

    }

    public void removeAllExistingCertificates() {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        List<Integer> result = new ArrayList<>();
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .get(apiBaseURL + "/ts/ontrack/um/v1/workers/921835/worker-certificates?filter=status:in=ACTIVE;DUE_TO_EXPIRE;ARCHIVED;EXPIRED&limit=100&offset=0&order_by=-status");

        if (response.statusCode() >= 400) {
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode() == 200) {

            result = response.jsonPath().getList("id");
            System.out.println("Certificate List is "+result);
            if (result.size()!=0 && result != null) {
                for (int i = 0; i < result.size(); i++) {
                    String certificateId = String.valueOf(result.get(i));

                    HashMap<String, String> certifcatemap = new HashMap<String, String>();
                    certifcatemap.put("certifcate_Id", certificateId);
                    removeCertificate(certifcatemap);
                }

            }else{
                System.out.println("Certificate List is empty");
            }

        }
    }


    public void deleteCertificateTemplate(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String certificateTemplateId = existingMap.get("certifcate_TemplateId").replaceAll("\\[", "").replaceAll("\\]","");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .delete(apiBaseURL + "/ts/ontrack/um/v1/worker-certificate-templates/"+certificateTemplateId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            System.out.println("Certificate Template deleted Successfully");
        }

    }
    public void getTemplatedetail(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        int requiredTemplateId = 0;




        String manufactureName = existingMap.get("manufacture_name");
        String ModelName= existingMap.get("model_name");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .queryParam("q",manufactureName)
                .get(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            List<Integer> listTemplateId = response.jsonPath().getList("response.id");
            List<String> resultTemplateName = response.jsonPath().getList("response.model");
            for (int i=0; i< resultTemplateName.size(); i++){
                if (resultTemplateName.get(i).equalsIgnoreCase(ModelName)){
                    requiredTemplateId = listTemplateId.get(i);
                    break;
                }
            }
            System.out.println("Manufacturer is " + manufactureName);
            System.out.println("Model is " + ModelName);
            if(requiredTemplateId==0){
                System.out.println("Provided template is not associated with asset");
            }else {
                System.out.println("Template id is " + requiredTemplateId);
                map.put("template_id", String.valueOf(requiredTemplateId));
            }
        }

    }

    public void getFieldRequestId() {

        if (!map.containsKey("access_token")) {
            getAuthTokenForFieldRequest();
        }
        int requiredFieldrequestId = 0;


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .queryParam("view","receiver")
                .get(apiBaseURL + "/ts/ontrack/am/v1/field-request");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            List<Integer> listTemplateId = response.jsonPath().getList("response.fieldRequestId");
            List<String> resultFieldrequest = response.jsonPath().getList("response.status.code");

            for (int i=0; i< resultFieldrequest.size(); i++){
                if (resultFieldrequest.get(i).equalsIgnoreCase("open")){
                    requiredFieldrequestId = listTemplateId.get(i);
                    break;
                }
            }

            if(requiredFieldrequestId==0){
                System.out.println("Field request list is empty");
            }else {
                System.out.println("Fieldrequest id is " + requiredFieldrequestId);
                map.put("request_id", String.valueOf(requiredFieldrequestId));
            }
        }

    }

    public void deleteTemplate(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }
        if(existingMap.containsKey("scan_code")){
            deleteAsset(existingMap);
        }
        if (!map.containsKey("template_id")) {
            getTemplatedetail(existingMap);
        }


        String templateId = map.get("template_id");
        String body = "{\n\t\"isSelectAll\": false,\n\t\"templateIds\": ["+templateId+"]\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){

            if(response.jsonPath().get("invalidResponse").toString().equalsIgnoreCase("[]")){

                System.out.println("Template id "+templateId+" deleted successfully");
            }else
            {
               // Assert.fail("Exception in api call create service " + response.prettyPrint());
                System.err.println("Exception in api call get asset " + response.prettyPrint());
            }
        }

    }

    public void updateManualcheck(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String status = existingMap.get("status");
        String body = "{\n\t\"isEnabled\": "+status+"\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/om/v1/company/check-inventory");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            map.put("Manual_check_Status",status);
            if(status.equalsIgnoreCase("true")){
                System.out.println("Manual check is enabled");
            }else{

                System.out.println("Manual check is disabled");
            }

        }

    }

    public void updateFieldRequestSetting(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }


        String status = existingMap.get("status");
        String body = "{\n\t\"isEnabled\": "+status+"\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/om/v1/company/field-request-setting");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            map.put("FieldRequest_Setting_Status",status);
            if(status.equalsIgnoreCase("true")){
                System.out.println("Field Request is enabled");
            }else{

                System.out.println("Field Request is disabled");
            }

        }

    }

    public void updateTracking(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String status = existingMap.get("status");
        String body = "{\n\t\"isPositionTrackingEnabled\": "+status+"\n}";
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/om/v1/company/position-tracking");


        if (response.statusCode()>=400){
            Assert.fail("Exception in api call create service " + response.prettyPrint());
        }
        if (response.statusCode()==200){
            map.put("tracking_Status",status);
            if(status.equalsIgnoreCase("true")){

                System.out.println("tracking is enabled");
            }else{

                System.out.println("tracking is disabled");
            }

        }

    }


    public  void transferAssetToNewLocationWithReturndate(HashMap<String,String> existingMap) {

        createLocation();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String uuid = UUID.randomUUID().toString();
        String dateTime = ZonedDateTime.now().withZoneSameInstant(ZoneId.of("GMT+1")).toString().replaceAll("\\..*","Z");
        String assetId = existingMap.get("asset_id");
        String fromLocationId = existingMap.get("location_id");
        String toLocationId = map.get("location_id");
        String fromWorkerId = existingMap.get("worker_id");
        String toWorkerId = existingMap.get("worker_id");

        String body = "{ \"toLocationId\": " + toLocationId + ", \"toStorageAssetId\": null, " +
                "\"toWorkerId\": "+toWorkerId+", \"timeZoneAwareTransferDateTime\": \"" + dateTime + "\"," +
                " \"assets\": [{ \"assetId\": " + assetId + ", " +
                "\"fromLocationId\": " + fromLocationId + ", " + "\"returnDate\": \""+ date +"\","+
                "\"fromWorkerId\": " + fromWorkerId + ", \"transferAssetType\": \"ASSET\", \"transferQuantity\": 1, \"toAllocationStatus\": \"AVAILABLE\" }]," +
                " \"transferUUID\": \"" + uuid + "==\" }";


        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/assets/transfers?transferOrigin=MOBILE");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call transfer asset to new location " + response.prettyPrint());
        }
        String id = response.jsonPath().get("transferId").toString();
        map.put("transfer_id", id);
        System.out.println("Transfer succesful. trasnfer id  " + id);


    }
    private void updateAssetStatus(HashMap<String, String> existingMap) {
        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String status = existingMap.get("asset_status");
        String assetId = existingMap.get("asset_id");

        String body = "{ \"filters\": [], \"isSelectAll\": false, \"view\": null," +
                " \"assetIds\": [" + assetId + "], \"excludedAssetIds\": [], \"storageAsset\": []," +
                " \"assetStatus\": \"" + status + "\" } ";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/asset-status");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update asset status " + response.prettyPrint());
        }

        if (response.statusCode()==200){
            System.out.println("Asset status update succesful");
        } else {
            Assert.fail("Asset status update failed " + response.prettyPrint());
        }



    }


    private void assignTemplateWithService() {
        if (!map.containsKey("access_token")) {
            getAuthToken();
        }

        String manufactureId = map.get("manufacturer_id");
        String model = map.get("model_Name");
        String serviceId = map.get("service_id");

        String body = "{\n\t\"manufacturerId\": \""+manufactureId+"\",\n\t\"manufacturerName\": \"TestManu90\",\n\t\"model\": \""+model+"\",\n\t\"description\": \"tiuyiu\",\n\t\"costCode\": \"790\",\n\t\"defaultGroupId\": null,\n\t\"defaultGroupName\": null,\n\t\"templateId\": null,\n\t\"templateServices\": [\""+serviceId+"\"]\n}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update asset status " + response.prettyPrint());
        }

        if (response.statusCode()==201){
            System.out.println("Template assigned with service successfully");
        }




    }


    public void updateAlertsettingsEnabled() {
        if (!map.containsKey("access_token")) {
            getAuthToken();
        }



        String body = "{\"settings\":[{\"id\":1,\"name\":{\"code\":\"SERVICE_ALERT_GROUP\",\"value\":\"Service alerts\"},\"communicationChannels\":[{\"id\":3,\"code\":\"EMAIL\",\"info\":{\"isConsolidated\":true,\"isPerAlert\":false,\"isEnabled\":true}},{\"id\":5,\"code\":\"IN_APP\",\"info\":{\"isEnabled\":true}}]},{\"id\":2,\"name\":{\"code\":\"WORKER_CERTIFICATE_ALERT_GROUP\",\"value\":\"Employee certificate alerts\"},\"communicationChannels\":[{\"id\":5,\"code\":\"IN_APP\",\"info\":{\"isEnabled\":true}},{\"id\":3,\"code\":\"EMAIL\",\"info\":{\"isConsolidated\":true,\"isPerAlert\":false,\"isEnabled\":false}}]},{\"id\":3,\"name\":{\"code\":\"TOOL_RETURN_ALERT_GROUP\",\"value\":\"Tool alerts\"},\"communicationChannels\":[{\"id\":5,\"code\":\"IN_APP\",\"info\":{\"isEnabled\":true}},{\"id\":3,\"code\":\"EMAIL\",\"info\":{\"isConsolidated\":true,\"isPerAlert\":false,\"isEnabled\":false}}]},{\"id\":4,\"name\":{\"code\":\"GATEWAY_ALERT_GROUP\",\"value\":\"Gateway alerts\"},\"communicationChannels\":[{\"id\":3,\"code\":\"EMAIL\",\"info\":{\"isConsolidated\":true,\"isPerAlert\":false,\"isEnabled\":false}},{\"id\":5,\"code\":\"IN_APP\",\"info\":{\"isEnabled\":true}}]},{\"id\":5,\"name\":{\"code\":\"QTY_ITEM_ALERT_GROUP\",\"value\":\"Quantity item alerts\"},\"communicationChannels\":[{\"id\":5,\"code\":\"IN_APP\",\"info\":{\"isEnabled\":true}},{\"id\":3,\"code\":\"EMAIL\",\"info\":{\"isConsolidated\":true,\"isPerAlert\":false,\"isEnabled\":false}}]}]}";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .put(apiBaseURL + "/ts/ontrack/an/v1/user/alerts/settings");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call update asset status " + response.prettyPrint());
        }

        if (response.statusCode()==200){
            System.out.println("Alert settings all are enabled");
        }



    }


    public  void addPurchaseDetailstoQtyItem(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")){
            getAuthToken();
        }


        String purchaseDate = date;
        String purchaseQty = RandomTestdataHelper.get(RANDOM_NUMERIC, 4);
        String purchaseUnitId = existingMap.get("purchase_unit_id");
        String purchasePrice = RandomTestdataHelper.get(RANDOM_NUMERIC, 3);
        String purchaseCurrencyCode = "EUR";
        String purchaseOrderNumber = RandomTestdataHelper.get(RANDOM_NUMERIC, 6);
        String vendor = "Hilti";
        String costCode = "123ABC";
        String qtyItemId = existingMap.get("quantity_items_id");

        String body = "{ \"purchaseDate\": \"" + purchaseDate + "\"," +
                " \"purchaseQty\": \"" + purchaseQty + "\"," +
                " \"purchaseUnitId\": " + purchaseUnitId + "," +
                " \"purchasePrice\": \"" + purchasePrice + "\"," +
                " \"purchaseCurrencyCode\": \"" + purchaseCurrencyCode + "\"," +
                " \"purchaseOrderNumber\": \"" + purchaseOrderNumber + "\"," +
                " \"vendor\": \"" + vendor + "\"," +
                " \"costCode\": \"" + costCode + "\"," +
                " \"notes\": \"notes\" }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .post(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/" + qtyItemId + "/purchase");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call transfer asset to new location " + response.prettyPrint());
        }



        System.out.println("Adding purchase details successful  " );


    }


    public  void deleteGeneratedData(){

        if (map.isEmpty()){
            System.out.println("No data to delete");
        }

        if (map.containsKey("asset_id")){
            deleteAsset();
        }

        if (map.containsKey("asset_template_id")){
            deleteAssetTemplate();
        }

        if (map.containsKey("location_id")){
            deleteLocation();
        }

        if (map.containsKey("worker_id")){
            deleteWorker();
        }

        if (map.containsKey("manufacturer_id")){
            deleteManufacturer();
        }

        if (map.containsKey("group_id")){
            deleteAssetGroups();
        }
        if (map.containsKey("allocation_id")){
            deleteAllocation();
        }

        if (map.containsKey("quantity_items_id")){
            deleteQuantityItems();
        }

        if (map.containsKey("Manual_check_Status")){
            if(map.get("Manual_check_Status").equalsIgnoreCase("false")){
                HashMap<String,String> status = new HashMap<>();
                status.put("status","true");
                updateManualcheck(status);
            }

        }

        if (map.containsKey("tracking_Status")){
            if(map.get("tracking_Status").equalsIgnoreCase("false")){
                HashMap<String,String> status = new HashMap<>();
                status.put("status","true");
                updateTracking(status);
            }

        }

        if (map.containsKey("FieldRequest_Setting_Status")){
            if(map.get("FieldRequest_Setting_Status").equalsIgnoreCase("false")){
                HashMap<String,String> status = new HashMap<>();
                status.put("status","true");
                updateFieldRequestSetting(status);
            }
        }

    }
}
