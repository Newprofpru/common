package com.scripted.dataload;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveOAuth2HeaderScheme;
import io.restassured.response.Response;
import org.testng.Assert;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static io.restassured.RestAssured.given;

public class BulkDeleteData {

    static int MAX_THREAD_COUNT = 20;
    static boolean PRINT_LOGS = false;

    static String baseURL = "https://ontrack3-qa.hilti.com";
    static String apiBaseURL = "https://hc-apigw-q.hilti.com";
    private HashMap<String,String> map = new HashMap();

    public static void main(String[] args) {
        BulkDeleteData bulkDelete = new BulkDeleteData();
        bulkDelete.deleteAllData();
    }

    public void deleteAllData(){
        // order of deletion
        // 1 - Qty items, 2 - Assets, 3- Groups, 4 - Templates, 5- Locations
        // 6 - Manufactureers, 7 - Workers
        // Eg. startOrder=1 and endOrder=3 will delete qty items, assets and groups alone

        int startOrder = 1;
        int endOrder = 7;

        for (int order = startOrder; order<=endOrder; order++){
            ExecutorService executor  = Executors.newFixedThreadPool(MAX_THREAD_COUNT);
            for (int i = 0; i< MAX_THREAD_COUNT; i++) {
                int _i = i;
                int _order = order;
                executor.execute(()->{
                    int offset = _i *250;
                    switch (_order){
                        case 1:
                            System.out.println("Deleting all Qty items");
                            new BulkDeleteData().deleteAllQuantityItems(offset);
                            break;
                        case 2:
                            System.out.println("Deleting all Assets");
                            new BulkDeleteData().deleteAllTheAssets(offset);
                            break;
                        case 3:
                            System.out.println("Deleting all Groups");
                            new BulkDeleteData().deleteAllAssetGroups(offset);
                            break;
                        case 4:
                            System.out.println("Deleting all Templates");
                            new BulkDeleteData().deleteAllTemplates(offset);
                            break;
                        case 5:
                            System.out.println("Deleting all Locations");
                            new BulkDeleteData().deleteAllTheLocations(offset);
                            break;
                        case 6:
                            System.out.println("Deleting all Manufacturers");
                            new BulkDeleteData().deleteAllManufacturers(offset);
                            break;
                        case 7:
                            System.out.println("Deleting all Workers");
                            new BulkDeleteData().deleteAllWorkers(offset);
                            break;
                    }
                });


            }
            executor.shutdown();
            try {
                executor.awaitTermination(20, TimeUnit.MINUTES);
            } catch (InterruptedException e) {}

        }


    }


    public void deleteAllQuantityItems(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  Quantity items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/quantity-items?limit=250&offset="+offset);


        List<Integer> jsonResponse = response.jsonPath().getList("response.id");





        for (int qtyItem : jsonResponse){
            Response response1 = given().relaxedHTTPSValidation()
                    .when()
                    .header("Content-Type","application/json")
                    .get(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/"+qtyItem+"/allocations");

            int allocationCount = response1.jsonPath().getInt("totalRecords");
            System.out.println(allocationCount);
            if (allocationCount==0){
                map.remove("quantity_items_id");
                map.put("quantity_items_id", String.valueOf(qtyItem));
                deleteQuantityItems();
            } else {
                List<Integer> allocationIds = response1.jsonPath().getList("response.allocationId");
                for (int allocationIs: allocationIds){
                    map.remove("allocation_id");
                    map.remove("quantity_items_id");
                    map.put("allocation_id", String.valueOf(allocationIs));
                    map.put("quantity_items_id", String.valueOf(qtyItem));
                    deleteAllocation();
                }
                map.put("quantity_items_id", String.valueOf(qtyItem));
                deleteQuantityItems();
            }

        }

    }

    public void deleteAllWorkers(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  workers items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/um/v1/workers?limit=250&offset="+offset);


        List<Integer> jsonResponse = response.jsonPath().getList("response.id");
        List<String> jsonResponseEmail = response.jsonPath().getList("response.email");

//        for (int workerid : jsonResponse){
        int size = jsonResponse.size();
        for (int i = 0; i< size; i++){
            int workerid = jsonResponse.get(i);
            String email = jsonResponseEmail.get(i);
            if (email !=null && (email.contains("mobautomationuser") || email.contains("mobileautomationuser"))) {
                System.out.println("Skipping user with emailid " + email);
                continue;
            }
            map.remove("worker_id");
            map.put("worker_id", String.valueOf(workerid));
            deleteWorker();
        }
    }

    public void deleteAllManufacturers(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  workers items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/manufacturers?limit=250&offset="+offset);



        List<Integer> jsonResponse = response.jsonPath().getList("response.id");

        for (int workerid : jsonResponse){
            map.remove("manufacturer_id");
            map.put("manufacturer_id", String.valueOf(workerid));
            deleteManufacturer();
        }
    }

    public void deleteAllAssetGroups(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  workers items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/group?limit=250&offset="+offset);



        List<Integer> jsonResponse = response.jsonPath().getList("response.groupId");

        for (int groupId : jsonResponse){
            map.remove("group_id");
            map.put("group_id", String.valueOf(groupId));
            deleteAssetGroups();
        }
    }

    public void deleteAllTemplates(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  templates items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template?limit=250&offset="+offset);


        List<Integer> jsonResponse = response.jsonPath().getList("response.id");

        for (int templateId : jsonResponse){
            map.remove("asset_template_id");
            map.put("asset_template_id", String.valueOf(templateId));
            deleteAssetTemplate();
        }
    }


    public void deleteAllTheLocations(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  locations items from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/om/v1/locations?limit=250&offset="+offset);


        List<Integer> jsonResponse = response.jsonPath().getList("response.id");

        for (int locationid : jsonResponse){
            map.remove("location_id");
            map.put("location_id", String.valueOf(locationid));
            deleteLocation();
        }
    }

    public void deleteAllTheAssets(int offset){

        // USE WITH CAUTION
        // USE WITH CAUTION
        // USE WITH CAUTION

        // This method will delete  assets  from the environment
        // Calling this method multiple times will delete all data

        // DO NOT CALL THIS method unless you want to clear all data

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/unique-asset?limit=250&offset="+offset);


        List<Integer> jsonResponse = response.jsonPath().getList("response.assetId");
        List<Boolean> listHiltiAsset = response.jsonPath().getList("response.hiltiIntegratedAsset");

        for (int i = 0; i<jsonResponse.size(); i++){
//        for (int assetId : jsonResponse){
            int assetId = jsonResponse.get(i);
            Boolean isHiltiAsset = listHiltiAsset.get(i);
            if (isHiltiAsset!=null && isHiltiAsset.equals(true)){
                System.out.println("Skipping hilti asset with id " + assetId);
                continue;
            }
            map.remove("asset_id");
            map.put("asset_id", String.valueOf(assetId));
            deleteAsset();
        }
    }


    private void generateTimeStamp() {
        final String dateFormat = "ddMMHHmmssSS";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
        String timestamp = LocalDateTime.now().format(formatter);
        map.put("TIMESTAMP", timestamp);
    }


    public void getAuthToken() {

        String username = "mobautomationuser@user.com", password = "H!lti@1234";
        String tenantId = "588";

        if (!map.containsKey("TIMESTAMP")){
            generateTimeStamp();
        }


        Response response = given().relaxedHTTPSValidation()
                .auth().preemptive()
                .basic(username, password)
                .when()
                .post(baseURL + "/auth/web/signin?tenant_id=" + tenantId);

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call nonce " + response.prettyPrint());
        }

        String nonce = response.jsonPath().get("authenticationNonce").toString();

        response = given().relaxedHTTPSValidation()
                .queryParam("authenticationNonce", nonce)
                .get(baseURL + "/auth/web/context");

        if (response.statusCode()>=400){
            Assert.fail("Exception in api call get token" + response.prettyPrint());
        }

        String token = response.jsonPath().get("access_token").toString();


        PreemptiveOAuth2HeaderScheme auth = new PreemptiveOAuth2HeaderScheme();
        auth.setAccessToken(token);
        map.put("access_token", token);
        RestAssured.authentication = auth;

    }


    public  void deleteWorker(){

        String workerId = map.get("worker_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("workerIdList", workerId)
                .delete(apiBaseURL + "/ts/ontrack/um/v1/worker-users/bulk-delete");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete worker" + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        System.out.println("Deleted worker " + workerId);

    }

    public  void deleteLocation(){

        String locationId = map.get("location_id");

        String body = "{ \"excludedIds\": null, \"filter\": []," +
                " \"locationIds\": ["+locationId+"], \"q\": \"\", \"selectAll\": false }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/om/v1/locations");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete location " + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        System.out.println("Deleted Location " + locationId);

    }

    public  void deleteManufacturer(){

        String manufacturerId = map.get("manufacturer_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("assetManufacturerIds", manufacturerId)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/manufacturers");


        if (PRINT_LOGS){
            response.prettyPrint();
        }

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete manufacturer" + response.prettyPrint());
        }

        System.out.println("Deleted Manufacturer " + manufacturerId);

    }

    public  void deleteAssetGroups(){

        String groupId = map.get("group_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .queryParam("groupIds", groupId)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/group");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset groups " + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        System.out.println("Deleted Asset group " + groupId);

    }

    public  void deleteAllocation(){

        String allocation_id = map.get("allocation_id");
        String quantity_items_id = map.get("quantity_items_id");

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body("{ \"stockQuantity\": \"0\", \"reason\": \"Test\" }")
                .patch(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/" + quantity_items_id + "/allocations/" + allocation_id + "/stock-correction");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call patch allocation " + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }


        response = given().relaxedHTTPSValidation()
                .when()
                .delete(apiBaseURL + "/ts/ontrack/am/v1/quantity-items/allocation/" + allocation_id);

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete allocation " + response.prettyPrint());
        }

        System.out.println("Deleted Allocation " + allocation_id);

    }

    public  void deleteQuantityItems(){

        String quantity_items_id = map.get("quantity_items_id");
        String body = "{ \"excludedIds\": null, \"filter\": [\"allocationStatus:in=AVAILABLE\"], \"isSelectAll\": false, \"query\": \"\"," +
                " \"qtyIds\": [" + quantity_items_id + "] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type", "application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/quantity-items");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete allocation " + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        System.out.println("Deleted Quantity Item " + quantity_items_id);

    }

    public  void deleteAssetTemplate(){

        String assetTemplateId = map.get("asset_template_id");

        String body = "{ \"isSelectAll\": false, \"templateIds\": ["+ assetTemplateId +"] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/unique-asset/template");

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset template" + response.prettyPrint());
        }

        System.out.println("Deleted Asset Template " + assetTemplateId);

    }

    public  void deleteAsset(HashMap<String,String> existingMap) {

        if (!map.containsKey("access_token")){
            getAuthToken();
        }

        String scanCode = existingMap.get("scan_code");
        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .get(apiBaseURL + "/ts/ontrack/am/v1/unique-asset?q=" + scanCode + "&fields=scanCode");

        if (response.statusCode()>=400){
            System.err.println("Exception in api call get asset " + response.prettyPrint());
        }

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        String assetId = response.jsonPath().getString("response[0].assetId");
        map.put("asset_id", assetId);
        deleteAsset();
    }



    public  void deleteAsset(){

        String assetId = map.get("asset_id");

        String body = "{ \"filters\": [], \"isSelectAll\": false, \"query\": \"TestAssetSC1101\", \"view\": null, " +
                "\"assetIds\": ["+assetId+"], \"excludedAssetIds\": [], \"storageAsset\": [] }";

        Response response = given().relaxedHTTPSValidation()
                .when()
                .header("Content-Type","application/json")
                .body(body)
                .delete(apiBaseURL + "/ts/ontrack/am/v1/unique-asset");

        if (PRINT_LOGS){
            response.prettyPrint();
        }

        if (response.statusCode()>=400){
            System.err.println("Exception in api call delete asset" + response.prettyPrint());
        }

        System.out.println("Deleted Asset " + assetId);

    }

}
