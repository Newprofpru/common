package com.scripted.dataload;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import org.apache.commons.io.FileUtils;
import org.testng.Assert;

import java.io.File;
import java.nio.charset.StandardCharsets;

public class JsonTestData {

    static Object document;


    public static void load(){
        String dir =System.getProperty("user.dir");
        String filePath  = dir + "/src/main/resources/DataFiles/json/Env_Quality.json";
        try{
            String jsonData = FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);
            document = Configuration.defaultConfiguration().jsonProvider().parse(jsonData);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String getTestData(String jsonPath){
        String value = "";
        try {
            value = JsonPath.read(document,jsonPath);
        } catch (Exception e) {
            Assert.fail("Test Data not available for path " + jsonPath);
        }
        return value;
    }

}
