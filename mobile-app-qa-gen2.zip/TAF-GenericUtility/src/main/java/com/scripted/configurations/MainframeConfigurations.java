package com.scripted.configurations;

public class MainframeConfigurations {

}
