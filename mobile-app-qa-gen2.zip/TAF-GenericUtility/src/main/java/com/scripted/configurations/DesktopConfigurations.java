package com.scripted.configurations;

public class DesktopConfigurations {

}
