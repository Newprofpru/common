package com.scripted.license;

public class InvalidLicensekeyException extends Exception {
	
	public InvalidLicensekeyException( String message )
    {
        super(message);
    }
}
