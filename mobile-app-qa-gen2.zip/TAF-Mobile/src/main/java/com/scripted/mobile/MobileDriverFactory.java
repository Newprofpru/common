package com.scripted.mobile;

import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.testng.Assert;

public class MobileDriverFactory {

    public static Logger LOGGER = LogManager.getLogger(MobileDriverFactory.class);

    public AndroidDriver<MobileElement> getLocalAndroidDriver(Properties mobConfigProp) {
        DesiredCapabilities capability = new DesiredCapabilities();
        AndroidDriver<MobileElement> androidNativeDriver = null;
        try {
            capability.setCapability("appPackage", mobConfigProp.getProperty("appPackage"));
            capability.setCapability("appActivity", mobConfigProp.getProperty("appActivity"));
            capability.setCapability("appium:chromeOptions", ImmutableMap.of("w3c", false));
            capability.setCapability("automationName", "UiAutomator2");
            capability.setCapability("autoGrantPermissions", "true");
            capability.setCapability("appium:noReset", "true");
            //capability.setCapability("appium:noReset", "true");
            capability.setCapability("udid", mobConfigProp.getProperty("LocalDeviceUdid"));
            androidNativeDriver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capability);
            androidNativeDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return androidNativeDriver;
    }

    public IOSDriver<MobileElement> getLocalIosDriver(Properties mobConfigProp) {
        DesiredCapabilities capability = new DesiredCapabilities();
        IOSDriver<MobileElement> iosNativeDriver = null;
        try {
            capability.setCapability("platformName", "IOS");
            capability.setCapability("bundleId", mobConfigProp.getProperty("appPackage"));
            capability.setCapability("automationName", "XCuiTest");
            capability.setCapability("autoGrantPermissions", "true");
            capability.setCapability("xcodeOrgId", "878T64ZC8F");
            capability.setCapability("deviceName", "iPhone");
//			capability.setCapability("updatedWDABundleId", "com.hilti.mobileq.am3.WebDriverAgentRunner");
            capability.setCapability(IOSMobileCapabilityType.USE_PREBUILT_WDA, true);
            capability.setCapability("xcodeSigningId", "iPhone Developer");
            //capability.setCapability("appium:noReset", "true");
            capability.setCapability("udid", mobConfigProp.getProperty("LocalDeviceUdid"));
            iosNativeDriver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capability);
            iosNativeDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return iosNativeDriver;
    }

    public IOSDriver<MobileElement> getSauceDriverIOS(Properties mobConfigProp) {
        DesiredCapabilities capability = new DesiredCapabilities();
        IOSDriver<MobileElement> iosNativeDriver = null;
        try {
            capability.setCapability("platformName", "iOS");
            capability.setCapability("appium:deviceOrientation", "portrait");
            capability.setCapability("appium:platformVersion", mobConfigProp.getProperty("PlatformVersion"));
            capability.setCapability("appium:automationName", "XCUITest");
            capability.setCapability("appium:deviceName", mobConfigProp.getProperty("DeviceName"));
            capability.setCapability("appium:noReset", "true");
            capability.setCapability("appium:app", "storage:"+mobConfigProp.getProperty("SauceLabsFileId"));
            MutableCapabilities sauceOptions = new MutableCapabilities();
            sauceOptions.setCapability("name", "Hilti test");
            String cacheId = System.getProperty("user.name") + Thread.currentThread().getId();
            if (mobConfigProp.getProperty("deviceCacheRequired").equalsIgnoreCase("true")) {
                sauceOptions.setCapability("cacheId", cacheId);
            }
            capability.setCapability("sauce:options", sauceOptions);
            URL url = new URL("https://" + mobConfigProp.getProperty("Username") + ":" + mobConfigProp.getProperty("ApiKey") +
                    "@ondemand.us-west-1.saucelabs.com:443/wd/hub");
            iosNativeDriver = new IOSDriver(url, capability);
            iosNativeDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error while creating saucelabs session " + e.getMessage());
        }
        return iosNativeDriver;
    }

    public AndroidDriver<MobileElement> getSauceDriverAndroid(Properties mobConfigProp) {
        DesiredCapabilities capability = new DesiredCapabilities();
        AndroidDriver<MobileElement> androidNativeDriver = null;
        try {
            capability.setCapability("platformName", "Android");
            capability.setCapability("appium:deviceOrientation", "portrait");
            capability.setCapability("appium:automationName", "UiAutomator2");
            capability.setCapability("appium:deviceName", mobConfigProp.getProperty("DeviceName"));
            capability.setCapability("appium:deviceType", "phone");
            capability.setCapability("appium:app", "storage:"+mobConfigProp.getProperty("SauceLabsFileId"));
            capability.setCapability("appPackage", mobConfigProp.getProperty("appPackage"));
            capability.setCapability("appActivity", mobConfigProp.getProperty("appActivity"));
            capability.setCapability("appium:platformVersion", mobConfigProp.getProperty("PlatformVersion"));
            capability.setCapability("appium:noReset", "true");
            MutableCapabilities sauceOptions = new MutableCapabilities();
            sauceOptions.setCapability("name", "Hilti Test");
            sauceOptions.setCapability("phoneOnly", "true");
            String cacheId = System.getProperty("user.name") + Thread.currentThread().getId();
            sauceOptions.setCapability("cacheId", cacheId);
            capability.setCapability("sauce:options", sauceOptions);
            URL url = new URL("https://" + mobConfigProp.getProperty("Username") + ":" + mobConfigProp.getProperty("ApiKey") +
                    "@ondemand.us-west-1.saucelabs.com:443/wd/hub");
            androidNativeDriver = new AndroidDriver<MobileElement>(url, capability);
            androidNativeDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error while creating saucelabs session " + e.getMessage());
        }
        return androidNativeDriver;
    }


}