package com.scripted.mobile;

import static io.appium.java_client.touch.offset.PointOption.point;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.scripted.dataload.ObjectRepository;
import io.appium.java_client.MobileBy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Function;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;


public class MobileWaitHelper {
	
	public static Logger LOGGER = LogManager.getLogger(MobileWaitHelper.class);
	protected static int getElementTimeout() {
		return 60;
	}

	public static By getBy(String key){

		String locator = ObjectRepository.get(key);
		Assert.assertNotNull(locator, "Unable to find object in Object Repository with key " + key);
		Assert.assertFalse(locator.isEmpty(), "Locator is empty for element " + key);

		int index = locator.indexOf(":");
		if (index==-1){
			Assert.fail("Please enter element locator in the format type://locator for "+ key);
		}
		String type = locator.substring(0,index );
		locator = locator.substring(index+1);

		switch (type){
			case "xpath":
				return By.xpath(locator);
			case "id":
				return By.id(locator);
			case "name":
				return By.name(locator);
			case "accessibility_id":
				return MobileBy.AccessibilityId(locator);
			default:
				Assert.fail("Locator type is not implemented for type " + type + " for key " + key);
		}

		return null;

	}

	private static long getPollingTimeoutInMilliSeconds() {
		return 30;
	}

	private static Duration getPollingTimeoutInDuration() {
		return Duration.ofMillis(200);
	}

	private static Duration getElementWaitTimeoutInDuration() {
		return Duration.ofSeconds(60);
	}

	public static void waitForElement(MobileElement mobileElement) {

		new FluentWait<WebDriver>(MobileDriverSettings.getCurrentDriver()).withTimeout(getElementWaitTimeoutInDuration())
				.pollingEvery(getPollingTimeoutInDuration()).ignoring(TimeoutException.class)
				.ignoring(ClassNotFoundException.class)
				.until(new Function<WebDriver, Boolean>() {
					boolean flag = false;

					public Boolean apply(WebDriver d) {
						try {
							By byEle = MobileHandlers.mobileElementBy(mobileElement);
//							waitForPresence(byEle, getElementTimeout());
//							waitForNotStale(byEle, getElementTimeout());
//							waitForVisibleble(byEle, getElementTimeout());
							waitForClickable(byEle, getElementTimeout());
							flag = true;
							LOGGER.info("waitForElement action completed successfully");
						} catch (Exception e) 
						{
							e.printStackTrace();
							LOGGER.error("Error  while performing  waitForElement action "+"Exception :"+e);
							Assert.fail("Error  while performing  waitForElement action "+"Exception :"+e);
						}
						return flag;
					}
				});

	}

	public static MobileElement waitForElement(String mobileElement) {

		By by = getBy(mobileElement);
		try
		{
			WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), 30, 10);
			MobileElement element = (MobileElement) wait.until(ExpectedConditions.presenceOfElementLocated(by));
			LOGGER.debug("waitForPresence action completed successfully");
			return element;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error while performing  waitForPresence action "+"Exception :"+e);
			Assert.fail("Error while performing  waitForPresence action "+"Exception :"+e);
		}
		return null;
	}

	public static MobileElement waitForElementClickable(String mobileElement) {

		By by = getBy(mobileElement);
		try
		{
			WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), 30, 10);

			MobileElement element = (MobileElement) wait.until(ExpectedConditions.elementToBeClickable(by));

			LOGGER.debug("waitForCickable action completed successfully");
			return element;
		}
		catch(Exception e)
		{
			LOGGER.error("Error while performing  waitForClickable action "+"Exception :"+e);
		}
		return null;
	}

	public static List<MobileElement> waitForElements(String mobileElement) {

		By by =  getBy(mobileElement);
		try
		{
			WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), 10, 10);
			List<WebElement> element = (List<WebElement>) wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(by));
			List<MobileElement> mobileElements = element.stream().map(el -> (MobileElement)el).collect(Collectors.toList());
			LOGGER.debug("waitForPresence action completed successfully");
			return mobileElements;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error while performing  waitForPresence action "+"Exception :"+e);
			Assert.fail("Error while performing  waitForPresence action "+"Exception :"+e);
		}
		return null;
	}

	public static void waitForPresence(By byEle, int time) {
		try
		{
		WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), time, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(byEle));
		LOGGER.info("waitForPresence action completed successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error while performing  waitForPresence action "+"Exception :"+e);
			Assert.fail("Error while performing  waitForPresence action "+"Exception :"+e);
		}
	}

	public static void waitForClickable(By byEle, int time) {
		try
		{
		WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), time, getPollingTimeoutInMilliSeconds());
		wait.until(ExpectedConditions.elementToBeClickable(byEle));
		LOGGER.info("waitForClickable action completed successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error  while performing  waitForClickable action "+"Exception :"+e);
			Assert.fail("Error  while performing  waitForClickable action "+"Exception :"+e);
		}
	}

	public static void waitForVisibleble(By byEle, int time) {
		try
		{
		WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), time, getPollingTimeoutInMilliSeconds());
		wait.until(ExpectedConditions.visibilityOfElementLocated(byEle));
		LOGGER.info("waitForVisibleble action completed successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error while performing  waitForVisibleble action "+"Exception :"+e);
			Assert.fail("Error while performing  waitForVisibleble action "+"Exception :"+e);
		}
	}

	public static void waitForNotStale(By byEle, int time) {
		try
		{
		WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), time, getPollingTimeoutInMilliSeconds());
		wait.until(stalenessOf(byEle));
		}
			
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error  while performing  waitForNotStale action "+"Exception :"+e);
			Assert.fail("Error  while performing  waitForNotStale action "+"Exception :"+e);
		}
	}
	
	
	public static WebElement scrollToElement(By locator, String scrollType) {
			boolean found=false;
			WebElement element = null;
			while(!found)
			{
				try
				{	
					MobileDriverSettings.getCurrentDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					// element=driver.findElement(locator);
					element = new WebDriverWait(((AppiumDriver) MobileDriverSettings.getCurrentDriver()), 2, 250)
						.until(ExpectedConditions.presenceOfElementLocated(locator));
					found=true;
				}
				catch(Exception e)
				{
					if(scrollType.equalsIgnoreCase("vertical")) {
						verticalSwipe();
					}else if(scrollType.equalsIgnoreCase("horizontal")) {
						horizontalSwipe();
					}
					
				}
			}
			return element;
		}
	
	
	public static void verticalSwipe () {
		try
		{
		Dimension size = MobileDriverSettings.getCurrentDriver().manage().window().getSize();
		int starty = (int) (size.height * 0.60);
		int endy = (int) (size.height * 0.80);
		int startx = size.width / 2;
		new TouchAction(MobileDriverSettings.getCurrentDriver()).
			press(point(startx, endy)).
			moveTo(point(startx, starty)).
			release().perform();
		LOGGER.info("vertical swipe done successfully");
		}
		catch (Exception e){
			e.printStackTrace();
			LOGGER.error("Error  while performing the verticalSwipe action "+"Exception :"+e);
			Assert.fail("Error  while performing the verticalSwipe action "+"Exception :"+e);
		}
	}
	
	
	public static void horizontalSwipe () {
		
        try {
        	Dimension size = MobileDriverSettings.getCurrentDriver().manage().window().getSize();
    		int startY = (int) (size.height / 2);
            int startX = (int) (size.width * 0.90);
            int  endX = (int) (size.width * 0.05);
            new TouchAction(MobileDriverSettings.getCurrentDriver())
                    .press(point(startX, startY))
                    .moveTo(point(endX, startY))
                    .release()
                    .perform();	
			Thread.sleep(2000);
			LOGGER.info("horizontalSwipe  done successfully");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER.error("Error  while performing the horizontalSwipe action "+"Exception :"+e);
			Assert.fail("Error  while performing the horizontalSwipe action "+"Exception :"+e);
			 Thread.currentThread().interrupt();
		}
        }
 
	

	public static ExpectedCondition<Boolean> stalenessOf(By byEle) {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver ignored) {
				try {
					// Calling any method forces a staleness check
					ignored.findElement(byEle).isEnabled();
					return true;
				} catch (StaleElementReferenceException expected) {
					return false;
				}
			}

			@Override
			public String toString() {
				return String.format("element (%s) to become stale", byEle);
			}
		};
	}

	public static void waitForClear(By by, int time) {
		try
		{
		WebDriverWait wait = new WebDriverWait(MobileDriverSettings.getCurrentDriver(), time, getPollingTimeoutInMilliSeconds());
		wait.until(clearOf(by));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Error  while performing the waitForClear action "+"Exception :"+e);
			Assert.fail("Error  while performing the waitForClear action "+"Exception :"+e);
		}
	}

	public static ExpectedCondition<Boolean> clearOf(final By by) {

		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver ignored) {
				try {
					WebElement element = ignored.findElement(by);

					try {
						getAction().keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).pause(1000)
								.sendKeys(Keys.DELETE).build().perform();
					} catch (Throwable e) {
						// TODO: handle exception
					}
					if (element.getText().length() < 1)
						return true;
					try {
						element.click();
						element.clear();
					} catch (Throwable e) {
						// TODO: handle exception
					}
					if (element.getText().length() < 1)
						return true;
					try {
						element.click();
						((JavascriptExecutor) ignored).executeScript("arguments[0].value ='';", element);
					} catch (Throwable e) {
						// TODO: handle exception
					}
					if (element.getText().length() < 1)
						return true;
					return false;
				} catch (Exception expected) {
					return false;
				}
			}

			@Override
			public String toString() {
				return String.format("textbox (%s) to become clear", by);
			}
		};
	}

	public static Actions getAction() {
		return new Actions(MobileDriverSettings.getCurrentDriver());
	}
}
