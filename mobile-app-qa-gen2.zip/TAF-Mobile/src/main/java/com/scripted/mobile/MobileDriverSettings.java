package com.scripted.mobile;

import java.io.FileReader;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.scripted.dataload.PropertyDriver;
import com.scripted.license.VerifyKey;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class MobileDriverSettings {

	public static Logger LOGGER = LogManager.getLogger(MobileDriverSettings.class);

	private static ThreadLocal<AppiumDriver> tlDriver = new ThreadLocal<>();


	public AppiumDriver<MobileElement> getAppiumDriver(String configFileName, boolean local, String devicefarm, boolean deviceCacheRequired) {

		boolean isAndroid = configFileName.toLowerCase().contains("android");
		MobileDriverFactory factory = new MobileDriverFactory();
		AppiumDriver<MobileElement> appiumDriver = null;

		Properties mobConfigReader = new Properties();
		try (FileReader reader = new FileReader(
				"src/main/resources/Mobile/Properties/" + configFileName + ".properties")) {
			mobConfigReader.load(reader);
			mobConfigReader.put("deviceCacheRequired", String.valueOf(deviceCacheRequired));
			if (local) {
				if (isAndroid)
					appiumDriver = factory.getLocalAndroidDriver(mobConfigReader);
				else
					appiumDriver = factory.getLocalIosDriver(mobConfigReader);
			} else {
				if (devicefarm.equalsIgnoreCase("saucelabs")) {
					if (isAndroid)
						appiumDriver = factory.getSauceDriverAndroid(mobConfigReader);
					else
						appiumDriver = factory.getSauceDriverIOS(mobConfigReader);
				}
			}
			setCurrentDriver(appiumDriver);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error while reading pCloudy Android native Apps Config file" + "Exception :" + e);
		}
		return appiumDriver;
	}


	public static void setCurrentDriver(AppiumDriver driver) {
		tlDriver.set(driver);
	}

	public static MobileDriver getCurrentDriver() {
		return tlDriver.get();
	}

	public static void removeDriver() {
		tlDriver.remove();
	}
}