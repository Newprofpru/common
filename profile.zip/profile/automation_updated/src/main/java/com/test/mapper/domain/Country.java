package com.test.mapper.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY)
public class Country {
    //@JsonIgnore
	private String countryCode;

	private String countryName;

	private String pointVal;
	//@JsonIgnore
	private String numericalCode;

	public String getPointVal() {
		return pointVal;
	}

	public void setPointVal(String pointVal) {
		this.pointVal = pointVal;
	}

	public String getNumericalCode() {
		return numericalCode;
	}

	public void setNumericalCode(String numericalCode) {
		this.numericalCode = numericalCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

}