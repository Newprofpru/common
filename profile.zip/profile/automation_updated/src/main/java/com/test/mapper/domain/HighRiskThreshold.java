package com.test.mapper.domain;

public class HighRiskThreshold {

	private FinalSummation finalSummation;

	public FinalSummation getFinalSummation() {
		return finalSummation;
	}

	public void setFinalSummation(FinalSummation finalSummation) {
		this.finalSummation = finalSummation;
	}

	@Override
	public String toString() {
		return "HighRiskThreshold [finalSummation=" + finalSummation + "]";
	}
}
