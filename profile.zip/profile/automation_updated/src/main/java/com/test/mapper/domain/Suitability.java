package com.test.mapper.domain;

public class Suitability {
	
	   private String timeHorizon;

	    private String liquidityNeeds;

	    private String riskTolerance;

	    private String investmentObjective;

		public String getTimeHorizon() {
			return timeHorizon;
		}

		public String getLiquidityNeeds() {
			return liquidityNeeds;
		}

		public String getRiskTolerance() {
			return riskTolerance;
		}

		public String getInvestmentObjective() {
			return investmentObjective;
		}

		public void setTimeHorizon(String timeHorizon) {
			this.timeHorizon = timeHorizon;
		}

		public void setLiquidityNeeds(String liquidityNeeds) {
			this.liquidityNeeds = liquidityNeeds;
		}

		public void setRiskTolerance(String riskTolerance) {
			this.riskTolerance = riskTolerance;
		}

		public void setInvestmentObjective(String investmentObjective) {
			this.investmentObjective = investmentObjective;
		}

		@Override
		public String toString() {
			return "Suitability [timeHorizon=" + timeHorizon + ", liquidityNeeds=" + liquidityNeeds + ", riskTolerance="
					+ riskTolerance + ", investmentObjective=" + investmentObjective + "]";
		}

}
