package com.test.mapper.domain;

public class Reputation {
	
	private String aml;

    private String politicallyExposed;

    private String sarorstrInd;

    private String adverseMedia;

    private String marijuana;

    private String localSanctions;

    private String pfc;

    private String ofac;

	public String getAml() {
		return aml;
	}

	public String getPoliticallyExposed() {
		return politicallyExposed;
	}

	public String getSarorstrInd() {
		return sarorstrInd;
	}

	public String getAdverseMedia() {
		return adverseMedia;
	}

	public String getMarijuana() {
		return marijuana;
	}

	public String getLocalSanctions() {
		return localSanctions;
	}

	public String getPfc() {
		return pfc;
	}

	public String getOfac() {
		return ofac;
	}

	public void setAml(String aml) {
		this.aml = aml;
	}

	public void setPoliticallyExposed(String politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}

	public void setSarorstrInd(String sarorstrInd) {
		this.sarorstrInd = sarorstrInd;
	}

	public void setAdverseMedia(String adverseMedia) {
		this.adverseMedia = adverseMedia;
	}

	public void setMarijuana(String marijuana) {
		this.marijuana = marijuana;
	}

	public void setLocalSanctions(String localSanctions) {
		this.localSanctions = localSanctions;
	}

	public void setPfc(String pfc) {
		this.pfc = pfc;
	}

	public void setOfac(String ofac) {
		this.ofac = ofac;
	}

	@Override
	public String toString() {
		return "Reputation [aml=" + aml + ", politicallyExposed=" + politicallyExposed + ", sarorstrInd=" + sarorstrInd
				+ ", adverseMedia=" + adverseMedia + ", marijuana=" + marijuana + ", localSanctions=" + localSanctions
				+ ", pfc=" + pfc + ", ofac=" + ofac + "]";
	}

}
