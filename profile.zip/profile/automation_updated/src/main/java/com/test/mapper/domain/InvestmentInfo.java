package com.test.mapper.domain;

public class InvestmentInfo {
	
	private String annualIncome;

  //  private String investmentExperience;

    private String taxBracket;

    private String liquidNetWorth;

    private String totalNetWorth;

	public String getAnnualIncome() {
		return annualIncome;
	}

	/*public String getInvestmentExperience() {
		return investmentExperience;
	}*/

	public String getTaxBracket() {
		return taxBracket;
	}

	public String getLiquidNetWorth() {
		return liquidNetWorth;
	}

	public String getTotalNetWorth() {
		return totalNetWorth;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	/*public void setInvestmentExperience(String investmentExperience) {
		this.investmentExperience = investmentExperience;
	}*/

	public void setTaxBracket(String taxBracket) {
		this.taxBracket = taxBracket;
	}

	public void setLiquidNetWorth(String liquidNetWorth) {
		this.liquidNetWorth = liquidNetWorth;
	}

	public void setTotalNetWorth(String totalNetWorth) {
		this.totalNetWorth = totalNetWorth;
	}

	@Override
	public String toString() {
		return "InvestmentInfo [annualIncome=" + annualIncome + ", taxBracket=" + taxBracket + ", liquidNetWorth=" + liquidNetWorth + ", totalNetWorth="
				+ totalNetWorth + "]";
	}

}
