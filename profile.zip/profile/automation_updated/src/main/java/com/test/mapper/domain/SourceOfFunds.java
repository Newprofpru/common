package com.test.mapper.domain;

import java.util.Map;

public class SourceOfFunds {
	
	private Map<String,String> paymentMethod;
	
	public Map<String, String> getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(Map<String, String> paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

}
