package com.test.mapper.domain;

public class ReputationUpdate {
	
	private Reputation reputation;

	public Reputation getReputation() {
		return reputation;
	}

	public void setReputation(Reputation reputation) {
		this.reputation = reputation;
	}

	@Override
	public String toString() {
		return "ReputationUpdate []";
	}

}
