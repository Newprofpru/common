package com.test.mapper.domain;

import java.util.Arrays;
import java.util.List;

public class Profiles {

	private String ssoId;

    private String sourceId;

    private PersonalInfo personalInfo;

    private String bURelationShip;

    private String userSourceCode;
    
    private String businessUnit;

    private String coUserId;

    private String relationshipToAccount;

    private String productName;

    private List<ContactChannels> contactChannels;

    private String isEditable;

    private String productGroup;

    private String eventStatus;

    private String contractId;

    private String benefitClaimId;

    private String userType;

    private String lineOfBusinessCode;

    private String sourceApplication;

	public String getSsoId() {
		return ssoId;
	}

	public String getSourceId() {
		return sourceId;
	}

	public PersonalInfo getPersonalInfo() {
		return personalInfo;
	}

	public String getbURelationShip() {
		return bURelationShip;
	}

	public String getUserSourceCode() {
		return userSourceCode;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public String getCoUserId() {
		return coUserId;
	}

	public String getRelationshipToAccount() {
		return relationshipToAccount;
	}

	public String getProductName() {
		return productName;
	}

	public List<ContactChannels> getContactChannels() {
		return contactChannels;
	}

	public String getIsEditable() {
		return isEditable;
	}

	public String getProductGroup() {
		return productGroup;
	}

	public String getEventStatus() {
		return eventStatus;
	}

	public String getContractId() {
		return contractId;
	}

	public String getBenefitClaimId() {
		return benefitClaimId;
	}

	public String getUserType() {
		return userType;
	}

	public String getLineOfBusinessCode() {
		return lineOfBusinessCode;
	}

	public String getSourceApplication() {
		return sourceApplication;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public void setPersonalInfo(PersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}

	public void setbURelationShip(String bURelationShip) {
		this.bURelationShip = bURelationShip;
	}

	public void setUserSourceCode(String userSourceCode) {
		this.userSourceCode = userSourceCode;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void setCoUserId(String coUserId) {
		this.coUserId = coUserId;
	}

	public void setRelationshipToAccount(String relationshipToAccount) {
		this.relationshipToAccount = relationshipToAccount;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setContactChannels(List<ContactChannels> contactChannels) {
		this.contactChannels = contactChannels;
	}

	public void setIsEditable(String isEditable) {
		this.isEditable = isEditable;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void setBenefitClaimId(String benefitClaimId) {
		this.benefitClaimId = benefitClaimId;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public void setLineOfBusinessCode(String lineOfBusinessCode) {
		this.lineOfBusinessCode = lineOfBusinessCode;
	}

	public void setSourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}

	@Override
	public String toString() {
		return "Profiles [ssoId=" + ssoId + ", sourceId=" + sourceId + ", personalInfo=" + personalInfo
				+ ", bURelationShip=" + bURelationShip + ", userSourceCode=" + userSourceCode + ", businessUnit="
				+ businessUnit + ", coUserId=" + coUserId + ", relationshipToAccount=" + relationshipToAccount
				+ ", productName=" + productName + ", contactChannels=" + contactChannels + ", isEditable=" + isEditable
				+ ", productGroup=" + productGroup + ", eventStatus=" + eventStatus + ", contractId=" + contractId
				+ ", benefitClaimId=" + benefitClaimId + ", userType=" + userType + ", lineOfBusinessCode="
				+ lineOfBusinessCode + ", sourceApplication=" + sourceApplication + "]";
	}

	
}
