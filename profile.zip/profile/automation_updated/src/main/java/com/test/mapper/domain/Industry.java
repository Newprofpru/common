package com.test.mapper.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY)
public class Industry {

	private String industryName;
	private String pointVal;
	private String industryCode;

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	public String getPointVal() {
		return pointVal;
	}

	public void setPointVal(String pointVal) {
		this.pointVal = pointVal;
	}
	
	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode =  industryCode;
	}

}
