package com.test.mapper.domain;

import java.util.List;

public class ProfileV4 {

	private String ssoId;

	private String sourceId;

	private String bURelationShip;

	private String userSourceCode;

	private String businessUnit;

	private String coUserId;

	private String relationshipToAccount;

	private String productName;

	private List<ContactChannels> contactChannels;

	private String isEditable;

	private String productGroup;

	private String eventStatus;

	private String contractId;

	private String benefitClaimId;

	private String userType;

	private String lineOfBusinessCode;

	private String sourceApplication;
}
