package com.test.mapper.domain;

public class PersonalInfo {
	
	private String sourceId;

    private String lastName;

    private String occupation;

    private String userStatus;

    private String gender;

    private String visaExpiration;

    private String prefix;

    private String employerName;

    private String ownerCoUserId;

    private String suffix;

    private String salary;

    private String employmentStatus;

    private String ssn;

    private String poaCoUserId;

    private String countryOfBirth;

    private String preferredName;

    private String last4Ssn;

    private String userSource;

    private String citizenship;
    
    private String userType;

    private String dateOfBirth;

    private String visaType;

    private String permanentResident;

    private String firstName;

    private String deleted;

    private String profilePhotoLink;

    private String middleName;

    private String position;

    private String euResidentFlag;

    private String maritalStatus;

	public String getSourceId() {
		return sourceId;
	}

	public String getLastName() {
		return lastName;
	}

	public String getOccupation() {
		return occupation;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public String getGender() {
		return gender;
	}

	public String getVisaExpiration() {
		return visaExpiration;
	}

	public String getPrefix() {
		return prefix;
	}

	public String getEmployerName() {
		return employerName;
	}

	public String getOwnerCoUserId() {
		return ownerCoUserId;
	}

	public String getSuffix() {
		return suffix;
	}

	public String getSalary() {
		return salary;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public String getSsn() {
		return ssn;
	}

	public String getPoaCoUserId() {
		return poaCoUserId;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public String getLast4Ssn() {
		return last4Ssn;
	}

	public String getUserSource() {
		return userSource;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public String getVisaType() {
		return visaType;
	}

	public String getPermanentResident() {
		return permanentResident;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getDeleted() {
		return deleted;
	}

	public String getProfilePhotoLink() {
		return profilePhotoLink;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getPosition() {
		return position;
	}

	public String getEuResidentFlag() {
		return euResidentFlag;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setVisaExpiration(String visaExpiration) {
		this.visaExpiration = visaExpiration;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public void setOwnerCoUserId(String ownerCoUserId) {
		this.ownerCoUserId = ownerCoUserId;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public void setPoaCoUserId(String poaCoUserId) {
		this.poaCoUserId = poaCoUserId;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public void setLast4Ssn(String last4Ssn) {
		this.last4Ssn = last4Ssn;
	}

	public void setUserSource(String userSource) {
		this.userSource = userSource;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public void setPermanentResident(String permanentResident) {
		this.permanentResident = permanentResident;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

	public void setProfilePhotoLink(String profilePhotoLink) {
		this.profilePhotoLink = profilePhotoLink;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public void setEuResidentFlag(String euResidentFlag) {
		this.euResidentFlag = euResidentFlag;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	@Override
	public String toString() {
		return "PersonalInfo [sourceId=" + sourceId + ", lastName=" + lastName + ", occupation=" + occupation
				+ ", userStatus=" + userStatus + ", gender=" + gender + ", visaExpiration=" + visaExpiration
				+ ", prefix=" + prefix + ", employerName=" + employerName + ", ownerCoUserId=" + ownerCoUserId
				+ ", suffix=" + suffix + ", salary=" + salary + ", employmentStatus=" + employmentStatus + ", ssn="
				+ ssn + ", poaCoUserId=" + poaCoUserId + ", countryOfBirth=" + countryOfBirth + ", preferredName="
				+ preferredName + ", last4Ssn=" + last4Ssn + ", userSource=" + userSource + ", citizenship="
				+ citizenship + ", userType=" + userType + ", dateOfBirth=" + dateOfBirth + ", visaType=" + visaType
				+ ", permanentResident=" + permanentResident + ", firstName=" + firstName + ", deleted=" + deleted
				+ ", profilePhotoLink=" + profilePhotoLink + ", middleName=" + middleName + ", position=" + position
				+ ", euResidentFlag=" + euResidentFlag + ", maritalStatus=" + maritalStatus + "]";
	}



}
