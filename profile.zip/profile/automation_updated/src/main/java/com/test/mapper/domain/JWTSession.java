package com.test.mapper.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"start",
"limit",
"visitorId",
"X-PruAuthJWT",
"ProspectUserId",
"ProspectPassword",
"CustomerUserId",
"CustomerPassword",
"ProspectUserIdStage",
"ProspectPasswordStage",
"CustomerIdStage",
"CustomerPasswordStage",
"buidtype"
})
public class JWTSession {

@JsonProperty("start")
private String start;
@JsonProperty("limit")
private String limit;
@JsonProperty("visitorId")
private String visitorId;
@JsonProperty("X-PruAuthJWT")
private String xPruAuthJWT;
@JsonProperty("ProspectUserId")
private String prospectUserId;
@JsonProperty("ProspectPassword")
private String prospectPassword;
@JsonProperty("CustomerUserId")
private String customerUserId;
@JsonProperty("CustomerPassword")
private String customerPassword;
@JsonProperty("ProspectUserIdStage")
private String prospectUserIdStage;
@JsonProperty("ProspectPasswordStage")
private String prospectPasswordStage;
@JsonProperty("CustomerIdStage")
private String customerIdStage;
@JsonProperty("CustomerPasswordStage")
private String customerPasswordStage;
@JsonProperty("buidtype")
private String buidtype;

@JsonProperty("start")
public String getStart() {
return start;
}

@JsonProperty("start")
public void setStart(String start) {
this.start = start;
}

@JsonProperty("limit")
public String getLimit() {
return limit;
}

@JsonProperty("limit")
public void setLimit(String limit) {
this.limit = limit;
}

@JsonProperty("visitorId")
public String getVisitorId() {
return visitorId;
}

@JsonProperty("visitorId")
public void setVisitorId(String visitorId) {
this.visitorId = visitorId;
}

@JsonProperty("X-PruAuthJWT")
public String getXPruAuthJWT() {
return xPruAuthJWT;
}

@JsonProperty("X-PruAuthJWT")
public void setXPruAuthJWT(String xPruAuthJWT) {
this.xPruAuthJWT = xPruAuthJWT;
}

@JsonProperty("ProspectUserId")
public String getProspectUserId() {
return prospectUserId;
}

@JsonProperty("ProspectUserId")
public void setProspectUserId(String prospectUserId) {
this.prospectUserId = prospectUserId;
}

@JsonProperty("ProspectPassword")
public String getProspectPassword() {
return prospectPassword;
}

@JsonProperty("ProspectPassword")
public void setProspectPassword(String prospectPassword) {
this.prospectPassword = prospectPassword;
}

@JsonProperty("CustomerUserId")
public String getCustomerUserId() {
return customerUserId;
}

@JsonProperty("CustomerUserId")
public void setCustomerUserId(String customerUserId) {
this.customerUserId = customerUserId;
}

@JsonProperty("CustomerPassword")
public String getCustomerPassword() {
return customerPassword;
}

@JsonProperty("CustomerPassword")
public void setCustomerPassword(String customerPassword) {
this.customerPassword = customerPassword;
}

@JsonProperty("ProspectUserIdStage")
public String getProspectUserIdStage() {
return prospectUserIdStage;
}

@JsonProperty("ProspectUserIdStage")
public void setProspectUserIdStage(String prospectUserIdStage) {
this.prospectUserIdStage = prospectUserIdStage;
}

@JsonProperty("ProspectPasswordStage")
public String getProspectPasswordStage() {
return prospectPasswordStage;
}

@JsonProperty("ProspectPasswordStage")
public void setProspectPasswordStage(String prospectPasswordStage) {
this.prospectPasswordStage = prospectPasswordStage;
}

@JsonProperty("CustomerIdStage")
public String getCustomerIdStage() {
return customerIdStage;
}

@JsonProperty("CustomerIdStage")
public void setCustomerIdStage(String customerIdStage) {
this.customerIdStage = customerIdStage;
}

@JsonProperty("CustomerPasswordStage")
public String getCustomerPasswordStage() {
return customerPasswordStage;
}

@JsonProperty("CustomerPasswordStage")
public void setCustomerPasswordStage(String customerPasswordStage) {
this.customerPasswordStage = customerPasswordStage;
}

@JsonProperty("buidtype")
public String getBuidtype() {
return buidtype;
}

@JsonProperty("buidtype")
public void setBuidtype(String buidtype) {
this.buidtype = buidtype;
}

}