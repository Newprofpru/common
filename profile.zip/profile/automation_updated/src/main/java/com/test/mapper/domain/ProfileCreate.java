package com.test.mapper.domain;

import java.util.List;

public class ProfileCreate {

	private List<ContactAddresses> contactAddresses;

    private String ssoId;

    private PersonalInfo personalInfo;

    private String deleted;

    private String businessUnit;

    private Suitability suitability;

    private String contractId;

    private String relationshipToAccount;

    private List<ContactChannels> contactChannels;
    
    private String coUserId;

    private String responseStatus;

    private String responseCode;

	public List<ContactAddresses> getContactAddresses() {
		return contactAddresses;
	}

	public String getSsoId() {
		return ssoId;
	}

	public PersonalInfo getPersonalInfo() {
		return personalInfo;
	}

	public String getDeleted() {
		return deleted;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public Suitability getSuitability() {
		return suitability;
	}

	public String getContractId() {
		return contractId;
	}

	public String getRelationshipToAccount() {
		return relationshipToAccount;
	}

	public List<ContactChannels> getContactChannels() {
		return contactChannels;
	}

	public String getCoUserId() {
		return coUserId;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setContactAddresses(List<ContactAddresses> contactAddresses) {
		this.contactAddresses = contactAddresses;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public void setPersonalInfo(PersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}

	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void setSuitability(Suitability suitability) {
		this.suitability = suitability;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public void setRelationshipToAccount(String relationshipToAccount) {
		this.relationshipToAccount = relationshipToAccount;
	}

	public void setContactChannels(List<ContactChannels> contactChannels) {
		this.contactChannels = contactChannels;
	}

	public void setCoUserId(String coUserId) {
		this.coUserId = coUserId;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	@Override
	public String toString() {
		return "ProfileCreate [contactAddresses=" + contactAddresses + ", ssoId=" + ssoId + ", personalInfo="
				+ personalInfo + ", deleted=" + deleted + ", businessUnit=" + businessUnit + ", suitability="
				+ suitability + ", contractId=" + contractId + ", relationshipToAccount=" + relationshipToAccount
				+ ", contactChannels=" + contactChannels + ", coUserId=" + coUserId + ", responseStatus="
				+ responseStatus + ", responseCode=" + responseCode + "]";
	}

	
}
