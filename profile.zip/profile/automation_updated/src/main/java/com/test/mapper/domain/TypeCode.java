package com.test.mapper.domain;

public class TypeCode {

}
