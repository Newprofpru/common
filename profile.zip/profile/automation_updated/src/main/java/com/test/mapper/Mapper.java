package com.test.mapper;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.json.JSONObject;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.domain.ProfileCreate;

public class Mapper {

	protected ObjectMapper mapper;
	private String pathMainStatic = "src/main/resources";
	private String pathTestStatic = "src/test/resources";

	public Mapper() {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public String getAsString(Object obj) throws JsonProcessingException {
		return mapper.writeValueAsString(obj);
	}

	public void load(String fileName,Object obj)
			throws IOException, IllegalAccessException, InvocationTargetException {

		String filePath=null;
		
		switch (obj.getClass().getSimpleName()) {
		
		case "ProfileCreate":
			filePath = pathMainStatic + "/Profile/POST/";
			break;
		case "ProfileUpdate":
			filePath = pathMainStatic + "/Profile/PUT/";
			break;
		case "ReputationUpdate":
			filePath = pathMainStatic + "/Reputation/PUT/";
			break;
		case "Profiles":
			filePath = pathMainStatic + "/Profile/PUT/";
			break;
		case "JWTSession":
			filePath = pathTestStatic + "/";
			break;
		}

		BeanUtils.copyProperties(obj, mapper.readValue(new File(filePath+(fileName)), obj.getClass()));


		
	}
	
}
