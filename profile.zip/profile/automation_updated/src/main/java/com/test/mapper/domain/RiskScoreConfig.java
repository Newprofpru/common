package com.test.mapper.domain;

public class RiskScoreConfig {

	    private Product product;

	    private Demography demography;

	    private HighRiskThreshold highRiskThreshold;

	    private Reputation reputation;

	    private SourceOfFunds sourceOfFunds;

	    private String type;

		public Product getProduct() {
			return product;
		}

		public Demography getDemography() {
			return demography;
		}

		public HighRiskThreshold getHighRiskThreshold() {
			return highRiskThreshold;
		}

				public Reputation getReputation() {
			return reputation;
		}

		public SourceOfFunds getSourceOfFunds() {
			return sourceOfFunds;
		}

		public String getType() {
			return type;
		}

		public void setProduct(Product product) {
			this.product = product;
		}

		public void setDemography(Demography demography) {
			this.demography = demography;
		}

		public void setHighRiskThreshold(HighRiskThreshold highRiskThreshold) {
			this.highRiskThreshold = highRiskThreshold;
		}

		public void setReputation(Reputation reputation) {
			this.reputation = reputation;
		}

		public void setSourceOfFunds(SourceOfFunds sourceOfFunds) {
			this.sourceOfFunds = sourceOfFunds;
		}

		public void setType(String type) {
			this.type = type;
		}

		@Override
		public String toString() {
			return "RiskScoreConfig [product=" + product + ", demography=" + demography + ", highRiskThreshold="
					+ highRiskThreshold + ", reputation=" + reputation + ", sourceOfFunds=" + sourceOfFunds + ", type="
					+ type + "]";
		}

		

	    
}
