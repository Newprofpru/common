package com.test.mapper.domain;

public class FinalSummation {
	private String finalhighriskthreshold;

    private String individualhighriskthreshold;

    private String operator;

    public String getFinalhighriskthreshold ()
    {
        return finalhighriskthreshold;
    }

    public void setFinalhighriskthreshold (String finalhighriskthreshold)
    {
        this.finalhighriskthreshold = finalhighriskthreshold;
    }

    public String getIndividualhighriskthreshold ()
    {
        return individualhighriskthreshold;
    }

    public void setIndividualhighriskthreshold (String individualhighriskthreshold)
    {
        this.individualhighriskthreshold = individualhighriskthreshold;
    }

    public String getOperator ()
    {
        return operator;
    }

    public void setOperator (String operator)
    {
        this.operator = operator;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [finalhighriskthreshold = "+finalhighriskthreshold+", individualhighriskthreshold = "+individualhighriskthreshold+", operator = "+operator+"]";
    }
}
