package com.Profile.StepDefination;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.json.simple.parser.ParseException;

import com.Profile.Utils.getEnvInfo;
import com.test.mapper.Mapper;
import com.test.mapper.domain.ProfileCreate;
import com.test.mapper.domain.Profiles;

import io.restassured.http.ContentType;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class CreateProfile {

	String inline = "";
	Mapper mapper = new Mapper();
	String Service_Url = getEnvInfo.getSecureProfileURL();
	io.restassured.response.Response responseCreate = null;
	RequestSpecification request = null;
	ProfileCreate profileCreate = new ProfileCreate();
	String requestID = "CreateProfile";
	Profiles profiles = new Profiles();
	String authorization = getEnvInfo.getRepAuthorization();

	public ResponseBody createProfile1(String ssoId)
			throws IllegalAccessException, InvocationTargetException, IOException, ParseException {

		/* code for mapping java objects to json objects */

		mapper.load("ProfileCreate.json", profileCreate);
		profileCreate.setSsoId(ssoId);
		System.out.println(mapper.getAsString(profileCreate));

		request = given().header("X-PruRequestId", requestID).header("Authorization", authorization);

		responseCreate = request.log().all().body(profileCreate).contentType(ContentType.JSON).post(Service_Url)
				.andReturn();

		System.out.println("POST Response of Profile with DOB as 01/01/0001-->" + responseCreate.prettyPrint());

		return responseCreate.getBody();

	}

	public ResponseBody createProfile2() throws IllegalAccessException, InvocationTargetException, IOException, ParseException {

		mapper.load("ProfileCreate2.json", profileCreate);
		System.out.println(mapper.getAsString(profileCreate));

		request = given().header("X-PruRequestId", requestID).header("Authorization", authorization);

		responseCreate = request.log().all().body(profileCreate).contentType(ContentType.JSON).post(Service_Url).andReturn();
		
		 System.out.println("POST Response of Profile  with DOB as 01/01/1991-->" +responseCreate.prettyPrint());
		 
		 return responseCreate.getBody();

	}

}
