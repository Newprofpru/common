package com.Profile.StepDefination;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import com.Profile.Utils.GetJwtTokenCSR;
import com.Profile.Utils.getEnvInfo;
import com.test.mapper.Mapper;
import com.test.mapper.domain.ProfileUpdate;
import com.test.mapper.domain.Profiles;
import com.test.mapper.domain.ReputationUpdate;

import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;


public class UpdateProfile {
	Mapper mapper =new Mapper();
	io.restassured.response.Response response = null;
	io.restassured.response.Response response3 = null;
	RequestSpecification request = null;
	String getSMSESSION = GetJwtTokenCSR.generateSmsessionToken("myid12345","pru12345");
	String authorization = getEnvInfo.getRepAuthorization();
	String Service_url_EntityRep = getEnvInfo.getSecureURLEntityRep();
	String Service_Url_PUT_PU = getEnvInfo.getSecureProfileURL();
	String  Service_Url_PUT_PUV4 ="https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
	Profiles profiles = new Profiles();
	ProfileUpdate profileUpdate = new ProfileUpdate();
	ReputationUpdate reputationUpdate = new ReputationUpdate();
	String requestID1 = "UpdateProfile";
	String requestID2 = "UpdateReputation";
	String requestID3 = "UpdateProfileV4";
	String entityID = "700000010623";
	String getJWTToken = GetJwtTokenCSR.getJWTAuthToken();
	
	public void updateProfile1(String ssoId,String couserId,String dob) throws IllegalAccessException, InvocationTargetException, IOException {
			
		/*code for mapping java objects to json objects */
		
		mapper.load("ProfileUpdate.json",profileUpdate);
		profileUpdate.setSsoId(ssoId);
		profileUpdate.setCoUserId(couserId);
		if(dob!=null) {
			profileUpdate.getPersonalInfo().setDateOfBirth(dob);
		}
		System.out.println(mapper.getAsString(profileUpdate));
		
		request = given()
				.header("X-PruRequestId", requestID1)
				.header("Authorization", authorization);
		
		response = request.log().all().body(profileUpdate).contentType(ContentType.JSON).put(Service_Url_PUT_PU).andReturn();
		System.out.println("PUT Response-->" + response.prettyPrint());
	}
	
	/*public void PutRiskScoreConfigReq() throws IllegalAccessException, InvocationTargetException, IOException  {
		YamlMapper yamlMapper =new YamlMapper();
		String Service_Url_PUT = "https://api-stage.prudential.com/co/stage/secure/platform/v1/riskscoreconfig";
		io.restassured.response.Response responsePut = null;
		RequestSpecification request = null;
		RiskScoreConfigGet riskScoreConfigGetYaml = new RiskScoreConfigGet();
		String requestID = "UpdateRiskScoreConfig";
		String authorization = "Basic U0FDYVlJbzNNTlA1Q3AyQVF0YTZ3S2FaakpHS2txNlg6SkE1ZjNqMUc2S2JQZ1RBNA==";
		String resultbody = "SMSESSION=bzoo7PWPgASHlvUGfdP8+6g7bNOQcqP7/CkngN8nOSwnHvUhBhntRpTbzHq44ggJWyD0oMms/y0+sPU7oKeWrEq8K1lOnAQwaObXcSoJDF5Z7eIA5m40uP4hSvMv/XSoxxeHZWQTOuSkyNVqhtxsRueQDMgTgbutAZBJ6044dD571iSOKnBnrDiRpLlvAp51H8JIkJmkawETOtH6tx5PJw1ab7ee3SghXyhi3I3l/Wn/Kiu7tbHxmgEP2I8gfa2Svrj3lgVfF6Gvw1gy8/a+aguVcoY4QoMLi4mHAXzAz47Hh25wt5CgtgcC1OjrLib2+lVdqHc8V/TJafyhI6Ug9vkBSr9sAeQFiI/QM/H4OwBpTUwgpgmUPd/2KkxqThZJW3CB8h0nEJG1x16uYesify/5eOtWjQFpUYXySOcKYBILtqDCXGAEAF2nBgq3COy/lEsq8dKEGFlFnqbwlaOcWtCVZ44K2g75gAZ5jqUlseZWDw7owlDD/BagYoo9fFOUf4mSZbNzIHWUSy7zSe3NYR8Op3f5Oj/T0yMoU8ut7FhCGqYTrQ8d/ADNLn9xeFCAJfU5foq5kiKOm3IipMAqvsn70IMHCm8NGEJC6YF4GrKe16Bq3pnV/KQ/u/lcNBb4/8cOcamg5T6tQNtV9xEPfAYOuM1eLM5Qzm4zS6rZHRqOCULVujZAGVGc8g3W1ArZKmRetf17fY7C9SUA5HKUmts0VkdPIQG95F8v/0SmNC+h/Xb7jX62aKPklhuhBwAyT6uSbcXDx///b5Q88VusI9mnepJ4PurtCDsK4WjJ9xekN+ozKtflPqqIXVov4YpXIH/XT+1d7tfUwAnf0Os2Nzv23/Nv1JSLoeB3Yo63vCDIbWrUYLmEJBAElzgr/NAFXMsLhWbh4ECdQDNoDid95TuwwetdcVoh7pC8jcKaFGeazDPWrCNIW33pNcibKzYdKc8gSPfCU3gPDn7HRR/AZwyO+zxHXrKFVBT8KH6qHzOCJddIVWIcECzsHh7OuiHzaZp53SbbD0AA5m1Ecl9KALTKP3G75MhYxGMiFrRS3D3fxeRcpAN9aMdIX3WCShw5T7mNhuqt2IIrjf/3y3Cxl3KBN1H680ySZc/061fjmF+S2Dv+ZijlkvJAcLvwmMYstsqzTXSXJcIbj4mVvubc5RDM8pA+wq4Eu8nlOJYHiFzEPAOKfHApSdnru2VD6OSDz8X8T2dP3qKAwiAVaTRWPSCyZEfd+0B2; path=/; domain=.prudential.com; secure"; 
		
		yamlMapper.load("src/main/resources/riskScoreConfigGet/PUT/" + riskScoreConfigGetYaml.getClass().getSimpleName() + ".yaml",riskScoreConfigGetYaml);
		System.out.println(yamlMapper.getAsString(riskScoreConfigGetYaml));
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Cookie", resultbody)
				.header("Authorization", authorization);
		
		responsePut = request.log().all().body(riskScoreConfigGetYaml).contentType(ContentType.JSON).put(Service_Url_PUT).andReturn();
		System.out.println("PUT Response of RiskScoreConfig -->" + responsePut.prettyPrint());
	}*/
	
	public void updateEntityReputation() throws IllegalAccessException, InvocationTargetException, IOException {
	
		/*code for mapping java objects to json objects */
		
		mapper.load("Reputation.json",reputationUpdate);
		System.out.println(mapper.getAsString(reputationUpdate));
		
		request = given()
				.header("X-PruRequestId", requestID2)
				.header("Authorization", authorization);
		
		
		response = request.log().all().body(reputationUpdate).contentType(ContentType.JSON).cookie(getSMSESSION).put(Service_url_EntityRep +entityID).andReturn();
		System.out.println("PUT Response-->" + response.prettyPrint());
	
	}
	
	public void updateV4Profile() throws IllegalAccessException, InvocationTargetException, IOException {
		
		mapper.load("ProfileUpdateV4.json",profiles);
		System.out.println(mapper.getAsString(profiles));
		
		request = given()
				.header("X-PruRequestId", requestID3)
				.header("X-PruAuthJWT", getJWTToken)
				.header("Authorization", authorization);
		
		response3 = request.log().all().body(profiles).contentType(ContentType.JSON).put(Service_Url_PUT_PUV4).andReturn();
		System.out.println("PUT Response of V4 -->" + response3.prettyPrint());
	
		
	}
}
