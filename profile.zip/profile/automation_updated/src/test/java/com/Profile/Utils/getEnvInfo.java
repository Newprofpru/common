package com.Profile.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class getEnvInfo {

	static Properties properties = loadFromPropFile();
	static Logger log = Logger.getLogger(getEnvInfo.class);
	static String Url;

	public static String getURL() {
		return properties.getProperty("URL");
	}

	public static String getPublicURL() {

		System.out.println(properties.getProperty("Environment"));
		if (properties.getProperty("Environment").equals("QA")) {
			Url = properties.getProperty("PublicUrl");
			System.out.println(Url);
		}
		if (properties.getProperty("Environment").equals("Stage"))
			Url = properties.getProperty("PublicUrl");

		return Url;
	}

	public static String getSecureProfileURL() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureProfileUrlQA");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlProfileSTAGE");
		return null;

	}

	public static String getAccountsSecureURL() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAAaccounts");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEaccounts");
		return null;

	}

	public static String getAuditTrailSecureURL() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAAuditTrail");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEAuditTrail");
		return null;

	}

	public static String getAuditTrailGetRequestGetRecordsURL() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAGetRecordsAuditAmlu");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageGetRecordsAuditAmlu");
		return null;

	}

	public static String getAuditTrailGetRequestViewRecordsURL() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAViewRecordsAuditAmlu");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageViewRecordsAuditAmlu");
		return null;

	}

	public static String getSecureURLIndvRep() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAIndvRep");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEIndvRep");
		return null;

	}

	public static String getSecureURLBeneRep() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQABeneRep");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEBeneRep");
		return null;

	}

	public static String getSecureURLEntityRep() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAEntityRep");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEEntityRep");
		return null;

	}

	public static String getSecureUrlSMSession() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQASMSession");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGESMSession");
		return null;

	}

	public static String getSecureUrlRiskScore() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQARiskScore");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGERiskScore");
		return null;

	}

	public static String getAuthorization() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AuthorizationQA");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AuthorizationSTAGE");
		return null;
	}

	public static String getRepAuthorization() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AuthorizationRepQA");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AuthorizationRepSTAGE");
		return null;
	}

	public static String getIVuser() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("IVuserQARep");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("IVuserStageRep");
		return null;
	}

	public static String getdb() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("DBqa");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("DBstg");
		return null;
	}

	public static String getdbUserName() {
		return properties.getProperty("dbUserName");
	}

	public static String getdbPass() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("dbPassqa");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("dbPassstg");
		return null;
	}

	public static String getaccountsdb() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			// System.out.println(properties.getProperty("AccountsDBqa"));
			return properties.getProperty("AccountsDBqa");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")) {
			return properties.getProperty("AccountsDBstg");
		}
		return null;
	}

	public static String getAuthorizationSMSESSION() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
			return properties.getProperty("AuthorizationSMSESSIONQA");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")) {
			System.out.println(properties.getProperty("AuthorizationSMSESSIONSTAGE"));
			return properties.getProperty("AuthorizationSMSESSIONSTAGE");
		}
		System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
		return null;
	}
	
	public static String getSsoLogin_url() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			return properties.getProperty("ssologin_url_QA");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")) {
			return properties.getProperty("ssologin_url_Stage");
		}
		return null;
	}
	
	public static String getJwtToken_url() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			return properties.getProperty("jwttoken_url_QA");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")) {
			return properties.getProperty("jwttoken_url_stage");
		}
		return null;
	}

	public static String getaccountsdbUserName() {
		return properties.getProperty("AccountsdbUserName");
	}

	public static String getaccountsdbPass() {
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {// System.out.println(properties.getProperty("AccountsdbPassqa"));
			return properties.getProperty("AccountsdbPassqa");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AccountsdbPassstg");
		return null;
	}

	public static String getEnvironment() {
		return properties.getProperty("Environment");
	}

	public static String getAuthUrl() {
		return properties.getProperty("AuthUrl");
	}

	public static String getCSRUrl() {
		return properties.getProperty("CSRUrl");
	}

	public static Properties getInstance() {
		return properties;
	}

	private static Properties loadFromPropFile() {
		Properties properties = new Properties();
		String relativePath = new File(System.getProperty("user.dir")).getAbsolutePath();
		relativePath = relativePath + getFileSeparator() + "src" + getFileSeparator() + "test" + getFileSeparator()
				+ "resources";

		try {
			properties.load(new FileInputStream(relativePath + getFileSeparator() + "GlobalSettings.properties"));
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return properties;
	}

	public static String getFileSeparator() {
		return System.getProperty("file.separator");
	}

	public static String getProxy() {
		return properties.getProperty("proxy");
	}

	public static String getBUIDType() {
		return properties.getProperty("buidType");
	}

}
