package com.Profile.Utils;

import static io.restassured.RestAssured.given;

import java.net.HttpURLConnection;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.mapper.Mapper;
import com.test.mapper.domain.JWTSession;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetJwtTokenCSR {
	static Properties properties = getEnvInfo.getInstance();

	static String URL = getEnvInfo.getSecureUrlSMSession();
	static String authorization = getEnvInfo.getAuthorizationSMSESSION();
	static RequestSpecification request1;
	static String payload1;
	static Response Res1;
	protected static Response response;
	static String resultbody = "";
	private static String XPruAuthJWT = null;
	static Map<String, String> cookie_Data = new HashMap<String, String>();
	static String EnvInUse = getEnvInfo.getEnvironment();
	protected static RequestSpecification request;
	static Map<String, String> cookies = new HashMap<>();

	/*public static String getCSRToken() throws InterruptedException {

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");
		options.setBinary("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
		System.setProperty("webdriver.chrome.driver", properties.getProperty("ChromeDriverPath"));
		capabilities.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		WebDriver driver = new ChromeDriver(capabilities);
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			driver.get("https://csrawssw1-dev.prudential.com/");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			driver.get("https://csrawssw1-stage.prudential.com/");

		driver.findElement(By.xpath("//input[contains(@name,'USER')]")).sendKeys("tsqa68@pru.com");
		driver.findElement(By.xpath("//input[contains(@name,'PASSWORD')]")).sendKeys("password1");
		driver.findElement(By.xpath("//input[contains(@name,'BUIDTYPE')]")).sendKeys("INDV");
		driver.findElement(By.xpath("//form/table/tbody/tr[5]/td/input[contains(@value,'Login')]")).click();

		Thread.sleep(5000);
		if (properties.getProperty("Environment").equalsIgnoreCase("QA"))
			driver.get("https://api-dev.prudential.com/.signjwt");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			driver.get("https://api-stage.prudential.com/.signjwt");
		Thread.sleep(2000);

		String responsenew = driver.findElement(By.xpath("/html//body")).getText();
		JSONObject obj = new JSONObject(responsenew);
		String jwtToken = obj.getString("jwt");
		System.out.println("out put is " + jwtToken);
		driver.quit();

		return jwtToken;

	}*/

	public static String generateSmsessionToken(String userid, String password) {

		try {
			request1 = given().log().all().header("Authorization", authorization).header("Content-Type",
					"application/json");
			cookie_Data.put("userid", userid);
			cookie_Data.put("password", password);
			cookie_Data.put("buidtype", "INDV");
			ObjectMapper mapper = new ObjectMapper();

			payload1 = mapper.writeValueAsString(Reputation_payload(cookie_Data));
			Res1 = request1.log().all().body(payload1).contentType(ContentType.JSON).post(URL).andReturn();

			JsonPath sessionres = new JsonPath(Res1.asString());

			resultbody = sessionres.getString("message");
			System.out.println("SMSESSION Token ======>" + resultbody);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultbody;
	}

	public static Session_info Reputation_payload(Map<String, String> Repu_Data) {

		Session_info request = new Session_info();

		request.setUserid(Repu_Data.get("userid"));
		request.setPassword(Repu_Data.get("password"));
		request.setBuidtype(Repu_Data.get("buidtype"));

		return request;

	}

	public static String getJWTAuthToken() {

		try {
			String buidType = getEnvInfo.getBUIDType();
			String ssoLogin_url = getEnvInfo.getSsoLogin_url();
			String jwtToken_url = getEnvInfo.getJwtToken_url();
			String userId = null;
			String password = null;
			Mapper mapper = new Mapper();
			JWTSession jwtSession = new JWTSession();

			mapper.load("JWTSession.json", jwtSession);

			if (EnvInUse.equalsIgnoreCase("QA")) {
				userId = jwtSession.getCustomerUserId();
				password = jwtSession.getCustomerPassword();
			} else {
				userId = jwtSession.getCustomerIdStage();
				password = jwtSession.getCustomerPasswordStage();
			}

			request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
					.formParam("BUIDTYPE", buidType).formParam("target", "/auth/login/").formParam("smquerydata", "")
					.formParam("smauthreason", "").formParam("smagentname", "ssologin");

			response = request.post(ssoLogin_url).andReturn();

			cookies = response.getCookies();
			logAllure("Cookies", cookies.toString());
			System.out.println("response-cookies :" + cookies);

			request = given().log().all().cookies(cookies);

			response = request.get(jwtToken_url).andReturn();

			JsonPath jp = new JsonPath(response.asString());

			XPruAuthJWT = jp.getString("jwt");

			System.out.println("Prospect JWT Toknen is :" + XPruAuthJWT);

			logAllure("UserId", userId);

			logAllure("JWT", XPruAuthJWT);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return XPruAuthJWT;

	}

	public static void logAllure(String name, String content) {

		// Allure.addAttachment(name, content);
	};

}
