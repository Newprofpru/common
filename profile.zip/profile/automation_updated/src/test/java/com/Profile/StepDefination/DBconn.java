package com.Profile.StepDefination;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Profile.Utils.DBConnection;
import com.Profile.Utils.getEnvInfo;

public class DBconn {
	
	public DBconn() throws SQLException {
		String query="select * from entityreputation";
		String queryAccounts="select * from HOLDINGSUMMARYREAD where rownum<=10";
		
		getEnvInfo gei=new getEnvInfo();
		gei.getaccountsdb();
		
		DBConnection conn= new DBConnection();
		Connection dbc=conn.InitConnection();
		Connection dbAccounts=conn.InitAccountsDbConnection();
		ResultSet rs=conn.execStatement(dbc, query);
		ResultSet rsAccounts=conn.execStatement(dbAccounts, queryAccounts);
		System.out.println("Platform Database connection");
		System.out.println("EntityId");
		System.out.println("================");
		while(rs.next()) {
			System.out.println(rs.getString("EntityId"));
		}
		System.out.println("Holding Database connection");
		System.out.println("HOLDINGSUMMARYID");
		System.out.println("==========");
		while(rsAccounts.next()) {
			System.out.println(rsAccounts.getString("HOLDINGSUMMARYID"));
		}
		rs.close();
		rsAccounts.close();
		conn.DbConnection_close(dbc);
		conn.DbConnection_close(dbAccounts);
	}
	
}
