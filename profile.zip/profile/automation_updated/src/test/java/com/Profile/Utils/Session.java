package com.Profile.Utils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"session"
})
public class Session {
	
	@JsonProperty("session")
	private Session_info session;

	@JsonProperty("session")
	public Session_info getSession() {
		return session;
	}

	@JsonProperty("session")
	public void setSession(Session_info session) {
		this.session = session;
	}

}