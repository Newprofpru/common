package com.Profile.Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ProfileUtils {
	
	static SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yyyy");
	
	public static String getTodayDate() {
		Calendar cal= Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	public static String getFutureDate(int noOfDaysFromToday) {
		Calendar cal= Calendar.getInstance();
		cal.add(Calendar.DATE, noOfDaysFromToday);
		return dateFormat.format(cal.getTime());
	}
	
	public static String getPastDate(int noOfDaysFromToday) {
		Calendar cal= Calendar.getInstance();
		cal.add(Calendar.DATE, -noOfDaysFromToday);
		return dateFormat.format(cal.getTime());
	}

}
