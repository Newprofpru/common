package com.Profile;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import org.json.simple.parser.ParseException;

import com.Profile.StepDefination.CreateProfile;
import com.Profile.StepDefination.DBconn;
import com.Profile.StepDefination.GetProfile;
import com.Profile.StepDefination.UpdateProfile;
import com.Profile.Utils.GetJwtTokenCSR;
import com.Profile.Utils.ProfileUtils;

import io.restassured.response.ResponseBody;

public class App {

	public static void main(String[] args) throws IOException, IllegalAccessException, InvocationTargetException, ParseException, SQLException, InterruptedException {
		
		String ssoId="20012854";
		String dob=ProfileUtils.getTodayDate();

		/* code for profile POST Request */
		
		CreateProfile createProfile = new CreateProfile();
		ResponseBody response=createProfile.createProfile1(ssoId);
		String coUserId1=response.jsonPath().getString("coUserId");
		
		/* code for profile GET Request */
		
    	GetProfile getAutomation = new GetProfile();
		getAutomation.getProfile1(coUserId1);
		
		/* code for profile PUT Request */

		UpdateProfile updateProfile = new UpdateProfile();
		updateProfile.updateProfile1(ssoId,coUserId1,dob);
		getAutomation.getProfile1(coUserId1);

		/*DB establishment*/
		
		DBconn DbConn = new DBconn();
		updateProfile.updateEntityReputation();		

		
		/*updateProfile.updateV4Profile();
		GetJwtTokenCSR getCSR = new GetJwtTokenCSR();
		getCSR.getCSRToken();*/

	}
}
