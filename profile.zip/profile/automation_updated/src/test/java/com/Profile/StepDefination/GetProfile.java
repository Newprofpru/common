package com.Profile.StepDefination;

import static io.restassured.RestAssured.given;

import com.Profile.Utils.getEnvInfo;
import com.google.gson.Gson;
import com.test.mapper.domain.ProfileCreate;

import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class GetProfile {
	String Service_Url_Get = "https://api-dev.prudential.com/co/qa/secure/profiles/v3/profile?coUserId=";
	io.restassured.response.Response responseGet = null;
	io.restassured.response.Response responseGet2 = null;
	RequestSpecification request = null;
	RequestSpecification request2 = null;
	String resultbody = null;
	ProfileCreate profile = new ProfileCreate();
	Gson gson = new Gson();
	String requestID = "getProfile";

	String payload = gson.toJson(profile);
	String authorization = getEnvInfo.getRepAuthorization();

	public void getProfile1(String coUserId1) {

		request = given().header("X-PruRequestId", requestID).header("Authorization", authorization);
		responseGet = request.contentType(ContentType.JSON).get(Service_Url_Get + coUserId1).andReturn();
		System.out.println("GET Response -->" + responseGet.prettyPrint());
	}

	public void getProfile2(String coUserId2) {

		request2 = given().header("X-PruRequestId", requestID).header("Authorization", authorization);
		responseGet2 = request2.contentType(ContentType.JSON).get(Service_Url_Get + coUserId2).andReturn();
		System.out.println("GET Response for DOB 01/01/1991-->" + responseGet2.prettyPrint());
	}

}
