/* This Module is connect to DB and get results from DB
 * Author : Krishnapriya.vellanki@prudential.com
 * 
 */
package com.Profile.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBConnection {

	static Connection con = null;
	static Statement stmt = null;
	static Properties properties = getEnvInfo.getInstance();

	public static Connection getConnection() {

		String user = getEnvInfo.getdbUserName();
		String pass = getEnvInfo.getdbPass();
		String db = getEnvInfo.getdb();
		return getConnection(db, user, pass);
	}

	public static Connection InitConnection() {

		String user = getEnvInfo.getdbUserName();
		String pass = getEnvInfo.getdbPass();
		String db = getEnvInfo.getdb();
		return getConnection(db, user, pass);
	}

	public static Connection getaccountsDbConnection() {

		String user = getEnvInfo.getaccountsdbUserName();
		String pass = getEnvInfo.getaccountsdbPass();
		String db = getEnvInfo.getaccountsdb();
		//System.out.println("DB is " + db);
		return getConnection(db, user, pass);
	}

	public static Connection InitAccountsDbConnection() {

		String user = getEnvInfo.getaccountsdbUserName();
		String pass = getEnvInfo.getaccountsdbPass();
		String db = getEnvInfo.getaccountsdb();
		return getConnection(db, user, pass);
	}

	public static Connection getConnection(String db, String Username, String Pass) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(db, Username, Pass);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}

	public static ResultSet execStatement(Connection conn, String query) {
		ResultSet Res = null;
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.getConnection();
			Res = ps.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Res;
	}

	public static void DbConnection_close(Connection conn) {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
