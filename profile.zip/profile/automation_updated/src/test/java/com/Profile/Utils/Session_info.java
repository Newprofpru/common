package com.Profile.Utils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
	"userid",
	"password",
	"buidtype"
})

public class Session_info {
	
	@JsonProperty("userid")
	private String userid;
	
	@JsonProperty("password")
	private String password;
	
	
	@JsonProperty("buidtype")
	private String buidtype;

	@JsonProperty("userid")
	public String getUserid() {
		return userid;
	}

	@JsonProperty("password")
	public String getPassword() {
		return password;
	}

	@JsonProperty("buidtype")
	public String getBuidtype() {
		return buidtype;
	}

	@JsonProperty("userid")
	public void setUserid(String userid) {
		this.userid = userid;
	}

	@JsonProperty("password")
	public void setPassword(String password) {
		this.password = password;
	}

	@JsonProperty("buidtype")
	public void setBuidtype(String buidtype) {
		this.buidtype = buidtype;
	}

}
