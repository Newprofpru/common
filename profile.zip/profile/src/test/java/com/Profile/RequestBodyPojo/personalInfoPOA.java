package com.Profile.RequestBodyPojo;

public class personalInfoPOA {
	
	String prefix;
	String firstName;
	String middleName;
	String lastName;
	String suffix;
	String preferredName;
	String maritalStatus;
	String dateOfBirth;
	String gender;
	String ssn;
	String userType;
	String userSource;
	String citizenship;
	String countryOfBirth;
	String occupation;
	String salary;
	String employmentStatus;
	String employerName;
	String visaType;
	String visaExpiration;
	String permanentResident;
	String euResidentFlag;
	String fedID;
	String cedulaId;
	String nit;
	String nonUsCitizenship;
	String govtIdType;
	String govtIdNumber;
	String issuanceCountry;
	String issuanceDate;
	String issuanceExpirationDate;
	String motherMaidenName;
	String paidInvestmentAdvice;
	String apexStatus;
	String registeredInvestmentAdvice;
	String dba;
	String tin;
	String registeredInvestmentNumber;
	String familyOffice;
	String professional;
	String legallyExempt;
	String attorneyType;
	String poaStatus;
	
	
}
