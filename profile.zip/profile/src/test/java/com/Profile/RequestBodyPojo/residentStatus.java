package com.Profile.RequestBodyPojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class residentStatus {
	
	String prc;
    String tra;   
    String nra;
    String pra;
    @JsonProperty("default")
    String rdefault;
        
    public residentStatus(){}
    
    public residentStatus(String prc, String tra, String nra, String pra, String rdefault){
    	this.prc = prc;
    	this.tra = tra;
    	this.nra = nra;
    	this.pra = pra;
    	this.rdefault = rdefault;    	
    }

	public String getPrc() {
		return prc;
	}
	public void setPrc(String prc) {
		this.prc = prc;
	}
	public String getTra() {
		return tra;
	}
	public void setTra(String tra) {
		this.tra = tra;
	}
	public String getNra() {
		return nra;
	}
	public void setNra(String nra) {
		this.nra = nra;
	}
	public String getPra() {
		return pra;
	}
	public void setPra(String pra) {
		this.pra = pra;
	}
	public String getRdefault() {
		return rdefault;
	}
	public void setRdefault(String rdefault) {
		this.rdefault = rdefault;
	}

	

	

}
