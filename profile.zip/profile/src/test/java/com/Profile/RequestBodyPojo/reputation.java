package com.Profile.RequestBodyPojo;

public class reputation {
	String aml;
    String politicallyExposed;
    String sarorstrInd;
    String adverseMedia;
    String marijuana;
    String localSanctions;
    String pfc;
    String ofac;
    
	public reputation(){}

	public reputation(String aml, String politicallyExposed, String sarorstrInd, String adverseMedia, String marijuana,
			String localSanctions, String pfc, String ofac) {
		this.aml = aml;
		this.politicallyExposed = politicallyExposed;
		this.sarorstrInd = sarorstrInd;
		this.adverseMedia = adverseMedia;
		this.marijuana = marijuana;
		this.localSanctions = localSanctions;
		this.pfc = pfc;
		this.ofac = ofac;
	}

	public String getAml() {
		return aml;
	}

	public void setAml(String aml) {
		this.aml = aml;
	}

	public String getPoliticallyExposed() {
		return politicallyExposed;
	}

	public void setPoliticallyExposed(String politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}

	public String getSarorstrInd() {
		return sarorstrInd;
	}

	public void setSarorstrInd(String sarorstrInd) {
		this.sarorstrInd = sarorstrInd;
	}

	public String getAdverseMedia() {
		return adverseMedia;
	}

	public void setAdverseMedia(String adverseMedia) {
		this.adverseMedia = adverseMedia;
	}

	public String getMarijuana() {
		return marijuana;
	}

	public void setMarijuana(String marijuana) {
		this.marijuana = marijuana;
	}

	public String getLocalSanctions() {
		return localSanctions;
	}

	public void setLocalSanctions(String localSanctions) {
		this.localSanctions = localSanctions;
	}

	public String getPfc() {
		return pfc;
	}

	public void setPfc(String pfc) {
		this.pfc = pfc;
	}

	public String getOfac() {
		return ofac;
	}

	public void setOfac(String ofac) {
		this.ofac = ofac;
	}

		
	
}
