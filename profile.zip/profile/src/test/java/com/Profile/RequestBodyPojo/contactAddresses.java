package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class contactAddresses {
	String contactAddressId;
	String addressType;
	String addressLine1;
	String addressLine2;
	String addressLine3;
	String addressLine4;
	String city;
	String state;
	String country;
	String zipCode;
	String zipPlus4;
	String addressStatus;
	String deleted;
	
	public contactAddresses(){}
	public contactAddresses(String contactAddressId, String addressType, String addressLine1, String addressLine2,
			String addressLine3, String addressLine4, String city, String state, String country, String zipCode,
			String zipPlus4, String addressStatus,String deleted) {
		this.contactAddressId = contactAddressId;
		this.addressType = addressType;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.addressLine4 = addressLine4;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipCode = zipCode;
		this.zipPlus4 = zipPlus4;
		this.addressStatus = addressStatus;
		this.deleted = deleted;
	}
	
	
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	public String getContactAddressId() {
		return contactAddressId;
	}
	public void setcontactAddressId(String contactAddressId) {
		this.contactAddressId = contactAddressId;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setaddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setaddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setaddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setaddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getAddressLine4() {
		return addressLine4;
	}
	public void setaddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}
	public String getCity() {
		return city;
	}
	public void setcity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setstate(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setcountry(String country) {
		this.country = country;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setzipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getZipPlus4() {
		return zipPlus4;
	}
	public void setzipPlus4(String zipPlus4) {
		this.zipPlus4 = zipPlus4;
	}
	public String getaddressStatus() {
		return addressStatus;
	}
	public void setaddressStatus(String addressStatus) {
		this.addressStatus = addressStatus;
	}
	
	
}
