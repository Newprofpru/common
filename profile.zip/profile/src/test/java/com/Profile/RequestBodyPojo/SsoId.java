package com.Profile.RequestBodyPojo;

import com.prudential.co.exception.model.ResponseHeader;

public class SsoId
{
    private String ssoid;

    private ResponseHeader responseHeader;

    private String statusMessage;

    public String getSsoid ()
    {
        return ssoid;
    }

    public void setSsoid (String ssoid)
    {
        this.ssoid = ssoid;
    }

    public ResponseHeader getResponseHeader ()
    {
        return responseHeader;
    }

    public void setResponseHeader (ResponseHeader responseHeader)
    {
        this.responseHeader = responseHeader;
    }

    public String getStatusMessage ()
    {
        return statusMessage;
    }

    public void setStatusMessage (String statusMessage)
    {
        this.statusMessage = statusMessage;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ssoid = "+ssoid+", responseHeader = "+responseHeader+", statusMessage = "+statusMessage+"]";
    }
}