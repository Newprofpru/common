package com.Profile.RequestBodyPojo;

public class product {
	
	riskScore productCashvalue;
	riskScore multipleProductCashvalue;
    
    public product(){}
	
	public product(riskScore productCashvalue, riskScore multipleProductCashvalue) {
		this.productCashvalue = productCashvalue;
		this.multipleProductCashvalue = multipleProductCashvalue;		
	}

	public riskScore getProductCashvalue() {
		return productCashvalue;
	}

	public void setProductCashvalue(riskScore productCashvalue) {
		this.productCashvalue = productCashvalue;
	}

	public riskScore getMultipleProductCashvalue() {
		return multipleProductCashvalue;
	}

	public void setMultipleProductCashvalue(riskScore multipleProductCashvalue) {
		this.multipleProductCashvalue = multipleProductCashvalue;
	}

	

}
