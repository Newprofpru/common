package com.Profile.RequestBodyPojo;

public class multipleProductCashvalue {
	
	String mdefault;
    String y;
    String n;
    public multipleProductCashvalue(){}
	
	public multipleProductCashvalue(String mdefault, String y, String n) {
		this.mdefault = mdefault;
		this.y = y;
		this.n = n;
	}

	public String getMdefault() {
		return mdefault;
	}

	public void setMdefault(String mdefault) {
		this.mdefault = mdefault;
	}

	public String getY() {
		return y;
	}

	public void setY(String y) {
		this.y = y;
	}

	public String getN() {
		return n;
	}

	public void setN(String n) {
		this.n = n;
	}

}
