package com.Profile.RequestBodyPojo;

public class productCashvalue {
	
	String pdefault;
    String y;
    String n;
    public productCashvalue(){}
	
	public productCashvalue(String pdefault, String y, String n) {
		this.pdefault = pdefault;
		this.y = y;
		this.n = n;
	}

	public String getPdefault() {
		return pdefault;
	}

	public void setPdefault(String pdefault) {
		this.pdefault = pdefault;
	}

	public String getY() {
		return y;
	}

	public void setY(String y) {
		this.y = y;
	}

	public String getN() {
		return n;
	}

	public void setN(String n) {
		this.n = n;
	}
	

}
