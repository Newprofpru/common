package com.Profile.RequestBodyPojo;

public class amluReputation {
	
	reputation reputation;
	
	public amluReputation(){}
	
	public amluReputation(reputation reputation) {
		this.reputation = reputation;
	}
	public reputation getReputation() {
		return reputation;
	}
	public void setReputation(reputation reputation) {
		this.reputation = reputation;
	}	

}
