package com.Profile.RequestBodyPojo;

public class RegistrationReq
{
    private ProfileDetails profileDetails;

    private String sourceType;

    public ProfileDetails getProfileDetails ()
    {
        return profileDetails;
    }

    public void setProfileDetails (ProfileDetails profileDetails)
    {
        this.profileDetails = profileDetails;
    }

    public String getSourceType ()
    {
        return sourceType;
    }

    public void setSourceType (String sourceType)
    {
        this.sourceType = sourceType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [profileDetails = "+profileDetails+", sourceType = "+sourceType+"]";
    }
}