package com.Profile.RequestBodyPojo;

public class fields {
	private String newValue;
    private String fieldName;
    private String oldValue;
    
    public fields() {}
    
    public fields(String newValue,String fieldName,String oldValue) 
    {
    	this.newValue=newValue;
    	this.fieldName=fieldName;
    	this.oldValue=oldValue;
   	
    }

    public String getnewValue ()
    {
        return newValue;
    }

    public void setnewValue (String newValue)
    {
        this.newValue = newValue;
    }

    public String getfieldName ()
    {
        return fieldName;
    }

    public void setfieldName (String fieldName)
    {
        this.fieldName = fieldName;
    }

    public String getoldValue ()
    {
        return oldValue;
    }

    public void setoldValue (String oldValue)
    {
        this.oldValue = oldValue;
    }
}
