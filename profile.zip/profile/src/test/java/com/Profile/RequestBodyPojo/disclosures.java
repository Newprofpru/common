package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class disclosures {
	
	String controlPerson;
	String companySymbols;
	String politicallyExposed;
	String organization;
	String relationship;
	String finraAffiliated;
	String firmName;
	String affliatedApprovalID;
	
	public disclosures(){}
	public disclosures(String controlPerson, String companySymbols, String politicallyExposed, String organization,
			String relationship, String finraAffiliated, String firmName, String affliatedApprovalID) {
		this.controlPerson = controlPerson;
		this.companySymbols = companySymbols;
		this.politicallyExposed = politicallyExposed;
		this.organization = organization;
		this.relationship = relationship;
		this.finraAffiliated = finraAffiliated;
		this.firmName = firmName;
		this.affliatedApprovalID = affliatedApprovalID;
	}
	
	
	
	public String getControlPerson() {
		return controlPerson;
	}
	public void setcontrolPerson(String controlPerson) {
		this.controlPerson = controlPerson;
	}
	public String getCompanySymbols() {
		return companySymbols;
	}
	public void setcompanySymbols(String companySymbols) {
		this.companySymbols = companySymbols;
	}
	public String getpoliticallyExposed() {
		return politicallyExposed;
	}
	public void setpoliticallyExposed(String politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}
	public String getorganization() {
		return organization;
	}
	public void setorganization(String organization) {
		this.organization = organization;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setrelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getFinraAffiliated() {
		return finraAffiliated;
	}
	public void setfinraAffiliated(String finraAffiliated) {
		this.finraAffiliated = finraAffiliated;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setfirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getAffliatedApprovalID() {
		return affliatedApprovalID;
	}
	public void setaffliatedApprovalID(String affliatedApprovalID) {
		this.affliatedApprovalID = affliatedApprovalID;
	}
	
	

}
