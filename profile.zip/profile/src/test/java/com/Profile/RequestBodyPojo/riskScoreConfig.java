package com.Profile.RequestBodyPojo;

public class riskScoreConfig {
	
	sourceOfFunds sourceOfFunds;
	product product; 
	highRiskThreshold highRiskThreshold;
	demography demography;
	riskreputation reputation;	

	public riskScoreConfig(){}
	
	public riskScoreConfig(sourceOfFunds sourceOfFunds, product product, highRiskThreshold highRiskThreshold, demography demography, riskreputation reputation) {
		this.sourceOfFunds = sourceOfFunds;
		this.product = product;
		this.highRiskThreshold = highRiskThreshold;
		this.demography = demography;
		this.reputation = reputation;
	}
	public sourceOfFunds getSourceOfFunds() {
		return sourceOfFunds;
	}
	public void setSourceOfFunds(sourceOfFunds sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}
	public product getProduct() {
		return product;
	}
	public void setProduct(product product) {
		this.product = product;
	}
	public highRiskThreshold getHighRiskThreshold() {
		return highRiskThreshold;
	}
	public void setHighRiskThreshold(highRiskThreshold highRiskThreshold) {
		this.highRiskThreshold = highRiskThreshold;
	}
	public demography getDemography() {
		return demography;
	}
	public void setDemography(demography demography) {
		this.demography = demography;
	}
	public riskreputation getReputation() {
		return reputation;
	}
	public void setReputation(riskreputation reputation) {
		this.reputation = reputation;
	}
}
