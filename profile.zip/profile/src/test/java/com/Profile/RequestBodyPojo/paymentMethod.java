package com.Profile.RequestBodyPojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class paymentMethod {
	@JsonProperty("fedwire-tp")
	String fedwiretp;
    String mo;
    @JsonProperty("eft-sb")
    String eftsb;
    @JsonProperty("dc/cc-c")
    String dcccc;
    @JsonProperty("c/b-c")
    String cbc;
    @JsonProperty("dc/cc-tp")
    String dccctp;
    String check;
    @JsonProperty("ach-us")
    String achus;
    String tc;
    @JsonProperty("default")
    String ddefault;
    @JsonProperty("ach-int")
    String achint;
    @JsonProperty("eft-cb")
    String eftcb;
    @JsonProperty("fedwire-c")
    String fedwirec;
    String cash;
    public paymentMethod(){}
	
	public paymentMethod(String fedwiretp, String mo, String eftsb, String dcccc, String cbc, String dccctp, String check, String achus,
			String tc, String achint, String eftcb, String fedwirec, String cash, String ddefault) {
		this.fedwiretp = fedwiretp;
		this.mo = mo;
		this.eftsb = eftsb;
		this.dcccc = dcccc;
		this.cbc = cbc;
		this.dccctp = dccctp;
		this.check = check;
		this.achus = achus;
		this.tc = tc;
		this.achint =achint;
		this.eftcb =eftcb;
		this.fedwirec = fedwirec;
		this.cash = cash;
		this.ddefault = ddefault;
	}

	public String getDdefault() {
		return ddefault;
	}
	public void setDdefault(String ddefault) {
		this.ddefault = ddefault;
	}
	public String getFedwiretp() {
		return fedwiretp;
	}
	public void setFedwiretp(String fedwiretp) {
		this.fedwiretp = fedwiretp;
	}
	public String getMo() {
		return mo;
	}
	public void setMo(String mo) {
		this.mo = mo;
	}
	public String getEftsb() {
		return eftsb;
	}
	public void setEftsb(String eftsb) {
		this.eftsb = eftsb;
	}
	public String getDcccc() {
		return dcccc;
	}
	public void setDcccc(String dcccc) {
		this.dcccc = dcccc;
	}
	public String getCbc() {
		return cbc;
	}
	public void setCbc(String cbc) {
		this.cbc = cbc;
	}
	public String getDccctp() {
		return dccctp;
	}
	public void setDccctp(String dccctp) {
		this.dccctp = dccctp;
	}
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	public String getAchus() {
		return achus;
	}
	public void setAchus(String achus) {
		this.achus = achus;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getAchint() {
		return achint;
	}
	public void setAchint(String achint) {
		this.achint = achint;
	}
	public String getEftcb() {
		return eftcb;
	}
	public void setEftcb(String eftcb) {
		this.eftcb = eftcb;
	}
	public String getFedwirec() {
		return fedwirec;
	}
	public void setFedwirec(String fedwirec) {
		this.fedwirec = fedwirec;
	}
	public String getCash() {
		return cash;
	}
	public void setCash(String cash) {
		this.cash = cash;
	}

}
