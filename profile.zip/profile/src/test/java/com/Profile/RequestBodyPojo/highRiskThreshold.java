package com.Profile.RequestBodyPojo;

public class highRiskThreshold {
	
	finalSummation finalSummation;
   
    public highRiskThreshold(){}
	
	public highRiskThreshold(finalSummation finalSummation) {
		this.finalSummation = finalSummation;	
	}

	public finalSummation getFinalSummation() {
		return finalSummation;
	}

	public void setFinalSummation(finalSummation finalSummation) {
		this.finalSummation = finalSummation;
	}	
	
}
