package com.Profile.RequestBodyPojo;

public class employers {

	String employeeId;
	String employer;
	String deleted;
	
	public employers(){}

	public employers(String employeeId, String employer, String deleted) {
		this.employeeId = employeeId;
		this.employer = employer;
		this.deleted = deleted;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setemployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployer() {
		return employer;
	}

	public void setemployer(String employer) {
		this.employer = employer;
	}

	public String getDeleted() {
		return deleted;
	}

	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	
	
	
}
