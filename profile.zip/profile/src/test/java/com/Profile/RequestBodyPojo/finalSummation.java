package com.Profile.RequestBodyPojo;

public class finalSummation {
	
	String finalhighriskthreshold;
    String individualhighriskthreshold;
    String operator;
    public finalSummation(){}
	
	public finalSummation(String finalhighriskthreshold, String individualhighriskthreshold, String operator) {
		this.finalhighriskthreshold = finalhighriskthreshold;
		this.individualhighriskthreshold = individualhighriskthreshold;
		this.operator = operator;
	}

	public String getFinalhighriskthreshold() {
		return finalhighriskthreshold;
	}

	public void setFinalhighriskthreshold(String finalhighriskthreshold) {
		this.finalhighriskthreshold = finalhighriskthreshold;
	}

	public String getIndividualhighriskthreshold() {
		return individualhighriskthreshold;
	}

	public void setIndividualhighriskthreshold(String individualhighriskthreshold) {
		this.individualhighriskthreshold = individualhighriskthreshold;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}
	
}
