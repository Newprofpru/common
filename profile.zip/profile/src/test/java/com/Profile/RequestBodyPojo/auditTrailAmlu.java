package com.Profile.RequestBodyPojo;

import java.util.List;

public class auditTrailAmlu {
	 
		private String role;
	    private String transactionRequestId;
	    private String linkedcontextcode;
	    private String sourceIPAddress;
	    private String linkedcontextrefid;
	    private String partyId;
	    private String partyType;
	    private String transactionTypeCode;
	    private String pruPrimaryIdentity;
	    private String coUserId;


	    List<fields> fields;
	    
	    private String sourceApplication;
	    private String transactioncategorycode;
	    private String transactionMsg;
	    
	    
	    public auditTrailAmlu() {}
	    
	    public auditTrailAmlu(String role,String transactionRequestId,String linkedcontextcode,String sourceIPAddress,String linkedcontextrefid,String partyId,
	    		String partyType,String transactionTypeCode, List<fields> fields, 
	    		String sourceApplication,String transactioncategorycode,String transactionMsg,String pruPrimaryIdentity,String coUserId) 
	    {
	    	this.role=role;
		    this.transactionRequestId=transactionRequestId;
		    this.linkedcontextcode=linkedcontextcode;
		    this.sourceIPAddress=sourceIPAddress;
		    this.linkedcontextrefid=linkedcontextrefid;
		    this.partyId=partyId;
		    this.partyType=partyType;
		    this.transactionTypeCode=transactionTypeCode;
		    this.fields=fields;
		    this.sourceApplication=sourceApplication;
		    this.transactioncategorycode=transactioncategorycode;
		    this.transactionMsg=transactionMsg;
		    this.coUserId=coUserId;
		    this.pruPrimaryIdentity=pruPrimaryIdentity;
	    		
	    }
	    
	    public String getcoUserId ()
	    {
	        return coUserId;
	    }

	    public void setcoUserId (String coUserId)
	    {
	        this.coUserId = coUserId;
	    }
	    
	    public String getpruPrimaryIdentity ()
	    {
	        return pruPrimaryIdentity;
	    }

	    public void setpruPrimaryIdentity (String pruPrimaryIdentity)
	    {
	        this.pruPrimaryIdentity = pruPrimaryIdentity;
	    }
	    
	    
	    
	    public String getrole ()
	    {
	        return role;
	    }

	    public void setrole (String role)
	    {
	        this.role = role;
	    }

	    public String gettransactionRequestId ()
	    {
	        return transactionRequestId;
	    }

	    public void settransactionRequestId (String transactionRequestId)
	    {
	        this.transactionRequestId = transactionRequestId;
	    }

	    public String getlinkedcontextcode ()
	    {
	        return linkedcontextcode;
	    }

	    public void setlinkedcontextcode (String linkedcontextcode)
	    {
	        this.linkedcontextcode = linkedcontextcode;
	    }

	    public String getsourceIPAddress ()
	    {
	        return sourceIPAddress;
	    }

	    public void setsourceIPAddress (String sourceIPAddress)
	    {
	        this.sourceIPAddress = sourceIPAddress;
	    }

	    public String getlinkedcontextrefid ()
	    {
	        return linkedcontextrefid;
	    }

	    public void setlinkedcontextrefid (String linkedcontextrefid)
	    {
	        this.linkedcontextrefid = linkedcontextrefid;
	    }

	    public String getpartyId ()
	    {
	        return partyId;
	    }

	    public void setpartyId (String partyId)
	    {
	        this.partyId = partyId;
	    }

	    public String getpartyType ()
	    {
	        return partyType;
	    }

	    public void setpartyType (String partyType)
	    {
	        this.partyType = partyType;
	    }

	    public String gettransactionTypeCode ()
	    {
	        return transactionTypeCode;
	    }
	    public void settransactionTypeCode (String transactionTypeCode)
	    {
	        this.transactionTypeCode = transactionTypeCode;
	    }	    

	    public String getsourceApplication ()
	    {
	        return sourceApplication;
	    }
	    public void setsourceApplication (String sourceApplication)
	    {
	        this.sourceApplication = sourceApplication;
	    }

	    public String gettransactioncategorycode ()
	    {
	        return transactioncategorycode;
	    }

	    public void settransactioncategorycode (String transactioncategorycode)
	    {
	        this.transactioncategorycode = transactioncategorycode;
	    }

	    public String gettransactionMsg ()
	    {
	        return transactionMsg;
	    }

	    public void settransactionMsg (String transactionMsg)
	    {
	        this.transactionMsg = transactionMsg;
	    }

	    public List<fields> getfields() {
			return fields;
		}
		public void setfields(List<fields> fields) {
			this.fields = fields;
		}

		}
		

