package com.Profile.RequestBodyPojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class riskScore {
	@JsonProperty("default")
	String rdefault;
    String y;
    String n;
    
    public riskScore(){}
    
    public riskScore(String rdefault, String y, String n){
    	this.rdefault = rdefault;
    	this.y = y;
    	this.n = n;
    }

	public String getRdefault() {
		return rdefault;
	}

	public void setRdefault(String rdefault) {
		this.rdefault = rdefault;
	}

	public String getY() {
		return y;
	}

	public void setY(String y) {
		this.y = y;
	}

	public String getN() {
		return n;
	}

	public void setN(String n) {
		this.n = n;
	}

}
