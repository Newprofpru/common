package com.Profile.RequestBodyPojo;

public class demography {
	
	riskScore beneOwnersNameAddress;
	riskScore beneOwnersPercent;
	typeCode typeCode;
	residentStatus residentStatus;
    
    public demography(){}
	
	public demography(riskScore beneOwnersNameAddress, riskScore beneOwnersPercent, typeCode typeCode, residentStatus residentStatus) {
		this.beneOwnersNameAddress = beneOwnersNameAddress;
		this.beneOwnersPercent = beneOwnersPercent;	
		this.typeCode = typeCode;
		this.residentStatus = residentStatus;
	}

	public riskScore getBeneOwnersNameAddress() {
		return beneOwnersNameAddress;
	}

	public void setBeneOwnersNameAddress(riskScore beneOwnersNameAddress) {
		this.beneOwnersNameAddress = beneOwnersNameAddress;
	}

	public riskScore getBeneOwnersPercent() {
		return beneOwnersPercent;
	}

	public void setBeneOwnersPercent(riskScore beneOwnersPercent) {
		this.beneOwnersPercent = beneOwnersPercent;
	}

	public typeCode getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(typeCode typeCode) {
		this.typeCode = typeCode;
	}	
	public residentStatus getResidentStatus() {
		return residentStatus;
	}

	public void setResidentStatus(residentStatus residentStatus) {
		this.residentStatus = residentStatus;
	}

}
