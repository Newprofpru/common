package com.Profile.RequestBodyPojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class typeCode {
	
	String opc;
    String dfi;
    @JsonProperty("ffi-o")
    String ffio;
    String ffi;
    String tppp;
    String pic;
    @JsonProperty("bs-corp")
    String bscorp;
    String sc;
    @JsonProperty("default")
    String tdefault;
    @JsonProperty("trust-f")
    String trustf;
    String ngo;
    @JsonProperty("trust-o")
    String trusto;
    String spv;
    @JsonProperty("emb/cons")
    String embcons;
    
    public typeCode(){}
    
    public typeCode(String opc, String dfi, String ffio, String ffi, String tppp, String pic, String bscorp, String sc,
    		String tdefault, String trustf, String ngo, String trusto, String spv, String embcons){
    	this.opc = opc;
    	this.dfi = dfi;
    	this.ffio = ffio;
    	this.ffi = ffi;
    	this.tppp = tppp;
    	this.pic  = pic;
    	this.bscorp = bscorp;
    	this.sc = sc;
    	this.tdefault = tdefault;
    	this.trustf = trustf;
    	this.ngo = ngo;
    	this.trusto = trusto;
    	this.spv = spv;
    	this.embcons = embcons;
    }

	public String getOpc() {
		return opc;
	}
	public void setOpc(String opc) {
		this.opc = opc;
	}
	public String getDfi() {
		return dfi;
	}
	public void setDfi(String dfi) {
		this.dfi = dfi;
	}
	public String getFfio() {
		return ffio;
	}
	public void setFfio(String ffio) {
		this.ffio = ffio;
	}
	public String getFfi() {
		return ffi;
	}
	public void setFfi(String ffi) {
		this.ffi = ffi;
	}
	public String getTppp() {
		return tppp;
	}
	public void setTppp(String tppp) {
		this.tppp = tppp;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getBscorp() {
		return bscorp;
	}
	public void setBscorp(String bscorp) {
		this.bscorp = bscorp;
	}
	public String getSc() {
		return sc;
	}
	public void setSc(String sc) {
		this.sc = sc;
	}
	public String getTdefault() {
		return tdefault;
	}
	public void setTdefault(String tdefault) {
		this.tdefault = tdefault;
	}
	public String getTrustf() {
		return trustf;
	}
	public void setTrustf(String trustf) {
		this.trustf = trustf;
	}
	public String getNgo() {
		return ngo;
	}
	public void setNgo(String ngo) {
		this.ngo = ngo;
	}
	public String getTrusto() {
		return trusto;
	}
	public void setTrusto(String trusto) {
		this.trusto = trusto;
	}
	public String getSpv() {
		return spv;
	}
	public void setSpv(String spv) {
		this.spv = spv;
	}
	public String getEmbcons() {
		return embcons;
	}
	public void setEmbcons(String embcons) {
		this.embcons = embcons;
	}

	

}
