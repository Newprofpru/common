package com.Profile.RequestBodyPojo;

public class sourceOfFunds {
	
	paymentMethod paymentMethod;
    public sourceOfFunds(){}
	
	public sourceOfFunds(paymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public paymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(paymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	

}
