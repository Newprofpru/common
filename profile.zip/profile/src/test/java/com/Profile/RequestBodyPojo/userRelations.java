package com.Profile.RequestBodyPojo;

public class userRelations {
	String relationId;
	String relationshipType;
	String relatedSSOId;
	String deleted;
	
	public userRelations(){}

	public userRelations(String relationId, String relationshipType, String relatedSSOId, String deleted) {
		
		this.relationId = relationId;
		this.relationshipType = relationshipType;
		this.relatedSSOId = relatedSSOId;
		this.deleted = deleted;
	}

	public String getRelationId() {
		return relationId;
	}

	public void setrelationId(String relationId) {
		this.relationId = relationId;
	}

	public String getRelationshipType() {
		return relationshipType;
	}

	public void setrelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public String getRelatedSSOId() {
		return relatedSSOId;
	}

	public void setrelatedSSOId(String relatedSSOId) {
		this.relatedSSOId = relatedSSOId;
	}

	public String getDeleted() {
		return deleted;
	}

	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	
	
	

}
