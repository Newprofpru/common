package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.Profile.RequestBodyPojo.*;

public class profile {
	personalInfo personalInfo;
	disclosures disclosures;
	suitability suitability;
	investmentInfo investmentInfo;
	trustedContactPerson trustedContactPerson;
	List<contactChannels> contactChannels;
	List<contactAddresses> contactAddresses;
	List<userRelations> userRelations;
	List<employers> employers;
	String ssoId;
	String coUserId;
	String contractId;
	String relationshipToAccount;
	String minorCoUserId;
	String businessUnit;
	String benefitClaimId;
	String deleted;
	public profile(){}
	public profile(personalInfo personalInfo,
			disclosures disclosures, suitability suitability,
			investmentInfo investmentInfo,
			trustedContactPerson trustedContactPerson,
			List<contactChannels> contactChannels,
			List<contactAddresses> contactAddresses,List<userRelations> userRelations,List<employers> employers, String ssoId,
			String coUserId, String contractId, String relationshipToAccount, String minorCoUserId, String businessUnit, String benefitClaimId, String deleted) {
		this.personalInfo = personalInfo;
		this.disclosures = disclosures;
		this.suitability = suitability;
		this.investmentInfo = investmentInfo;
		this.trustedContactPerson = trustedContactPerson;
		this.contactChannels = contactChannels;
		this.contactAddresses = contactAddresses;
		this.userRelations = userRelations;
		this.employers = employers;
		this.ssoId = ssoId;
		this.coUserId = coUserId;
		this.contractId = contractId;
		this.relationshipToAccount = relationshipToAccount;
		this.minorCoUserId = minorCoUserId;
		this.businessUnit = businessUnit;
		this.benefitClaimId = benefitClaimId;
		this.deleted = deleted;
	}
	
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	public personalInfo getPersonalInfo() {
		return personalInfo;
	}
	public void setpersonalInfo(personalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}
	public disclosures getDisclosures() {
		return disclosures;
	}
	public void setdisclosures(disclosures disclosures) {
		this.disclosures = disclosures;
	}
	public suitability getSuitability() {
		return suitability;
	}
	public void setsuitability(suitability suitability) {
		this.suitability = suitability;
	}
	public investmentInfo getInvestmentInfo() {
		return investmentInfo;
	}
	public void setinvestmentInfo(investmentInfo investmentInfo) {
		this.investmentInfo = investmentInfo;
	}
	public trustedContactPerson getTrustedContactPerson() {
		return trustedContactPerson;
	}
	public void settrustedContactPerson(trustedContactPerson trustedContactPerson) {
		this.trustedContactPerson = trustedContactPerson;
	}
	public List<contactChannels> getContactChannels() {
		return contactChannels;
	}
	public void setcontactChannels(List<contactChannels> contactChannels) {
		this.contactChannels = contactChannels;
	}
	public List<contactAddresses> getContactAddresses() {
		return contactAddresses;
	}
	public void setcontactAddresses(List<contactAddresses> contactAddresses) {
		this.contactAddresses = contactAddresses;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setssoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getCoUserId() {
		return coUserId;
	}
	public void setcoUserId(String coUserId) {
		this.coUserId = coUserId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setcontractId(String contractId) {
		this.contractId = contractId;
	}
	public String getRelationshipToAccount() {
		return relationshipToAccount;
	}
	public void setrelationshipToAccount(String relationshipToAccount) {
		this.relationshipToAccount = relationshipToAccount;
	}
	public String getminorCoUserId() {
		return minorCoUserId;
	}
	public void setminorCoUserId(String minorCoUserId) {
		this.minorCoUserId = minorCoUserId;
	}
	
	public String getbusinessUnit() {
		return businessUnit;
	}
	public void setbusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getBenefitClaimId() {
		return benefitClaimId;
	}
	public void setbenefitClaimId(String benefitClaimId) {
		this.benefitClaimId = benefitClaimId;
	}
	public List<userRelations> getUserRelations() {
		return userRelations;
	}
	public void setuserRelations(List<userRelations> userRelations) {
		this.userRelations = userRelations;
	}
	public List<employers> getEmployers() {
		return employers;
	}
	public void setemployers(List<employers> employers) {
		this.employers = employers;
	}
	
	
}
