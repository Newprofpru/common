package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class suitability {
	String timeHorizon;
	String liquidityNeeds;
	String investmentObjective;
	String riskTolerance;
	
	public suitability(){}
	public suitability(String timeHorizon, String liquidityNeeds, String investmentObjective, String riskTolerance) {
		this.timeHorizon = timeHorizon;
		this.liquidityNeeds = liquidityNeeds;
		this.investmentObjective = investmentObjective;
		this.riskTolerance = riskTolerance;
	}
	
	
	public String getTimeHorizon() {
		return timeHorizon;
	}
	public void settimeHorizon(String timeHorizon) {
		this.timeHorizon = timeHorizon;
	}
	public String getLiquidityNeeds() {
		return liquidityNeeds;
	}
	public void setliquidityNeeds(String liquidityNeeds) {
		this.liquidityNeeds = liquidityNeeds;
	}
	public String getInvestmentObjective() {
		return investmentObjective;
	}
	public void setinvestmentObjective(String investmentObjective) {
		this.investmentObjective = investmentObjective;
	}
	public String getRiskTolerance() {
		return riskTolerance;
	}
	public void setriskTolerance(String riskTolerance) {
		this.riskTolerance = riskTolerance;
	}
	
	

}
