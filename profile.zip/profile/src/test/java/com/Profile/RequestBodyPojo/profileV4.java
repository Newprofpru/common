package com.Profile.RequestBodyPojo;

import java.util.List;

public class profileV4 {
	
	personalInfo personalInfo;
    disclosures disclosures;
	suitability suitability;
	investmentInfo investmentInfo;
	trustedContactPerson trustedContactPerson;
    String bURelationShip;
    String userSourceCode;
    String ssoId;
    String sourceId;
    String coUserId;
    String openBlock;
    String relationshipToAccount;
    String minorCoUserId;
    String contractId;
    String benefitClaimId;
    String lineOfBusinessCode;
    String deleted;
    String productName;
    List<contactChannelsV4> contactChannels;
    List<contactAddressesV4> contactAddresses;
    List<userRelations> userRelations;
	List<employers> employers;
    String productGroup;
    String eventStatus;    
    String userType;
    String sourceApplication;   
	
	public profileV4(){}
	public profileV4(personalInfo personalInfo,
			disclosures disclosures, suitability suitability,
			investmentInfo investmentInfo,
			trustedContactPerson trustedContactPerson, String bURelationShip, String userSourceCode, String ssoId, String sourceId,
			String coUserId, String openBlock, String relationshipToAccount, String minorCoUserId, String productName,
			List<contactChannelsV4> contactChannels,
			List<contactAddressesV4> contactAddresses, List<userRelations> userRelations,List<employers> employers, 
			String productGroup, String eventStatus, String contractId,
			String benefitClaimId, String userType, String sourceApplication, String lineOfBusinessCode, String deleted) {
		this.personalInfo = personalInfo;
		this.disclosures = disclosures;
		this.suitability = suitability;
		this.investmentInfo = investmentInfo;
		this.trustedContactPerson = trustedContactPerson;
		this.bURelationShip = bURelationShip;
		this.userSourceCode = userSourceCode;
		this.ssoId = ssoId;
		this.sourceId = sourceId;
		this.coUserId = coUserId;
		this.openBlock = openBlock;
		this.relationshipToAccount = relationshipToAccount;
		this.minorCoUserId = minorCoUserId;
		this.productName = productName;
		this.contactChannels = contactChannels;
		this.contactAddresses = contactAddresses;
		this.userRelations = userRelations;
		this.employers = employers;
		this.productGroup = productGroup;
		this.eventStatus = eventStatus;
		this.contractId = contractId;		
		this.benefitClaimId = benefitClaimId;
		this.userType = userType;
		this.sourceApplication = sourceApplication;
		this.lineOfBusinessCode = lineOfBusinessCode;	
		this.deleted = deleted;
	}
	
	public personalInfo getPersonalInfo() {
		return personalInfo;
	}
	public void setpersonalInfo(personalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}
	public disclosures getDisclosures() {
		return disclosures;
	}
	public void setdisclosures(disclosures disclosures) {
		this.disclosures = disclosures;
	}
	public suitability getSuitability() {
		return suitability;
	}
	public void setsuitability(suitability suitability) {
		this.suitability = suitability;
	}
	public investmentInfo getInvestmentInfo() {
		return investmentInfo;
	}
	public void setinvestmentInfo(investmentInfo investmentInfo) {
		this.investmentInfo = investmentInfo;
	}
	public trustedContactPerson getTrustedContactPerson() {
		return trustedContactPerson;
	}
	public void settrustedContactPerson(trustedContactPerson trustedContactPerson) {
		this.trustedContactPerson = trustedContactPerson;
	}
	public String getbURelationShip() {
		return bURelationShip;
	}
	public void setbURelationShip(String bURelationShip) {
		this.bURelationShip = bURelationShip;
	}
	public String getUserSourceCode() {
		return userSourceCode;
	}
	public void setuserSourceCode(String userSourceCode) {
		this.userSourceCode = userSourceCode;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setssoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setsourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getCoUserId() {
		return coUserId;
	}
	public void setcoUserId(String coUserId) {
		this.coUserId = coUserId;
	}
	public String getOpenBlock() {
		return openBlock;
	}
	public void setopenBlock(String openBlock) {
		this.openBlock = openBlock;
	}
	public String getRelationshipToAccount() {
		return relationshipToAccount;
	}
	public void setrelationshipToAccount(String relationshipToAccount) {
		this.relationshipToAccount = relationshipToAccount;
	}
	public String getMinorCoUserId() {
		return minorCoUserId;
	}
	public void setminorCoUserId(String minorCoUserId) {
		this.minorCoUserId = minorCoUserId;
	}	
	public String getProductName() {
		return productName;
	}
	public void setproductName(String productName) {
		this.productName = productName;
	}
	public List<contactChannelsV4> getContactChannels() {
		return contactChannels;
	}
	public void setcontactChannels(List<contactChannelsV4> contactChannels) {
		this.contactChannels = contactChannels;
	}
	public List<contactAddressesV4> getContactAddresses() {
		return contactAddresses;
	}
	public void setcontactAddresses(List<contactAddressesV4> contactAddresses) {
		this.contactAddresses = contactAddresses;
	}
	public List<userRelations> getUserRelations() {
		return userRelations;
	}
	public void setuserRelations(List<userRelations> userRelations) {
		this.userRelations = userRelations;
	}
	public List<employers> getEmployers() {
		return employers;
	}
	public void setemployers(List<employers> employers) {
		this.employers = employers;
	}
	public String getProductGroup() {
		return productGroup;
	}
	public void setproductGroup(String productGroup) {
		this.productGroup = productGroup;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void seteventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public String getContractId() {
		return contractId;
	}
	public void setcontractId(String contractId) {
		this.contractId = contractId;
	}
	public String getBenefitClaimId() {
		return benefitClaimId;
	}
	public void setbenefitClaimId(String benefitClaimId) {
		this.benefitClaimId = benefitClaimId;
	}
	public String getUserType() {
		return userType;
	}
	public void setuserType(String userType) {
		this.userType = userType;
	}
	public String getSourceApplication() {
		return sourceApplication;
	}
	public void setsourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}
	public String getlineOfBusinessCode() {
		return lineOfBusinessCode;
	}
	public void setlineOfBusinessCode(String lineOfBusinessCode) {
		this.lineOfBusinessCode = lineOfBusinessCode;
	}
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}	
	
}
