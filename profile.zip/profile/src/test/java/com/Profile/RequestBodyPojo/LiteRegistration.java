package com.Profile.RequestBodyPojo;

public class LiteRegistration {
    private RegistrationReq registrationReq;

    public RegistrationReq getRegistrationReq ()
    {
        return registrationReq;
    }

    public void setRegistrationReq (RegistrationReq registrationReq)
    {
        this.registrationReq = registrationReq;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [registrationReq = "+registrationReq+"]";
    }
}
