package com.Profile.RequestBodyPojo;

public class ProfileDetails
{
    private String firstName;

    private String lastName;

    private String password;

    private TermsAcceptance[] termsAcceptance;

    private String marketingInd;

    private String emailID;

    private String userType;

    private String userID;

    public String getFirstName ()
    {
        return firstName;
    }

    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName ()
    {
        return lastName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }

    public String getPassword ()
    {
        return password;
    }

    public void setPassword (String password)
    {
        this.password = password;
    }

    public TermsAcceptance[] getTermsAcceptance ()
    {
        return termsAcceptance;
    }

    public void setTermsAcceptance (TermsAcceptance[] termsAcceptance)
    {
        this.termsAcceptance = termsAcceptance;
    }

    public String getMarketingInd ()
    {
        return marketingInd;
    }

    public void setMarketingInd (String marketingInd)
    {
        this.marketingInd = marketingInd;
    }

    public String getEmailID ()
    {
        return emailID;
    }

    public void setEmailID (String emailID)
    {
        this.emailID = emailID;
    }

    public String getUserType ()
    {
        return userType;
    }

    public void setUserType (String userType)
    {
        this.userType = userType;
    }

    public String getUserID ()
    {
        return userID;
    }

    public void setUserID (String userID)
    {
        this.userID = userID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [firstName = "+firstName+", lastName = "+lastName+", password = "+password+", termsAcceptance = "+termsAcceptance+", marketingInd = "+marketingInd+", emailID = "+emailID+", userType = "+userType+", userID = "+userID+"]";
    }
}