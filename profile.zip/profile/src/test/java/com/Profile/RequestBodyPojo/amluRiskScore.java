package com.Profile.RequestBodyPojo;

public class amluRiskScore {
	
	riskScoreConfig riskScoreConfig;
    String type;
    public amluRiskScore(){}
	
	public amluRiskScore(riskScoreConfig riskScoreConfig, String type) {
		this.riskScoreConfig = riskScoreConfig;
		this.type = type;
	}
    
	public riskScoreConfig getRiskScoreConfig() {
		return riskScoreConfig;
	}

	public void setRiskScoreConfig(riskScoreConfig riskScoreConfig) {
		this.riskScoreConfig = riskScoreConfig;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


}
