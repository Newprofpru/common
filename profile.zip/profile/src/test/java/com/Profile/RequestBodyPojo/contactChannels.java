package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class contactChannels {
	String contactChannelId;
	String contactChannel;
	String contactChannelType;
	String contactChannelValue;
	String phoneExtension;
	String contactStatus;
	String deleted;
	
	public contactChannels(){}
	public contactChannels(String contactChannelId, String contactChannel, String contactChannelType,
			String contactChannelValue, String phoneExtension, String contactStatus,String deleted) {
		this.contactChannelId = contactChannelId;
		this.contactChannel = contactChannel;
		this.contactChannelType = contactChannelType;
		this.contactChannelValue = contactChannelValue;
		this.phoneExtension = phoneExtension;
		this.contactStatus = contactStatus;
		this.deleted = deleted;
	}
	
	
	public String getDeleted() {
		return deleted;
	}
	public void setdeleted(String deleted) {
		this.deleted = deleted;
	}
	public String getContactChannelId() {
		return contactChannelId;
	}
	public void setcontactChannelId(String contactChannelId) {
		this.contactChannelId = contactChannelId;
	}
	public String getContactChannel() {
		return contactChannel;
	}
	public void setcontactChannel(String contactChannel) {
		this.contactChannel = contactChannel;
	}
	public String getContactChannelType() {
		return contactChannelType;
	}
	public void setcontactChannelType(String contactChannelType) {
		this.contactChannelType = contactChannelType;
	}
	public String getContactChannelValue() {
		return contactChannelValue;
	}
	public void setcontactChannelValue(String contactChannelValue) {
		this.contactChannelValue = contactChannelValue;
	}
	public String getPhoneExtension() {
		return phoneExtension;
	}
	public void setphoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}
	public String getContactStatus() {
		return contactStatus;
	}
	public void setcontactStatus(String contactStatus) {
		this.contactStatus = contactStatus;
	}
	
	
}
