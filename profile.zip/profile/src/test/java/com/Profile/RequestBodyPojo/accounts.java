package com.Profile.RequestBodyPojo;

public class accounts {  

	String periodMode; //done
	String name; //done
    String policyNumber; //done
    String typeCode; //done
    String financialInstitutionID; // done
    String assetValue; // done
    String accountNumber; //done
    String policyStatus;  //done
    String statusMessage; //done
    String accountID; //done
    String deleted; //done
    String id; //done
    String providerAccountID; //done
    String productFullName; //done
    String sourceName; // done
    String category; //done
    String asOfDate; // done
    String financialInstitution;  // done
    String sourceTypeCode; //  done
    String lineOfBusinessCode;  // done
    String productType; // done
    String productSubtype; //done
    String statusCode; // done
    
    
    public accounts(){}
    
    public accounts(String periodMode,String name,String policyNumber,String typeCode,String financialInstitutionID,
    		String assetValue,
    		String accountNumber,String policyStatus,String statusMessage,String accountID,
    		String deleted,String id, String providerAccountID,String productFullName,String asOfDate,String financialInstitution,
    		String sourceTypeCode,String lineOfBusinessCode,String productType,String statusCode , String category , String sourceName) {
    	
    	this.periodMode=periodMode;
        this.name=name;
        this.policyNumber=policyNumber;
        this.typeCode=typeCode;
        this.financialInstitutionID=financialInstitutionID;
        this.assetValue=assetValue;
        this.accountNumber=accountNumber;
        this.policyStatus=policyStatus;
        this.statusMessage=statusMessage;
        this.accountID=accountID;
        this.deleted=deleted;
        this.id=id;
        this.providerAccountID=providerAccountID;
        this.productFullName=productFullName;
        this.sourceName=sourceName;
        this.category=category;
        this.asOfDate=asOfDate;
        this.financialInstitution=financialInstitution;
        this.sourceTypeCode=sourceTypeCode;
        this.lineOfBusinessCode=lineOfBusinessCode;
        this.productType=productType;
        this.productSubtype=productSubtype;
        this.statusCode=statusCode;
    	
    }
    
    
    
    public String getperiodMode ()
    {
        return periodMode;
    }

    public void setperiodMode (String periodMode)
    {
        this.periodMode = periodMode;
    }

 

    public String getname ()
    {
        return name;
    }

    public void setname (String tame)
    {
        this.name = name;
    }

    public String getpolicyNumber ()
    {
        return policyNumber;
    }

    public void setpolicyNumber (String policyNumber)
    {
        this.policyNumber = policyNumber;
    }

    public String gettypeCode ()
    {
        return typeCode;
    }

    public void settypeCode (String typeCode)
    {
        this.typeCode = typeCode;
    }

    public String getfinancialInstitutionID ()
    {
        return financialInstitutionID;
    }

    public void setfinancialInstitutionID (String financialInstitutionID)
    {
        this.financialInstitutionID = financialInstitutionID;
    }

    public String getassetValue ()
    {
        return assetValue;
    }

    public void setassetValue (String assetValue)
    {
        this.assetValue = assetValue;
    }

    public String getaccountNumber ()
    {
        return accountNumber;
    }

    public void setaccountNumber (String accountNumber)
    {
        this.accountNumber = accountNumber;
    }

    public String getpolicyStatus ()
    {
        return policyStatus;
    }

    public void setpolicyStatus (String policyStatus)
    {
        this.policyStatus = policyStatus;
    }

    public String getstatusMessage ()
    {
        return statusMessage;
    }

    public void setstatusMessage (String statusMessage)
    {
        this.statusMessage = statusMessage;
    }

    public String getaccountID ()
    {
        return accountID;
    }

    public void setaccountID (String accountID)
    {
        this.accountID = accountID;
    }

    public String getdeleted ()
    {
        return deleted;
    }

    public void setdeleted (String deleted)
    {
        this.deleted = deleted;
    }

    public String getid ()
    {
        return id;
    }

    public void setid (String id)
    {
        this.id = id;
    }

    public String getproviderAccountID ()
    {
        return providerAccountID;
    }

    public void setproviderAccountID (String providerAccountID)
    {
        this.providerAccountID = providerAccountID;
    }

    public String getproductFullName ()
    {
        return productFullName;
    }

    public void setproductFullName (String productFullName)
    {
        this.productFullName = productFullName;
    }

    public String getsourceName ()
    {
        return sourceName;
    }

    public void setsourceName (String sourceName)
    {
        this.sourceName = sourceName;
    }

    public String getcategory ()
    {
        return category;
    }

    public void setcategory (String category)
    {
        this.category = category;
    }

    public String getasOfDate ()
    {
        return asOfDate;
    }

    public void setasOfDate (String asOfDate)
    {
        this.asOfDate = asOfDate;
    }

    public String getfinancialInstitution ()
    {
        return financialInstitution;
    }

    public void setfinancialInstitution (String financialInstitution)
    {
        this.financialInstitution = financialInstitution;
    }

    public String getsourceTypeCode ()
    {
        return sourceTypeCode;
    }

    public void setsourceTypeCode (String sourceTypeCode)
    {
        this.sourceTypeCode = sourceTypeCode;
    }

    public String getlineOfBusinessCode ()
    {
        return lineOfBusinessCode;
    }

    public void setlineOfBusinessCode (String lineOfBusinessCode)
    {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }

    public String getproductType ()
    {
        return productType;
    }

    public void setproductType (String productType)
    {
        this.productType = productType;
    }

    public String getproductSubtype ()
    {
        return productSubtype;
    }

    public void setproductSubtype (String productSubtype)
    {
        this.productSubtype = productSubtype;
    }

    public String getstatusCode ()
    {
        return statusCode;
    }

    public void setstatusCode (String statusCode)
    {
        this.statusCode = statusCode;
    }

}
