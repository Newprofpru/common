package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.Profile.supportLibraries.Util;
import com.Profile.supportLibraries.getEnvInfo;

public class RequestBodyPojoCreater {
	static String path = System.getProperty("user.dir")+Util.getFileSeparator()+"src"+Util.getFileSeparator()+"test"+Util.getFileSeparator()+"java"+Util.getFileSeparator()+"com"+Util.getFileSeparator()+"Profile"+Util.getFileSeparator()+"RequestBodyPojo"+Util.getFileSeparator()+"TestData.xlsx";
	static String Service_Url = getEnvInfo.getSecureURL();
	public static String contact;
	public static String Email;
	public static profile getProfile(String profile_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		
		Method method;
		profile profile1 = new profile();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("profile");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("profile_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(profile_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("profile_id")&&!(cellValue2.isEmpty())){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("profile_id")){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
			if((cellValue1.equalsIgnoreCase("personalInfo"))&&!(cellValue2.isEmpty())){
				profile1.setpersonalInfo(getpersonalInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("disclosures"))&&!(cellValue2.isEmpty())){
				profile1.setdisclosures(getdisclosures(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("suitability"))&&!(cellValue2.isEmpty())){
				profile1.setsuitability(getsuitability(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("investmentInfo"))&&!(cellValue2.isEmpty())){
				profile1.setinvestmentInfo(getinvestmentInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("trustedContactPerson"))&&!(cellValue2.isEmpty())){
				profile1.settrustedContactPerson(gettrustedContactPerson(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("contactAddresses"))&&!(cellValue2.isEmpty())){
				String[] addrList = cellValue2.split(",");
				List<contactAddresses> temp = new ArrayList<>();
				for(String addr : addrList){
					temp.add(getcontactAddresses(addr,isNullNeeded));
				}
				profile1.setcontactAddresses(temp);
			}
			if((cellValue1.equalsIgnoreCase("contactChannels"))&&!(cellValue2.isEmpty())){
				String[] contList = cellValue2.split(",");
				List<contactChannels> temp = new ArrayList<>();
				for(String cont : contList){
					temp.add(getcontactChannels(cont,isNullNeeded));
				}
				profile1.setcontactChannels(temp);
			}
			if((cellValue1.equalsIgnoreCase("userRelations"))&&!(cellValue2.isEmpty())){
				String[] userRelList = cellValue2.split(",");
				List<userRelations> temp = new ArrayList<>();
				for(String userRel : userRelList){
					temp.add(getuserRelations(userRel,isNullNeeded));
				}
				profile1.setuserRelations(temp);
			}
			if((cellValue1.equalsIgnoreCase("employers"))&&!(cellValue2.isEmpty())){
				String[] empList = cellValue2.split(",");
				List<employers> temp = new ArrayList<>();
				for(String emp : empList){
					temp.add(getemployers(emp,isNullNeeded));
				}
				profile1.setemployers(temp);
			}
		}
		return profile1;
	}
	
public static profileV4 getProfileV4(String profile_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		profileV4 profile1 = new profileV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("profileV4");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("profile_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(profile_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("profile_id")&&!(cellValue2.isEmpty())){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("profile_id")){
					if(profile1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
						method = profile1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(profile1, cellValue2);
					}
				}
			}
			if((cellValue1.equalsIgnoreCase("personalInfo"))&&!(cellValue2.isEmpty())){
				profile1.setpersonalInfo(getpersonalInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("disclosures"))&&!(cellValue2.isEmpty())){
				profile1.setdisclosures(getdisclosures(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("suitability"))&&!(cellValue2.isEmpty())){
				profile1.setsuitability(getsuitability(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("investmentInfo"))&&!(cellValue2.isEmpty())){
				profile1.setinvestmentInfo(getinvestmentInfo(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("trustedContactPerson"))&&!(cellValue2.isEmpty())){
				profile1.settrustedContactPerson(gettrustedContactPerson(cellValue2,isNullNeeded));
			}
			if((cellValue1.equalsIgnoreCase("contactAddresses"))&&!(cellValue2.isEmpty())){
				String[] addrList = cellValue2.split(",");
				List<contactAddressesV4> temp = new ArrayList<>();
				for(String addr : addrList){
					temp.add(getContactAddressesV4(addr,isNullNeeded));
				}
				profile1.setcontactAddresses(temp);
			}
			if((cellValue1.equalsIgnoreCase("contactChannels"))&&!(cellValue2.isEmpty())){
				String[] contList = cellValue2.split(",");
				List<contactChannelsV4> temp = new ArrayList<>();
				for(String cont : contList){
					temp.add(getcontactChannelsV4(cont,isNullNeeded));
				}
				profile1.setcontactChannels(temp);
			}
			if((cellValue1.equalsIgnoreCase("userRelations"))&&!(cellValue2.isEmpty())){
				String[] userRelList = cellValue2.split(",");
				List<userRelations> temp = new ArrayList<>();
				for(String userRel : userRelList){
					temp.add(getuserRelations(userRel,isNullNeeded));
				}
				profile1.setuserRelations(temp);
			}
			if((cellValue1.equalsIgnoreCase("employers"))&&!(cellValue2.isEmpty())){
				String[] empList = cellValue2.split(",");
				List<employers> temp = new ArrayList<>();
				for(String emp : empList){
					temp.add(getemployers(emp,isNullNeeded));
				}
				profile1.setemployers(temp);
			}
		}
		return profile1;
	}
	
	public static personalInfo getpersonalInfo(String personalInfo_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		personalInfo personalInfo1 = new personalInfo();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("personalInfo");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("personalInfo_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(personalInfo_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("personalInfo_id")&&!(cellValue2.isEmpty())){
					method = personalInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(personalInfo1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("personalInfo_id")){
					method = personalInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(personalInfo1, cellValue2);
				}
			}
		}
		return personalInfo1;
	}
	
	public static suitability getsuitability(String suitability_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		suitability suitability1 = new suitability();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("suitability");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("suitability_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(suitability_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
					if(!cellValue1.equalsIgnoreCase("suitability_id")&&!(cellValue2.isEmpty())){
					method = suitability1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(suitability1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("suitability_id")){
				method = suitability1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
				method.invoke(suitability1, cellValue2);
			}
		}
		}
		return suitability1;
	}
	
	public static trustedContactPerson gettrustedContactPerson(String trustedContactPerson_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		trustedContactPerson trustedContactPerson1 = new trustedContactPerson();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("trustedContactPerson");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("trustedContactPerson_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(trustedContactPerson_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("trustedContactPerson_id")&&!(cellValue2.isEmpty())){
					method = trustedContactPerson1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(trustedContactPerson1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("trustedContactPerson_id")){
					method = trustedContactPerson1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(trustedContactPerson1, cellValue2);
				}
			}
		}
		return trustedContactPerson1;
	}
	
	public static disclosures getdisclosures(String disclosures_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		disclosures disclosures1 = new disclosures();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("disclosures");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("disclosures_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(disclosures_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("disclosures_id")&&!(cellValue2.isEmpty())){
					method = disclosures1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(disclosures1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("disclosures_id")){
					method = disclosures1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(disclosures1, cellValue2);
				}
			}
		}
		return disclosures1;
	}
	
	public static investmentInfo getinvestmentInfo(String investmentInfo_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		investmentInfo investmentInfo1 = new investmentInfo();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("investmentInfo");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("investmentInfo_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(investmentInfo_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("investmentInfo_id")&&!(cellValue2.isEmpty())){
					method = investmentInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(investmentInfo1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("investmentInfo_id")){
					method = investmentInfo1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(investmentInfo1, cellValue2);
				}
			}
		}
		return investmentInfo1;
	}
	
	public static contactAddresses getcontactAddresses(String contactAddresses_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
	
		
		Method method;
		contactAddresses contactAddresses1 = new contactAddresses();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactAddresses");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("contactAddresses_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(contactAddresses_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")&&!(cellValue2.isEmpty())){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomAddressLine")){
						cellValue2 = rand.ints(3,111111,999999).findFirst().getAsInt()+"Street";
					}
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomAddressLine")){
						cellValue2 = rand.ints(3,111111,999999).findFirst().getAsInt()+"Street";
					}
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
		}
		return contactAddresses1;
	}
		
	public static contactAddressesV4 getContactAddressesV4(String contactAddresses_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
	
		
		Method method;
		contactAddressesV4 contactAddresses1 = new contactAddressesV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactAddressesV4");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("contactAddresses_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(contactAddresses_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			/*List<String> boolean_fields = new ArrayList() {{
		        add("isUpdated");
		        add("isDeleted");
		        add("isEditable");
		    }};
		if(boolean_fields.contains(cellValue1)&&!(cellValue2.isEmpty())){
			
			method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, boolean.class);
			method.invoke(contactAddresses1, Boolean.parseBoolean(cellValue2));
		}
			if(isNullNeeded&&!boolean_fields.contains(cellValue1)){*/
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")&&!(cellValue2.isEmpty())){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomAddressLine")){
						cellValue2 = rand.ints(3,111111,999999).findFirst().getAsInt()+"Street";
					}
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("contactAddresses_id")){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomAddressLine")){
						cellValue2 = rand.ints(3,111111,999999).findFirst().getAsInt()+"Street";
					}
					
					method = contactAddresses1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactAddresses1, cellValue2);
				}
			}
		}
		return contactAddresses1;
	}
		
	
	public static contactChannels getcontactChannels(String contactChannels_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		contactChannels contactChannels1 = new contactChannels();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactChannels");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("contactChannels_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(contactChannels_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("contactChannels_id")&&!(cellValue2.isEmpty())){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomEmail")){
						cellValue2 = "testEmail"+rand.ints(10,111111,999999).findFirst().getAsInt()+"@test.com";
						Email=cellValue2;
					}
					else if(cellValue2.equalsIgnoreCase("RandomPhone")){
						cellValue2 = ""+rand.longs(10,1111111111L,9999999999L).findFirst().getAsLong();
						contact = cellValue2;
					}
					method = contactChannels1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactChannels1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("contactChannels_id")){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomEmail")){
						cellValue2 = "testEmail"+rand.ints(10,111111,999999).findFirst().getAsInt()+"@test.com";
					}
					else if(cellValue2.equalsIgnoreCase("RandomPhone")){
						cellValue2 = ""+rand.longs(10,1111111111L,9999999999L).findFirst().getAsLong();
					}
					method = contactChannels1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactChannels1, cellValue2);
				}
			}
		}
		return contactChannels1;
	}
	
	
public static contactChannelsV4 getcontactChannelsV4(String contactChannels_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		contactChannelsV4 contactChannels1 = new contactChannelsV4();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("contactChannelsV4");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("contactChannels_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(contactChannels_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
						 /*List<String> boolean_fields = new ArrayList() {{
			        add("isUpdated");
			        add("isDeleted");
			        add("isEditable");
			    }};
			   
			    if(!cellValue1.equalsIgnoreCase("contactChannelId"))
			    {
			    
			    	if(boolean_fields.contains(cellValue1)&&!(cellValue2.isEmpty())){
						
						method = contactChannels1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
						method.invoke(contactChannels1, Boolean.parseBoolean(cellValue2));
					}*/
			
			
//			if(isNullNeeded && !boolean_fields.contains(cellValue1)){
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("contactChannels_id")&&!(cellValue2.isEmpty())){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomEmail")){
						cellValue2 = "testEmail"+rand.ints(10,111111,999999).findFirst().getAsInt()+"@test.com";
					}
					else if(cellValue2.equalsIgnoreCase("RandomPhone")){
						cellValue2 = ""+rand.longs(10,1111111111L,9999999999L).findFirst().getAsLong();
					}
					method = contactChannels1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactChannels1,cellValue2 );
					/*String channelvalue=cellValue2;
					Cell newcell2=row2.getCell(k-1);
					
					String newcellValue2=dataFormatter.formatCellValue(newcell2);
					String channeltype=newcellValue2;
					
					Channel_Value.put(channeltype, channelvalue);*/
					
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("contactChannels_id")){
					Random rand = new Random(); 
					if(cellValue2.equalsIgnoreCase("RandomEmail")){
						cellValue2 = "testEmail"+rand.ints(10,111111,999999).findFirst().getAsInt()+"@test.com";
						
						
					}
					else if(cellValue2.equalsIgnoreCase("RandomPhone")){
						cellValue2 = ""+rand.longs(10,1111111111L,9999999999L).findFirst().getAsLong();
						
					}
					method = contactChannels1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(contactChannels1, cellValue2);
					
				}
			}
			     
			   
			    
		}
		return contactChannels1;
	}
	
	public static userRelations getuserRelations(String userRelations_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		userRelations userRelations1 = new userRelations();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("userRelations");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("userRelations_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(userRelations_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("userRelations_id")&&!(cellValue2.isEmpty())){
					method = userRelations1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(userRelations1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("userRelations_id")){
					method = userRelations1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(userRelations1, cellValue2);
				}
			}
		}
		return userRelations1;
	}
	
	public static employers getemployers(String employers_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Method method;
		employers employers1 = new employers();
		FileInputStream file = new FileInputStream(new File(path));
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheet("employers");
		int rownum=0,colnum=0,i=-1,j=-1;
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            i++;
            if(i==0){
            while (cellIterator.hasNext()) {
            	j++;
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                if(cellValue.equalsIgnoreCase("employers_id"))
                	colnum = j;
            	}
            }
            else{
            	Cell cell = row.getCell(colnum);
            	String temp = dataFormatter.formatCellValue(cell);
            	if(temp.equalsIgnoreCase(employers_id)) {
            		rownum = i;
            	}
            }
		}
		Row row1=sheet.getRow(0);
		Row row2=sheet.getRow(rownum);
		for(int k=1;k<row1.getLastCellNum();k++){
			Cell cell1=row1.getCell(k);
			Cell cell2=row2.getCell(k);
			String cellValue1=dataFormatter.formatCellValue(cell1);
			String cellValue2=dataFormatter.formatCellValue(cell2);
			if(isNullNeeded){
				if(!cellValue1.equalsIgnoreCase("employers_id")&&!(cellValue2.isEmpty())){
					method = employers1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(employers1, cellValue2);
				}
			}
			else{
				if(!cellValue1.equalsIgnoreCase("employers_id")){
					method = employers1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(employers1, cellValue2);
				}
			}
		}
		return employers1;
	}



public static accounts getAccounts(String accounts_Id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
	
	Method method;
	accounts accounts1 = new accounts();
	FileInputStream file = new FileInputStream(new File(path));
	Workbook wb = WorkbookFactory.create(file);
	Sheet sheet = wb.getSheet("accounts");
	int rownum=0,colnum=0,i=-1,j=-1;
	DataFormatter dataFormatter = new DataFormatter();
	Iterator<Row> rowIterator = sheet.rowIterator();
	while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        Iterator<Cell> cellIterator = row.cellIterator();
        i++;
        if(i==0){
        while (cellIterator.hasNext()) {
        	j++;
            Cell cell = cellIterator.next();
            String cellValue = dataFormatter.formatCellValue(cell);
            if(cellValue.equalsIgnoreCase("accounts_Id"))
            	colnum = j;
        	}
        }
        else{
        	Cell cell = row.getCell(colnum);
        	String temp = dataFormatter.formatCellValue(cell);
        	if(temp.equalsIgnoreCase(accounts_Id)) {
        		rownum = i;
        	}
        }
	}
	Row row1=sheet.getRow(0);
	Row row2=sheet.getRow(rownum);
	for(int k=1;k<row1.getLastCellNum();k++){
		Cell cell1=row1.getCell(k);
		Cell cell2=row2.getCell(k);
		String cellValue1=dataFormatter.formatCellValue(cell1);
		String cellValue2=dataFormatter.formatCellValue(cell2);
		if(isNullNeeded){
			if(!cellValue1.equalsIgnoreCase("accounts_Id")&&!(cellValue2.isEmpty())){
				if(accounts1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = accounts1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(accounts1, cellValue2);
				}
			}
		}
		else{
			if(!cellValue1.equalsIgnoreCase("accounts_Id")){
				if(accounts1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = accounts1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(accounts1, cellValue2);
				}
			}
		}
		
		}

	return accounts1;

}
public static accounts getAccountsCreate(String accounts_Id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
	
	Method method;
	accounts accounts1 = new accounts();
	FileInputStream file = new FileInputStream(new File(path));
	Workbook wb = WorkbookFactory.create(file);
	Sheet sheet = wb.getSheet("accountsCreate");
	int rownum=0,colnum=0,i=-1,j=-1;
	DataFormatter dataFormatter = new DataFormatter();
	Iterator<Row> rowIterator = sheet.rowIterator();
	while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        Iterator<Cell> cellIterator = row.cellIterator();
        i++;
        if(i==0){
        while (cellIterator.hasNext()) {
        	j++;
            Cell cell = cellIterator.next();
            String cellValue = dataFormatter.formatCellValue(cell);
            if(cellValue.equalsIgnoreCase("accounts_Id"))
            	colnum = j;
        	}
        }
        else{
        	Cell cell = row.getCell(colnum);
        	String temp = dataFormatter.formatCellValue(cell);
        	if(temp.equalsIgnoreCase(accounts_Id)) {
        		rownum = i;
        	}
        }
	}
	Row row1=sheet.getRow(0);
	Row row2=sheet.getRow(rownum);
	for(int k=1;k<row1.getLastCellNum();k++){
		Cell cell1=row1.getCell(k);
		Cell cell2=row2.getCell(k);
		String cellValue1=dataFormatter.formatCellValue(cell1);
		String cellValue2=dataFormatter.formatCellValue(cell2);
		if(isNullNeeded){
			if(!cellValue1.equalsIgnoreCase("accounts_Id")&&!(cellValue2.isEmpty())){
				if(accounts1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = accounts1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(accounts1, cellValue2);
				}
			}
		}
		else{
			if(!cellValue1.equalsIgnoreCase("accounts_Id")){
				if(accounts1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = accounts1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(accounts1, cellValue2);
				}
			}
		}
		
		}

	return accounts1;

}

public static auditTrailAmlu getAuditTrailAmlu(String auditTrailAmlu_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
	
	Method method;
	auditTrailAmlu auditTrailAmlu1 = new auditTrailAmlu();
	FileInputStream file = new FileInputStream(new File(path));
	Workbook wb = WorkbookFactory.create(file);
	Sheet sheet = wb.getSheet("auditTrailAmlu");
	int rownum=0,colnum=0,i=-1,j=-1;
	DataFormatter dataFormatter = new DataFormatter();
	Iterator<Row> rowIterator = sheet.rowIterator();
	while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        Iterator<Cell> cellIterator = row.cellIterator();
        i++;
        if(i==0){
        while (cellIterator.hasNext()) {
        	j++;
            Cell cell = cellIterator.next();
            String cellValue = dataFormatter.formatCellValue(cell);
            if(cellValue.equalsIgnoreCase("auditTrailAmlu_id"))
            	colnum = j;
        	}
        }
        else{
        	Cell cell = row.getCell(colnum);
        	String temp = dataFormatter.formatCellValue(cell);
        	if(temp.equalsIgnoreCase(auditTrailAmlu_id)) {
        		rownum = i;
        	}
        }
	}
	Row row1=sheet.getRow(0);
	Row row2=sheet.getRow(rownum);
	for(int k=1;k<row1.getLastCellNum();k++){
		Cell cell1=row1.getCell(k);
		Cell cell2=row2.getCell(k);
		String cellValue1=dataFormatter.formatCellValue(cell1);
		String cellValue2=dataFormatter.formatCellValue(cell2);
		if(isNullNeeded){
			if(!cellValue1.equalsIgnoreCase("auditTrailAmlu_id")&&!(cellValue2.isEmpty())){
				if(auditTrailAmlu1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = auditTrailAmlu1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(auditTrailAmlu1, cellValue2);
				}
			}
		}
		else{
			if(!cellValue1.equalsIgnoreCase("auditTrailAmlu_id")){
				if(auditTrailAmlu1.getClass().getDeclaredField(cellValue1).getType().equals(String.class)){
					method = auditTrailAmlu1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
					method.invoke(auditTrailAmlu1, cellValue2);
				}
			}
		}
		
		if((cellValue1.equalsIgnoreCase("fields"))&&!(cellValue2.isEmpty())){
			String[] fieldlist = cellValue2.split(",");
			List<fields> temp = new ArrayList<>();
			for(String field : fieldlist){
				temp.add(getfields(field,isNullNeeded));
			}
			auditTrailAmlu1.setfields(temp);
		
		}
	
	}
	return auditTrailAmlu1;
}
public static fields getfields(String fields_id,boolean isNullNeeded) throws EncryptedDocumentException, InvalidFormatException, IOException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
	
	Method method;
	fields fields1 = new fields();
	FileInputStream file = new FileInputStream(new File(path));
	Workbook wb = WorkbookFactory.create(file);
	Sheet sheet = wb.getSheet("fields");
	int rownum=0,colnum=0,i=-1,j=-1;
	DataFormatter dataFormatter = new DataFormatter();
	Iterator<Row> rowIterator = sheet.rowIterator();
	while (rowIterator.hasNext()) {
        Row row = rowIterator.next();
        Iterator<Cell> cellIterator = row.cellIterator();
        i++;
        if(i==0){
        while (cellIterator.hasNext()) {
        	j++;
            Cell cell = cellIterator.next();
            String cellValue = dataFormatter.formatCellValue(cell);
            if(cellValue.equalsIgnoreCase("fields_id"))
            	colnum = j;
        	}
        }
        else{
        	Cell cell = row.getCell(colnum);
        	String temp = dataFormatter.formatCellValue(cell);
        	if(temp.equalsIgnoreCase(fields_id)) {
        		rownum = i;
        	}
        }
	}
	Row row1=sheet.getRow(0);
	Row row2=sheet.getRow(rownum);
	for(int k=1;k<row1.getLastCellNum();k++){
		Cell cell1=row1.getCell(k);
		Cell cell2=row2.getCell(k);
		String cellValue1=dataFormatter.formatCellValue(cell1);
		String cellValue2=dataFormatter.formatCellValue(cell2);
		if(isNullNeeded){
			if(!cellValue1.equalsIgnoreCase("fields_id")&&!(cellValue2.isEmpty())){
				method = fields1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
				method.invoke(fields1, cellValue2);
			}
		}
		else{
			if(!cellValue1.equalsIgnoreCase("fields_id")){
				method = fields1.getClass().getDeclaredMethod("set"+cellValue1, String.class);
				method.invoke(fields1, cellValue2);
			}
		}
	}
	return fields1;
}
}

