package com.Profile.RequestBodyPojo;

public class riskreputation {
	riskScore beneMarijuana;
	riskScore beneOFAC;
	riskScore transactionMedia;
	riskScore adverseMedia;
	riskScore sar;
	riskScore beneAdverseMedia;
	riskScore marijuana;
	riskScore benePFC;
	riskScore localSanctions;
	riskScore pfc;
	riskScore ofac;
	riskScore pep;
    
	public riskreputation(){}

	public riskreputation(riskScore beneMarijuana, riskScore beneOFAC, riskScore transactionMedia, riskScore adverseMedia, riskScore sar,
			riskScore beneAdverseMedia, riskScore marijuana, riskScore benePFC, riskScore localSanctions, riskScore pfc, riskScore ofac, riskScore pep) {
		this.beneMarijuana = beneMarijuana;
		this.beneOFAC = beneOFAC;
		this.transactionMedia = transactionMedia;
		this.adverseMedia = adverseMedia;
		this.sar = sar;
		this.beneAdverseMedia = beneAdverseMedia;
		this.marijuana = marijuana;
		this.localSanctions = localSanctions;
		this.pfc = pfc;
		this.ofac = ofac;
		this.pep =pep;
	}

	public riskScore getBeneMarijuana() {
		return beneMarijuana;
	}
	public void setBeneMarijuana(riskScore beneMarijuana) {
		this.beneMarijuana = beneMarijuana;
	}
	public riskScore getBeneOFAC() {
		return beneOFAC;
	}
	public void setBeneOFAC(riskScore beneOFAC) {
		this.beneOFAC = beneOFAC;
	}
	public riskScore getTransactionMedia() {
		return transactionMedia;
	}
	public void setTransactionMedia(riskScore transactionMedia) {
		this.transactionMedia = transactionMedia;
	}
	public riskScore getAdverseMedia() {
		return adverseMedia;
	}
	public void setAdverseMedia(riskScore adverseMedia) {
		this.adverseMedia = adverseMedia;
	}
	public riskScore getSar() {
		return sar;
	}
	public void setSar(riskScore sar) {
		this.sar = sar;
	}
	public riskScore getBeneAdverseMedia() {
		return beneAdverseMedia;
	}
	public void setBeneAdverseMedia(riskScore beneAdverseMedia) {
		this.beneAdverseMedia = beneAdverseMedia;
	}
	public riskScore getMarijuana() {
		return marijuana;
	}
	public void setMarijuana(riskScore marijuana) {
		this.marijuana = marijuana;
	}
	public riskScore getBenePFC() {
		return benePFC;
	}
	public void setBenePFC(riskScore benePFC) {
		this.benePFC = benePFC;
	}
	public riskScore getLocalSanctions() {
		return localSanctions;
	}
	public void setLocalSanctions(riskScore localSanctions) {
		this.localSanctions = localSanctions;
	}
	public riskScore getPfc() {
		return pfc;
	}
	public void setPfc(riskScore pfc) {
		this.pfc = pfc;
	}
	public riskScore getOfac() {
		return ofac;
	}
	public void setOfac(riskScore ofac) {
		this.ofac = ofac;
	}
	public riskScore getPep() {
		return pep;
	}
	public void setPep(riskScore pep) {
		this.pep = pep;
	}

	
}
