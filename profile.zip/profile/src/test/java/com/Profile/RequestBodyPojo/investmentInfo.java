package com.Profile.RequestBodyPojo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class investmentInfo {
	String investmentExperience;
	String taxBracket;
	String annualIncome;
	String liquidNetWorth;
	String totalNetWorth;
	public investmentInfo(){}
	public investmentInfo(String investmentExperience, String taxBracket, String annualIncome, String liquidNetWorth,
			String totalNetWorth) {
		this.investmentExperience = investmentExperience;
		this.taxBracket = taxBracket;
		this.annualIncome = annualIncome;
		this.liquidNetWorth = liquidNetWorth;
		this.totalNetWorth = totalNetWorth;
	}
	
	public String getInvestmentExperience() {
		return investmentExperience;
	}
	public void setinvestmentExperience(String investmentExperience) {
		this.investmentExperience = investmentExperience;
	}
	public String getTaxBracket() {
		return taxBracket;
	}
	public void settaxBracket(String taxBracket) {
		this.taxBracket = taxBracket;
	}
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setannualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public String getLiquidNetWorth() {
		return liquidNetWorth;
	}
	public void setliquidNetWorth(String liquidNetWorth) {
		this.liquidNetWorth = liquidNetWorth;
	}
	public String getTotalNetWorth() {
		return totalNetWorth;
	}
	public void settotalNetWorth(String totalNetWorth) {
		this.totalNetWorth = totalNetWorth;
	}
	
	
}
