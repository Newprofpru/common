package com.Profile.TestNGrunners;

public @interface CucumberOptions {

}
