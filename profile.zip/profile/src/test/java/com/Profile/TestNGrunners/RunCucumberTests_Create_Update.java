package com.Profile.TestNGrunners;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.Profile.supportLibraries.getEnvInfo;
import com.Profile.supportLibraries.TimeStamp;
import com.Profile.supportLibraries.Util;


import com.github.mkolisnyk.cucumber.reporting.CucumberDetailedResults;
import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import io.restassured.specification.RequestSpecification;
import cucumber.api.junit.Cucumber;

//@RunWith(Cucumber.class)
@ExtendedCucumberOptions(jsonReport = "target/cucumber-report/Regresssion/cucumber.json", 
	jsonUsageReport = "target/cucumber-report/Regresssion/cucumber-usage.json", 
	outputFolder = "target/cucumber-report/Regresssion", 
	detailedReport = true, 
	detailedAggregatedReport = true, 
	overviewReport = true, 
	usageReport = true)

/**
 * Please notice that com.CucumberCraft.stepDefinations.CukeHooks class
 * is in the same package as the steps definitions.
 * It has two methods that are executed before or after scenario.
 * I'm using to take a screenshot if scenario fails.
 */
@CucumberOptions(features = "src/test/resources/features", 
	glue = { "com.Profile.stepDefinitions" }, 
	tags = { "@jointAccountsCreate,@jointAccountsUpdate,@profileCreate,@profileUpdate" }, 
			//tags = { "@profileUpdate" }, 
	monochrome = true,
	plugin = { 
		"pretty", 
		"pretty:target/cucumber-report/Regresssion/pretty.txt",
		"html:target/cucumber-report/Regresssion",
		"json:target/cucumber-report/Regresssion/cucumber.json",
		"junit:target/cucumber-report/Regresssion/cucumber-junitreport.xml",
		"ru.yandex.qatools.allure.cucumberjvm.AllureReporter" })



public class RunCucumberTests_Create_Update extends AbstractTestNGCucumberTests {

	
	
	@BeforeSuite()
	void getEnv() {
		//getEnvInfo();
	}

	@AfterTest
	private void test() throws IOException, InterruptedException {
		generateCustomReports();
		Thread.sleep(1000);
		copyReportsFolder();
		Thread.sleep(1000);
		copyStoredReports();
	}
      
   
	
	

	private void generateCustomReports() {

		CucumberResultsOverview results1 = new CucumberResultsOverview();
		results1.setOutputDirectory("target");
		results1.setOutputName("cucumber-results");
		results1.setSourceFile("target/cucumber-report/Regresssion/cucumber.json");
		try {
			results1.executeFeaturesOverviewReport();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		CucumberDetailedResults detailedResults = new CucumberDetailedResults();
        detailedResults.setOutputDirectory("target");
        detailedResults.setOutputName("cucumber-results");
        detailedResults
                     .setSourceFile("target/cucumber-report/Regresssion/cucumber.json");
        detailedResults.setScreenShotLocation("./screenshot");
        try {
               detailedResults.executeDetailedResultsReport(false, true);
        } catch (Exception e) {

               e.printStackTrace();
        }
		
	}

	private void copyReportsFolder() {

		Date today = new Date();
		  SimpleDateFormat output4= new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
		  String  formattedTime4= output4.format(today);
			String timeStampResultPath = "Run_"+formattedTime4.toString().replaceAll(":", "-");;
			//System.out.println(timeStampResultPath);

		File sourceCucumber = new File(Util.getTargetPath());

		File destCucumber = new File(timeStampResultPath);

		try {
			FileUtils.copyDirectory(sourceCucumber, destCucumber);
			try {
				FileUtils.cleanDirectory(sourceCucumber);
			} catch (Exception e) {

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}


	
	private void copyStoredReports() throws IOException, InterruptedException {
		   
		   // Any customizations after execution can be added here
		   Document doc = Jsoup.parse(new File("target/cucumber-results-agg-test-results.html"),"utf-8");   
		   System.out.println("In Percentage Report Folder");
		   String title = doc.title(); 
		   String FeaturesPercentage = doc.select("body > table:nth-child(4) > tbody > tr:nth-child(2) > td:nth-child(5)").text();
		   String ScenariosPercentage = doc.select("body > table:nth-child(4) > tbody > tr:nth-child(3) > td:nth-child(5)").text();
		   // This will output the full path where the file will be written to...

		  
		   System.out.println("scenariopercentage is:"+ScenariosPercentage);
		   Thread.sleep(10000);
		   String FILENAME= "results.properties";

		   BufferedWriter bw = null;
		   FileWriter fw = null;

		   SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy HH-mm-ss");
		   Date date = new Date();

		   String content = FeaturesPercentage;
		   String Scenarios = ScenariosPercentage;

		   float num= Float.parseFloat(Scenarios);

		   bw = new BufferedWriter(new FileWriter( FILENAME));
		   
		   try {
		      if(num>=90)
		      {
		         
		         //bw.write("Result output of QA regression is PASS where passing percent of scenarios is: : "+Scenarios+"%");
		    	  bw.write("Result=PASS "+"\n"+"PERCENTAGE="+Scenarios+"%");
		      
		      }
		      else {
		         
		    	  bw.write("Result=FAIL "+"\n"+"PERCENTAGE="+Scenarios+"%");
		         //bw.write("Result output of QA regression is FAIL where passing percent of scenarios is: "+Scenarios+"% Please check the test scripts");
		      }


		   } catch (IOException e) {

		      e.printStackTrace();

		   } finally {

		      try {

		         if (bw != null)
		            bw.close();

		         if (fw != null)
		            fw.close();

		      } catch (IOException ex) {

		         ex.printStackTrace();

		      

		      }
		   }

	}
	@AfterSuite
	private void copyStored1Reports() {
		// Any customizations after execution can be added here
	}

}