package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.Profile.RequestBodyPojo.*;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class auditTrailNew {
	
	private static Logger logger = LogManager.getLogger();
	 static Properties properties = getEnvInfo.getInstance();
	static RequestSpecification request;
	static Response Res1;
	String Service_Url = getEnvInfo.getSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	ResultSet rs,rs1,rs2,rs3;
	static Map<String, String> data;
	static String transactionRequestId = null;
	auditTrailAmlu auditTrailAmlu = new auditTrailAmlu();
	JsonObject responseObject = new JsonObject();
	JsonArray eventsArray = new JsonArray();
	static Set<String> paramNames;
	String profileId = null;
	String requestID = null;
	profile profile = new profile();
	boolean isNullNeeded = false;
	static 	String date;
	static String Contact;
	
	static String Email;static String Addressline1;
	static String Addressline2;
	static String Addressline3;
	static String Addressline4;
	
	static String ConvertedDate;
	
	@Given("^the working endpoint exists for the \"([^\"]*)\" trailNew api$")
	public void valid_endpoint_for_auditTrailNEW_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	
	@When("^the PUT request is sent to profile API with below request body data to validate the Audittrail$")
	public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile_to_validate_the_audit_trail(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException, org.json.simple.parser.ParseException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		isNullNeeded = false;	
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		
		
		
		 
		 
		
		 List<contactChannels> obj ;
		
		 
		 obj =profile.getContactChannels();
		 
		 
		 String ContactChannel = obj.get(0).getContactChannel();
		 
		 if(ContactChannel.equalsIgnoreCase("Phone"))
		 {
		 
		   Contact = obj.get(0).getContactChannelValue();
		 }
		   
		 if(ContactChannel.equalsIgnoreCase("Email"))
		 {
		   Email = obj.get(0).getContactChannelValue();
		 }
		 
		 
		
		 
		 
		  System.out.println(Contact);
		  System.out.println(Contact);
		  System.out.println(Contact);
		  System.out.println(Contact);
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		
		
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm");
		
		
	
		 date = dateFormat.format(new Date());
		
		System.out.println(date);
		System.out.println(date);
		
		
		logger.info("Response----->:" + Res1.prettyPrint());
		
	}
	
	@When("^the PUT request is sent to profile API with below request body data to validate the Audittrail contactadresses$")
	public void a_PUT_request_is_sent_to_profile_API_with_below_request_body_details_of_Profile_to_validate_the_audit_trail_contact_addreses(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException, org.json.simple.parser.ParseException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		isNullNeeded = false;	
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		
		
		
		 
		 
		
		 
		 List<contactAddresses> obj1 ;
		 
		
		 obj1 = profile.getContactAddresses();
		 
		
		 
		 
		 Addressline1 = obj1.get(0).getAddressLine1();
		 Addressline2 = obj1.get(0).getAddressLine2();
		 Addressline3 = obj1.get(0).getAddressLine3();
		 Addressline4 = obj1.get(0).getAddressLine4();
		 
		 
		  System.out.println(Contact);
		  System.out.println(Contact);
		  System.out.println(Contact);
		  System.out.println(Contact);
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		
		
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm");
		
		
	
		 date = dateFormat.format(new Date());
		
		System.out.println(date);
		System.out.println(date);
		
		
		logger.info("Response----->:" + Res1.prettyPrint());
		
	}
	


	@When("^the user sends a GET request to AuditTrail API with below parameters of a prospect profile$")
	public void the_user_sends_a_GET_request_to_AudiTrail_API_with_below_parameters_of_a_prospect_profile() throws IllegalAccessException, InvocationTargetException, IOException, InterruptedException, org.json.simple.parser.ParseException{
		
		
		logger.info("In When");
		Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "profileGet" + n;
		RestAssured.baseURI = getEnvInfo.getAuditTrailGetRequestViewRecordsURL();
		
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
	 Authorization = "Basic cXR1WFZTSG84ZEcwYmJZbDFxMkFtcDlVb01FNURqTlk6M00xWVo5S2xBdkZLODdkNQ==";
		if(properties.getProperty("Environment").equalsIgnoreCase("stage"))
	 Authorization = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";
			
		request = given().log().all()
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
			
			
			request.param("activityType","Prospect");
			request.param("coUserId",profile.getCoUserId());
			request.param("offset","0");
			request.param("limit","100");
			
		Thread.sleep(2000);
		Res1 = request.when().get().andReturn();
		//logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
		
		
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		
		if(responseObject.has("response"))
		{
			JsonObject responseObject21 = responseObject.get("response").getAsJsonObject();
		JsonArray eventsListArray = responseObject21.get("eventsList").getAsJsonArray();
		String elm =null;
		String newValue=null;
		String updatedOn = null;
		
			elm = eventsListArray.get(0).getAsJsonObject().get("fieldName").getAsString();
			
			System.out.println("*************** 1 ***********************");
			newValue = eventsListArray.get(0).getAsJsonObject().get("newValue").getAsString();
			
			System.out.println("*************** 2 ***********************");
			updatedOn = eventsListArray.get(0).getAsJsonObject().get("updatedOn").getAsString();
			
			System.out.println("*************** 3 ***********************");
			
			System.out.println(updatedOn);
			
			System.out.println(date);
			
			System.out.println(newValue);
			System.out.println(Contact);


			String Date[] = date.split(" ");
			
			int size = Date.length;
			
			String DateSplit = Date[0];
			
			String DateSplitMonth[] = DateSplit.split("-");
			
			String MonthToUpper = DateSplitMonth[1].toUpperCase();
			
			String NewDate = DateSplitMonth[0]+"-"+MonthToUpper+"-"+DateSplitMonth[2];
			
			 ConvertedDate = NewDate+" "+Date[1];
			
			System.out.println(NewDate);
			System.out.println(ConvertedDate);
			
			System.out.println(size);
			
			
	
			if(newValue.equalsIgnoreCase(Contact)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Contact);
				
				System.out.println("*************** 4 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Email)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Email);
				
				System.out.println("*************** 5 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline1)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline1);
				
				System.out.println("*************** 6 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline2)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline2);
				
				System.out.println("*************** 7 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline3)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline3);
				
				System.out.println("*************** 8 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline4)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline4);
				
				System.out.println("*************** 9 ***********************");
				
				
			}
			
		
		}
	}
	
	
	@When("^the user sends a GET request to AuditTrail API with below parameters of a contract profile$")
	public void the_user_sends_a_GET_request_to_AudiTrail_API_with_below_parameters_of_a_contract_profile() throws IllegalAccessException, InvocationTargetException, IOException, InterruptedException, org.json.simple.parser.ParseException{
		
		
		logger.info("In When");
		Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "profileGet" + n;
		RestAssured.baseURI = getEnvInfo.getAuditTrailGetRequestViewRecordsURL();
			
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			 Authorization = "Basic cXR1WFZTSG84ZEcwYmJZbDFxMkFtcDlVb01FNURqTlk6M00xWVo5S2xBdkZLODdkNQ==";
				if(properties.getProperty("Environment").equalsIgnoreCase("stage"))
			 Authorization = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";
					
				request = given().log().all()
						.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
			
			
			request.param("activityType","Customer");
			request.param("coUserId",profile.getCoUserId());
			request.param("offset","0");
			request.param("limit","100");
			
		Thread.sleep(2000);
		Res1 = request.when().get().andReturn();
		//logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
		
		
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		
		if(responseObject.has("response"))
		{
			JsonObject responseObject21 = responseObject.get("response").getAsJsonObject();
		JsonArray eventsListArray = responseObject21.get("eventsList").getAsJsonArray();
		String elm =null;
		String newValue=null;
		String updatedOn = null;
		
			elm = eventsListArray.get(0).getAsJsonObject().get("fieldName").getAsString();
			
			System.out.println("*************** 1 ***********************");
			newValue = eventsListArray.get(0).getAsJsonObject().get("newValue").getAsString();
			
			System.out.println("*************** 2 ***********************");
			updatedOn = eventsListArray.get(0).getAsJsonObject().get("updatedOn").getAsString();
			
			System.out.println("*************** 3 ***********************");
			
			System.out.println(updatedOn);
			
			System.out.println(date);
			
			System.out.println(newValue);
			System.out.println(Contact);


			String Date[] = date.split(" ");
			
			int size = Date.length;
			
			String DateSplit = Date[0];
			
			String DateSplitMonth[] = DateSplit.split("-");
			
			String MonthToUpper = DateSplitMonth[1].toUpperCase();
			
			String NewDate = DateSplitMonth[0]+"-"+MonthToUpper+"-"+DateSplitMonth[2];
			
			 ConvertedDate = NewDate+" "+Date[1];
			
			System.out.println(NewDate);
			System.out.println(ConvertedDate);
			
			System.out.println(size);
			
			
	
			if(newValue.equalsIgnoreCase(Contact)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Contact);
				
				System.out.println("*************** 4 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Email)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Email);
				
				System.out.println("*************** 5 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline1)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline1);
				
				System.out.println("*************** 6 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline2)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline2);
				
				System.out.println("*************** 7 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline3)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline3);
				
				System.out.println("*************** 8 ***********************");
				
				
			}
			
			if(newValue.equalsIgnoreCase(Addressline4)  && updatedOn.contains(ConvertedDate) )
			{
				Assert.assertEquals(newValue, Addressline4);
				
				System.out.println("*************** 9 ***********************");
				
				
			}
			
		
		}
	}
	
	
	
	@Then("^the user recieves correct responsebody content AUditTrail$")
	public void user_recieves_correct_responsebody() throws SQLException, ParseException{
	
	
		Gson gson = new Gson();
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		
	
		}

}
	




		
	
	
	
		
		
		
				
		
		
	


