package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalInt;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.DB_Module;
import com.Profile.supportLibraries.GeneratePayloadRepInput;
import com.Profile.supportLibraries.GetSmsessionToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IndvRiskScoreUpdate {
	
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static RequestSpecification request1;
	static Response Res;
	static Response Res1;
	static String payload;
	static String payload2;
    String resultbody;
	static Map<String,String> cookie_Data = new HashMap<String,String>();
	static Map<String,String> Repu_Data = new HashMap<String,String>();
	Map<String, String> valueDiff = new HashMap<String,String>();
	static Map<String, String> OldValueMap = new HashMap<String,String>();
	static Map<String, String> OldValueMap1 = new HashMap<String,String>();
	static Map<String, String> OldValueMap2 = new HashMap<String,String>();
	static Map<String, String> OldValueMap3 = new HashMap<String,String>();
	static Map<String, String> OldValueMap4 = new HashMap<String,String>();
	static Map<String, String> OldValueMap5 = new HashMap<String,String>();
	static Map<String, String> OldValueMap6 = new HashMap<String,String>();
	static Map<String, String> OldValueMap7 = new HashMap<String,String>();
	static Map<String, String> NewValueMap = new HashMap<String,String>();
	static Map<String, String> NewValueMap1 = new HashMap<String,String>();
	static Map<String, String> NewValueMap2 = new HashMap<String,String>();
	static Map<String, String> NewValueMap3 = new HashMap<String,String>();
	static Map<String, String> NewValueMap4 = new HashMap<String,String>();
	static Map<String, String> NewValueMap5 = new HashMap<String,String>();
	static Map<String, String> NewValueMap6 = new HashMap<String,String>();
	static Map<String, String> NewValueMap7 = new HashMap<String,String>();
	ResultSet rs;
	String Authorization = getEnvInfo.getRepAuthorization();
	String Service_Url = getEnvInfo.getSecureUrlRiskScore();
	String ivUser = getEnvInfo.getIVuser();
	String requestID = null;
	String userTransactionlogID = null;	
	
	@Given("^working endpoint exists as \"([^\"]*)\" API$")
	public void valid_endpoint_for_accounts_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	@When("^valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate a smsession$")
	public void valid_user_to_generate_smsession(String username, String password, String buid) throws Throwable {		
		resultbody = GetSmsessionToken.generateSmsessionToken(username,password);
		logger.info("SMSession Cookie: " +resultbody);	    
	}

	@When("^request for indv sourceOfFunds is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_sourceOfFunds_is_submitted_with_(String eftcb, String eftsb, String dcccc, String dccctp, String cash, String check, String mo, String tc, String cbc, String fedwirec, String fedwiretp, String achus, String achint, String ddefault, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPaymentMethod'";
    	logger.info("Query: "+query); 
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);    	    	
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("EFTCB", eftcb+ m.getAsInt());
    	Repu_Data.put("EFTSB", eftsb+ m.getAsInt());
    	Repu_Data.put("DCCCC", dcccc+ m.getAsInt());
    	Repu_Data.put("DCCCTP", dccctp+ m.getAsInt());
    	Repu_Data.put("CASH", cash+ m.getAsInt());
    	Repu_Data.put("CHECK", check+ m.getAsInt());
    	Repu_Data.put("MO", mo+ m.getAsInt());
    	Repu_Data.put("TC", tc+ m.getAsInt());
    	Repu_Data.put("CBC", cbc+ m.getAsInt());
    	Repu_Data.put("FEDWIREC", fedwirec+ m.getAsInt());
    	Repu_Data.put("FEDWIRETP", fedwiretp+ m.getAsInt());
    	Repu_Data.put("ACHUS", achus+ m.getAsInt());
    	Repu_Data.put("ACHINT", achint+ m.getAsInt());
    	Repu_Data.put("DDEFAULT", ddefault+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.src_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for indv product is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_product_is_submitted_with_(String prody, String prodn, String pdefault, String multprody, String multprodn, String mdefault, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvProductCashvalue'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvMultipleProductCashvalue'";
    	logger.info("Query: "+query);
    	logger.info("Query: "+query1);
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("PRODY", prody+ m.getAsInt());
    	Repu_Data.put("PRODN", prodn+ m.getAsInt());
    	Repu_Data.put("PDEFAULT", pdefault+ m.getAsInt());
    	Repu_Data.put("MULTPRODY", multprody+ m.getAsInt());
    	Repu_Data.put("MULTPRODN", multprodn+ m.getAsInt());
    	Repu_Data.put("MDEFAULT", mdefault+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.prod_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for indv highRiskThreshold is submitted with (.*),(.*),(.*),(.*)$")
	public void request_for_highRiskThreshold_is_submitted_with_(String finalHigh, String IndvHigh, String operator, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvFinalSummation'";
		logger.info("Query: "+query);
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("finalhighriskthreshold", finalHigh+ m.getAsInt());
    	Repu_Data.put("individualhighriskthreshold", IndvHigh+ m.getAsInt());
    	Repu_Data.put("operator", operator);
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.finalSum_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for indv resStatus is submitted with (.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_indv_resStatus_is_submitted_with_(String prc, String pra, String tra, String nra, String rdefault, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='ResidentStatus'";
		logger.info("Query: "+query); 
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);    
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("prc", prc+ m.getAsInt());
    	Repu_Data.put("pra", pra+ m.getAsInt());
    	Repu_Data.put("tra", tra+ m.getAsInt());
    	Repu_Data.put("nra", nra+ m.getAsInt());
    	Repu_Data.put("rdefault", rdefault+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.resStatus_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for indv reputation is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_reputation_is_submitted_with_(String mariy, String marin, String mariDef, String pfcy, String pfcn, String pfcDef, String advmedy, String advmedn, String advmedDef, String transmedy, String transmedn, String transmedDef, String ofacy, String ofacn, String ofacDef, String locsany, String locsann, String locsanDef, String sary, String sarn, String sarDef, String pepy, String pepn, String pepDef, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvTransactionMedia'";
		OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvSAR'";
		OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPFC'";
		OldValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvOFAC'";
		OldValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);
		String query4 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvMarijuana'";
		OldValueMap4 = DB_Module.seperatevalueSinglecolumn(con, query4);
		String query5 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvLocalTrans'";
		OldValueMap5 = DB_Module.seperatevalueSinglecolumn(con, query5);
		String query6 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvAdverseMedia'";
		OldValueMap6 = DB_Module.seperatevalueSinglecolumn(con, query6);
		String query7 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPEP'";
		OldValueMap7 = DB_Module.seperatevalueSinglecolumn(con, query7);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("mariy", mariy+ m.getAsInt());
    	Repu_Data.put("marin", marin+ m.getAsInt());
    	Repu_Data.put("mariDef", mariDef+ m.getAsInt());
    	Repu_Data.put("pfcy", pfcy+ m.getAsInt());
    	Repu_Data.put("pfcn", pfcn+ m.getAsInt());
    	Repu_Data.put("pfcDef", pfcDef+ m.getAsInt());
    	Repu_Data.put("advmedy", advmedy+ m.getAsInt());
    	Repu_Data.put("advmedn", advmedn+ m.getAsInt());
    	Repu_Data.put("advmedDef", advmedDef+ m.getAsInt());
    	Repu_Data.put("transmedy", transmedy+ m.getAsInt());
    	Repu_Data.put("transmedn", transmedn+ m.getAsInt());
    	Repu_Data.put("transmedDef", transmedDef+ m.getAsInt());
    	Repu_Data.put("ofacy", ofacy+ m.getAsInt());
    	Repu_Data.put("ofacn", ofacn+ m.getAsInt());
    	Repu_Data.put("ofacDef", ofacDef+ m.getAsInt());
    	Repu_Data.put("locsany", locsany+ m.getAsInt());
    	Repu_Data.put("locsann", locsann+ m.getAsInt());
    	Repu_Data.put("locsanDef", locsanDef+ m.getAsInt());
    	Repu_Data.put("sary", sary+ m.getAsInt());
    	Repu_Data.put("sarn", sarn+ m.getAsInt());
    	Repu_Data.put("sarDef", sarDef+ m.getAsInt());
    	Repu_Data.put("pepy", pepy+ m.getAsInt());
    	Repu_Data.put("pepn", pepn+ m.getAsInt());
    	Repu_Data.put("pepDef", pepDef+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.indvrep_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	
	@Then("^success response is received from put api for indv$")
	public void success_response_is_received_from_the_api_for_indv() throws Throwable {
		try{
			logger.info("In Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}

	@Then("^response for indv sourceofFunds should match with values in DB$")
	public void response_for_sourceofFunds_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPaymentMethod'";
    	logger.info("Query: "+query);    	  
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Assert.assertEquals(Repu_Data.get("EFTCB"),NewValueMap.get("eft-cb") );
    	logger.info("EFTCB is equal, value is "+Repu_Data.get("EFTCB"));
    	Assert.assertEquals(Repu_Data.get("EFTSB"),NewValueMap.get("eft-sb") );  
    	logger.info("EFTSB is equal, value is "+Repu_Data.get("EFTSB"));
    	Assert.assertEquals(Repu_Data.get("DCCCC"),NewValueMap.get("dc/cc-c") ); 
    	logger.info("DCCCC is equal, value is "+Repu_Data.get("DCCCC"));
    	Assert.assertEquals(Repu_Data.get("DCCCTP"),NewValueMap.get("dc/cc-tp") );   
    	logger.info("DCCCTP is equal, value is "+Repu_Data.get("DCCCTP"));
    	Assert.assertEquals(Repu_Data.get("CASH"),NewValueMap.get("cash") ); 
    	logger.info("CASH is equal, value is "+Repu_Data.get("CASH"));
    	Assert.assertEquals(Repu_Data.get("CHECK"),NewValueMap.get("check") ); 
    	logger.info("CHECK is equal, value is "+Repu_Data.get("CHECK"));
    	Assert.assertEquals(Repu_Data.get("MO"),NewValueMap.get("mo") );
    	logger.info("MO is equal, value is "+Repu_Data.get("MO"));
    	Assert.assertEquals(Repu_Data.get("TC"),NewValueMap.get("tc") );
    	logger.info("TC is equal, value is "+Repu_Data.get("TC"));
    	Assert.assertEquals(Repu_Data.get("CBC"),NewValueMap.get("c/b-c") );
    	logger.info("CBC is equal, value is "+Repu_Data.get("CBC"));
    	Assert.assertEquals(Repu_Data.get("FEDWIREC"),NewValueMap.get("fedwire-c") );  
    	logger.info("FEDWIREC is equal, value is "+Repu_Data.get("FEDWIREC"));
    	Assert.assertEquals(Repu_Data.get("FEDWIRETP"),NewValueMap.get("fedwire-tp") ); 
    	logger.info("FEDWIRETP is equal, value is "+Repu_Data.get("FEDWIRETP"));
    	Assert.assertEquals(Repu_Data.get("ACHUS"),NewValueMap.get("ach-us") );   
    	logger.info("ACHUS is equal, value is "+Repu_Data.get("ACHUS"));
    	Assert.assertEquals(Repu_Data.get("ACHINT"),NewValueMap.get("ach-int") ); 
    	logger.info("ACHINT is equal, value is "+Repu_Data.get("ACHINT"));
	}
	
	@Then("^response for indv product should match with values in DB$")
	public void response_for_product_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvProductCashvalue'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvMultipleProductCashvalue'";
    	logger.info("Query: "+query);
    	logger.info("Query: "+query1);
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);  
    	Assert.assertEquals(Repu_Data.get("PRODY"),NewValueMap.get("y") );
    	logger.info("PRODY is equal, value is "+Repu_Data.get("PRODY"));
    	Assert.assertEquals(Repu_Data.get("PRODN"),NewValueMap.get("n") );  
    	logger.info("PRODN is equal, value is "+Repu_Data.get("PRODN"));
    	Assert.assertEquals(Repu_Data.get("MULTPRODY"),NewValueMap1.get("y") ); 
    	logger.info("MULTPRODY is equal, value is "+Repu_Data.get("MULTPRODY"));
    	Assert.assertEquals(Repu_Data.get("MULTPRODN"),NewValueMap1.get("n") );   
    	logger.info("MULTPRODN is equal, value is "+Repu_Data.get("MULTPRODN"));    	
	}
	
	@Then("^response for indv highRiskThreshold should match with values in DB$")
	public void response_for_highRiskThreshold_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvFinalSummation'";
		logger.info("Query: "+query);
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Assert.assertEquals(Repu_Data.get("finalhighriskthreshold"),NewValueMap.get("finalhighriskthreshold") );
    	logger.info("Finalhighriskthreshold is equal, value is "+Repu_Data.get("finalhighriskthreshold"));
    	Assert.assertEquals(Repu_Data.get("individualhighriskthreshold"),NewValueMap.get("individualhighriskthreshold") );  
    	logger.info("individualhighriskthreshold is equal, value is "+Repu_Data.get("individualhighriskthreshold"));
    	Assert.assertEquals(Repu_Data.get("operator"),NewValueMap.get("operator") ); 
    	logger.info("operator is equal, value is "+Repu_Data.get("operator"));    	    	
	}
	
	@Then("^response for indv resStatus should match with values in DB$")
	public void response_for_indv_resStatus_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='ResidentStatus'";
		NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Assert.assertEquals(Repu_Data.get("pra"),NewValueMap.get("pra") );
    	logger.info("PRA is equal, value is "+Repu_Data.get("pra"));
    	Assert.assertEquals(Repu_Data.get("prc"),NewValueMap.get("prc") );  
    	logger.info("PRC is equal, value is "+Repu_Data.get("prc"));
    	Assert.assertEquals(Repu_Data.get("tra"),NewValueMap.get("tra") ); 
    	logger.info("TRA is equal, value is "+Repu_Data.get("tra"));
    	Assert.assertEquals(Repu_Data.get("nra"),NewValueMap.get("nra") );   
    	logger.info("NRA is equal, value is "+Repu_Data.get("nra"));     	
	}

	@Then("^response for indv reputation should match with values in DB$")
	public void response_for_reputation_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvTransactionMedia'";
		NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvSAR'";
		NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPFC'";
		NewValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvOFAC'";
		NewValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);
		String query4 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvMarijuana'";
		NewValueMap4 = DB_Module.seperatevalueSinglecolumn(con, query4);
		String query5 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvLocalTrans'";
		NewValueMap5 = DB_Module.seperatevalueSinglecolumn(con, query5);
		String query6 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvAdverseMedia'";
		NewValueMap6 = DB_Module.seperatevalueSinglecolumn(con, query6);
		String query7 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='IndvPEP'";
		NewValueMap7 = DB_Module.seperatevalueSinglecolumn(con, query7);
    	Assert.assertEquals(Repu_Data.get("mariy"),NewValueMap4.get("y") );
    	logger.info("MARIJUANAY is equal, value is "+Repu_Data.get("mariy"));
    	Assert.assertEquals(Repu_Data.get("marin"),NewValueMap4.get("n") );  
    	logger.info("MARIJUANAN is equal, value is "+Repu_Data.get("marin"));
    	Assert.assertEquals(Repu_Data.get("pfcy"),NewValueMap2.get("y") ); 
    	logger.info("PFCY is equal, value is "+Repu_Data.get("pfcy"));
    	Assert.assertEquals(Repu_Data.get("pfcn"),NewValueMap2.get("n") );   
    	logger.info("PFCN is equal, value is "+Repu_Data.get("pfcn")); 
    	Assert.assertEquals(Repu_Data.get("advmedy"),NewValueMap6.get("y") );
    	logger.info("ADVERSEMEDIAY is equal, value is "+Repu_Data.get("advmedy"));
    	Assert.assertEquals(Repu_Data.get("advmedn"),NewValueMap6.get("n") );  
    	logger.info("ADVERSEMEDIAN is equal, value is "+Repu_Data.get("advmedn"));
    	Assert.assertEquals(Repu_Data.get("transmedy"),NewValueMap.get("y") );
    	logger.info("TRANSMEDIAY is equal, value is "+Repu_Data.get("transmedy"));
    	Assert.assertEquals(Repu_Data.get("transmedn"),NewValueMap.get("n") );  
    	logger.info("TRANSMEDIAN is equal, value is "+Repu_Data.get("transmedn"));
    	Assert.assertEquals(Repu_Data.get("ofacy"),NewValueMap3.get("y") );
    	logger.info("OFACY is equal, value is "+Repu_Data.get("ofacy"));
    	Assert.assertEquals(Repu_Data.get("ofacn"),NewValueMap3.get("n") );  
    	logger.info("OFACN is equal, value is "+Repu_Data.get("ofacn"));
    	Assert.assertEquals(Repu_Data.get("locsany"),NewValueMap5.get("y") );
    	logger.info("LOCSANY is equal, value is "+Repu_Data.get("locsany"));
    	Assert.assertEquals(Repu_Data.get("locsann"),NewValueMap5.get("n") );  
    	logger.info("LOCSANN is equal, value is "+Repu_Data.get("locsann"));
    	Assert.assertEquals(Repu_Data.get("sary"),NewValueMap1.get("y") );
    	logger.info("SARY is equal, value is "+Repu_Data.get("sary"));
    	Assert.assertEquals(Repu_Data.get("sarn"),NewValueMap1.get("n") );  
    	logger.info("SARN is equal, value is "+Repu_Data.get("sarn"));
    	Assert.assertEquals(Repu_Data.get("pepy"),NewValueMap7.get("y") );
    	logger.info("PEPY is equal, value is "+Repu_Data.get("pepy"));
    	Assert.assertEquals(Repu_Data.get("pepn"),NewValueMap7.get("n") );  
    	logger.info("PEPN is equal, value is "+Repu_Data.get("pepn"));
    	
	}	
	
	@Then("^usertransactionlog validation for indv sourceofFunds should be successful (.*)$")
	public void usertransactionlog_validation_also_should_be_successful_for(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900002", "ENTITY", Jwtcoid, linkedContextCode, "\"900002\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.srcfFundsAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}		
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for indv product should be successful (.*)$")
	public void usertransactionlog_validation_for_product_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900002", "ENTITY", Jwtcoid, linkedContextCode, "\"900002\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.prodAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryM : OldValueMap1.entrySet()) {			  
			  if(!entryM.getValue().equalsIgnoreCase(NewValueMap1.get(entryM.getKey()))) {
				valueDiff.put(GlobalStaticInfo.mulprodAmlu.get(entryM.getKey()),entryM.getValue()+','+NewValueMap1.get(entryM.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for indv highRiskThreshold should be successful (.*)$")
	public void usertransactionlog_validation_for_highRiskThreshold_should_be_successful_for(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900002", "ENTITY", Jwtcoid, linkedContextCode, "\"900002\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.highRisThresAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}		
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}
		ObjectMapper mapper = new ObjectMapper();
		OldValueMap.put("TYPE","entity");
		payload2 = mapper.writeValueAsString(GeneratePayloadRepInput.finalSum_payload(OldValueMap));
    	Res = request.log().all().body(payload2).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for indv resStatus should be successful (.*)$")
	public void usertransactionlog_validation_for_indv_resStatus_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900002", "ENTITY", Jwtcoid, linkedContextCode, "\"900002\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.resStatusAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}		
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for indv reputation should be successful (.*)$")
	public void usertransactionlog_validation_for_reputation_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900002", "ENTITY", Jwtcoid, linkedContextCode, "\"900002\"");
		
		for (Map.Entry<String, String> entryM : OldValueMap4.entrySet()) {			  
			  if(!entryM.getValue().equalsIgnoreCase(NewValueMap4.get(entryM.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuMarAmlu.get(entryM.getKey()),entryM.getValue()+','+NewValueMap4.get(entryM.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryS : OldValueMap1.entrySet()) {			  
			  if(!entryS.getValue().equalsIgnoreCase(NewValueMap1.get(entryS.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuSarAmlu.get(entryS.getKey()),entryS.getValue()+','+NewValueMap1.get(entryS.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryP : OldValueMap2.entrySet()) {			  
			  if(!entryP.getValue().equalsIgnoreCase(NewValueMap2.get(entryP.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repupfcAmlu.get(entryP.getKey()),entryP.getValue()+','+NewValueMap2.get(entryP.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryT : OldValueMap.entrySet()) {			  
			  if(!entryT.getValue().equalsIgnoreCase(NewValueMap.get(entryT.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuTransMAmlu.get(entryT.getKey()),entryT.getValue()+','+NewValueMap.get(entryT.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryO : OldValueMap3.entrySet()) {			  
			  if(!entryO.getValue().equalsIgnoreCase(NewValueMap3.get(entryO.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuofacAmlu.get(entryO.getKey()),entryO.getValue()+','+NewValueMap3.get(entryO.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryL : OldValueMap5.entrySet()) {			  
			  if(!entryL.getValue().equalsIgnoreCase(NewValueMap5.get(entryL.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuLocSanAmlu.get(entryL.getKey()),entryL.getValue()+','+NewValueMap5.get(entryL.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryA : OldValueMap6.entrySet()) {			  
			  if(!entryA.getValue().equalsIgnoreCase(NewValueMap6.get(entryA.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuAdvMAmlu.get(entryA.getKey()),entryA.getValue()+','+NewValueMap6.get(entryA.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryA : OldValueMap7.entrySet()) {			  
			  if(!entryA.getValue().equalsIgnoreCase(NewValueMap7.get(entryA.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuPepAmlu.get(entryA.getKey()),entryA.getValue()+','+NewValueMap7.get(entryA.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;
	}
	
	@When("^valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate a invalid smsession$")
	public void valid_user_to_generate_invalid_smsession(String username, String password, String buid) throws Throwable {		
		resultbody = "a"+GetSmsessionToken.generateSmsessionToken(username,password);
		logger.info("SMSession Cookie: " +resultbody);	
	}
	
	@Then("^API should return error message and response should contain error code \"([^\"]*)\" and error message as \"([^\"]*)\"$")
	public void api_should_return_proper_error_message_and_response_should_contain_error_code_as_and_error_message_as(String errCode, String errMsg) throws Throwable {
		Assert.assertEquals(Res.getStatusCode(), 400);
		JsonPath jsonPathEvaluator = Res.jsonPath();
		Assert.assertEquals(jsonPathEvaluator.get("errorDetail.fieldError[0].code").toString(),errCode);
		Assert.assertEquals(jsonPathEvaluator.get("errorDetail.fieldError[0].fieldName").toString(),errMsg); 
	}
	
}


