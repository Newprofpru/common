package com.Profile.stepDefinitions;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.accounts;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GeneratePayloadSMSession;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.Profile.supportLibraries.GetSmsessionToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

public class accountsGet {

    private static Logger logger = LogManager.getLogger();
    static RequestSpecification request;
    static String query=null;
    static Response Res1;
    String Service_Url = getEnvInfo.getAccountsSecureURL();
    String Authorization = getEnvInfo.getAuthorization();
    static String coUserId = null;
    static String contractId = null;
    String ssoid = "227657";
    String accounts_Id = null;
    String requestID = null;
    private static RequestSpecification request1;
    static String resultbody;
    boolean isNullNeeded = false;
    Map<String, String> data;
    static String SmCookie = "SMSESSION=IZC6SMudtwvfmzA12FmiM2ZXACivkZkiBtiAX3nzs8VqZQxXaEtr6zcHrAxGsPp1G6TYrp3GWhY987nSIbZgAGl5sQ4uCK3d3umPNRDq0FuU9LLFq/8hjFRJhWIKiifIyQs0ksqY3ywZROnh9+EupycTmblJmm2Ar3DlfribwCoSEXHp9czXE3gN/HLjnzpaAQwcHubYf9P1HRI8m8ckZOMUwxI2R3xMa0hc3tXGQG1qq3JjJNE32FsRZ0nndKA/nOGNtg3hXl2bS1rtHMsW6EJ/jweXP8P4XUouQaRJrhzGzFrNTbuta+YEqTTiab/Ra/dwoqfESTeMcPJuhO9Jp7BC0XOEagjPzh0QyC/fbxmoWl+VqDcxj6cTmEi/CfCcBT/Jt0TxspjpzI4HXZXSwr449Yikv9bT35QLiAqhD5+rFgZlm6QOnPv2eUzyIpklWTD+13ZLHyBmLVxcjoifQulJSO7PherWH3wPm/1vF7y4Fv0s3acbAPva+A/aVcg5OFa++8DwRHRmbn2sfofxG5aN/NYBDS4PvDH3f+SMdhW/J3mME9dPfXYTKvKXkORcsGLHFL/zmrxI+aTQsQBzAo1VlVa8fAlYwr5WypxIryimzYmhn0GbGgwZfNcwVN+9Np/vq4KoRQnsP+dQz3+SqZeNcq9uvG2sAqnt1YME5ZLrqI/3e18HQXuJ8Ne3XqcAvpYvlECeNIrb0+YpBIECEjvzinCvOWuQVBagu4khuwILhm0/FVVROnka4U2fbZUKeh8EIUKG/hUdUuzFWsjK5M9O+aPkoRFuVjmVx/7DT57N8K731R8kPUgZcUxaB/RU/XV0sOxUqctCdwr4Ht7qy5nHOLrIa2mXLZ7YeRfkVKatyg423685/nK2/ItqraIF5Xy3IA0otItX3ueyx2+gVgKFI1TlJYxdll4nhVMqXA1fEHLww9YWN3ZECCyivNp9cxOtxqKHF0YXJaIZGVmVAm4HVPhFbDVNTRr6NJ+aAMDyrsofnLLVDHRjvyVTy/EaGTJFruVHxDGJfA7nnC421O6HYlHLTrPg6gy+nA/leVR+7SIpBJ5n56JHK34H7CO32UPa0Se6Nf9HneWmCrx/CMk8MoeHFSMCYGWJ28/YO/W11J62rS6/YLnM5+B4PZhjbMfDB0Q9x9u1KUdBUo+JaNhVVZg8v7PEWLpVQxzaMGLVN5J/BwV58zYufqUqjmgtR8LF9TX0eNp+oIpcBSNTJWI9+ro+XP6Z3jNb3tZGIl5sZLbPgkCJ9d9+0pRhSajc; path=/; domain=.prudential.com; Secure;";

    accounts accounts = new accounts();

    @Given("^a valid working endpoint exists for \"([^\"]*)\" and valid request is sent$")
    public void a_valid_working_endpoint_exists_for(String serviceName) throws Throwable {
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        GlobalStaticInfo.loadGlobalStaticInfo();

      
    }

    @Given("^a valid working endpoint exists for \"([^\"]*)\" and invalid request is sent$")
    public void an_invalid_source_exists_for(String serviceName) throws Throwable {
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        GlobalStaticInfo.loadGlobalStaticInfo();

    }
    
    

    @When("^the user sends a GET request to accounts API with below parameters$")
    public void the_user_sends_a_GET_request_to_accounts_API_with_below_parameters(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
    	data = parameters.asMap(String.class, String.class);
		Set<String> paramNames=data.keySet();
        logger.info("\nIn--------------------> When the PUT request is sent to accounts API with below request body data of accounts");
        Random rand = new Random();
        isNullNeeded = false;
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "accountstest_" + n;
        RestAssured.baseURI = Service_Url;
       
        accounts_Id = data.get("accounts_Id");
        ssoid=data.get("Header_ssoId");
      
        //accounts = RequestBodyPojoCreater.getAccounts(accounts_Id,isNullNeeded);

        request = given().log().all()
                .header("X-PruRequestId", requestID)
                .header("Authorization", Authorization);

        
        
        for(String paramName:paramNames){
			if(paramName.equalsIgnoreCase("Header_ssoId"))
				request.header("X-PruPrimaryIdentity",data.get(paramName) );
			else
				request.param(paramName,data.get(paramName));
		}

        Gson gson = new Gson();
        String body = gson.toJson(accounts);
        logger.info("body ----> "+body);
        Res1 = request.when().cookie(SmCookie).get().andReturn();

        logger.info(Res1.asString());
        logger.info("Response----->:" + Res1.prettyPrint());
    }

    @Then("^the user receives correct responsebody content from Accounts API$")
    public void success_response_should_be_received() throws Throwable {
        try{
            logger.info("\nIn--------------------> Then the data is updated correctly and the success response code 200 is recieved");
            Integer actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);

            // Validate the response
            logger.info(Res1.getStatusCode());
            Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }

    @Then("^the user gets a bad request message$")
    public void error_must_be_thrown() throws Throwable {
        try{
            logger.info("\nIn--------------------> Then the data is updated correctly and the success response code 200 is recieved");
            Integer actualResponseCode = Res1.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);

            // Validate the response
            logger.info(Res1.getStatusCode());
            Assert.assertEquals(Res1.getStatusCode(), 400, "responseCode received in the Response");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }
    
    @And("^the user recieves correct responsebody content for the accounts and the response is verified with db$")
	public void the_data_is_created_in_the_Holdingsummaryread_holding_tables_and_verified_successfully() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
    	logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		JsonArray accountsArray = new JsonArray();
		 accountsArray = responseObject.getAsJsonArray("accounts");
		
		 List<String> idJsonArray = new ArrayList<>();
		 JsonObject beneObj ;
			
			for(int i=0;i<accountsArray.size();i++){
				
				System.out.println(accountsArray.size());
				
				beneObj=accountsArray.get(i).getAsJsonObject();
				String Finid = beneObj.get("financialInstituionID").getAsString();
				
				String [] FinancialInstitutionId = new String[20];
				FinancialInstitutionId[0]="3140";
				FinancialInstitutionId[1]="3651";
				FinancialInstitutionId[2]="3946";
				FinancialInstitutionId[3]="4385";
				FinancialInstitutionId[4]="5428";
				FinancialInstitutionId[5]="6882";
				FinancialInstitutionId[6]="7382";
				FinancialInstitutionId[7]="9949";
				FinancialInstitutionId[8]="12586";
				FinancialInstitutionId[9]="13395";
				FinancialInstitutionId[10]="14567";
				FinancialInstitutionId[11]="20481";
				FinancialInstitutionId[12]="21052";
				FinancialInstitutionId[13]="21100";
				FinancialInstitutionId[14]="22184";
				FinancialInstitutionId[15]="22787";
				FinancialInstitutionId[16]="23306";
				FinancialInstitutionId[17]="24463";
				FinancialInstitutionId[18]="25530";
				FinancialInstitutionId[19]="26996";
				
				for(int j=0;j<FinancialInstitutionId.length;j++)
				{
				
					String FinIdCheck = FinancialInstitutionId[j];
					Assert.assertFalse((Finid.equals(FinIdCheck)), Finid);
				}
				
				
				String typeCode = beneObj.get("typeCode").getAsString();
				String typeCodeDisplay = beneObj.get("typeCodeDisplay").getAsString();
				
				if(typeCode.contains("_"))
				{
					
					String[] newTypeCodeDisplay = typeCode.split("_");
					
				String ModifiedtypeCodeDisplay = newTypeCodeDisplay[0]+" "+newTypeCodeDisplay[1];
				System.out.println(newTypeCodeDisplay[0]);
				
				
				
				Assert.assertEquals(typeCodeDisplay, ModifiedtypeCodeDisplay, "typeCode &  typeCodeDisplay   are equal");
					
				}
				
				
			}
			
			
				}
			}
			
		
