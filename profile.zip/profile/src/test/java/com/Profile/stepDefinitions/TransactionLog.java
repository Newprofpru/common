package com.Profile.stepDefinitions;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.DB_Module;
import com.Profile.supportLibraries.GenericEvent;

public class TransactionLog {
	
	private static final Logger log = LogManager.getLogger();
	String usertransactionlogId =null;	
	public static ArrayList<GenericEvent> dbRows = null;
    public void auditlog_should_match_in_db(String requestID,String ssoid,String typeCode,String Message,String RoleCode) throws Throwable {
    	Connection con = null;
		try {
			boolean synapse = false;
			con = DBConnection.InitConnection();
			String query = "select * from usertransactionlog where ssoid='"+ssoid+"' and TRANSACTIONREQUESTID='"+requestID+"' and CREATEDBY='"+ssoid+"' and TRANSACTIONCATEGORYCODE = 'updateProfile'";
			ResultSet res = DBConnection.execStatement(con,query);
			log.info("Query Input : "+query);
			Thread.sleep(500);
			while(res.next()){
				Assert.assertEquals(typeCode,res.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals(Message,res.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(RoleCode,res.getString("ROLECODE"),"ROLECODE is equal");
				log.info("ROLECODE is equal,value is "+RoleCode);
			}
			String query1 = "select * from usertransactionlog where ssoid='"+ssoid+"' and TRANSACTIONREQUESTID='"+requestID+"' and CREATEDBY='CO'";
			ResultSet res1 = DBConnection.execStatement(con,query1);
			Thread.sleep(500);
			while(res1.next()){
				log.info("Query Input : "+query);
				synapse = true;
				Assert.assertEquals("createSynapseEvent",res1.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals("Success",res1.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(RoleCode,res1.getString("ROLECODE"),"ROLECODE is equal");
				log.info("ROLECODE is equal,value is "+RoleCode);
			}
			if(synapse){
				checkEventtable("select * from(select * from event where createdby='"+ssoid+"' and eventcontextrefid='"+ssoid+"' order by createddate desc) where rownum<=2");
				String q2 = "select * from couser where ssoid = '"+ssoid+"' order by createddate asc";
				ResultSet res2 = DBConnection.execStatement(con,q2);
				String couserid = null;
				while(res2.next()){
					couserid = res2.getString("COUSERID");
				}
				checkEventtable("select * from(select * from event where createdby='"+couserid+"' and eventcontextrefid='"+couserid+"' order by createddate desc) where rownum<=2");
			}else{
				log.info("No Synapse event triggered...");
			}
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

			}
    }
    
    public String auditlog_should_match_in_db_for_profile(String ssoid,String typeCode,String Message, String linkedContextCode) throws Throwable {
    	Connection con = null;
    	Thread.sleep(3000);
		try {
			con = DBConnection.InitConnection();
			String query = "select * from (select * from usertransactionlog where ssoid='"+ssoid+"'and Transactiontypecode='PROFILE' order by updateddate desc) where ROWNUM <=1";
			ResultSet res = DBConnection.execStatement(con,query);
			log.info("Query Input : "+query);
			Thread.sleep(3500);
			while(res.next()){
				Assert.assertEquals(typeCode,res.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals(Message,res.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(linkedContextCode,res.getString("LINKEDCONTEXTCODE"),"LINKEDCONTEXTCODE is equal");
				log.info("LINKEDCONTEXTCODE is equal,value is "+linkedContextCode);
				usertransactionlogId = res.getString("USERTRANSACTIONLOGID");
				log.info("USERTRANSACTIONLOGID is "+usertransactionlogId);					
			}
			
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

			}
		return usertransactionlogId;
    }
    
    public String auditlog_should_match_in_db_for_profile_for_minor(String couserid,String typeCode,String Message, String linkedContextCode) throws Throwable {
    	Connection con = null;
    	Thread.sleep(3000);
		try {
			con = DBConnection.InitConnection();
			String query = "select * from (select * from usertransactionlog where couserid='"+couserid+"'and Transactiontypecode='PROFILE' order by updateddate desc) where ROWNUM <=1";
			ResultSet res = DBConnection.execStatement(con,query);
			log.info("Query Input : "+query);
			Thread.sleep(3500);
			while(res.next()){
				Assert.assertEquals(typeCode,res.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals(Message,res.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(linkedContextCode,res.getString("LINKEDCONTEXTCODE"),"LINKEDCONTEXTCODE is equal");
				log.info("LINKEDCONTEXTCODE is equal,value is "+linkedContextCode);
				usertransactionlogId = res.getString("USERTRANSACTIONLOGID");
				log.info("USERTRANSACTIONLOGID is "+usertransactionlogId);					
			}
			
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

			}
		return usertransactionlogId;
    }
    
    
    public void auditlog_should_match_in_db_for_minor(String requestID,String couserid,String typeCode,String Message,String RoleCode) throws Throwable {
    	Connection con = null;
		try {
			boolean synapse = false;
			con = DBConnection.InitConnection();
			String query = "select * from usertransactionlog where couserid='"+couserid+"' and TRANSACTIONREQUESTID='"+requestID+"' and TRANSACTIONCATEGORYCODE='"+typeCode+"'";
			ResultSet res = DBConnection.execStatement(con,query);
			log.info("Query Input : "+query);
			Thread.sleep(500);
			while(res.next()){
				Assert.assertEquals(typeCode,res.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals(Message,res.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(RoleCode,res.getString("ROLECODE"),"ROLECODE is equal");
				log.info("ROLECODE is equal,value is "+RoleCode);
			}
			String query1 = "select * from usertransactionlog where couserid='"+couserid+"' and TRANSACTIONREQUESTID='"+requestID+"' and TRANSACTIONCATEGORYCODE='createSynapseEvent'";
			ResultSet res1 = DBConnection.execStatement(con,query1);
			Thread.sleep(500);
			while(res1.next()){
				log.info("Query Input : "+query);
				synapse = true;
				Assert.assertEquals("createSynapseEvent",res1.getString("TRANSACTIONTYPECODE"),"TRANSACTIONTYPECODE is equal");
				log.info("TRANSACTIONTYPECODE is equal,value is "+typeCode);
				Assert.assertEquals("Success",res1.getString("TRANSACTIONMESSAGE"),"TRANSACTIONMESSAGE is equal");
				log.info("TRANSACTIONMESSAGE is equal,value is "+Message);
				Assert.assertEquals(RoleCode,res1.getString("ROLECODE"),"ROLECODE is equal");
				log.info("ROLECODE is equal,value is "+RoleCode);
			}
			if(synapse){
				checkEventtable("select * from(select * from event where createdby='"+couserid+"' and eventcontextrefid='"+couserid+"' order by createddate desc) where rownum<=2");
				String q2 = "select * from couser where couserid = '"+couserid+"' order by createddate asc";
				ResultSet res2 = DBConnection.execStatement(con,q2);
				String ssoid = null;
				while(res2.next()){
					ssoid = res2.getString("SSOID");
				}
				checkEventtable("select * from(select * from event where createdby='"+ssoid+"' and eventcontextrefid='"+ssoid+"' order by createddate desc) where rownum<=2");
			}else{
				log.info("No Synapse event triggered...");
			}
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

			}
    }
public static void checkEventtable(String query) throws Exception {
	Connection Con2 = null;
	try{
	Con2 = DBConnection.InitConnection();
	ResultSet rs = DBConnection.execStatement(Con2,query);
	log.info("Validating Synapse Event Status Code ");
	log.info("Query Input : "+query);
	List<String> codes = new ArrayList<>();
	while(rs.next()){
		codes.add(rs.getString("EVENTSTATUSCODE"));
		log.info(rs.getString("EVENTSTATUSCODE"));
	}
	if(codes.size()>0){
	log.info("The codes are :");
	Assert.assertEquals(true, codes.size()%2==0,"The no of status codes are even");
	log.info("The no of status codes are even");
	for(int i=1;i<codes.size();i+=2){
		if(codes.get(i).equals("RECD")){
			Assert.assertEquals(codes.get(i+1), "DLVD","The pair is RECD,DLVD");
			log.info("The pair is RECD,DLVD");
		}
		else if(codes.get(i).equals("DLVD")){
			
			System.out.println(codes.get(i));
			System.out.println(codes.get(i+1));
			Assert.assertEquals(codes.get(i+1), "RECD","The pair is DLVD,RECD");
			log.info("The pair is DLVD,RECD");
		}
	}
	}
	else{
		log.info("Could not find using this query, using another one...");
	}
	}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (Con2 != null) {
				Con2.close();
				}

	}	// DBConnection.DbConnection_close(con2);
	}

	public void getAlltransactionAuditLogs(String transactionlogID,String field, String value) throws Throwable {
		Connection con = null;
		String col1=null,col2=null,col3=null;
		boolean flag=false,found=false;		
		try {
		con = DBConnection.InitConnection();
		if(dbRows==null){
		String query = "Select FIELDNAME,OLDVALUE,NEWVALUE from usertransactionlogdtl where usertransactionlogid = '"+transactionlogID+"'";
		dbRows = DB_Module.DBRS_ArraylistMultipleRows(con, query);	
		}	
		for (int i=0;i<dbRows.size()&&!flag;i++){				
			for(int j=0;j<(dbRows.get(i).getEvent_cols().size())&&!flag;j=j+3){				
				 col1 = dbRows.get(i).getEvent_cols().get(j);
				 col2 = dbRows.get(i).getEvent_cols().get(j+1);
				 col3 = dbRows.get(i).getEvent_cols().get(j+2);	
				 
				 if(!col1.equalsIgnoreCase(field)){
					 break;
				 }
				 else if(field.contains("Date")&& col1.contains("Date")){					 
					Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(col3);
					Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(value);
					Assert.assertEquals(dt1,dt2,""+col1+" is equal");
					log.info(col1+" is equal,NEW VALUE is "+col3);
					flag=true;
					found=true;
				 }
				 else if(col1.equalsIgnoreCase(field)){
					 Assert.assertEquals(col3, value, ""+col1+" is equal");
					 log.info(col1+" is equal,NEW VALUE is "+col3);	
					 flag=true;
					 found=true;					 
				}
				 
			}			
		}	
		Assert.assertEquals(col2, null, "old value is null for "+field);
		log.info("OLD VALUE is null for "+field);
		Assert.assertEquals(found, true, ""+field+" is audited");		
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

		}		
			
	}	
	
	public void getAlltransactionAuditLogsforUpdate(String transactionlogID,String field, String newValue, String oldValue) throws Throwable {
		Connection con = null;
		String col1=null,col2=null,col3=null;
		boolean flag=false,found=false;		
		try {
		con = DBConnection.InitConnection();
		if(dbRows==null){
		String query = "Select FIELDNAME,OLDVALUE,NEWVALUE from usertransactionlogdtl where usertransactionlogid = '"+transactionlogID+"'";
		dbRows = DB_Module.DBRS_ArraylistMultipleRows(con, query);	
		}	
		for (int i=0;i<dbRows.size()&&!flag;i++){				
			for(int j=0;j<(dbRows.get(i).getEvent_cols().size())&&!flag;j=j+3){				
				 col1 = dbRows.get(i).getEvent_cols().get(j);
				 col2 = dbRows.get(i).getEvent_cols().get(j+1);
				 col3 = dbRows.get(i).getEvent_cols().get(j+2);	
				 
				 if(!col1.equalsIgnoreCase(field)){
					 break;
				 }
				 else if(field.contains("Date")&& col1.contains("Date")){					 
					Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(col3);
					Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(newValue);
					Assert.assertEquals(dt1,dt2,""+col1+" is equal");
					log.info(col1+" is equal,NEW VALUE is "+col3);
					Date dt3 = new SimpleDateFormat("yyyy-MM-dd").parse(col2);
					Date dt4 = new SimpleDateFormat("MM/dd/yyyy").parse(oldValue);
					Assert.assertEquals(dt3,dt4,""+col1+" is equal");
					log.info(col1+" is equal,OLD VALUE is "+col2);
					flag=true;
					found=true;
				 }
				 else if(col1.equalsIgnoreCase(field)){
					 Assert.assertEquals(col3, newValue, ""+col1+" is equal");
					 log.info(col1+" is equal,NEW VALUE is "+col3);	
					 Assert.assertEquals(col2, oldValue, ""+col1+" is equal");
					 log.info(col1+" is equal,OLD VALUE is "+col2);	
					 flag=true;
					 found=true;					 
				}
				 
			}			
		}	
		Assert.assertEquals(found, true, ""+field+" is audited");		
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

		}		
			
	}
	
	public static HashMap<String,String> GetNullValues(Map<String,String> Repu_Data,String query) throws SQLException{
		HashMap<String,String> db_res_for_null_values = new HashMap<String,String>();		
		List<String> EMPTY_VALUE = Repu_Data.entrySet().stream()
	    	.filter(e -> e.getValue().equals("")).map(e -> e.getKey()).collect(Collectors.toList());	     	    			
	   log.info("EMPTY indicator is " +EMPTY_VALUE);	   
	   String listString = String.join(", ", EMPTY_VALUE);
	   if(!EMPTY_VALUE.isEmpty()){
		   String Query = "select " + listString +query;   	
	   	   log.info("Query is " +Query);   	
		   GenericEvent DB_RES1 = DB_Module.DBRS_SingleArraylist(DBConnection.InitConnection(), Query);
		   log.info("DB RES Size is"+ DB_RES1.event_cols.size());		   	
		   for(int i =0 ; i < DB_RES1.event_cols.size();i++){
		   		db_res_for_null_values.put(EMPTY_VALUE.get(i),DB_RES1.event_cols.get(i));
		   }
   	
	   }
	return db_res_for_null_values;
	}
	
	public String auditlog_should_match_in_db_for_AMLU(String partyid,String partyType,String updatedBy,String linkedContextCode, String linkedrefId) throws Throwable {
    	Connection con = null;
    	Thread.sleep(3000);
		try {
			con = DBConnection.InitConnection();
			String query = "select * from (select * from usertransactionlog where partyid='"+partyid+"'and partyType = '"+partyType+"' and Transactiontypecode='AMLU' order by updateddate desc) where ROWNUM <=1";
			ResultSet res = DBConnection.execStatement(con,query);
			log.info("Query Input : "+query);
			Thread.sleep(3500);
			while(res.next()){
				Assert.assertEquals(updatedBy,res.getString("UPDATEDBY"),"UPDATEDBY is equal");
				log.info("UPDATEDBY is equal,value is "+updatedBy);
				Assert.assertEquals("["+linkedrefId+"]",res.getString("LINKEDCONTEXTREFID"),"LINKEDCONTEXTREFID is equal");
				log.info("LINKEDCONTEXTREFID is equal,value is "+linkedrefId);
				Assert.assertEquals(linkedContextCode,res.getString("LINKEDCONTEXTCODE"),"LINKEDCONTEXTCODE is equal");
				log.info("LINKEDCONTEXTCODE is equal,value is "+linkedContextCode);
				usertransactionlogId = res.getString("USERTRANSACTIONLOGID");
				log.info("USERTRANSACTIONLOGID is "+usertransactionlogId);					
			}
			
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

			}
		return usertransactionlogId;
    }
	
	public void getReputationAuditLogs(String transactionlogID,String field, String newValue, String oldValue) throws Throwable {
		Connection con = null;
		String col1=null,col2=null,col3=null;
		boolean flag=false,found=false;		
		try {
		con = DBConnection.InitConnection();
		if(dbRows==null){
		String query = "Select FIELDNAME,OLDVALUE,NEWVALUE from usertransactionlogdtl where usertransactionlogid = '"+transactionlogID+"'";
		dbRows = DB_Module.DBRS_ArraylistMultipleRows(con, query);	
		}	
		for (int i=0;i<dbRows.size()&&!flag;i++){				
			for(int j=0;j<(dbRows.get(i).getEvent_cols().size())&&!flag;j=j+3){				
				 col1 = dbRows.get(i).getEvent_cols().get(j);
				 col2 = dbRows.get(i).getEvent_cols().get(j+1);
				 col3 = dbRows.get(i).getEvent_cols().get(j+2);	
				 
				 if(!col1.equalsIgnoreCase(field)){
					 break;
				 }				 
				 else if(col1.equalsIgnoreCase(field)){
					 Assert.assertEquals(col3, newValue, ""+col1+" is equal");
					 log.info(col1+" is equal,NEW VALUE is "+col3);	
					 Assert.assertEquals(col2, oldValue, ""+col1+" is equal");
					 log.info(col1+" is equal,OLD VALUE is "+col2);	
					 flag=true;
					 found=true;					 
				}
				 
			}			
		}	
		Assert.assertEquals(found, true, ""+field+" is audited");		
		}catch (Exception e) {
			log.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}

		}		
			
	}
}
