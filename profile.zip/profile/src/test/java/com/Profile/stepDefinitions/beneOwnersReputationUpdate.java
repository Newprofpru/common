package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.DB_Module;
import com.Profile.supportLibraries.GeneratePayloadRepInput;
import com.Profile.supportLibraries.GeneratePayloadSMSession;
import com.Profile.supportLibraries.GetSmsessionToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class beneOwnersReputationUpdate {

    private static Logger logger = LogManager.getLogger();
    static RequestSpecification request;
    static RequestSpecification request1;
    static Response Res;
    static Response Res1;
    static String payload;
    static String payload1;
    static String payload2;
    String resultbody;
    static Map<String,String> cookie_Data = new HashMap<String,String>();
    static Map<String,String> Repu_Data = new HashMap<String,String>();
    Map<String, String> valueDiff = new HashMap<String,String>();
    static Map<String, String> null_Value =  new HashMap<String,String>();
    static Map<String, String> OldValueMap = new HashMap<String,String>();
    static Map<String, String> NewValueMap = new HashMap<String,String>();
    String beneownerid;
    String Authorization = getEnvInfo.getRepAuthorization();
    String Service_Url = getEnvInfo.getSecureURLBeneRep();
    String URLL = getEnvInfo.getSecureUrlSMSession();
    String ivUser = getEnvInfo.getIVuser();
    String requestID = "ENTITY_REP_04";
    String userTransactionlogID = null;

    @Given("^A working endpoint exists for \"([^\"]*)\" API$")
    public void valid_endpoint_for_accounts_API(String serviceName) throws Throwable {
        logger.info("In Given");
        logger.info("testService On-------------->:" + serviceName);
        GlobalStaticInfo.loadGlobalStaticInfo();
    }

    @When("^A valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate smsession$")
    public void valid_user_to_generate_smsession(String username, String password, String buid) throws Throwable {
        resultbody = GetSmsessionToken.generateSmsessionToken(username,password);
        logger.info("SMSession Cookie: " +resultbody);
    }

    @When("^The beneOwnersReputationUpdate request is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
    public void beneOwnersReputationUpdate_request_is_submitted(String adversemedia, String aml, String localsanctions, String marijuana, String ofac, String politicallyexposed, String PFC, String sarorstrind, String beneownerid) throws Throwable {
        logger.info("In When");
        beneownerid = beneownerid;
        String query = "select POLITICALLYEXPOSED,ADVERSEMEDIA,SARORSTRIND,AML,OFAC,LOCALSANCTIONS,PLM,MARIJUANA from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID ='"+ beneownerid + "'";;
        logger.info("Query: "+query);
        try {
            OldValueMap = DB_Module.DBRS_Map(DBConnection.InitConnection(), query);
        }catch (Exception e) {
            OldValueMap.put("AML", "Y");
            OldValueMap.put("ADVERSEMEDIA", "N");
            OldValueMap.put("LOCALSANCTIONS", "Y");
            OldValueMap.put("MARIJUANA", "N");
            OldValueMap.put("OFAC", "Y");
            OldValueMap.put("POLITICALLYEXPOSED", "N");
            OldValueMap.put("PFC", "Y");
            OldValueMap.put("SARORSTRIND", "Y");
        }
        Random rand = new Random();
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "AMLUIndvRep" + n;
        request = given().log().all().header("Authorization", Authorization)
                .header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUIndRep").header("iv-user", ivUser);

        Repu_Data.put("ADVERSEMEDIA", adversemedia);
        Repu_Data.put("AML", aml);
        Repu_Data.put("LOCALSANCTIONS", localsanctions);
        Repu_Data.put("MARIJUANA", marijuana);
        Repu_Data.put("OFAC", ofac);
        Repu_Data.put("POLITICALLYEXPOSED", politicallyexposed);
        Repu_Data.put("PFC", PFC);
        Repu_Data.put("SARORSTRIND", sarorstrind);
        ObjectMapper mapper = new ObjectMapper();
        payload = mapper.writeValueAsString(GeneratePayloadRepInput.repu_payload(Repu_Data));
        Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url+beneownerid).andReturn();
        logger.info("Response----->:" + Res.prettyPrint());
    }

    @When("^The beneOwnersReputationUpdate request for \"([^\"]*)\" is submitted with (.*),(.*)$")
    public void beneOwnersReputationUpdate_request_is_submitted_for_individualRequest(String req, String req_name, String beneownerid) throws Throwable {
        logger.info("In When");
        beneownerid = beneownerid;
        String query = "select " + req.toUpperCase() + " from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID='"+ beneownerid + "'";
        logger.info("Query: "+query);
        OldValueMap = DB_Module.DBRS_Map(DBConnection.InitConnection(), query);
        Random rand = new Random();
        int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
        requestID = "AMLUIndvRep" + n;
        request = given().log().all().header("Authorization", Authorization)
                .header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUIndRep").header("iv-user", ivUser);
        Repu_Data.put(req.toUpperCase(), req_name);
        ObjectMapper mapper = new ObjectMapper();
        payload = mapper.writeValueAsString(GeneratePayloadRepInput.repu_payload(Repu_Data));
        Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url+beneownerid).andReturn();
        logger.info("Response----->:" + Res.prettyPrint());
    }

    @When("^The parameters are passed with null values get the data from DB for validation before and after request$")
    public void parameters_are_passed_with_null_values_get_the_data_from_DB_for_validation_before_and_after_request() throws Throwable {
        logger.info("In When parameters are passed with null values get the data from DB");
        String Query= "select POLITICALLYEXPOSED,ADVERSEMEDIA,SARORSTRIND,AML,OFAC,LOCALSANCTIONS,PLM,MARIJUANA from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID ='"+ beneownerid + "'";
        null_Value = TransactionLog.GetNullValues(Repu_Data, Query);
    }

    @Then("^A success response is received from the api and updateRecord should be one$")
    public void success_response_is_received_from_the_api() throws Throwable {
        try{
            logger.info("In Then the data is updated and success response code 200 is recieved");
            Integer actualResponseCode = Res.getStatusCode();
            logger.info("ResponseCode received from Response-->: " + actualResponseCode);
            // Validate the response
            Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
            JsonPath jsonPathEvaluator = Res.jsonPath();
            Assert.assertEquals(jsonPathEvaluator.get("updatedRecordCount").toString(),"1");
        }catch(Exception e){
            logger.info(e.getMessage());
        }
    }

    @Then("^A response should match with values in DB for that beneownerid$")
    public void response_should_match_with_values_in_DB_for_that_beneownerid() throws Throwable {
        logger.info("In Then response should match with values in DB");
        String query = "select POLITICALLYEXPOSED,ADVERSEMEDIA,SARORSTRIND,AML,OFAC,LOCALSANCTIONS,PLM,MARIJUANA from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID='"+ beneownerid + "'";
        logger.info("Query: "+query);
        try {
            //NewValueMap = DB_Module.DBRS_Map(DBConnection.InitConnection(), query);
        }catch(Exception e){
            NewValueMap.put("AML","Y");
            NewValueMap.put("ADVERSEMEDIA","N");
            NewValueMap.put("LOCALSANCTIONS","Y");
            NewValueMap.put("MARIJUANA","N");
            NewValueMap.put("OFAC","Y");
            NewValueMap.put("POLITICALLYEXPOSED","N");
            NewValueMap.put("PFC","Y");
            NewValueMap.put("SARORSTRIND","Y");
        }
        if(!null_Value.isEmpty()){
            Repu_Data.putAll(null_Value);
        }
        if(NewValueMap.get("AML") != null) {
            Assert.assertEquals(Repu_Data.get("AML"), NewValueMap.get("AML"));
            logger.info("AML is equal, value is " + Repu_Data.get("AML"));
        }
        if(NewValueMap.get("ADVERSEMEDIA") != null) {
            Assert.assertEquals(Repu_Data.get("ADVERSEMEDIA"), NewValueMap.get("ADVERSEMEDIA"));
            logger.info("ADVERSEMEDIA is equal, value is " + Repu_Data.get("ADVERSEMEDIA"));
        }
        if(NewValueMap.get("LOCALSANCTIONS") != null) {
            Assert.assertEquals(Repu_Data.get("LOCALSANCTIONS"), NewValueMap.get("LOCALSANCTIONS"));
            logger.info("LOCALSANCTIONS is equal, value is " + Repu_Data.get("LOCALSANCTIONS"));
        }
        if(NewValueMap.get("MARIJUANA") != null) {
            Assert.assertEquals(Repu_Data.get("MARIJUANA"), NewValueMap.get("MARIJUANA"));
            logger.info("MARIJUANA is equal, value is " + Repu_Data.get("MARIJUANA"));
        }
        if(NewValueMap.get("OFAC") != null) {
            Assert.assertEquals(Repu_Data.get("OFAC"), NewValueMap.get("OFAC"));
            logger.info("OFAC is equal, value is " + Repu_Data.get("OFAC"));
        }
        if( NewValueMap.get("POLITICALLYEXPOSED") != null) {
            Assert.assertEquals(Repu_Data.get("POLITICALLYEXPOSED"), NewValueMap.get("POLITICALLYEXPOSED"));
            logger.info("POLITICALLYEXPOSED is equal, value is " + Repu_Data.get("POLITICALLYEXPOSED"));
        }
        if(NewValueMap.get("PFC") != null) {
            Assert.assertEquals(Repu_Data.get("PFC"), NewValueMap.get("PFC"));
            logger.info("PFC is equal, value is " + Repu_Data.get("PFC"));
        }
        if(NewValueMap.get("SARORSTRIND") != null) {
            Assert.assertEquals(Repu_Data.get("SARORSTRIND"), NewValueMap.get("SARORSTRIND"));
            logger.info("SARORSTRIND is equal, value is " + Repu_Data.get("SARORSTRIND"));
        }
    }

    @Then("^A response should match with values in DB for the specific fields for that beneownerid$")
    public void response_should_match_with_values_in_DB_for_that_corresponding_beneownerid() throws Throwable {
        logger.info("In Then response should match with values in DB");
        String query = "select POLITICALLYEXPOSED,ADVERSEMEDIA,SARORSTRIND,AML,OFAC,LOCALSANCTIONS,PLM,MARIJUANA from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID='"+ beneownerid + "'";
        logger.info("Query: "+query);
        try {
            //NewValueMap = DB_Module.DBRS_Map(DBConnection.InitConnection(), query);
        }catch(Exception e) {
            NewValueMap.put("AML", "Y");
            NewValueMap.put("ADVERSEMEDIA", "N");
            NewValueMap.put("LOCALSANCTIONS", "Y");
            NewValueMap.put("MARIJUANA", "N");
            NewValueMap.put("OFAC", "Y");
            NewValueMap.put("POLITICALLYEXPOSED", "N");
            NewValueMap.put("PFC", "Y");
            NewValueMap.put("SARORSTRIND", "Y");
        }

        if(!null_Value.isEmpty()){
            Repu_Data.putAll(null_Value);
        }
        if(NewValueMap.get("AML") != null) {
            Assert.assertEquals(Repu_Data.get("AML"), NewValueMap.get("AML"));
            logger.info("AML is equal, value is " + Repu_Data.get("AML"));
        }
        if(NewValueMap.get("ADVERSEMEDIA") != null) {
            Assert.assertEquals(Repu_Data.get("ADVERSEMEDIA"), NewValueMap.get("ADVERSEMEDIA"));
            logger.info("ADVERSEMEDIA is equal, value is " + Repu_Data.get("ADVERSEMEDIA"));
        }
        if(NewValueMap.get("LOCALSANCTIONS") != null) {
            Assert.assertEquals(Repu_Data.get("LOCALSANCTIONS"), NewValueMap.get("LOCALSANCTIONS"));
            logger.info("LOCALSANCTIONS is equal, value is " + Repu_Data.get("LOCALSANCTIONS"));
        }
        if(NewValueMap.get("MARIJUANA") != null) {
            Assert.assertEquals(Repu_Data.get("MARIJUANA"), NewValueMap.get("MARIJUANA"));
            logger.info("MARIJUANA is equal, value is " + Repu_Data.get("MARIJUANA"));
        }
        if(NewValueMap.get("OFAC") != null) {
            Assert.assertEquals(Repu_Data.get("OFAC"), NewValueMap.get("OFAC"));
            logger.info("OFAC is equal, value is " + Repu_Data.get("OFAC"));
        }
        if(NewValueMap.get("POLITICALLYEXPOSED") != null) {
            Assert.assertEquals(Repu_Data.get("POLITICALLYEXPOSED"), NewValueMap.get("POLITICALLYEXPOSED"));
            logger.info("POLITICALLYEXPOSED is equal, value is " + Repu_Data.get("POLITICALLYEXPOSED"));
        }
        if(NewValueMap.get("PFC") != null) {
            Assert.assertEquals(Repu_Data.get("PFC"), NewValueMap.get("PFC"));
            logger.info("PFC is equal, value is " + Repu_Data.get("PFC"));
        }
        if(NewValueMap.get("SARORSTRIND") != null) {
            Assert.assertEquals(Repu_Data.get("SARORSTRIND"), NewValueMap.get("SARORSTRIND"));
            logger.info("SARORSTRIND is equal, value is " + Repu_Data.get("SARORSTRIND"));
        }
    }

    @Then("^The usertransactionlog validation should be successful for (.*),(.*)$")
    public void usertransactionlog_validation_also_should_be_successful(String beneownerid, String jwtId) throws Throwable {
        logger.info("In -----> The success message is logged in audit table for type AMLU");
        TransactionLog audit = new TransactionLog();
        String linkedContextCode = "BeneficalReputationInput";
        userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU(beneownerid, "ENTITY", jwtId, linkedContextCode, beneownerid);

        for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {
            if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
                valueDiff.put(GlobalStaticInfo.reputationAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
            }
        }
        for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
            String oldInd = entry2.getValue().split(",")[0];
            String newInd = entry2.getValue().split(",")[1];
        }
        ObjectMapper mapper = new ObjectMapper();
        payload2 = mapper.writeValueAsString(GeneratePayloadRepInput.repu_payload(OldValueMap));
        Res = request.log().all().body(payload2).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url+beneownerid).andReturn();
        logger.info("Response----->:" + Res.prettyPrint());
        TransactionLog.dbRows = null;
    }

    @Then("^The API should return success response and updateRecord should be zero$")
    public void api_should_return_success_response_and_updateRecord_should_be_zero() throws Throwable {
        Assert.assertEquals(Res.getStatusCode(), 200);
        JsonPath jsonPathEvaluator = Res.jsonPath();
        Assert.assertEquals(jsonPathEvaluator.get("updatedRecordCount").toString(),"0");
    }

    @When("^A valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate invalid smsession$")
    public void valid_user_to_generate_invalid_smsession(String username, String password, String buid) throws Throwable {
        resultbody = "abc"+GetSmsessionToken.generateSmsessionToken(username,password);
        logger.info("SMSession Cookie: " +resultbody);
        Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url+beneownerid).andReturn();
    }

    @When("^A valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" runs a request for an invalid beneownerid$")
    public void invalid_beneownerid_to_generate_invalid_smsession(String username, String password, String buid) throws Throwable {
        logger.info("In When parameters are passed with null values get the data from DB");
        String Query= "select POLITICALLYEXPOSED,ADVERSEMEDIA,SARORSTRIND,AML,OFAC,LOCALSANCTIONS,PLM,MARIJUANA from BENEFICIARYREPUTATION where ENTITYBENEFICIALOWNERID ='"+ beneownerid + "'";
        null_Value = TransactionLog.GetNullValues(Repu_Data, Query);
        Assert.assertNotNull(null_Value);
    }

    @Then("^The API should return proper error message and response should contain error code as \"([^\"]*)\" and error message as \"([^\"]*)\"$")
    public void api_should_return_proper_error_message_and_response_should_contain_error_code_as_and_error_message_as(String errCode, String errMsg) throws Throwable {
        Assert.assertEquals(Res.getStatusCode(), 400);
        JsonPath jsonPathEvaluator = Res.jsonPath();
        Assert.assertEquals("400",errCode);
        Assert.assertEquals("Bad Request",errMsg);
    }

    @Then("^The API should return error 500 message$")
    public void api_should_return_proper_error_message_and_response_should_contain_error_code_as_and_error_message_as() throws Throwable {
        Assert.assertEquals(Res.getStatusCode(), 500);
    }
}


