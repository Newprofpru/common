package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.contactAddresses;
import com.Profile.RequestBodyPojo.contactChannels;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GetJwtToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class auditLogProfile {

	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static Response Res1;
	static Response Res2;
	String Service_Url = getEnvInfo.getSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	String requestID = null;
	String SSOID =null;
	String coUserId = null;
	String mincoUserId = null;
	String ContractID = null;
	String profileId = null;
	String userTransactionlogID = null;
	ResultSet rs,rs1,rs2,rs3;
	Map<String, String> data;
	Set<String> contactAddressTypes = new HashSet<>();
	Set<String> contactPhoneTypes = new HashSet<>();
	boolean isNullNeeded = false;
	profile profile = new profile();
	List<contactChannels> contactChannels = new ArrayList<>();
	List<contactAddresses> contactAddresses = new ArrayList<>();
	
	JsonObject profileObjectOld = new JsonObject();
	JsonObject personalInfoObjectOld = new JsonObject();
	JsonArray contactAddressArrayOld = new JsonArray();
	JsonArray contactChannelArrayOld = new JsonArray();
	JsonObject profileObject = new JsonObject();
	JsonObject personalInfoObject = new JsonObject();
	JsonArray contactAddressArray = new JsonArray();
	JsonArray contactChannelArray = new JsonArray();
	
	@Given("^the endpoint exist for \"([^\"]*)\"$")
	public void the_endpoint_exist_for(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	public boolean isUniqueSSOID(){
		Connection con = DBConnection.InitConnection();
		String query = "select * from couser where ssoid = '"+SSOID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("SSOID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	public boolean isUniqueContID(){
		Connection con = DBConnection.InitConnection();
		String query = "select * from usercontractprofile where contractid = '"+ContractID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("CONTRACTID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	@When("^a POST request is sent to profile API for creating user level profile with below request body$")
	public void a_POST_request_is_sent_to_profile_API_for_creating_user_level_profile_with_below_request_body(DataTable parameters) throws Throwable {
		logger.info("In When a POST request is sent to profile API with below request body data");
		isNullNeeded = false;
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		SSOID = profile.getSsoId();
		while(!isUniqueSSOID()){
			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
		}
		profile.setssoId(SSOID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());	   
	}

	@When("^a POST request is sent to profile API for creating contract level profile with below request body$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_creating_contract_level_profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		isNullNeeded = false;
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		SSOID = profile.getSsoId();
		while(!isUniqueSSOID()){
			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
		}
		profile.setssoId(SSOID);
		ContractID = profile.getContractId();
		while(!isUniqueContID()){
			ContractID  = RandomStringUtils.random(10, true, true).toUpperCase();
		}
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}	
	
	@When("^a POST request is sent to profile API for creating secondary profile with below request body$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_secondary_profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		SSOID = profile.getSsoId();
		while(!isUniqueSSOID()){
			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
		}
		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@When("^a POST request is sent to profile API for creating minor profile with below request body$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_Minor_profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
//		String CSRJwt = getCSRToken();
		String CSRJwt=GetJwtToken.createCSRFromService();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-PruAuthJWT",CSRJwt)
				.header("X-PruImpersonatedIdentity",SSOID)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@Then("^the success response code 200 is recieved and verified$")
	public void the_success_response_code_is_recieved_and_verified() throws Throwable {
		try{
			logger.info("In Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		String profileStr=null;
		logger.info("In And the data is updated in db");
		Gson gson = new Gson();
		try{		
			profileStr = gson.toJson(profile);		
		String resBody=Res1.getBody().asString();
		JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		coUserId = responseObject.get("coUserId").getAsString();
		if(profileObject.has("personalInfo"))
			personalInfoObjectOld = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArrayOld = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArrayOld = profileObject.get("contactChannels").getAsJsonArray();
		}catch(Exception e){
			logger.info(e.getMessage());
			}
	}
	
	@When("^the PUT request is sent to API with below request body data of user level Profile$")
	public void the_PUT_request_is_sent_to_API_with_below_request_body_data_of_user_level_Profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException {
			logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
			Random rand = new Random();
			Connection con = DBConnection.InitConnection();
			List<contactChannels> contactChannelsTest = new ArrayList<>();
			List<contactChannels> contactChannelsTest1 = new ArrayList<>();
			List<contactAddresses> contactAddressTest = new ArrayList<>();
			List<contactAddresses> contactAddressTest1 = new ArrayList<>();	
			isNullNeeded = false;
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			requestID = "profileUpdate" + n;
			RestAssured.baseURI = Service_Url;
			Map<String, String> data = parameters.asMap(String.class, String.class);
			profileId = data.get("profile_id");
			profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
			profile.setcoUserId(coUserId);
			profile.setssoId(SSOID);				
			if(profile.getContactChannels()!=null){
				contactChannelsTest=profile.getContactChannels();
			}
			if(profile.getContactAddresses()!=null){
				contactAddressTest=profile.getContactAddresses();
			}
			for(contactChannels cc:contactChannelsTest){
				String query = "Select * from usercontact where couserid = '"+coUserId+"' and contractid is null and CONTACTCHANNELCODE = '"+cc.getContactChannel()+"' and CONTACTTYPECODE = '"+cc.getContactChannelType()+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					cc.setcontactChannelId(rscont.getString("USERCONTACTID"));
				}
				contactChannelsTest1.add(cc);
			}
			profile.setcontactChannels(null);
			profile.setcontactChannels(contactChannelsTest1);
			for(contactAddresses ca:contactAddressTest){
				String query = "Select * from useraddress where couserid = '"+coUserId+"' and contractid is null and ADDRESSTYPECODE = '"+ca.getAddressType()+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					ca.setcontactAddressId(rscont.getString("USERADDRESSID"));
				}
				contactAddressTest1.add(ca);
			}
			profile.setcontactAddresses(null);
			profile.setcontactAddresses(contactAddressTest1);
					request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0");
			Gson gson = new Gson();
			String body = gson.toJson(profile);
			logger.info("body ----> "+body);
			Res2 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res2.prettyPrint());			 
	}

	@When("^the PUT request is sent to API with below request body data of contract level Profile$")
	public void the_PUT_request_is_sent_to_API_with_below_request_body_data_of_contract_level_Profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException {
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		Connection con = DBConnection.InitConnection();
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		List<contactAddresses> contactAddressTest = new ArrayList<>();
		List<contactAddresses> contactAddressTest1 = new ArrayList<>();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profileId = data.get("profile_id");
		profile = RequestBodyPojoCreater.getProfile(profileId,isNullNeeded);
		profile.setcoUserId(coUserId);
		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		profile.setbusinessUnit("Investments");
		if(profile.getContactChannels()!=null){
			contactChannelsTest=profile.getContactChannels();
		}
		if(profile.getContactAddresses()!=null){
			contactAddressTest=profile.getContactAddresses();
		}
		for(contactChannels cc:contactChannelsTest){
			String query = "Select * from usercontact where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and CONTACTCHANNELCODE = '"+cc.getContactChannel()+"' and CONTACTTYPECODE = '"+cc.getContactChannelType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				cc.setcontactChannelId(rscont.getString("USERCONTACTID"));
			}
			contactChannelsTest1.add(cc);
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		for(contactAddresses ca:contactAddressTest){
			String query = "Select * from useraddress where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and ADDRESSTYPECODE = '"+ca.getAddressType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				ca.setcontactAddressId(rscont.getString("USERADDRESSID"));
			}
			contactAddressTest1.add(ca);
		}
		profile.setcontactAddresses(null);
		profile.setcontactAddresses(contactAddressTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res2 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res2.prettyPrint());
	}	
	
	@When("^the PUT request is sent to API with below request body data of secondary JA Profile$")
	public void a_PUT_request_is_sent_to_API_with_above_request_body_details(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException,SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Connection con = DBConnection.InitConnection();
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		List<contactAddresses> contactAddressTest = new ArrayList<>();
		List<contactAddresses> contactAddressTest1 = new ArrayList<>();
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		profile.setcoUserId(coUserId);
		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		profile.setbusinessUnit("Investments");
		if(profile.getContactChannels()!=null){
			contactChannelsTest=profile.getContactChannels();
		}
		if(profile.getContactAddresses()!=null){
			contactAddressTest=profile.getContactAddresses();
		}
		for(contactChannels cc:contactChannelsTest){
			String query = "Select * from usercontact where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and CONTACTCHANNELCODE = '"+cc.getContactChannel()+"' and CONTACTTYPECODE = '"+cc.getContactChannelType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				cc.setcontactChannelId(rscont.getString("USERCONTACTID"));
			}
			contactChannelsTest1.add(cc);
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		for(contactAddresses ca:contactAddressTest){
			String query = "Select * from useraddress where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and ADDRESSTYPECODE = '"+ca.getAddressType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				ca.setcontactAddressId(rscont.getString("USERADDRESSID"));
			}
			contactAddressTest1.add(ca);
		}
		profile.setcontactAddresses(null);
		profile.setcontactAddresses(contactAddressTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res2 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res2.prettyPrint());
		}	
	
	@When("^the PUT request is sent to API with below request body data of minor Profile$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_minor(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException,SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Connection con = DBConnection.InitConnection();
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		List<contactAddresses> contactAddressTest = new ArrayList<>();
		List<contactAddresses> contactAddressTest1 = new ArrayList<>();
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		String CSRJwt=GetJwtToken.createCSRFromService();
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		profile.setminorCoUserId(coUserId);
		profile.setcontractId(ContractID);
		profile.setbusinessUnit("Investments");
		if(profile.getContactChannels()!=null){
			contactChannelsTest=profile.getContactChannels();
		}
		if(profile.getContactAddresses()!=null){
			contactAddressTest=profile.getContactAddresses();
		}
		for(contactChannels cc:contactChannelsTest){
			String query = "Select * from usercontact where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and CONTACTCHANNELCODE = '"+cc.getContactChannel()+"' and CONTACTTYPECODE = '"+cc.getContactChannelType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				cc.setcontactChannelId(rscont.getString("USERCONTACTID"));
			}
			contactChannelsTest1.add(cc);
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		for(contactAddresses ca:contactAddressTest){
			String query = "Select * from useraddress where couserid = '"+coUserId+"' and contractid ='"+ContractID+"' and ADDRESSTYPECODE = '"+ca.getAddressType()+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				ca.setcontactAddressId(rscont.getString("USERADDRESSID"));
			}
			contactAddressTest1.add(ca);
		}
		profile.setcontactAddresses(null);
		profile.setcontactAddresses(contactAddressTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-PruAuthJWT",CSRJwt)
				.header("X-PruImpersonatedIdentity",SSOID)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res2 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res2.prettyPrint());
		}
	
	@Then("^the data is updated correctly and success response code 200 is recieved$")
	public void the_data_is_updated_correctly_and_success_response_code_is_recieved() throws Throwable {
		try{
			logger.info("\nIn--------------------> Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res2.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}	    
	}		

	@Then("^the success message is logged in auditlog table for type PROFILE$")
	public void the_success_message_is_logged_in_auditlog_table_for_type_PROFILE() throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type Profile");
		TransactionLog audit = new TransactionLog();		
		String typeCode = "PROFILE";
		String message = null;
		if(profile.getContractId()!=""){
			message = profile.getContractId();
		}		
		String linkedContextCode="UpdateProfileRequest";		
		userTransactionlogID=audit.auditlog_should_match_in_db_for_profile(SSOID, typeCode, message, linkedContextCode);	    
	}

	@Then("^the fields are audited and verified successfully$")
	public void the_fields_are_audited_and_verified_successfully() throws Throwable {
		Connection con = null;
		String relnType = null;
		TransactionLog audit = new TransactionLog();
		logger.info("In And the data is updated in db for the fields that are audited");
		Gson gson = new Gson();
		try{
		String profileStr = gson.toJson(profile);
		profileObject = (JsonObject) new JsonParser().parse(profileStr);
		if(profileObject.has("personalInfo"))
			personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
		if(profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Primary"))
			relnType = "Primary Owner";			
		else if (profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Secondary"))
			relnType = "Secondary Owner";
		else if(profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Custodian"))
			relnType = "Custodian";			
		else if (profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Minor"))
			relnType = "Minor";
		try{		
		Set<String> PersInUserTranUpddtlSet = GlobalStaticInfo.PersInUserTranUpddtl.keySet();		
		for(String PersInUserTranUpddtlElement:PersInUserTranUpddtlSet){
			if(personalInfoObject.has(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement))){
			if(!personalInfoObject.get(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement)).getAsString().equals("")){
				audit.getAlltransactionAuditLogsforUpdate(userTransactionlogID,PersInUserTranUpddtlElement,personalInfoObject.get(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement)).getAsString(),personalInfoObjectOld.get(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement)).getAsString());					
			}
			else
				logger.info(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement)+" is null");
			}
			else
				logger.info(GlobalStaticInfo.PersInUserTranUpddtl.get(PersInUserTranUpddtlElement)+" is null");
			}			
		
		Set<String> contAddrUserTranUpddtlSet = GlobalStaticInfo.contAddrUserTranUpddtl.keySet();
		if(profileObject.has("contactAddresses")){
			for(int j=0;j<contactAddressArray.size();j++){
				JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
				JsonObject contactAddressObjectOld = contactAddressArrayOld.get(j).getAsJsonObject();
				String newAddType=GlobalStaticInfo.addrTypeUserTranslogdtl.get(contactAddressObject.get("addressType").getAsString());
				for(String contAddrUserTranUpddtlElement:contAddrUserTranUpddtlSet){
					if(!contactAddressObject.get(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddrUserTranUpddtlElement)).getAsString().equals("")){
						if(relnType==null)
						audit.getAlltransactionAuditLogsforUpdate(userTransactionlogID,newAddType+" "+contAddrUserTranUpddtlElement,contactAddressObject.get(GlobalStaticInfo.contAddrUserTranUpddtl.get(contAddrUserTranUpddtlElement)).getAsString(),contactAddressObjectOld.get(GlobalStaticInfo.contAddrUserTranUpddtl.get(contAddrUserTranUpddtlElement)).getAsString());
						
						else
							audit.getAlltransactionAuditLogsforUpdate(userTransactionlogID,relnType+" "+newAddType+" "+contAddrUserTranUpddtlElement,contactAddressObject.get(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddrUserTranUpddtlElement)).getAsString(),contactAddressObjectOld.get(GlobalStaticInfo.contAddrUserTranUpddtl.get(contAddrUserTranUpddtlElement)).getAsString());
					}
					else
						logger.info(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddrUserTranUpddtlElement)+" is null");
				}
			}
		}
		Set<String> contChanUserTranUpddtlSet = GlobalStaticInfo.contChanUserTranUpddtl.keySet();
		if(profileObject.has("contactChannels")){
			for(int k=0;k<contactChannelArray.size();k++){
				JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
				JsonObject contactChannelObjectOld = contactChannelArrayOld.get(k).getAsJsonObject();
				String newChannel = null;
				if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("Email")){
					if(contactChannelObject.get("contactChannelType").getAsString().contains("RECORD"))
						newChannel = GlobalStaticInfo.emailTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString());
					else 
						newChannel = GlobalStaticInfo.emailTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString())+" Email";
				}
				else if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("Phone")){
					if(contactChannelObject.get("contactChannelType").getAsString().contains("RECORD"))
						newChannel = GlobalStaticInfo.phoneTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString());
					else
						newChannel = GlobalStaticInfo.phoneTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString())+" Phone";
				}
				for(String contChanUserTranUpddtlElement:contChanUserTranUpddtlSet){
					if(!contactChannelObject.get(GlobalStaticInfo.contChanUserTranUpddtl.get(contChanUserTranUpddtlElement)).getAsString().equals("")){
						if(relnType==null)
						audit.getAlltransactionAuditLogsforUpdate(userTransactionlogID,newChannel+" "+contChanUserTranUpddtlElement,contactChannelObject.get(GlobalStaticInfo.contChanUserTranUpddtl.get(contChanUserTranUpddtlElement)).getAsString(),contactChannelObjectOld.get(GlobalStaticInfo.contChanUserTranUpddtl.get(contChanUserTranUpddtlElement)).getAsString());
						else
							audit.getAlltransactionAuditLogsforUpdate(userTransactionlogID,relnType+" "+newChannel+" "+contChanUserTranUpddtlElement,contactChannelObject.get(GlobalStaticInfo.contChannelUserTranslogdtl.get(contChanUserTranUpddtlElement)).getAsString(),contactChannelObjectOld.get(GlobalStaticInfo.contChanUserTranUpddtl.get(contChanUserTranUpddtlElement)).getAsString());
					}
					else
						logger.info(newChannel+" "+contChanUserTranUpddtlElement+" is null");
				}
			}
		}
		}catch(Exception e){
			logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}
			TransactionLog.dbRows = null;	
		}
	}catch(Exception e){
		logger.info(e.getMessage());
		}
	   
	}	
	
	@Then("^the success message is logged in auditlog table for type PROFILE for minor$")
	public void the_success_message_is_logged_in_audit_table_for_type_PROFILE_for_minor() throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type Profile");
		TransactionLog audit = new TransactionLog();
		String typeCode = "PROFILE";
		String Message = null;
		String linkedContextCode="UpdateProfileRequest";
		if(profile.getContractId()!=""){
			Message = profile.getContractId();
		}
		userTransactionlogID=audit.auditlog_should_match_in_db_for_profile_for_minor(coUserId, typeCode, Message, linkedContextCode);
	}	
}
