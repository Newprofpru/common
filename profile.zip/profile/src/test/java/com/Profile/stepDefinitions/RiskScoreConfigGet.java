package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GetSmsessionToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RiskScoreConfigGet {


	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static Response Res1;
	String Authorization = getEnvInfo.getRepAuthorization();
	String Service_Url = getEnvInfo.getSecureUrlRiskScore();
	String ivUser = getEnvInfo.getIVuser();
	JsonArray industryArray = new JsonArray();
	JsonArray countryArray = new JsonArray();
	JsonArray occupationArray = new JsonArray();
	String resultbody;
	String type;
	String que,query1;
	ResultSet rs1;
	static Map<String, String> data;
	JsonObject responseObject = new JsonObject();
	JsonObject eventsBody = new JsonObject();
	JsonObject eventResponse = new JsonObject();
	@Given("^the valid endpoint exists for AMLU \"([^\"]*)\"$")
	public void valid_endpoint_exists_for_AMLU(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	@When("^a valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate smsession$")
	public void a_valid_user_to_generate_smsession(String username, String password, String buid) throws Throwable {		
		resultbody = GetSmsessionToken.generateSmsessionToken(username,password);
		logger.info("SMSession Cookie: " +resultbody);	    
	}
	
	@When("^the user sends a GET request to RiskScore API with below parameters$")
	public void the_user_sends_a_GET_request_to_RiskScore_API_with_below_parameters(DataTable parameters){
		data = parameters.asMap(String.class, String.class);
		Set<String> paramNames=data.keySet();
		logger.info("In When");
		Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "RiskScoreGet" + n;
		RestAssured.baseURI = Service_Url;
		request = given().log().all()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0")
				.header("Cookie", resultbody);
		for(String paramName:paramNames){			
				request.param(paramName,data.get(paramName));
				type = data.get(paramName);
		}
		Res1 = request.when().get(Service_Url).andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
	}
	
	@Then("^the user recieves correct responsebody for industry and is verified with db$")
	public void user_recieves_correct_responsebody_for_industry_and_is_verified_in_db() throws SQLException, ParseException{
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);			
		JsonObject riskConfigObject  = responseObject.get("riskScoreConfig").getAsJsonObject();
		Assert.assertEquals(riskConfigObject.get("type").getAsString(),type,"type received in the Response");
		JsonObject demObject  = riskConfigObject.get("demography").getAsJsonObject();
		if(demObject.has("industry")){
			industryArray  = demObject.get("industry").getAsJsonArray();
		}
		Connection con = DBConnection.InitConnection();	
		Statement stmt = con.createStatement();
		try{			
			for(int i=0;i<industryArray.size();i++){			
				Set<String> industryAmluSet = GlobalStaticInfo.industryAmlu.keySet();
				if(demObject.has("industry")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("Size of IndustryCodes from JSON are:");
					for(int l=0;l<industryArray.size();l++){
						elm = industryArray.get(l).getAsJsonObject().get("industryCode").getAsString();
						idJsonArray.add(elm);						
					}
					logger.info(idJsonArray.size());
					que = "select * from industrymaster";
					logger.info("Size of Industrycodes from db are ");
					
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("INDUSTRYCODE");
						idDbArray.add(elm);						
					}
					logger.info(idDbArray.size()-1);
					Collections.sort(idJsonArray);
					Assert.assertEquals(idJsonArray.size(),idDbArray.size() ,"Industrycodes in response JSON are same as in db");
					logger.info("Industrycodes in response JSON are same as in db");
					try{
						for(int k=0;k<industryArray.size();k++){
							JsonObject industryObject = industryArray.get(k).getAsJsonObject();
							query1 ="Select * from industrymaster where INDUSTRYCODE = '"+industryObject.get("industryCode").getAsString()+"'";
		//						rs1 = DBConnection.execStatement(con,query1);
							rs1 = stmt.executeQuery(query1);
							while(rs1.next()){
								for(String industryAmluElement:industryAmluSet){
									if(!industryObject.get(GlobalStaticInfo.industryAmlu.get(industryAmluElement)).isJsonNull()){
									 Assert.assertEquals(rs1.getString(industryAmluElement),industryObject.get(GlobalStaticInfo.industryAmlu.get(industryAmluElement)).getAsString(),GlobalStaticInfo.industryAmlu.get(industryAmluElement)+" is Equal");
									 logger.info(GlobalStaticInfo.industryAmlu.get(industryAmluElement)+" is equal,value is "+rs1.getString(industryAmluElement));
									}
									else
										logger.info(GlobalStaticInfo.industryAmlu.get(industryAmluElement)+" is null");
								}					
							}
						}
					}
					finally {
					    try { stmt.close(); } catch (Exception e) 
					    { logger.info(e.getMessage()); }
					}
				}			
			}		
		}
        catch(Exception e){
            logger.info(e.getMessage());
        }finally {
            if (con != null) {
                con.close();                
            }
        }	
	}
	
	@Then("^the user recieves correct responsebody for country and is verified with db$")
	public void user_recieves_correct_responsebody_for_country_and_is_verified_in_db() throws SQLException, ParseException{
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);			
		JsonObject riskConfigObject  = responseObject.get("riskScoreConfig").getAsJsonObject();
		Assert.assertEquals(riskConfigObject.get("type").getAsString(),type,"type received in the Response");
		JsonObject geoObject  = riskConfigObject.get("geography").getAsJsonObject();
		if(geoObject.has("countrycode")){
			countryArray  = geoObject.get("countrycode").getAsJsonArray();
		}
		Connection con = DBConnection.InitConnection();	
		Statement stmt = con.createStatement();
		try{			
			for(int i=0;i<countryArray.size();i++){			
				Set<String> countryAmluSet = GlobalStaticInfo.countryAmlu.keySet();
				if(geoObject.has("countrycode")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("Size of CountryCodes from JSON are:");
					for(int l=0;l<countryArray.size();l++){
						elm = countryArray.get(l).getAsJsonObject().get("countryCode").getAsString();
						idJsonArray.add(elm);						
					}
					logger.info(idJsonArray.size());
					que = "select * from countrymaster";
					logger.info("Size of Countrycodes from db are ");
					
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("COUNTRYCODE");
						idDbArray.add(elm);						
					}
					logger.info(idDbArray.size()-1);
					Collections.sort(idJsonArray);
					Assert.assertEquals(idJsonArray.size(),idDbArray.size()-1 ,"Countrycodes in response JSON are same as in db");
					logger.info("Countrycodes in response JSON are same as in db");
					try{
						for(int k=0;k<countryArray.size();k++){
							JsonObject countryObject = countryArray.get(k).getAsJsonObject();
							query1 ="Select * from countrymaster where COUNTRYCODE = '"+countryObject.get("countryCode").getAsString()+"'";
		//						rs1 = DBConnection.execStatement(con,query1);
							rs1 = stmt.executeQuery(query1);
							while(rs1.next()){
								for(String countryAmluElement:countryAmluSet){
									if(!countryObject.get(GlobalStaticInfo.countryAmlu.get(countryAmluElement)).isJsonNull()){
									 Assert.assertEquals(rs1.getString(countryAmluElement),countryObject.get(GlobalStaticInfo.countryAmlu.get(countryAmluElement)).getAsString(),GlobalStaticInfo.countryAmlu.get(countryAmluElement)+" is Equal");
									 logger.info(GlobalStaticInfo.countryAmlu.get(countryAmluElement)+" is equal,value is "+rs1.getString(countryAmluElement));
									}
									else
										logger.info(GlobalStaticInfo.countryAmlu.get(countryAmluElement)+" is null");
								}					
							}
						}
					}
					finally {
					    try { stmt.close(); } catch (Exception e) 
					    { logger.info(e.getMessage()); }
					}
				}			
			}		
		}
        catch(Exception e){
            logger.info(e.getMessage());
        }finally {
            if (con != null) {
                con.close();                
            }
        }	
	}
	
	@Then("^the user recieves correct responsebody for occupation and is verified with db$")
	public void user_recieves_correct_responsebody_for_occupation_and_is_verified_in_db() throws SQLException, ParseException{
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody=Res1.getBody().asString();
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);			
		JsonObject riskConfigObject  = responseObject.get("riskScoreConfig").getAsJsonObject();
		Assert.assertEquals(riskConfigObject.get("type").getAsString(),type,"type received in the Response");
		JsonObject demObject  = riskConfigObject.get("demography").getAsJsonObject();
		if(demObject.has("occupation")){
			occupationArray  = demObject.get("occupation").getAsJsonArray();
		}
		Connection con = DBConnection.InitConnection();	
		Statement stmt = con.createStatement();
		try{			
			for(int i=0;i<occupationArray.size();i++){			
				Set<String> occupationAmluSet = GlobalStaticInfo.occupationAmlu.keySet();
				if(demObject.has("occupation")){
					List<String> idDbArray = new ArrayList<>();
					List<String> idJsonArray = new ArrayList<>();
					String elm =null;
					logger.info("Size of OccupationCodes from JSON are:");
					for(int l=0;l<occupationArray.size();l++){
						elm = occupationArray.get(l).getAsJsonObject().get("occupationCode").getAsString();
						idJsonArray.add(elm);						
					}
					logger.info(idJsonArray.size());
					que = "select * from occupationmaster";
					logger.info("Size of Occupationcodes from db are ");
					
					ResultSet res = DBConnection.execStatement(con,que);
					while(res.next()){
						elm = res.getString("OCCUPATIONCODE");
						idDbArray.add(elm);						
					}
					logger.info(idDbArray.size()-1);
					Collections.sort(idJsonArray);
					Assert.assertEquals(idJsonArray.size(),idDbArray.size(),"Occupationcodes in response JSON are same as in db");
					logger.info("Occupationcodes in response JSON are same as in db");
					try{
						for(int k=0;k<occupationArray.size();k++){
							JsonObject occupationObject = occupationArray.get(k).getAsJsonObject();
							query1 ="Select * from occupationmaster where OCCUPATIONCODE = '"+occupationObject.get("occupationCode").getAsString()+"'";
		//						rs1 = DBConnection.execStatement(con,query1);
							rs1 = stmt.executeQuery(query1);
							while(rs1.next()){
								for(String occupationAmluElement:occupationAmluSet){
									if(!occupationObject.get(GlobalStaticInfo.occupationAmlu.get(occupationAmluElement)).isJsonNull()){
									 Assert.assertEquals(rs1.getString(occupationAmluElement),occupationObject.get(GlobalStaticInfo.occupationAmlu.get(occupationAmluElement)).getAsString(),GlobalStaticInfo.occupationAmlu.get(occupationAmluElement)+" is Equal");
									 logger.info(GlobalStaticInfo.occupationAmlu.get(occupationAmluElement)+" is equal,value is "+rs1.getString(occupationAmluElement));
									}
									else
										logger.info(GlobalStaticInfo.occupationAmlu.get(occupationAmluElement)+" is null");
								}					
							}
						}
					}
					finally {
					    try { stmt.close(); } catch (Exception e) 
					    { logger.info(e.getMessage()); }
					}
				}			
			}		
		}
        catch(Exception e){
            logger.info(e.getMessage());
        }finally {
            if (con != null) {
                con.close();                
            }
        }	
	}
	
	@Then("^the user recieves correct responsebody for default value and is verified with db$")
	public void user_recieves_correct_responsebody_for_defaultValue_and_is_verified_in_db()
			throws SQLException, ParseException {
		Connection con = null;
		Connection con1 = null;
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		String resBody = Res1.getBody().asString();
		JsonObject amluObject = (JsonObject) new JsonParser().parse(resBody);
		try {
			if (amluObject.has("riskScoreConfig"))
				responseObject = amluObject.get("riskScoreConfig").getAsJsonObject();

			if (responseObject.has("sourceOfFunds")) {
				eventsBody = responseObject.get("sourceOfFunds").getAsJsonObject();
				eventResponse = eventsBody.get("paymentMethod").getAsJsonObject();
				JsonElement defaultEvent = eventResponse.get("default");
				queryExecute();
			}
			if (responseObject.has("product")) {
				eventsBody = responseObject.get("product").getAsJsonObject();
				eventResponse = eventsBody.get("productCashvalue").getAsJsonObject();
				eventResponse = eventsBody.get("multipleProductCashvalue").getAsJsonObject();
				JsonElement defaultEvent = eventResponse.get("default");
				queryExecute();
			}
			if (responseObject.has("demography")) {
				eventsBody = responseObject.get("demography").getAsJsonObject();
				eventResponse = eventsBody.get("beneOwnersNameAddress").getAsJsonObject();
				eventResponse = eventsBody.get("beneOwnersPercent").getAsJsonObject();
				eventResponse = eventsBody.get("typeCode").getAsJsonObject();
				JsonElement defaultEvent = eventResponse.get("default");
				queryExecute();
			}
			if (responseObject.has("reputation")) {
				eventsBody = responseObject.get("reputation").getAsJsonObject();
				eventResponse = eventsBody.get("marijuana").getAsJsonObject();
				eventResponse = eventsBody.get("pfc").getAsJsonObject();
				eventResponse = eventsBody.get("beneMarijuana").getAsJsonObject();
				eventResponse = eventsBody.get("benePFC").getAsJsonObject();
				eventResponse = eventsBody.get("adverseMedia").getAsJsonObject();
				eventResponse = eventsBody.get("transactionMedia").getAsJsonObject();
				eventResponse = eventsBody.get("ofac").getAsJsonObject();
				eventResponse = eventsBody.get("localSanctions").getAsJsonObject();
				eventResponse = eventsBody.get("sar").getAsJsonObject();
				eventResponse = eventsBody.get("beneOFAC").getAsJsonObject();
				eventResponse = eventsBody.get("beneAdverseMedia").getAsJsonObject();
				JsonElement defaultEvent = eventResponse.get("default");
				queryExecute();
			}

			con = DBConnection.InitConnection();
			con1 = DBConnection.InitConnection();
			
			query1 = "SELECT JSON_VALUE(subruleconfig,'$.default') as defaultEvent from ruleconfig where subrulename='"	+ data.get("type") + "' order by updateddate desc";

			ResultSet resultset = DBConnection.execStatement(con1, query1);
			Set<String> eventSet = GlobalStaticInfo.defaultAmlu.keySet();
			if (responseObject.has("riskScoreConfig")) {

				JsonObject eventsListObject = eventsBody.getAsJsonObject();
				resultset.next();
				for (String fieldsElement : eventSet) {
					if (null != eventsListObject.get(GlobalStaticInfo.defaultAmlu.get(fieldsElement))&& !eventsListObject.get(GlobalStaticInfo.defaultAmlu.get(fieldsElement)).getAsString().equals("")) {
						Assert.assertEquals(resultset.getString(fieldsElement),eventsListObject.get(GlobalStaticInfo.defaultAmlu.get(fieldsElement)).getAsString(),GlobalStaticInfo.defaultAmlu.get(fieldsElement) + " is Equal");
						logger.info(GlobalStaticInfo.defaultAmlu.get(fieldsElement) + " is equal,value is "+ resultset.getString(fieldsElement));
					} else
						logger.info(GlobalStaticInfo.defaultAmlu.get(fieldsElement) + " is null");
				}
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		} finally {
			if (con != null) {
				con.close();
				con1.close();
			}
		}
	}

	private void queryExecute() {
		if (data.containsKey("type")) {
			query1 = "SELECT JSON_VALUE(subruleconfig,'$.default') as defaultEvent from ruleconfig where subrulename='"	+ data.get("type") + "' order by updateddate desc";
		}

	}

}
