package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.contactAddresses;
import com.Profile.RequestBodyPojo.contactChannels;
import com.Profile.RequestBodyPojo.disclosures;
import com.Profile.RequestBodyPojo.investmentInfo;
import com.Profile.RequestBodyPojo.personalInfo;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.RequestBodyPojo.suitability;
import com.Profile.RequestBodyPojo.trustedContactPerson;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GetJwtToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;

import static com.Profile.supportLibraries.GetJwtTokenCSR.getCSRToken;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class minorCustodianCreate {

	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static Response Res1;
	String Service_Url = getEnvInfo.getSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	String SSOID =null;
	String coUserId = null;
	String ContractID = null;
	String requestID = null;
	String userTransactionlogID =null;
	profile profile = new profile();
	personalInfo personalInfo = new personalInfo();
	disclosures disclosures = new disclosures();
	suitability suitability = new suitability();
	investmentInfo investmentInfo = new investmentInfo();
	trustedContactPerson trustedContactPerson = new trustedContactPerson();
	List<contactChannels> contactChannels = new ArrayList<>();
	List<contactAddresses> contactAddresses = new ArrayList<>();
	
	@Given("^a valid working endpoint exists for the \"([^\"]*)\" API$")
	public void a_valid_endpoint_for_GetMasterKey(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	public boolean isUniqueSSOID(){
		Connection con = DBConnection.InitConnection();
		String query = "select * from couser where ssoid = '"+SSOID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("SSOID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	public boolean isUniqueContID(){
		Connection con = DBConnection.InitConnection();
		String query = "select * from usercontractprofile where contractid = '"+ContractID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("CONTRACTID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	@When("^a POST request is sent to profile API with below request body data for Custodian profile$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_Custodian_profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		SSOID = profile.getSsoId();
		while(!isUniqueSSOID()){
			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
		}
		profile.setssoId(SSOID);
		ContractID = profile.getContractId();
		while(!isUniqueContID()){
			ContractID  = RandomStringUtils.random(10, true, true).toUpperCase();
		}
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@When("^a POST request is sent to profile API with below request body data for minor profile$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_Minor_profile(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
//		String CSRJwt = getCSRToken();
		String CSRJwt=GetJwtToken.createCSRFromService();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
//		SSOID = profile.getSsoId();
//		while(!isUniqueSSOID()){
//			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
//		}
//		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-PruAuthJWT",CSRJwt)
				.header("X-PruImpersonatedIdentity",SSOID)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@When("^a POST request is sent to profile API with below request body data for minor profile with custodian ssoid in header$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_Minor_profile_with_custodian_ssoid_in_header(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		//String CSRJwt = getCSRToken();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
//		SSOID = profile.getSsoId();
//		while(!isUniqueSSOID()){
//			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
//		}
//		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				//.header("X-PruAuthJWT",CSRJwt)
				.header("X-PruPrimaryIdentity",SSOID)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@When("^a POST request is sent to profile API with below request body data for minor profile with custodian ssoid as X-PruImpersonatedIdentity in header$")
	public void a_POST_request_is_sent_to_profile_API_with_above_request_body_details_for_Minor_profile_with_custodian_ssoid_as_PruImpersonatedIdentity_in_header(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("In When a POST request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;
		RestAssured.baseURI = Service_Url;
		//String CSRJwt = getCSRToken();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
//		SSOID = profile.getSsoId();
//		while(!isUniqueSSOID()){
//			SSOID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
//		}
//		profile.setssoId(SSOID);
		profile.setcontractId(ContractID);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				//.header("X-PruAuthJWT",CSRJwt)
				.header("X-PruImpersonatedIdentity",SSOID)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@Then("^the data is created succesfully and success response code 200 is recieved from API$")
	public void the_data_is_created_and_success_response_code_200_is_recieved(){
		try{
			logger.info("In Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@And("^the data is created in db successfully$")
	public void the_data_is_created_in_db() throws SQLException, ParseException{
		String query1 = null,query2=null,query3=null,query4=null;
		ResultSet rs,rs1,rs2,rs3;
		logger.info("In And the data is updated in db");
		Gson gson = new Gson();
		Connection con = null;
		try{
		String profileStr = gson.toJson(profile);
		String resBody=Res1.getBody().asString();
		JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		coUserId = responseObject.get("coUserId").getAsString();
		JsonObject personalInfoObject = new JsonObject();
		JsonObject disclosureObject = new JsonObject();
		JsonObject suitablityObject = new JsonObject();
		JsonObject investmentObject = new JsonObject();
		JsonObject trustContObject = new JsonObject();
		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		if(profileObject.has("personalInfo"))
			personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("disclosures"))
			disclosureObject = profileObject.get("disclosures").getAsJsonObject();
		if(profileObject.has("suitability"))
			suitablityObject = profileObject.get("suitability").getAsJsonObject();
		if(profileObject.has("investmentInfo"))
			investmentObject = profileObject.get("investmentInfo").getAsJsonObject();
		if(profileObject.has("trustedContactPerson"))
			trustContObject = profileObject.get("trustedContactPerson").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
		con = DBConnection.InitConnection();
		query1 = "Select * from usercontractprofile where couserid = '"+coUserId+"'";
		query2 = "Select * from couser where couserid = '"+coUserId+"'";
		rs = DBConnection.execStatement(con,query1);
		rs1 = DBConnection.execStatement(con,query2);
		while(rs.next()){
			Set<String> persInfoDBUserContractSet = GlobalStaticInfo.persInfoDBUserContract.keySet();
			Set<String> trustContDBUserContractSet = GlobalStaticInfo.trustContDBUserContract.keySet();
			Set<String> suitablityDBUserContractSet = GlobalStaticInfo.suitablityDBUserContract.keySet();
			Set<String> investmentDBUserContractSet = GlobalStaticInfo.investmentDBUserContract.keySet();
			Set<String> disclosureDBUserContractSet = GlobalStaticInfo.disclosureDBUserContract.keySet();
			if(!profileObject.get("contractId").getAsString().equals("")){
			for(String persInfoDBUserContractElement:persInfoDBUserContractSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement))){
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
					if(persInfoDBUserContractElement.contains("DATE")||persInfoDBUserContractElement.equalsIgnoreCase("VISAEXPIRATION")){
						String tmp[]=rs.getString(persInfoDBUserContractElement).split(" ");
						Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
						Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString());
						Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal");
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
					}
					else{
							if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
								 Assert.assertEquals(rs.getString(persInfoDBUserContractElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString(),GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is Equal");
								 logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
							}
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is blank");
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("trustedContactPerson")){
			for(String trustContDBUserContractElement:trustContDBUserContractSet){
				if(!trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString().equals("")){
				 Assert.assertEquals(rs.getString(trustContDBUserContractElement),trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString(),GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is Equal");
				 logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is equal,value is "+rs.getString(trustContDBUserContractElement));
				}
				else
					logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String suitablityDBUserContractElement:suitablityDBUserContractSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(suitablityDBUserContractElement),suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString(),GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is equal,value is "+rs.getString(suitablityDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String investmentDBUserContractElement:investmentDBUserContractSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(investmentDBUserContractElement),investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString(),GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is equal,value is "+rs.getString(investmentDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("disclosures")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String disclosureDBUserContractElement:disclosureDBUserContractSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(disclosureDBUserContractElement),disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString(),GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is equal,value is "+rs.getString(disclosureDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is null");
				}
			}
		}
		while(rs1.next()){
			Set<String> persInfoDBCouserSet = GlobalStaticInfo.persInfoDBCouser.keySet();
			Set<String> disclosureDBCouserSet = GlobalStaticInfo.disclosureDBCouser.keySet();
			Set<String> suitablityDBCouserSet = GlobalStaticInfo.suitablityDBCouser.keySet();
			Set<String> investmentDBCouserSet = GlobalStaticInfo.investmentDBCouser.keySet();
			Set<String> persInfoDBCouser1Set = GlobalStaticInfo.persInfoDBCouser1.keySet();
			if(profileObject.get("contractId").getAsString().equals("")){
			for(String persInfoDBCouserElement:persInfoDBCouserSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement))){
				if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString().equals("")){
				 Assert.assertEquals(rs1.getString(persInfoDBCouserElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is Equal");
				 logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is equal,value is "+rs1.getString(persInfoDBCouserElement));
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is null");
				}
				}
			}
			if(profileObject.get("contractId").getAsString().equals("")){
				for(String persInfoDBCouser1SetElement:persInfoDBCouser1Set){
					if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement))){	
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString().equals("")){
						if(persInfoDBCouser1SetElement.contains("DATE")||persInfoDBCouser1SetElement.equalsIgnoreCase("VISAEXPIRATION")){
							String tmp[]=rs1.getString(persInfoDBCouser1SetElement).split(" ");
							Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
							Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString());
							Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal");
							logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
						else{
							 Assert.assertEquals(rs1.getString(persInfoDBCouser1SetElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is Equal");
							 logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
				}
			}
			if(profileObject.has("disclosures")&&profileObject.get("contractId").getAsString().equals("")){
				for(String disclosureDBCouserElement:disclosureDBCouserSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(disclosureDBCouserElement),disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString(),GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is equal,value is "+rs1.getString(disclosureDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&profileObject.get("contractId").getAsString().equals("")){
				for(String suitablityDBCouserElement:suitablityDBCouserSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(suitablityDBCouserElement),suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString(),GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is equal,value is "+rs1.getString(suitablityDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&profileObject.get("contractId").getAsString().equals("")){
				for(String investmentDBCouserElement:investmentDBCouserSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(investmentDBCouserElement),investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString(),GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is equal,value is "+rs1.getString(investmentDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is null");
				}
			}
		}
		//while(rs2.next()){
			Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
			Set<String> contChannelDBUserContactSet = GlobalStaticInfo.contChannelDBUserContact.keySet();
			if(profileObject.has("contactAddresses")){
				for(int j=0;j<contactAddressArray.size();j++){
					JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
					query3 ="Select * from useraddress where COUSERID = '"+coUserId+"' and ADDRESSTYPECODE ='"+contactAddressObject.get("addressType").getAsString()+"'";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
					for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
						if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
						 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
						}
						else
							logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
					}
					Assert.assertEquals(rs2.getString("COUSERID"), coUserId,"COUSERID of Address is equal, value is "+coUserId);
					logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					if(!profileObject.get("contractId").getAsString().equals("")){
						Assert.assertEquals(rs2.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						Assert.assertEquals(rs2.getString("LINEOFBUSINESSCODE"),profileObject.get("businessUnit").getAsString().toUpperCase(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
						logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
					}
				}
			}
		}
		
			if(profileObject.has("contactChannels")){
				for(int k=0;k<contactChannelArray.size();k++){
					JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
					query4 ="Select * from usercontact where COUSERID = '"+coUserId+"' and CONTACTTYPECODE ='"+contactChannelObject.get("contactChannelType").getAsString()+"'";
					rs3 = DBConnection.execStatement(con,query4);
					while(rs3.next()){
					for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
						if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
						 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
						}
						else
							logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
					}
					Assert.assertEquals(rs3.getString("COUSERID"), coUserId,"COUSERID of Address is equal, value is "+coUserId);
					logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					if(!profileObject.get("contractId").getAsString().equals("")){
						Assert.assertEquals(rs3.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						Assert.assertEquals(rs3.getString("LINEOFBUSINESSCODE"),profileObject.get("businessUnit").getAsString().toUpperCase(),"LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
						logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
					}
				}
			}
		}
	}catch(Exception e){
		logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			}
		}
	}
	
	@Then("^the user recieved BAD_REQUEST response with error response code (\\d+) succesfully as expected$")
	public void user_recieves_BAD_REQUEST_response_with_error_response_code_succesfully(int responseCode)throws SQLException{
		try{
			logger.info("In Then");
			int actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode, responseCode, "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@And("^success message is logged in audit table for \"([^\"]*)\"$")
	public void The_success_message_is_logged_in_audit_table(String User) throws Throwable{
		logger.info("In -----> The success message is logged in audit table");
		TransactionLog audit = new TransactionLog();
		String typeCode = "Create Profile";
		String Message = "Success - User profile information was inserted for user: "+SSOID;
		audit.auditlog_should_match_in_db(requestID,SSOID,typeCode,Message,User);
	}
	
	@And("^success message is logged in audit table for \"([^\"]*)\" for Minor profile$")
	public void The_success_message_is_logged_in_audit_table_for_Minor_profile(String User) throws Throwable{
		logger.info("In -----> The success message is logged in audit table");
		TransactionLog audit = new TransactionLog();
		String typeCode = "Create Profile";
		String Message = "Success - User profile information was inserted for user: ";//+SSOID;
		audit.auditlog_should_match_in_db_for_minor(requestID,coUserId,typeCode,Message,User);
	}

	@Then("^a success row is logged in audit log table for type PROFILE for custodian$")
	public void the_success_message_is_logged_in_audit_table_for_type_PROFILE() throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type Profile");
		TransactionLog audit = new TransactionLog();
		String typeCode = "PROFILE";
		String Message = ContractID;
		String linkedContextCode="UpdateProfileRequest";
		userTransactionlogID=audit.auditlog_should_match_in_db_for_profile(SSOID, typeCode, Message, linkedContextCode);
	}
	@Then("^a success row is logged in audit log table for type PROFILE for minor$")
	public void the_success_message_is_logged_in_audit_table_for_type_PROFILE_for_minor() throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type Profile");
		TransactionLog audit = new TransactionLog();
		String typeCode = "PROFILE";
		String Message = ContractID;
		String linkedContextCode="UpdateProfileRequest";
		userTransactionlogID=audit.auditlog_should_match_in_db_for_profile_for_minor(coUserId, typeCode, Message, linkedContextCode);
	}

	@Then("^fields audited are verified successfully$")
	public void the_fields_that_are_audited_are_verified_successfully() throws Throwable {
		Connection con = null;
		TransactionLog audit = new TransactionLog();
		logger.info("In And the data is updated in db for the fields that are audited");
		Gson gson = new Gson();
		try{
		String profileStr = gson.toJson(profile);
		String resBody=Res1.getBody().asString();
		JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
		JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
		coUserId = responseObject.get("coUserId").getAsString();
		String relnType = null;
		JsonObject personalInfoObject = new JsonObject();
		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		if(profileObject.has("personalInfo"))
			personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
		if(profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Custodian"))
			relnType = "Custodian";			
		else if (profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("Minor"))
			relnType = "Minor";
		try{		
		Set<String> persInfoUserTranlogdtlSet = GlobalStaticInfo.persInfoUserTranlogdtl.keySet();		
		for(String persInfoUserTranlogdtlElement:persInfoUserTranlogdtlSet){
			if(personalInfoObject.has(GlobalStaticInfo.persInfoUserTranlogdtl.get(persInfoUserTranlogdtlElement))){
			if(!personalInfoObject.get(GlobalStaticInfo.persInfoUserTranlogdtl.get(persInfoUserTranlogdtlElement)).getAsString().equals("")){
				audit.getAlltransactionAuditLogs(userTransactionlogID,persInfoUserTranlogdtlElement,personalInfoObject.get(GlobalStaticInfo.persInfoUserTranlogdtl.get(persInfoUserTranlogdtlElement)).getAsString());					
			}
			else
				logger.info(GlobalStaticInfo.persInfoUserTranlogdtl.get(persInfoUserTranlogdtlElement)+" is null");
			}
			else
				logger.info(GlobalStaticInfo.persInfoUserTranlogdtl.get(persInfoUserTranlogdtlElement)+" is null");
			}			
		
		Set<String> contAddUserTranslogdtlSet = GlobalStaticInfo.contAddUserTranslogdtl.keySet();
		if(profileObject.has("contactAddresses")){
			for(int j=0;j<contactAddressArray.size();j++){
				JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
				String newAddType=GlobalStaticInfo.addrTypeUserTranslogdtl.get(contactAddressObject.get("addressType").getAsString());
				for(String contAddUserTranslogdtlElement:contAddUserTranslogdtlSet){
					if(!contactAddressObject.get(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddUserTranslogdtlElement)).getAsString().equals("")){
						audit.getAlltransactionAuditLogs(userTransactionlogID,relnType+" "+newAddType+" "+contAddUserTranslogdtlElement,contactAddressObject.get(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddUserTranslogdtlElement)).getAsString());
					}
					else
						logger.info(GlobalStaticInfo.contAddUserTranslogdtl.get(contAddUserTranslogdtlElement)+" is null");
				}
			}
		}
		Set<String> contChannelUserTranslogdtlSet = GlobalStaticInfo.contChannelUserTranslogdtl.keySet();
		if(profileObject.has("contactChannels")){
			for(int k=0;k<contactChannelArray.size();k++){
				JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();				
				String newChannel=null;
				if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("Email")){
					if(contactChannelObject.get("contactChannelType").getAsString().contains("RECORD"))
						newChannel = GlobalStaticInfo.emailTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString());
					else 
						newChannel = GlobalStaticInfo.emailTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString())+" Email";
				}
				else if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("Phone")){
					if(contactChannelObject.get("contactChannelType").getAsString().contains("RECORD"))
						newChannel = GlobalStaticInfo.phoneTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString());
					else
						newChannel = GlobalStaticInfo.phoneTypeUserTranslogdtl.get(contactChannelObject.get("contactChannelType").getAsString())+" Phone";
				}
				for(String contChannelUserTranslogdtlElement:contChannelUserTranslogdtlSet){
					if(!contactChannelObject.get(GlobalStaticInfo.contChannelUserTranslogdtl.get(contChannelUserTranslogdtlElement)).getAsString().equals("")){
						audit.getAlltransactionAuditLogs(userTransactionlogID,relnType+" "+newChannel+" "+contChannelUserTranslogdtlElement,contactChannelObject.get(GlobalStaticInfo.contChannelUserTranslogdtl.get(contChannelUserTranslogdtlElement)).getAsString());
					}
					else
						logger.info(newChannel+" "+contChannelUserTranslogdtlElement+" is null");
				}
			}
		}

	}catch(Exception e){
		logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			}
		TransactionLog.dbRows = null;
		}
	}catch(Exception e){
		logger.info(e.getMessage());
		}
	}
}
