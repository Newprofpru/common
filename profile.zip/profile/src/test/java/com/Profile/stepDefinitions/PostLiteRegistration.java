package com.Profile.stepDefinitions;

import cucumber.api.PendingException;

import cucumber.api.junit.Cucumber;


import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import org.testng.Assert;

import com.Profile.stepDefinitions.TransactionLog;

import cucumber.api.java.en.And;

//import com.IDM_Service.supportLibraries.getEnvInfo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostLiteRegistration {

	private static Logger log = Logger.getLogger(PostLiteRegistration.class);
	static RequestSpecification request;
	static Response Res1;
	
	TransactionLog audit = new TransactionLog();
	private String Service_Url = "https://api-dev.prudential.com/co/qa/public/selfservicepublic/v1/literegistration";
	private String contentType  = "application/json";
	private String Authoriztion = "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==";	
	
	// Stage 
	//private String Service_Url = "https://api-stage.prudential.com/co/stage/public/selfservicepublic/v1/literegistration";
	//private String contentType  = "application/json";
	//private String Authoriztion = "Basic eDZjMlNqZUdYWkdFR2R5cWRKemZZc2FFRjN0VlhVbVA6cWNkcUNUaERHSGRKTjFLTg==";	
	
	String requestID;
		
		@Given("^valid endpoint for Lite registration service \"([^\"]*)\"$")
		public void valid_endpoint_for_Lite_registration_service(String serviceName) throws Throwable {	   	         
	   
	    	System.out.println("In Given");
			System.out.println("testService On-------------->:" + serviceName);	
	        
	    }
		
		@When("^a user calls postLiteUser service with \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
		public void a_user_calls_postLiteUser_service_with_and(String firstname, String lastname, String userid, String password, String usertype, String emailid, String marketingind, String documentname, String documentid, String dateaccepted, String sourcetype) throws Throwable {
		   	RestAssured.baseURI = Service_Url;

		   	Random rand = new Random(); int n = rand.nextInt(00450)+1234456;
		   	String username_prospectuser = userid+n;
		   	requestID ="LiteUser_"+n;
		   	
	    	request = given().log().all().         
	                header("Authorization",Authoriztion).
	                header("Content-Type",contentType)
	                .header("X-PruRequestID",requestID);
	    	
	    	
	    	
			//request = given().log().all().auth().basic("Z8TDSCE", "5JE8HGVW").contentType("application/json").and()
			//		.header("Authorization", Authoriztion);																																																			//String payload1 = "{\"lifeInsuranceEstimatorRequest\":{\"currentLifeInsuranceCoverage\": \""+ currentlifeinsurancecoverage + "\",\"savingsInvestment\": \""+ savingsinvestment +"\", \"retirementSavings\":\""+retirementsavings+"\", \"annualIncomeRequiredByFamily\":\""+annualincomerequiredbyfamily+"\",\"otherAnnualIncomeAvailableToFamily\":\""+otherannualincomeavailabletofamily+"\", \"dependencyYears\":\"" +dependencyyears+"\",\"currentDebt\":\""+currentdebt+"\"}}";
			
			String payload1 = "{\"registrationReq\":"
					+ "{\"profileDetails\":"
					+ "{"
					+ "\"firstName\": \""+ firstname + "\","
						+ "\"lastName\": \""+ lastname + "\","
							+ "\"userID\": \""+ userid + "\","
									+ "\"password\": \""+ password + "\","
											+ "\"userType\": \""+ usertype + "\","
													+ "\"emailID\": \""+ emailid + "\","
															+ "\"marketingInd\": \""+ marketingind + "\","
																	+ "\"termsAcceptance\":[{"
																	+ "\"documentName\": \""+ documentname + "\","
																			+ "\"documentId\": \""+ documentid + "\","
																					+ "\"dateAccepted\": \""+ dateaccepted + "\" }]},"
																							+ "\"sourceType\": \""+ sourcetype + "\"}}"; 
						
			System.out.println("In When");
			
			Res1 = request.log().all().log().all().body(payload1).contentType(ContentType.JSON).post().andReturn();
			System.out.println("Lite user name....>:"+username_prospectuser);
			int Responsebody = Res1.getStatusCode();
			
			System.out.println("Response----->:" + Res1.prettyPrint());

			log.info(Responsebody);
			log.info(Res1.asString());
	        
	    }
		
		@Then("^user gets \"([^\"]*)\" and \"([^\"]*)\" for postLiteUser$")
		public void user_gets_and_for_postLiteUser(String expectedresponsecode, String responseStatus) throws Throwable {
			System.out.println("In Then");
			
	    	JsonPath jp = new JsonPath(Res1.asString());
	    	
	    	String actualResponseCode = jp.getString("responseHeader.responseCode");
	    	String actualResponseStatus = jp.getString("responseHeader.responseStatus");
	    	
	    	
			System.out.println("ResponseCode received from Response-->: " + actualResponseCode);
			System.out.println("ResponseStatus received from Response-->: " + actualResponseStatus);
			// Validate the response
			Assert.assertEquals(actualResponseCode, expectedresponsecode, "responseCode received in the Response");
			// Transaction Log validation
			
				/*if (actualResponseCode.equals(expectedresponsecode)){
					          System.out.println("Trasaction DB Validation Starts >>>:");
					          System.out.println("Request Id is>>>: "+requestID );
					          audit.auditlog_should_match_in_db(requestID, "LiteUser");
					          
				}else {
					System.out.println("Not receiving Success Response >>>:"+actualResponseCode);
				}*/
					          
			
			Assert.assertEquals(actualResponseStatus, responseStatus, "responseStatus received in the Response");
		}
		
		
		@And("^response contains ssoid and \"([^\"]*)\" for postliteUser service$")
		public void response_contains_ssoid_and_for_postliteUser_service(String statusMsg) throws Throwable {
			System.out.println("In And");
			JsonPath jp = new JsonPath(Res1.asString());
	    	
	    	String ssoID = jp.getString("ssoid");
	    	String status = jp.getString("statusMessage");
	    	
	    	System.out.println("SSOID received from Response-->: " + ssoID);
			System.out.println("Status received from Response-->: " + status);
			
			Assert.assertNotNull(ssoID);
			Assert.assertTrue(status.contains(statusMsg));
		}
		
		@When("^a user calls postLiteUser service withexistinguser \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
		public void a_user_calls_postLiteUser_service_withexistinguser_and(String firstname, String lastname, String userid, String password, String usertype, String emailid, String marketingind, String documentname, String documentid, String dateaccepted, String sourcetype) throws Throwable {
		   	RestAssured.baseURI = Service_Url;

		   	String username_prospectuser = userid;
		   	
	    	request = given().log().all().         
	                header("Authorization",Authoriztion).
	                header("Content-Type",contentType);               
	    	
			//request = given().log().all().auth().basic("Z8TDSCE", "5JE8HGVW").contentType("application/json").and()
			//		.header("Authorization", Authoriztion);																																																			//String payload1 = "{\"lifeInsuranceEstimatorRequest\":{\"currentLifeInsuranceCoverage\": \""+ currentlifeinsurancecoverage + "\",\"savingsInvestment\": \""+ savingsinvestment +"\", \"retirementSavings\":\""+retirementsavings+"\", \"annualIncomeRequiredByFamily\":\""+annualincomerequiredbyfamily+"\",\"otherAnnualIncomeAvailableToFamily\":\""+otherannualincomeavailabletofamily+"\", \"dependencyYears\":\"" +dependencyyears+"\",\"currentDebt\":\""+currentdebt+"\"}}";
			
			String payload1 = "{\"registrationReq\":"
					+ "{\"profileDetails\":"
					+ "{"
					+ "\"firstName\": \""+ firstname + "\","
						+ "\"lastName\": \""+ lastname + "\","
							+ "\"userID\": \""+ username_prospectuser + "\","
									+ "\"password\": \""+ password + "\","
											+ "\"userType\": \""+ usertype + "\","
													+ "\"emailID\": \""+ emailid + "\","
															+ "\"marketingInd\": \""+ marketingind + "\","
																	+ "\"termsAcceptance\":[{"
																	+ "\"documentName\": \""+ documentname + "\","
																			+ "\"documentId\": \""+ documentid + "\","
																					+ "\"dateAccepted\": \""+ dateaccepted + "\" }]},"
																							+ "\"sourceType\": \""+ sourcetype + "\"}}"; 
						
			System.out.println("In When");
			
			Res1 = request.log().all().log().all().body(payload1).contentType(ContentType.JSON).post().andReturn();
			System.out.println("Lite user name....>:"+username_prospectuser);
			int Responsebody = Res1.getStatusCode();

			System.out.println("Response----->:" + Res1.prettyPrint());

			log.info(Responsebody);
			log.info(Res1.asString());
	        
		}
		
		@Then("^user should get error response code \"([^\"]*)\" and \"([^\"]*)\" for liteUsercreation Service$")
		public void user_should_get_error_response_code_and_for_liteUsercreation_Service(String expectedresponsecode, String statusmsg) throws Throwable {
			  
			  String responseCode = Res1.then().extract().path("responseHeader.responseCode");
				Assert.assertEquals(responseCode, expectedresponsecode);
				String statusMsg = Res1.then().extract().path("responseHeader.responseStatus");
				Assert.assertTrue(statusMsg.contains(statusmsg)); 
		  }
		
		@And("^\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"  should match with expected for liteUsercreation Service$")
		public void and_should_match_with_expected_for_liteUsercreation_Service(String Errorcode, String Errormsg, String FieldName, String Fielderror) throws Throwable {
			  System.out.println("In And");
			  JsonPath jp = new JsonPath(Res1.asString());
			  
			  String actualErrorCode = Res1.then().extract().path("responseHeader.errorDetails.subErrorCode"); 
		    	String actualerrorMsg = Res1.then().extract().path("responseHeader.errorDetails.errorMessage");
		    	String fieldname =jp.getString ("responseHeader.errorDetails.fieldError.fieldName");
		    	String fieldmsg = jp.getString("responseHeader.errorDetails.fieldError.fieldMessage");
		    	
				  System.out.println("ErrorCode received from Response-->: " + actualErrorCode);
				  System.out.println("ErrorMsg received from Response-->: " + actualerrorMsg);
				  System.out.println("Error-Fieldname received from Response-->: " + fieldname);
				  System.out.println("Error-FieldMSG received from Response-->: " + fieldmsg);
				  
				  
				  Assert.assertTrue(actualErrorCode.contains(Errorcode));
				  Assert.assertTrue(actualerrorMsg.contains(Errormsg));
				  Assert.assertTrue(fieldname.contains(FieldName));
				  Assert.assertTrue(fieldmsg.contains(Fielderror)); 
		
		}
		
		@When("^a user calls postLiteUser service without docname \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
		public void a_user_calls_postLiteUser_service_without_docname_and(String firstname, String lastname, String userid, String password, String usertype, String emailid, String marketingind, String documentname, String documentid, String dateaccepted, String sourcetype) throws Throwable {
		   	RestAssured.baseURI = Service_Url;

		   	Random rand = new Random(); int n = rand.nextInt(00450)+12344;
		   	String username_prospectuser = userid+n;
		   	
	    	request = given().log().all().         
	                header("Authorization",Authoriztion).
	                header("Content-Type",contentType);               
	    	
			//request = given().log().all().auth().basic("Z8TDSCE", "5JE8HGVW").contentType("application/json").and()
			//		.header("Authorization", Authoriztion);																																																			//String payload1 = "{\"lifeInsuranceEstimatorRequest\":{\"currentLifeInsuranceCoverage\": \""+ currentlifeinsurancecoverage + "\",\"savingsInvestment\": \""+ savingsinvestment +"\", \"retirementSavings\":\""+retirementsavings+"\", \"annualIncomeRequiredByFamily\":\""+annualincomerequiredbyfamily+"\",\"otherAnnualIncomeAvailableToFamily\":\""+otherannualincomeavailabletofamily+"\", \"dependencyYears\":\"" +dependencyyears+"\",\"currentDebt\":\""+currentdebt+"\"}}";
			
			String payload1 = "{\"registrationReq\":"
					+ "{\"profileDetails\":"
					+ "{"
					+ "\"firstName\": \""+ firstname + "\","
						+ "\"lastName\": \""+ lastname + "\","
							+ "\"userID\": \""+ username_prospectuser + "\","
									+ "\"password\": \""+ password + "\","
											+ "\"userType\": \""+ usertype + "\","
													+ "\"emailID\": \""+ emailid + "\","
															+ "\"marketingInd\": \""+ marketingind + "\","
																	+ "\"termsAcceptance\":[{"
																	//+ "\"documentName\": \""+ documentname + "\","
																			+ "\"documentId\": \""+ documentid + "\","
																					+ "\"dateAccepted\": \""+ dateaccepted + "\" }]},"
																							+ "\"sourceType\": \""+ sourcetype + "\"}}"; 
						
			System.out.println("In When");
			
			Res1 = request.log().all().log().all().body(payload1).contentType(ContentType.JSON).post().andReturn();
			System.out.println("Lite user name....>:"+username_prospectuser);
			int Responsebody = Res1.getStatusCode();

			System.out.println("Response----->:" + Res1.prettyPrint());

			log.info(Responsebody);
			log.info(Res1.asString());

		}
		
		
		@When("^a user calls postLiteUser service without docID \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
		public void a_user_calls_postLiteUser_service_without_docID_and(String firstname, String lastname, String userid, String password, String usertype, String emailid, String marketingind, String documentname, String documentid, String dateaccepted, String sourcetype) throws Throwable {
		   	RestAssured.baseURI = Service_Url;

		   	Random rand = new Random(); int n = rand.nextInt(00450)+12344;
		   	String username_prospectuser = userid+n;
		   	
	    	request = given().log().all().         
	                header("Authorization",Authoriztion).
	                header("Content-Type",contentType);               
	    	
			//request = given().log().all().auth().basic("Z8TDSCE", "5JE8HGVW").contentType("application/json").and()
			//		.header("Authorization", Authoriztion);																																																			//String payload1 = "{\"lifeInsuranceEstimatorRequest\":{\"currentLifeInsuranceCoverage\": \""+ currentlifeinsurancecoverage + "\",\"savingsInvestment\": \""+ savingsinvestment +"\", \"retirementSavings\":\""+retirementsavings+"\", \"annualIncomeRequiredByFamily\":\""+annualincomerequiredbyfamily+"\",\"otherAnnualIncomeAvailableToFamily\":\""+otherannualincomeavailabletofamily+"\", \"dependencyYears\":\"" +dependencyyears+"\",\"currentDebt\":\""+currentdebt+"\"}}";
			
			String payload1 = "{\"registrationReq\":"
					+ "{\"profileDetails\":"
					+ "{"
					+ "\"firstName\": \""+ firstname + "\","
						+ "\"lastName\": \""+ lastname + "\","
							+ "\"userID\": \""+ username_prospectuser + "\","
									+ "\"password\": \""+ password + "\","
											+ "\"userType\": \""+ usertype + "\","
													+ "\"emailID\": \""+ emailid + "\","
															+ "\"marketingInd\": \""+ marketingind + "\","
																	+ "\"termsAcceptance\":[{"
																	+ "\"documentName\": \""+ documentname + "\","
																			//+ "\"documentId\": \""+ documentid + "\","
																					+ "\"dateAccepted\": \""+ dateaccepted + "\" }]},"
																							+ "\"sourceType\": \""+ sourcetype + "\"}}"; 
						
			System.out.println("In When");
			
			Res1 = request.log().all().log().all().body(payload1).contentType(ContentType.JSON).post().andReturn();
			System.out.println("Lite user name....>:"+username_prospectuser);
			int Responsebody = Res1.getStatusCode();

			System.out.println("Response----->:" + Res1.prettyPrint());

			log.info(Responsebody);
			log.info(Res1.asString());

		}

}

