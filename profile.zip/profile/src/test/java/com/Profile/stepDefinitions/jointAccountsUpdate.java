package com.Profile.stepDefinitions;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import com.Profile.RequestBodyPojo.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GenericEvent;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;

import java.io.IOException;
import java.lang.reflect.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONObject;
import org.testng.Assert;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class jointAccountsUpdate {
	private static Logger logger = LogManager.getLogger();
	static Properties properties = getEnvInfo.getInstance();
	static RequestSpecification request;
	static Response Res1;
	private String XPruAuthJWT = null;
	private Response response = null;
    Map<String, String> cookie_Data = new HashMap<String, String>();
	Map<String, String> cookies = new HashMap<>();
	String Service_Url = getEnvInfo.getSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	String coUserId = null;
	String contractId = null;
	String ssoid = null;
	String requestID = null;
	Set<String> contactAddressTypes = new HashSet<>();
	Set<String> contactPhoneTypes = new HashSet<>();
	profile profile = new profile();
	profileV4 profile1 = new profileV4();
	personalInfo personalInfo = new personalInfo();
	disclosures disclosures = new disclosures();
	suitability suitability = new suitability();
	investmentInfo investmentInfo = new investmentInfo();
	trustedContactPerson trustedContactPerson = new trustedContactPerson();
	List<contactChannels> contactChannels = new ArrayList<>();
	List<contactAddresses> contactAddresses = new ArrayList<>();
	
	@Given("^valid endpoint exists for \"([^\"]*)\" API$")
	public void valid_endpoint_for_GetMasterKey(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
		
	}
		
	@When("^a PUT request is sent to profile API with below request body data with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details(String userid, String password, DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3"))
		{
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		if(Service_Url.contains("v4")) {
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			coUserId=profile1.getCoUserId();
			contractId=profile1.getContractId();
			ssoid = profile1.getSsoId();
			XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
		}
//		JsonObject profileObject = (JsonObject) new JsonParser().parse(body);
//		JsonObject personalinfo = profileObject.get("personalInfo").getAsJsonObject();
//		profileObject.remove("personalInfo");
//		profileObject.add("personalinfo", personalinfo);
//		body=profileObject.toString();		
		}
	
	
	@When("^a PUT request is sent to profile API with below request body data$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_profileV3( DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3"))
		{
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		if(Service_Url.contains("v4")) {
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			coUserId=profile1.getCoUserId();
			contractId=profile1.getContractId();
			ssoid = profile1.getSsoId();
			//XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
		}
//		JsonObject profileObject = (JsonObject) new JsonParser().parse(body);
//		JsonObject personalinfo = profileObject.get("personalInfo").getAsJsonObject();
//		profileObject.remove("personalInfo");
//		profileObject.add("personalinfo", personalinfo);
//		body=profileObject.toString();		
		}
	
	@When("^a PUT request is sent to profile API with below request body data to delete phone with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_phone(String userid, String password, DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		contactChannelsTest = profile.getContactChannels();
		List<String> contactChannelTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactChannels cc : contactChannelsTest){
			contactChannelTypes.add(cc.getContactChannelType());
		}
		for(String contactChannelType:contactChannelTypes){
			String query = null;
			String contactChannelId = null;
			if(contractid!=null)
				query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			else
				query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactChannelId = rscont.getString("USERCONTACTID");				
			}
			for(contactChannels cc : contactChannelsTest){
				if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
					cc.setcontactChannelId(contactChannelId);					
				contactChannelsTest1.add(cc);
			}
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
	}
		else if(Service_Url.contains("v4")){		
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactChannelsV4> contactChannelsTest = new ArrayList<>();
			List<contactChannelsV4> contactChannelsTest1 = new ArrayList<>();
			contactChannelsTest = profile1.getContactChannels();
			List<String> contactChannelTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactChannelsV4 cc : contactChannelsTest){
				contactChannelTypes.add(cc.getContactChannelType());
			}
			for(String contactChannelType:contactChannelTypes){
				String query = null;
				String contactChannelId = null;
				if(contractid!=null)
					query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				else
					query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactChannelId = rscont.getString("USERCONTACTID");				
				}
				for(contactChannelsV4 cc : contactChannelsTest){
					if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
						cc.setcontactChannelId(contactChannelId);					
					contactChannelsTest1.add(cc);
				}
			}
			profile1.setcontactChannels(null);
			profile1.setcontactChannels(contactChannelsTest1);

			XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
		}
		Thread.sleep(1000);
		}
	
	
	@When("^a PUT request is sent to profile API with below request body data to delete phone$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_phone_profilev3(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException, InterruptedException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		contactChannelsTest = profile.getContactChannels();
		List<String> contactChannelTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactChannels cc : contactChannelsTest){
			contactChannelTypes.add(cc.getContactChannelType());
		}
		for(String contactChannelType:contactChannelTypes){
			String query = null;
			String contactChannelId = null;
			if(contractid!=null)
				query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			else
				query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactChannelId = rscont.getString("USERCONTACTID");				
			}
			for(contactChannels cc : contactChannelsTest){
				if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
					cc.setcontactChannelId(contactChannelId);					
				contactChannelsTest1.add(cc);
			}
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
	}
		else if(Service_Url.contains("v4")){		
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactChannelsV4> contactChannelsTest = new ArrayList<>();
			List<contactChannelsV4> contactChannelsTest1 = new ArrayList<>();
			contactChannelsTest = profile1.getContactChannels();
			List<String> contactChannelTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactChannelsV4 cc : contactChannelsTest){
				contactChannelTypes.add(cc.getContactChannelType());
			}
			for(String contactChannelType:contactChannelTypes){
				String query = null;
				String contactChannelId = null;
				if(contractid!=null)
					query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				else
					query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'PHONE' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactChannelId = rscont.getString("USERCONTACTID");				
				}
				for(contactChannelsV4 cc : contactChannelsTest){
					if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
						cc.setcontactChannelId(contactChannelId);					
					contactChannelsTest1.add(cc);
				}
			}
			profile1.setcontactChannels(null);
			profile1.setcontactChannels(contactChannelsTest1);

			//XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
		}
		Thread.sleep(1000);
		}
	
	@When("^a PUT request is sent to profile API with below request body data to delete email with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_email(String userid, String password, DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){			
		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		contactChannelsTest = profile.getContactChannels();
		List<String> contactChannelTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactChannels cc : contactChannelsTest){
			contactChannelTypes.add(cc.getContactChannelType());
		}
		for(String contactChannelType:contactChannelTypes){
			String query = null;
			String contactChannelId = null;
			if(contractid!=null)
				query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			else
				query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactChannelId = rscont.getString("USERCONTACTID");
			}
			for(contactChannels cc : contactChannelsTest){
				if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
					cc.setcontactChannelId(contactChannelId);
				contactChannelsTest1.add(cc);
			}
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		else if(Service_Url.contains("v4")){			
			
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactChannelsV4> contactChannelsTest = new ArrayList<>();
			List<contactChannelsV4> contactChannelsTest1 = new ArrayList<>();
			contactChannelsTest = profile1.getContactChannels();
			List<String> contactChannelTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactChannelsV4 cc : contactChannelsTest){
				contactChannelTypes.add(cc.getContactChannelType());
			}
			for(String contactChannelType:contactChannelTypes){
				String query = null;
				String contactChannelId = null;
				if(contractid!=null)
					query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				else
					query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactChannelId = rscont.getString("USERCONTACTID");
				}
				for(contactChannelsV4 cc : contactChannelsTest){
					if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
						cc.setcontactChannelId(contactChannelId);
					contactChannelsTest1.add(cc);
				}
			}
			profile1.setcontactChannels(null);
			profile1.setcontactChannels(contactChannelsTest1);
			
			XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);	
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			}
		}
	
	@When("^a PUT request is sent to profile API with below request body data to delete email$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_email_profileV3(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){			
		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactChannels> contactChannelsTest = new ArrayList<>();
		List<contactChannels> contactChannelsTest1 = new ArrayList<>();
		contactChannelsTest = profile.getContactChannels();
		List<String> contactChannelTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactChannels cc : contactChannelsTest){
			contactChannelTypes.add(cc.getContactChannelType());
		}
		for(String contactChannelType:contactChannelTypes){
			String query = null;
			String contactChannelId = null;
			if(contractid!=null)
				query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			else
				query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactChannelId = rscont.getString("USERCONTACTID");
			}
			for(contactChannels cc : contactChannelsTest){
				if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
					cc.setcontactChannelId(contactChannelId);
				contactChannelsTest1.add(cc);
			}
		}
		profile.setcontactChannels(null);
		profile.setcontactChannels(contactChannelsTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		else if(Service_Url.contains("v4")){			
			
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactChannelsV4> contactChannelsTest = new ArrayList<>();
			List<contactChannelsV4> contactChannelsTest1 = new ArrayList<>();
			contactChannelsTest = profile1.getContactChannels();
			List<String> contactChannelTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactChannelsV4 cc : contactChannelsTest){
				contactChannelTypes.add(cc.getContactChannelType());
			}
			for(String contactChannelType:contactChannelTypes){
				String query = null;
				String contactChannelId = null;
				if(contractid!=null)
					query = "Select * from usercontact where couserid = '"+couserid+"' and contractid = '"+contractid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				else
					query = "Select * from usercontact where couserid = '"+couserid+"' and CONTACTCHANNELCODE = 'EMAIL' and CONTACTTYPECODE = '"+contactChannelType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactChannelId = rscont.getString("USERCONTACTID");
				}
				for(contactChannelsV4 cc : contactChannelsTest){
					if(cc.getContactChannelType().equalsIgnoreCase(contactChannelType))
						cc.setcontactChannelId(contactChannelId);
					contactChannelsTest1.add(cc);
				}
			}
			profile1.setcontactChannels(null);
			profile1.setcontactChannels(contactChannelsTest1);
			
			//XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);	
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			}
		}
	
	@When("^a PUT request is sent to profile API with below request body data to delete address with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_address(String userid, String password, DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){			
		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactAddresses> contactAddressTest = new ArrayList<>();
		List<contactAddresses> contactAddressTest1 = new ArrayList<>();
		contactAddressTest = profile.getContactAddresses();
		List<String> contactAddressTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactAddresses cc : contactAddressTest){
			contactAddressTypes.add(cc.getAddressType());
		}
		for(String contactAddressType:contactAddressTypes){
			String query = null;
			String contactAddressId = null;
			if(contractid!=null)
				query = "Select * from useraddress where couserid = '"+couserid+"' and contractid = '"+contractid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
			else
				query = "Select * from useraddress where couserid = '"+couserid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactAddressId = rscont.getString("USERADDRESSID");
			}
			for(contactAddresses cc : contactAddressTest){
				if(cc.getAddressType().equalsIgnoreCase(contactAddressType))
					cc.setcontactAddressId(contactAddressId);
					contactAddressTest1.add(cc);
			}
		}
		profile.setcontactAddresses(null);
		profile.setcontactAddresses(contactAddressTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		else if(Service_Url.contains("v4")){			
			
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactAddressesV4> contactAddressTest = new ArrayList<>();
			List<contactAddressesV4> contactAddressTest1 = new ArrayList<>();
			contactAddressTest = profile1.getContactAddresses();
			List<String> contactAddressTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactAddressesV4 cc : contactAddressTest){
				contactAddressTypes.add(cc.getAddressType());
			}
			for(String contactAddressType:contactAddressTypes){
				String query = null;
				String contactAddressId = null;
				if(contractid!=null)
					query = "Select * from useraddress where couserid = '"+couserid+"' and contractid = '"+contractid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
				else
					query = "Select * from useraddress where couserid = '"+couserid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactAddressId = rscont.getString("USERADDRESSID");
				}
				for(contactAddressesV4 cc : contactAddressTest){
					if(cc.getAddressType().equalsIgnoreCase(contactAddressType))
						cc.setcontactAddressID(contactAddressId);
						contactAddressTest1.add(cc);
				}
			}
			profile1.setcontactAddresses(null);
			profile1.setcontactAddresses(contactAddressTest1);
			
			XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			}
		}
	
	@When("^a PUT request is sent to profile API with below request body data to delete address$")
	public void a_PUT_request_is_sent_to_profile_API_with_above_request_body_details_to_delete_address_profileV3(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("\nIn--------------------> When a PUT request is sent to profile API with below request body data");
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileUpdate" + n;
		RestAssured.baseURI = Service_Url;
		if(!contactAddressTypes.isEmpty())
			contactAddressTypes.clear();
		if(!contactPhoneTypes.isEmpty())
			contactPhoneTypes.clear();
		Map<String, String> data = parameters.asMap(String.class, String.class);
		if(Service_Url.contains("v3")){			
		
		profile = RequestBodyPojoCreater.getProfile(data.get("profile_id"),false);
		List<contactAddresses> contactAddressTest = new ArrayList<>();
		List<contactAddresses> contactAddressTest1 = new ArrayList<>();
		contactAddressTest = profile.getContactAddresses();
		List<String> contactAddressTypes = new ArrayList<>();
		String couserid=null,contractid=null;
		couserid = profile.getCoUserId();
		Connection con = DBConnection.InitConnection();
		if(profile.getContractId()!="")
			contractid = profile.getContractId();
		for(contactAddresses cc : contactAddressTest){
			contactAddressTypes.add(cc.getAddressType());
		}
		for(String contactAddressType:contactAddressTypes){
			String query = null;
			String contactAddressId = null;
			if(contractid!=null)
				query = "Select * from useraddress where couserid = '"+couserid+"' and contractid = '"+contractid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
			else
				query = "Select * from useraddress where couserid = '"+couserid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
			ResultSet rscont = DBConnection.execStatement(con,query);
			while(rscont.next()){
				contactAddressId = rscont.getString("USERADDRESSID");
			}
			for(contactAddresses cc : contactAddressTest){
				if(cc.getAddressType().equalsIgnoreCase(contactAddressType))
					cc.setcontactAddressId(contactAddressId);
					contactAddressTest1.add(cc);
			}
		}
		profile.setcontactAddresses(null);
		profile.setcontactAddresses(contactAddressTest1);
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		Gson gson = new Gson();
		String body = gson.toJson(profile);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		else if(Service_Url.contains("v4")){			
			
			profile1 = RequestBodyPojoCreater.getProfileV4(data.get("profile_id"),false);
			List<contactAddressesV4> contactAddressTest = new ArrayList<>();
			List<contactAddressesV4> contactAddressTest1 = new ArrayList<>();
			contactAddressTest = profile1.getContactAddresses();
			List<String> contactAddressTypes = new ArrayList<>();
			String couserid=null,contractid=null;
			couserid = profile1.getCoUserId();
			ssoid =profile1.getSsoId();
			Connection con = DBConnection.InitConnection();
			if(profile1.getContractId()!="")
				contractid = profile1.getContractId();
			for(contactAddressesV4 cc : contactAddressTest){
				contactAddressTypes.add(cc.getAddressType());
			}
			for(String contactAddressType:contactAddressTypes){
				String query = null;
				String contactAddressId = null;
				if(contractid!=null)
					query = "Select * from useraddress where couserid = '"+couserid+"' and contractid = '"+contractid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
				else
					query = "Select * from useraddress where couserid = '"+couserid+"' and ADDRESSTYPECODE = '"+contactAddressType+"' and deleted = 'N'";
				ResultSet rscont = DBConnection.execStatement(con,query);
				while(rscont.next()){
					contactAddressId = rscont.getString("USERADDRESSID");
				}
				for(contactAddressesV4 cc : contactAddressTest){
					if(cc.getAddressType().equalsIgnoreCase(contactAddressType))
						cc.setcontactAddressID(contactAddressId);
						contactAddressTest1.add(cc);
				}
			}
			profile1.setcontactAddresses(null);
			profile1.setcontactAddresses(contactAddressTest1);
			
			//XPruAuthJWT = getJWTAuthToken(userid, password);
			
			request = given()
					.header("X-PruRequestId", requestID)
					.header("Authorization", Authorization)
					.header("X-Forwarded-For", "0.0.0.0")
					.header("X-PruAuthJWT", XPruAuthJWT)
					.header("X-PruPrimaryIdentity", ssoid);
			Gson gson = new Gson();
			String body = gson.toJson(profile1);
			logger.info("body ----> "+body);
			Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			}
		}
	
	@Then("^the data is updated and success response code 200 is recieved$")
	public void the_data_is_updated_and_success_response_code_200_is_recieved(){
		try{
			logger.info("\nIn--------------------> Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@And("^the data is updated in db$")
	public void the_data_is_updated_in_db() throws SQLException, ParseException, InterruptedException{
		Thread.sleep(100);
		String query1 = null,query2=null,query3=null,query4=null;
		String profileStr = null;
		ResultSet rs,rs1,rs2,rs3,rs4,rs5,rs6;
		logger.info("\nIn--------------------> And the data is updated in db");
		Gson gson = new Gson();
		Connection con = null;
		try{		
			
			if(Service_Url.contains("v3"))
				profileStr = gson.toJson(profile);
			else
				profileStr = gson.toJson(profile1);			
			
		JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
		coUserId = profileObject.get("coUserId").getAsString();
		JsonObject personalInfoObject = new JsonObject();
		JsonObject disclosureObject = new JsonObject();
		JsonObject suitablityObject = new JsonObject();
		JsonObject investmentObject = new JsonObject();
		JsonObject trustContObject = new JsonObject();
		JsonArray contactAddressArray = new JsonArray();
		JsonArray contactChannelArray = new JsonArray();
		String contractId = profileObject.get("contractId").getAsString();
		if(profileObject.has("personalInfo"))
			personalInfoObject = profileObject.get("personalInfo").getAsJsonObject();
		if(profileObject.has("disclosures"))
			disclosureObject = profileObject.get("disclosures").getAsJsonObject();
		if(profileObject.has("suitability"))
			suitablityObject = profileObject.get("suitability").getAsJsonObject();
		if(profileObject.has("investmentInfo"))
			investmentObject = profileObject.get("investmentInfo").getAsJsonObject();
		if(profileObject.has("trustedContactPerson"))
			trustContObject = profileObject.get("trustedContactPerson").getAsJsonObject();
		if(profileObject.has("contactAddresses"))
			contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
		if(profileObject.has("contactChannels"))
			contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
		con = DBConnection.InitConnection();
		query1 = "Select * from usercontractprofile where couserid = '"+coUserId+"'";
		query2 = "Select * from couser where couserid = '"+coUserId+"'";
		rs = DBConnection.execStatement(con,query1);
		rs1 = DBConnection.execStatement(con,query2);
		while(rs.next()){
			Set<String> persInfoDBUserContractSet = GlobalStaticInfo.persInfoDBUserContract.keySet();
			Set<String> trustContDBUserContractSet = GlobalStaticInfo.trustContDBUserContract.keySet();
			Set<String> suitablityDBUserContractSet = GlobalStaticInfo.suitablityDBUserContract.keySet();
			Set<String> investmentDBUserContractSet = GlobalStaticInfo.investmentDBUserContract.keySet();
			Set<String> disclosureDBUserContractSet = GlobalStaticInfo.disclosureDBUserContract.keySet();
			if(profileObject.has("personalInfo")){
			if(!profileObject.get("contractId").getAsString().equals("")){
			for(String persInfoDBUserContractElement:persInfoDBUserContractSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement))){
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
					if(persInfoDBUserContractElement.contains("DATE")||persInfoDBUserContractElement.equalsIgnoreCase("VISAEXPIRATION")){
						String tmp[]=rs.getString(persInfoDBUserContractElement).split(" ");
						Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
						Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString());
						Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal");
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
					}
					else{
							if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString().equals("")){
								 Assert.assertEquals(rs.getString(persInfoDBUserContractElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)).getAsString(),GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is Equal");
								 logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is equal,value is "+rs.getString(persInfoDBUserContractElement));
							}
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is blank");
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBUserContract.get(persInfoDBUserContractElement)+" is null");
				}
			}
		}
			if(profileObject.has("trustedContactPerson")){
			for(String trustContDBUserContractElement:trustContDBUserContractSet){
				if(!trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString().equals("")){
				 Assert.assertEquals(rs.getString(trustContDBUserContractElement),trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString(),GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is Equal");
				 logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is equal,value is "+rs.getString(trustContDBUserContractElement));
				}
				else
					logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String suitablityDBUserContractElement:suitablityDBUserContractSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(suitablityDBUserContractElement),suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString(),GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is equal,value is "+rs.getString(suitablityDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String investmentDBUserContractElement:investmentDBUserContractSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(investmentDBUserContractElement),investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString(),GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is equal,value is "+rs.getString(investmentDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is null");
				}
			}
			if(profileObject.has("disclosures")&&!profileObject.get("contractId").getAsString().equals("")){
				for(String disclosureDBUserContractElement:disclosureDBUserContractSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(disclosureDBUserContractElement),disclosureObject.get(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)).getAsString(),GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is equal,value is "+rs.getString(disclosureDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBUserContract.get(disclosureDBUserContractElement)+" is null");
				}
			}
		}
		while(rs1.next()){
			Set<String> persInfoDBCouserSet = GlobalStaticInfo.persInfoDBCouser.keySet();
			Set<String> disclosureDBCouserSet = GlobalStaticInfo.disclosureDBCouser.keySet();
			Set<String> suitablityDBCouserSet = GlobalStaticInfo.suitablityDBCouser.keySet();
			Set<String> investmentDBCouserSet = GlobalStaticInfo.investmentDBCouser.keySet();
			Set<String> persInfoDBCouser1Set = GlobalStaticInfo.persInfoDBCouser1.keySet();
			if(profileObject.has("personalInfo")){
				if(profileObject.get("contractId").getAsString().equals("")){
			for(String persInfoDBCouserElement:persInfoDBCouserSet){
				if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement))){
				if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString().equals("")){
				 Assert.assertEquals(rs1.getString(persInfoDBCouserElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is Equal");
				 logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is equal,value is "+rs1.getString(persInfoDBCouserElement));
				}
				else
					logger.info(GlobalStaticInfo.persInfoDBCouser.get(persInfoDBCouserElement)+" is null");
				}
				}
			}
		}
			if(profileObject.has("personalInfo")){
			if(profileObject.get("contractId").getAsString().equals("")){
				for(String persInfoDBCouser1SetElement:persInfoDBCouser1Set){
					if(personalInfoObject.has(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement))){	
					if(!personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString().equals("")){
						if(persInfoDBCouser1SetElement.contains("DATE")||persInfoDBCouser1SetElement.equalsIgnoreCase("VISAEXPIRATION")){
							String tmp[]=rs1.getString(persInfoDBCouser1SetElement).split(" ");
							Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(tmp[0]);
							Date dt2 = new SimpleDateFormat("MM/dd/yyyy").parse(personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString());
							Assert.assertEquals(dt1,dt2,GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal");
							logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
						else{
							 Assert.assertEquals(rs1.getString(persInfoDBCouser1SetElement),personalInfoObject.get(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)).getAsString(),GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is Equal");
							 logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is equal,value is "+rs1.getString(persInfoDBCouser1SetElement));
						}
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
					}
					else
						logger.info(GlobalStaticInfo.persInfoDBCouser1.get(persInfoDBCouser1SetElement)+" is null");
				}
			}
		}
			if(profileObject.has("disclosures")&&profileObject.get("contractId").getAsString().equals("")){
				for(String disclosureDBCouserElement:disclosureDBCouserSet){
					if(!disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(disclosureDBCouserElement),disclosureObject.get(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)).getAsString(),GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is equal,value is "+rs1.getString(disclosureDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.disclosureDBCouser.get(disclosureDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("suitability")&&profileObject.get("contractId").getAsString().equals("")){
				for(String suitablityDBCouserElement:suitablityDBCouserSet){
					if(!suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(suitablityDBCouserElement),suitablityObject.get(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)).getAsString(),GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is equal,value is "+rs1.getString(suitablityDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBCouserElement)+" is null");
				}
			}
			if(profileObject.has("investmentInfo")&&profileObject.get("contractId").getAsString().equals("")){
				for(String investmentDBCouserElement:investmentDBCouserSet){
					if(!investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString().equals("")){
					 Assert.assertEquals(rs1.getString(investmentDBCouserElement),investmentObject.get(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)).getAsString(),GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is Equal");
					 logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is equal,value is "+rs1.getString(investmentDBCouserElement));
					}
					else
						logger.info(GlobalStaticInfo.investmentDBCouser.get(investmentDBCouserElement)+" is null");
				}
			}
		}
		//while(rs2.next()){
			Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
			Set<String> contChannelDBUserContactSet = GlobalStaticInfo.contChannelDBUserContact.keySet();
			String queryaddr = "Select * from useraddress where couserid = '"+coUserId+"' and contractid = '"+contractId+"' and deleted = 'N'";
			ResultSet rsAddr = DBConnection.execStatement(con,queryaddr);
			while(rsAddr.next()){
				if(rsAddr.getString("DELETED").equalsIgnoreCase("N"))
					contactAddressTypes.add(rsAddr.getString("ADDRESSTYPECODE"));
			}
			if(profileObject.has("contactAddresses")){
				
				for(int j=0;j<contactAddressArray.size();j++){
					JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
					query3 ="Select * from useraddress where USERADDRESSID = '"+contactAddressObject.get("contactAddressId").getAsString()+"'";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
					for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
						if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
						 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
						}
						else
							logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
					}
					Assert.assertEquals(rs2.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					if(!profileObject.get("contractId").getAsString().equals("")){
						Assert.assertEquals(rs2.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						if (!Service_Url.contains("v4")) {
							Assert.assertEquals(rs2.getString("LINEOFBUSINESSCODE"), profileObject.get("businessUnit").getAsString().toUpperCase(),	"LINEOFBUSINESSCODE is equal, value is "+ profileObject.get("businessUnit").getAsString());
							logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
						}
						else {
							Assert.assertEquals(rs2.getString("LINEOFBUSINESSCODE"), profileObject.get("lineOfBusinessCode").getAsString().toUpperCase(), "LINEOFBUSINESSCODE is equal, value is "+ profileObject.get("lineOfBusinessCode").getAsString());
							logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
						}
					}
				}
					String addressType = contactAddressObject.get("addressType").getAsString();
					if (Service_Url.contains("v3") && contactAddressObject.get("deleted").getAsString().equalsIgnoreCase("N")
							|| Service_Url.contains("v4") && contactAddressObject.get("isDeleted").getAsString().equalsIgnoreCase("false")) {
					if(addressType.equalsIgnoreCase("CORRESPONDENCE")){
						String query5="";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+addressType+" address with ADDRESSOFRECORD address");
							query5="Select * from useraddress where couserid='"+coUserId+"' and contractid='"+contractId+"' and addresstypecode = 'ADDRESSOFRECORD'";
							ResultSet rst = DBConnection.execStatement(con,query5);
						while(rst.next()){
							for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
								if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
									if(!(contAddressDBUserAddressElement.equalsIgnoreCase("USERADDRESSID")||(contAddressDBUserAddressElement.equalsIgnoreCase("ADDRESSTYPECODE")))){
									 Assert.assertEquals(rst.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
									 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rst.getString(contAddressDBUserAddressElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
							}
						}
					}
				}
					if(addressType.equalsIgnoreCase("HOME")&&!contactAddressTypes.contains("CORRESPONDENCE")){
						String query="";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+addressType+" address with ADDRESSOFRECORD address");
							query="Select * from useraddress where couserid='"+coUserId+"' and contractid='"+contractId+"' and addresstypecode = 'ADDRESSOFRECORD'";
							ResultSet rst = DBConnection.execStatement(con,query);
						while(rst.next()){
							for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
								if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
									if(!(contAddressDBUserAddressElement.equalsIgnoreCase("USERADDRESSID")||(contAddressDBUserAddressElement.equalsIgnoreCase("ADDRESSTYPECODE")))){
									 Assert.assertEquals(rst.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
									 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rst.getString(contAddressDBUserAddressElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
							}
						}
					}
				}
				}
			}
				
			
		}
			String queryPhone = "Select * from usercontact where contactchannelcode = 'PHONE' and couserid = '"+coUserId+"' and contractid = '"+contractId+"' and deleted = 'N'";
			ResultSet rsPhone = DBConnection.execStatement(con,queryPhone);
			while(rsPhone.next()){
				if(rsPhone.getString("DELETED").equalsIgnoreCase("N"))
					contactPhoneTypes.add(rsPhone.getString("CONTACTTYPECODE"));
			}
			if(profileObject.has("contactChannels")){
				
				for(int k=0;k<contactChannelArray.size();k++){
					JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
					query4 ="Select * from usercontact where USERCONTACTID = '"+contactChannelObject.get("contactChannelId").getAsString()+"'";
					rs3 = DBConnection.execStatement(con,query4);
					while(rs3.next()){
					for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
						if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
						 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
						 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
						}
						else
							logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
					}
					Assert.assertEquals(rs3.getString("COUSERID"), profileObject.get("coUserId").getAsString(),"COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					logger.info("COUSERID of Address is equal, value is "+profileObject.get("coUserId").getAsString());
					if(!profileObject.get("contractId").getAsString().equals("")){
						Assert.assertEquals(rs3.getString("CONTRACTID"),profileObject.get("contractId").getAsString(),"CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
						logger.info("CONTRACTID is equal, value is "+profileObject.get("contractId").getAsString());
							if (!Service_Url.contains("v4")) {
								Assert.assertEquals(rs3.getString("LINEOFBUSINESSCODE"), profileObject.get("businessUnit").getAsString().toUpperCase(),	"LINEOFBUSINESSCODE is equal, value is "+ profileObject.get("businessUnit").getAsString());
								logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("businessUnit").getAsString());
							}
							else {
								Assert.assertEquals(rs3.getString("LINEOFBUSINESSCODE"), profileObject.get("lineOfBusinessCode").getAsString().toUpperCase(), "LINEOFBUSINESSCODE is equal, value is "+ profileObject.get("lineOfBusinessCode").getAsString());
								logger.info("LINEOFBUSINESSCODE is equal, value is "+profileObject.get("lineOfBusinessCode").getAsString());
							}
					}
				}
					String contactType = contactChannelObject.get("contactChannelType").getAsString();
					if (Service_Url.contains("v3") && contactChannelObject.get("deleted").getAsString().equalsIgnoreCase("N")
							|| Service_Url.contains("v4") && contactChannelObject.get("isDeleted").getAsString().equalsIgnoreCase("false")) {
					if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("EMAIL")){
					if(contactType.equalsIgnoreCase("PRIMARY")){
						String query6 = "";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+contactType+" EMAIL with EMAILOFRECORD ");
							query6 = "select * from usercontact where couserid='"+coUserId+"' and contractid='"+contractId+"' and contacttypecode='EMAILOFRECORD'";
						rs5=DBConnection.execStatement(con,query6);
						while(rs5.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
								 if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
									Assert.assertEquals(rs5.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs5.getString(contChannelDBUserContactElement));
								 }
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
					}
				}
					}
					if (Service_Url.contains("v3") && contactChannelObject.get("deleted").getAsString().equalsIgnoreCase("N")
							|| Service_Url.contains("v4") && contactChannelObject.get("isDeleted").getAsString().equalsIgnoreCase("false")) {
					if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("PHONE")){
					if(contactType.equalsIgnoreCase("MOBILE")){
						String query7 = "";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+contactType+" PHONE with PHONEOFRECORD ");
							query7 = "select * from usercontact where couserid='"+coUserId+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs6=DBConnection.execStatement(con,query7);
						while(rs6.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs6.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs6.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
					if(contactType.equalsIgnoreCase("Home")&&!contactPhoneTypes.contains("MOBILE")){
						String query7 = "";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+contactType+" PHONE with PHONEOFRECORD ");
							query7 = "select * from usercontact where couserid='"+coUserId+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs6=DBConnection.execStatement(con,query7);
						while(rs6.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs6.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs6.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
					if(contactType.equalsIgnoreCase("Work")&&!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")){
						String query7 = "";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+contactType+" PHONE with PHONEOFRECORD ");							
							query7 = "select * from usercontact where couserid='"+coUserId+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs6=DBConnection.execStatement(con,query7);
						while(rs6.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs6.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs6.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
					if(contactType.equalsIgnoreCase("Other")&&!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")&&!contactPhoneTypes.contains("WORK")){
						String query7 = "";
						if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
							logger.info("\nIn-------------------->Checking "+contactType+" PHONE with PHONEOFRECORD ");
							query7 = "select * from usercontact where couserid='"+coUserId+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs6=DBConnection.execStatement(con,query7);
						while(rs6.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs6.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs6.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
				}
				}
			}
			
		}
			//testscenario
			if(!contractId.equals("") && profileObject.get("relationshipToAccount").getAsString().equalsIgnoreCase("PRIMARY")){
				logger.info("\n\n\nIn-------------------->Checking AOR,POR are updated correctly.. verifying in db!");
				HashMap<String,String> AOR = new HashMap<>();
				Set<String> setAOR = GlobalStaticInfo.contAddressDBUserAddress.keySet();
				//HashMap<String,String> EOR = new HashMap<>();
				HashMap<String,String> POR = new HashMap<>();
				Set<String> setPOR = GlobalStaticInfo.contChannelDBUserContact.keySet();
				String queryAOR = "Select * from useraddress where couserid = '"+coUserId+"' and ADDRESSTYPECODE = 'ADDRESSOFRECORD' and contractid = '"+contractId+"'";
				ResultSet rsAOR = DBConnection.execStatement(con,queryAOR);
				while(rsAOR.next()){
					for(String keyAOR : setAOR){
						if(!keyAOR.equalsIgnoreCase("USERADDRESSID")&&!keyAOR.equalsIgnoreCase("ADDRESSTYPECODE")){
							AOR.put(keyAOR,  rsAOR.getString(keyAOR));
						}
					}
				}
				String queryPOR = "Select * from usercontact where couserid = '"+coUserId+"' and CONTACTTYPECODE = 'PHONEOFRECORD' and contractid = '"+contractId+"'";
				ResultSet rsPOR = DBConnection.execStatement(con,queryPOR);
				while(rsPOR.next()){
					for(String keyPOR : setPOR){
						if(!keyPOR.equalsIgnoreCase("USERADDRESSID")&&!keyPOR.equalsIgnoreCase("ADDRESSTYPECODE")){
							POR.put(keyPOR,  rsPOR.getString(keyPOR));
						}
					}
				}
				if(contactAddressTypes.contains("CORRESPONDENCE")){
					String corr = "Select * from useraddress where couserid = '"+coUserId+"' and ADDRESSTYPECODE = 'CORRESPONDENCE' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyAOR : setAOR){
							if(!keyAOR.equalsIgnoreCase("USERADDRESSID")&&!keyAOR.equalsIgnoreCase("ADDRESSTYPECODE")){
								Assert.assertEquals(AOR.get(keyAOR),corrRS.getString(keyAOR),keyAOR+" is equal between AOR and Correspondence");
								logger.info(keyAOR+" is equal between AOR and Correspondence");
							}
						}
					}
				}
				else{
					String corr = "Select * from useraddress where couserid = '"+coUserId+"' and ADDRESSTYPECODE = 'HOME' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyAOR : setAOR){
							if(!keyAOR.equalsIgnoreCase("USERADDRESSID")&&!keyAOR.equalsIgnoreCase("ADDRESSTYPECODE")){
								Assert.assertEquals(AOR.get(keyAOR),corrRS.getString(keyAOR),keyAOR+" is equal between AOR and HOME");
								logger.info(keyAOR+" is equal between AOR and Correspondence");
							}
						}
					}
				}				
				if(contactPhoneTypes.contains("MOBILE")){
					String corr = "Select * from usercontact where couserid = '"+coUserId+"' and CONTACTTYPECODE = 'MOBILE' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyPOR : setPOR){
							if(!keyPOR.equalsIgnoreCase("USERCONTACTID")&&!keyPOR.equalsIgnoreCase("CONTACTTYPECODE")){
								Assert.assertEquals(POR.get(keyPOR),corrRS.getString(keyPOR),keyPOR+" is equal between POR and Mobile");
								logger.info(keyPOR+" is equal between POR and Mobile");
							}
						}
					}
				}
				else if(!contactPhoneTypes.contains("MOBILE")&&contactPhoneTypes.contains("HOME")){
					String corr = "Select * from usercontact where couserid = '"+coUserId+"' and CONTACTTYPECODE = 'HOME' and CONTACTCHANNELCODE = 'PHONE' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyPOR : setPOR){
							if(!keyPOR.equalsIgnoreCase("USERCONTACTID")&&!keyPOR.equalsIgnoreCase("CONTACTTYPECODE")){
								Assert.assertEquals(POR.get(keyPOR),corrRS.getString(keyPOR),keyPOR+" is equal between POR and Home");
								logger.info(keyPOR+" is equal between POR and Home");
							}
						}
					}
				}
				else if(!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")&&contactPhoneTypes.contains("WORK")){
					String corr = "Select * from usercontact where couserid = '"+coUserId+"' and CONTACTTYPECODE = 'WORK' and CONTACTCHANNELCODE = 'PHONE' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyPOR : setPOR){
							if(!keyPOR.equalsIgnoreCase("USERCONTACTID")&&!keyPOR.equalsIgnoreCase("CONTACTTYPECODE")){
								Assert.assertEquals(POR.get(keyPOR),corrRS.getString(keyPOR),keyPOR+" is equal between POR and WORK");
								logger.info(keyPOR+" is equal between POR and WORK");
							}
						}
					}
				}
				else if(!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")&&!contactPhoneTypes.contains("WORK")&&contactPhoneTypes.contains("OTHER")){
					String corr = "Select * from usercontact where couserid = '"+coUserId+"' and CONTACTTYPECODE = 'OTHER' and CONTACTCHANNELCODE = 'PHONE' and contractid = '"+contractId+"' and deleted = 'N'";
					ResultSet corrRS = DBConnection.execStatement(con,corr);
					while(corrRS.next()){
						for(String keyPOR : setPOR){
							if(!keyPOR.equalsIgnoreCase("USERCONTACTID")&&!keyPOR.equalsIgnoreCase("CONTACTTYPECODE")){
								Assert.assertEquals(POR.get(keyPOR),corrRS.getString(keyPOR),keyPOR+" is equal between POR and OTHER");
								logger.info(keyPOR+" is equal between POR and OTHER");
							}
						}
					}
				}
				
			}
		}catch(Exception e){
			logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				}
			}
		
	
	}	
	
	@And("^the shared data is updated in the other linked profile also whose id are given below$")
		public void the_shared_data_is_updated_in_the_other_linked_profile_also_whose_id_are_given_below(DataTable parameters) throws SQLException{
			Map<String, String> data = parameters.asMap(String.class, String.class);
			String coUserIdSec = data.get("coUserId");
			String contractId = data.get("contractId");
			String query1 = null,query3=null,query4=null;
			String profileStr = null;
			ResultSet rs,rs2,rs3;
			logger.info("\nIn--------------------> And the shared data is updated in the other linked profile also whose id are given below");
			Gson gson = new Gson();
			Connection con = null;
			try{
				if(Service_Url.contains("v3"))
					profileStr = gson.toJson(profile);
				else
					profileStr = gson.toJson(profile1);	
			JsonObject profileObject = (JsonObject) new JsonParser().parse(profileStr);
			JsonObject suitablityObject = new JsonObject();
			JsonObject investmentObject = new JsonObject();
			JsonObject trustContObject = new JsonObject();
			JsonArray contactAddressArray = new JsonArray();
			JsonArray contactChannelArray = new JsonArray();
			if(profileObject.has("suitability"))
				suitablityObject = profileObject.get("suitability").getAsJsonObject();
			if(profileObject.has("investmentInfo"))
				investmentObject = profileObject.get("investmentInfo").getAsJsonObject();
			if(profileObject.has("trustedContactPerson"))
				trustContObject = profileObject.get("trustedContactPerson").getAsJsonObject();
			if(profileObject.has("contactAddresses"))
				contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
			if(profileObject.has("contactChannels"))
				contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
			con = DBConnection.InitConnection();
			query1 = "Select * from usercontractprofile where couserid = '"+coUserIdSec+"'";
			//query2 = "Select * from couser where couserid = '"+coUserId+"'";
			rs = DBConnection.execStatement(con,query1);
			//rs1 = DBConnection.execStatement(con,query2);
			while(rs.next()){

				//Set<String> persInfoDBUserContractSet = GlobalStaticInfo.persInfoDBUserContract.keySet();
				Set<String> trustContDBUserContractSet = GlobalStaticInfo.trustContDBUserContract.keySet();
				Set<String> suitablityDBUserContractSet = GlobalStaticInfo.suitablityDBUserContract.keySet();
				Set<String> investmentDBUserContractSet = GlobalStaticInfo.investmentDBUserContract.keySet();
				//Set<String> disclosureDBUserContractSet = GlobalStaticInfo.disclosureDBUserContract.keySet();
				if(profileObject.has("trustedContactPerson")){
				for(String trustContDBUserContractElement:trustContDBUserContractSet){
					if(!trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString().equals("")){
					 Assert.assertEquals(rs.getString(trustContDBUserContractElement),trustContObject.get(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)).getAsString(),GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is Equal");
					 logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is equal,value is "+rs.getString(trustContDBUserContractElement));
					}
					else
						logger.info(GlobalStaticInfo.trustContDBUserContract.get(trustContDBUserContractElement)+" is null");
					}
				}
				if(profileObject.has("suitability")&&!profileObject.get("contractId").getAsString().equals("")){
					for(String suitablityDBUserContractElement:suitablityDBUserContractSet){
						if(!suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString().equals("")){
						 Assert.assertEquals(rs.getString(suitablityDBUserContractElement),suitablityObject.get(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)).getAsString(),GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is Equal");
						 logger.info(GlobalStaticInfo.suitablityDBUserContract.get(suitablityDBUserContractElement)+" is equal,value is "+rs.getString(suitablityDBUserContractElement));
						}
						else
							logger.info(GlobalStaticInfo.suitablityDBCouser.get(suitablityDBUserContractElement)+" is null");
					}
				}
				if(profileObject.has("investmentInfo")&&!profileObject.get("contractId").getAsString().equals("")){
					for(String investmentDBUserContractElement:investmentDBUserContractSet){
						if(!investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString().equals("")){
						 Assert.assertEquals(rs.getString(investmentDBUserContractElement),investmentObject.get(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)).getAsString(),GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is Equal");
						 logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is equal,value is "+rs.getString(investmentDBUserContractElement));
						}
						else
							logger.info(GlobalStaticInfo.investmentDBUserContract.get(investmentDBUserContractElement)+" is null");
					}
				}
				
			
			}
			Set<String> contAddressDBUserAddressSet = GlobalStaticInfo.contAddressDBUserAddress.keySet();
			Set<String> contChannelDBUserContactSet = GlobalStaticInfo.contChannelDBUserContact.keySet();
			if(profileObject.has("contactAddresses")){
				for(int j=0;j<contactAddressArray.size();j++){
					JsonObject contactAddressObject = contactAddressArray.get(j).getAsJsonObject();
					String addressType = contactAddressObject.get("addressType").getAsString();
					if(addressType.equalsIgnoreCase("ADDRESSOFRECORD")){
					query3 ="Select * from useraddress where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and addresstypecode = 'ADDRESSOFRECORD'";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
						for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
							if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
								if(!(contAddressDBUserAddressElement.equalsIgnoreCase("USERADDRESSID")||(contAddressDBUserAddressElement.equalsIgnoreCase("ADDRESSTYPECODE")))){
								 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
								 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
								}
							}
							else
								logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
						}
					}
				}
					if(addressType.equalsIgnoreCase("CORRESPONDENCE")){
					query3 ="Select * from useraddress where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and addresstypecode = 'ADDRESSOFRECORD'";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
						for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
							if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
								if(!(contAddressDBUserAddressElement.equalsIgnoreCase("USERADDRESSID")||(contAddressDBUserAddressElement.equalsIgnoreCase("ADDRESSTYPECODE")))){
								 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
								 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
								}
							}
							else
								logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
						}
					}
				}
				if(addressType.equalsIgnoreCase("HOME")&&!contactAddressTypes.contains("CORRESPONDENCE")){
					query3 ="Select * from useraddress where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and addresstypecode = 'ADDRESSOFRECORD'";
					rs2 = DBConnection.execStatement(con,query3);
					while(rs2.next()){
						for(String contAddressDBUserAddressElement:contAddressDBUserAddressSet){
							if(!contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString().equals("")){
								if(!(contAddressDBUserAddressElement.equalsIgnoreCase("USERADDRESSID")||(contAddressDBUserAddressElement.equalsIgnoreCase("ADDRESSTYPECODE")))){
								 Assert.assertEquals(rs2.getString(contAddressDBUserAddressElement),contactAddressObject.get(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)).getAsString(),GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is Equal");
								 logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is equal,value is "+rs2.getString(contAddressDBUserAddressElement));
								}
							}
							else
								logger.info(GlobalStaticInfo.contAddressDBUserAddress.get(contAddressDBUserAddressElement)+" is null");
						}
					}
				}
			}
			
		}
			if(profileObject.has("contactChannels")){
				for(int k=0;k<contactChannelArray.size();k++){
					JsonObject contactChannelObject = contactChannelArray.get(k).getAsJsonObject();
					String contactType = contactChannelObject.get("contactChannelType").getAsString();
					if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("EMAIL")){
					if(contactType.equalsIgnoreCase("EMAILOFRECORD")||contactType.equalsIgnoreCase("PRIMARY")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='EMAILOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
								 if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
									Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
								 }
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
					if(contactChannelObject.get("contactChannel").getAsString().equalsIgnoreCase("PHONE")){
					if(contactType.equalsIgnoreCase("PHONEOFRECORD")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
					if(contactType.equalsIgnoreCase("MOBILE")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
					if(contactType.equalsIgnoreCase("Home")&&!contactPhoneTypes.contains("MOBILE")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
					if(contactType.equalsIgnoreCase("Work")&&!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
					if(contactType.equalsIgnoreCase("Other")&&!contactPhoneTypes.contains("MOBILE")&&!contactPhoneTypes.contains("HOME")&&!contactPhoneTypes.contains("WORK")){
						query4 = "select * from usercontact where couserid='"+coUserIdSec+"' and contractid='"+contractId+"' and contacttypecode='PHONEOFRECORD'";
						rs3=DBConnection.execStatement(con,query4);
						while(rs3.next()){
							for(String contChannelDBUserContactElement:contChannelDBUserContactSet){
								if(!contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString().equals("")){
									if(!(contChannelDBUserContactElement.equalsIgnoreCase("USERCONTACTID")||contChannelDBUserContactElement.equalsIgnoreCase("CONTACTTYPECODE"))){
										 Assert.assertEquals(rs3.getString(contChannelDBUserContactElement),contactChannelObject.get(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)).getAsString(),GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is Equal");
										 logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is equal,value is "+rs3.getString(contChannelDBUserContactElement));
									}
								}
								else
									logger.info(GlobalStaticInfo.contChannelDBUserContact.get(contChannelDBUserContactElement)+" is null");
							}
						}
					}
				}
			}
			
		}
	}catch(Exception e){
		logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			}
		}
			
		}
	
	@Then("^user recieves BAD_REQUEST response with error response code (\\d+)$")
	public void user_recieves_BAD_REQUEST_response_with_error_response_code(int responseCode)throws SQLException{
		try{
			logger.info("In Then");
			int actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode, responseCode, "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@And("^a success message is logged in audit log table for \"([^\"]*)\"$")
	public void The_success_message_is_logged_in_audit_table(String User) throws Throwable{
		logger.info("In -----> The success message is logged in audit table");
		TransactionLog audit = new TransactionLog();
		String SSOID = null;
		if(Service_Url.contains("v3"))
			SSOID = profile.getSsoId();
		else if(Service_Url.contains("v4"))
			SSOID = profile1.getSsoId();
		String typeCode = "updateProfile";
		String Message = "Success";
		audit.auditlog_should_match_in_db(requestID,SSOID,typeCode,Message,User);
	}
	
	@And("^a error message is logged in audit log table for \"([^\"]*)\"$")
	public void The_error_message_is_logged_in_audit_table(String User) throws Throwable{
		logger.info("In -----> The success message is logged in audit table");
		TransactionLog audit = new TransactionLog();
		String SSOID = null;
		if(Service_Url.contains("v3"))
			SSOID = profile.getSsoId();
		else if(Service_Url.contains("v4"))
			SSOID = profile1.getSsoId();
		String typeCode = "updateProfile";
		String Message = "Error";
		audit.auditlog_should_match_in_db(requestID,SSOID,typeCode,Message,User);
	}
	
	public String getJWTAuthToken(String userId, String password) {

		try {
		
			
			request = given().log().all().formParam("USER", userId).formParam("PASSWORD", password)
					.formParam("BUIDTYPE", "INDV").formParam("target", "/auth/login/").formParam("smquerydata", "")
					.formParam("smauthreason", "").formParam("smagentname", "ssologin");

			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.post("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))				
				response = request.post("https://ssologin-stage.prudential.com/app/ssologin/AuthLogin.fcc").andReturn();

			cookies = response.getCookies();
		
			logger.info("response-cookies :" + cookies);

			request = given().log().all().cookies(cookies);
			
			if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
				response = request.get("https://api-dev.prudential.com/.signjwt").andReturn();
			else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
				response = request.get("https://api-stage.prudential.com/.signjwt").andReturn();
			JsonPath jp = new JsonPath(response.asString());

			XPruAuthJWT = jp.getString("jwt");

			logger.info("Prospect JWT Token is :" + XPruAuthJWT);

			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return XPruAuthJWT;

	}
	
}
