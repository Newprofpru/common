package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.accounts;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GeneratePayloadSMSession;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class accountsCreate {
	
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static String query=null;
	static String query2=null;
	static Response Res1;
	String Service_Url = getEnvInfo.getAccountsSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	String resBody=null;
	static String accountId = null;
	static String accountNumber = null;
	static String sourceTypeCode = null;
	String ssoid = null;
	String accounts_Id = null;
	String requestID = null;
	static Map<String,String> cookie_Data = new HashMap<String,String>();
    static Map<String,String> param_Data = new HashMap<String,String>();
    public static HashMap<String,String> beneficialownerinfo = new HashMap<>();
    private static RequestSpecification request1;
    static String payload1;
    static String SmCookie = "SMSESSION=IZC6SMudtwvfmzA12FmiM2ZXACivkZkiBtiAX3nzs8VqZQxXaEtr6zcHrAxGsPp1G6TYrp3GWhY987nSIbZgAGl5sQ4uCK3d3umPNRDq0FuU9LLFq/8hjFRJhWIKiifIyQs0ksqY3ywZROnh9+EupycTmblJmm2Ar3DlfribwCoSEXHp9czXE3gN/HLjnzpaAQwcHubYf9P1HRI8m8ckZOMUwxI2R3xMa0hc3tXGQG1qq3JjJNE32FsRZ0nndKA/nOGNtg3hXl2bS1rtHMsW6EJ/jweXP8P4XUouQaRJrhzGzFrNTbuta+YEqTTiab/Ra/dwoqfESTeMcPJuhO9Jp7BC0XOEagjPzh0QyC/fbxmoWl+VqDcxj6cTmEi/CfCcBT/Jt0TxspjpzI4HXZXSwr449Yikv9bT35QLiAqhD5+rFgZlm6QOnPv2eUzyIpklWTD+13ZLHyBmLVxcjoifQulJSO7PherWH3wPm/1vF7y4Fv0s3acbAPva+A/aVcg5OFa++8DwRHRmbn2sfofxG5aN/NYBDS4PvDH3f+SMdhW/J3mME9dPfXYTKvKXkORcsGLHFL/zmrxI+aTQsQBzAo1VlVa8fAlYwr5WypxIryimzYmhn0GbGgwZfNcwVN+9Np/vq4KoRQnsP+dQz3+SqZeNcq9uvG2sAqnt1YME5ZLrqI/3e18HQXuJ8Ne3XqcAvpYvlECeNIrb0+YpBIECEjvzinCvOWuQVBagu4khuwILhm0/FVVROnka4U2fbZUKeh8EIUKG/hUdUuzFWsjK5M9O+aPkoRFuVjmVx/7DT57N8K731R8kPUgZcUxaB/RU/XV0sOxUqctCdwr4Ht7qy5nHOLrIa2mXLZ7YeRfkVKatyg423685/nK2/ItqraIF5Xy3IA0otItX3ueyx2+gVgKFI1TlJYxdll4nhVMqXA1fEHLww9YWN3ZECCyivNp9cxOtxqKHF0YXJaIZGVmVAm4HVPhFbDVNTRr6NJ+aAMDyrsofnLLVDHRjvyVTy/EaGTJFruVHxDGJfA7nnC421O6HYlHLTrPg6gy+nA/leVR+7SIpBJ5n56JHK34H7CO32UPa0Se6Nf9HneWmCrx/CMk8MoeHFSMCYGWJ28/YO/W11J62rS6/YLnM5+B4PZhjbMfDB0Q9x9u1KUdBUo+JaNhVVZg8v7PEWLpVQxzaMGLVN5J/BwV58zYufqUqjmgtR8LF9TX0eNp+oIpcBSNTJWI9+ro+XP6Z3jNb3tZGIl5sZLbPgkCJ9d9+0pRhSajc; path=/; domain=.prudential.com; Secure;";
    
	boolean isNullNeeded = false;
	static accounts accounts = new accounts();
	JsonObject accountsObject = new JsonObject();;
	JsonObject responseObject = new JsonObject();
	

	
	@Given("^a working valid endpoint is exists for the\"([^\"]*)\" API$")
	public void valid_endpoint_for_accounts_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
		
	
	}
	
	
	@When("^the POST request is sent to accounts API with below request body data of accounts$")
	public void a_POST_request_is_sent_to_accounts_API_with_below_request_body_details_of_accounts(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		Random rand = new Random();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "accountstest_" + n;
		RestAssured.baseURI = Service_Url;
		
		Map<String, String> data = parameters.asMap(String.class, String.class);
		
		accounts_Id = data.get("accounts_Id");
				ssoid=data.get("Header_ssoId");
		Set<String> paramNames=data.keySet();
		
		accounts = RequestBodyPojoCreater.getAccountsCreate(accounts_Id,isNullNeeded);
		
		accountNumber=accounts.getaccountNumber();
		System.out.println(accounts.getaccountNumber());
		accountId = accounts.getaccountID();
		
			accountId  = RandomStringUtils.random(10, true, true).toUpperCase();
			accountNumber=RandomStringUtils.random(10, true, true).toUpperCase();
			
			
			System.out.println(accountId);
			System.out.println(accountNumber);
		
		accounts.setaccountID(accountId);
		//accounts.setaccountNumber(accountNumber);
	
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-PruPrimaryIdentity", ssoid);
	
		Gson gson = new Gson();
		String body = gson.toJson(accounts);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).cookie(SmCookie).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@When("^the POST request is sent to accounts API with below request body data for Manual accounts$")
	public void a_POST_request_is_sent_to_accounts_API_with_below_request_body_for_Manual_accounts(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		Random rand = new Random();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "accountstest_" + n;
		RestAssured.baseURI = Service_Url;
		
		Map<String, String> data = parameters.asMap(String.class, String.class);
		
		accounts_Id = data.get("accounts_Id");
				ssoid=data.get("Header_ssoId");
		Set<String> paramNames=data.keySet();
		
		accounts = RequestBodyPojoCreater.getAccountsCreate(accounts_Id,isNullNeeded);
		
		accountNumber=accounts.getaccountNumber();
		System.out.println(accounts.getaccountNumber());
		
		
		
			accountNumber=RandomStringUtils.random(10, true, true).toUpperCase();
			
			
			System.out.println(accountId);
			System.out.println(accountNumber);
		
		
		accounts.setaccountNumber(accountNumber);
	
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-PruPrimaryIdentity", ssoid);
	
		Gson gson = new Gson();
		String body = gson.toJson(accounts);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).cookie(SmCookie).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		
	@When("^the POST request is sent to accounts API without SSOID$")
	public void a_POST_request_is_sent_to_accounts_API_without_ssoid(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		Random rand = new Random();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "accountstest_" + n;
		RestAssured.baseURI = Service_Url;
		
		Map<String, String> data = parameters.asMap(String.class, String.class);
		
		accounts_Id = data.get("accounts_Id");
				
		Set<String> paramNames=data.keySet();
		
		accounts = RequestBodyPojoCreater.getAccountsCreate(accounts_Id,isNullNeeded);
		
	
	
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization);
	
		Gson gson = new Gson();
		String body = gson.toJson(accounts);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).cookie(SmCookie).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	@When("^the POST request is sent to accounts API without accountid$")
	public void a_POST_request_is_sent_to_accounts_API_without_accountid(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		Random rand = new Random();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "accountstest_" + n;
		RestAssured.baseURI = Service_Url;
		
		Map<String, String> data = parameters.asMap(String.class, String.class);
		
		accounts_Id = data.get("accounts_Id");
				
		Set<String> paramNames=data.keySet();
		
		accounts = RequestBodyPojoCreater.getAccountsCreate(accounts_Id,isNullNeeded);
		ssoid=data.get("Header_ssoId");
	
	
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization).header("X-PruPrimaryIdentity", ssoid);;
	
		Gson gson = new Gson();
		String body = gson.toJson(accounts);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).cookie(SmCookie).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
	
	@Then("^the is updated and success response code 200 is recieved succesfully$")
	public void the_data_is_updated_and_the_success_response_code_200_is_recieved_successfully(){
		try{
			logger.info("\nIn--------------------> Then the data is updated correctly and the success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@Then("^the data is not updated and response code 400 is recieved$")
	public void the_data_is_not_updated_and_response_code_400_is_recieved(){
		try{
			logger.info("\nIn--------------------> Then the data is updated correctly and the success response code 200 is recieved");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "400", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	
	
	@And("^the data is created in the party holding mapping , Holding summary read ,holding tables and verified successfully$")
	public void the_data_is_created_in_the_party_holding_mapping_Holdingsummaryread_holding_tables_and_verified_successfully() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
		
		String query1 = null,query2=null,query3=null,query4=null,query5=null,query6=null;
		Connection con = null;
		Connection con1 = null;
		String accountsStr = null;
		
	
		
	
		
		accountId=accounts.getaccountID();
		accountNumber=accounts.getaccountNumber();

		logger.info("In And the data is updated in db");
		
		Gson gson = new Gson();
		
		try{
		
		accounts = RequestBodyPojoCreater.getAccountsCreate(accounts_Id, isNullNeeded);
		accounts.setaccountID(accountId);
		accounts.setaccountNumber(accountNumber);
		accountsStr = gson.toJson(accounts);
		
		resBody=Res1.getBody().asString();
		accountsObject = (JsonObject) new JsonParser().parse(accountsStr);
		responseObject = (JsonObject) new JsonParser().parse(resBody);
		String holdingId = responseObject.get("holdingID").getAsString();
		System.out.println(holdingId);
		
		

		con = DBConnection.InitAccountsDbConnection();
		con1 = DBConnection.InitAccountsDbConnection();
		

		
		query1=  "Select * from (Select * from PARTYHOLDINGMAPPING where accountid = '"+accountId+"' order by updateddate desc)where ROWNUM <=1";
		query2 = "Select *  from (Select * from holdingsummaryread where accountid = '"+accountId+"' order by updateddate desc)where ROWNUM <=1";
		query3 = "Select *  from (Select * from holding where accountid = '"+accountId+"' order by updateddate desc)where ROWNUM <=1";
	
		
		
		ResultSet resultset1  = DBConnection.execStatement(con,query1);		
		
		Set<String> accountsPartyHoldingMapSet = GlobalStaticInfo.accountsPartyHoldingMap.keySet();

		while(resultset1.next()){
	
			for(String accountsPartyHoldingMapElement:accountsPartyHoldingMapSet){

				boolean a = accountsPartyHoldingMapElement.contains("ACCOUNTID");
				
				System.out.println(a);
				System.out.println(accountsObject.get(GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)).getAsString());
				if(!accountsObject.get(GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)).isJsonNull()){
					Assert.assertEquals(resultset1.getString(accountsPartyHoldingMapElement),accountsObject.get(GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)).getAsString(),GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)+" is Equal");
					 logger.info(GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)+" is equal,value is "+resultset1.getString(accountsPartyHoldingMapElement));
					}
					else
						logger.info(GlobalStaticInfo.accountsPartyHoldingMap.get(accountsPartyHoldingMapElement)+" is null");	
			}
		}
		
		
	
		ResultSet resultset2  = DBConnection.execStatement(con,query2);		
		
		Set<String> accountsHoldingSummarySet = GlobalStaticInfo.accountsHoldingSummary.keySet();
		
		
						
		while(resultset2.next()){


for(String accountsHoldingSummaryElement:accountsHoldingSummarySet){

	
	if(!accountsObject.get(GlobalStaticInfo.accountsHoldingSummary.get(accountsHoldingSummaryElement)).isJsonNull()){
		
	
				
		Assert.assertEquals(resultset2.getString(accountsHoldingSummaryElement),accountsObject.get(GlobalStaticInfo.accountsHoldingSummary.get(accountsHoldingSummaryElement)).getAsString(),GlobalStaticInfo.accountsHoldingSummary.get(accountsHoldingSummaryElement)+" is Equal");
		 logger.info(GlobalStaticInfo.accountsHoldingSummary.get(accountsHoldingSummaryElement)+" is equal,value is "+resultset2.getString(accountsHoldingSummaryElement));
		}
		else
			logger.info(GlobalStaticInfo.accountsHoldingSummary.get(accountsHoldingSummaryElement)+" is null");	
}
  
		}
		
		ResultSet resultset3  = DBConnection.execStatement(con,query3);		
	
		Set<String> accountsHoldingSet = GlobalStaticInfo.accountsHolding.keySet();
	
		
		
						
		while(resultset3.next()){
		
			for(String accountsHoldingElement:accountsHoldingSet){
				
				
				if(!accountsObject.get(GlobalStaticInfo.accountsHolding.get(accountsHoldingElement)).isJsonNull()){
					Assert.assertEquals(resultset3.getString(accountsHoldingElement),accountsObject.get(GlobalStaticInfo.accountsHolding.get(accountsHoldingElement)).getAsString(),GlobalStaticInfo.accountsHolding.get(accountsHoldingElement)+" is Equal");
					 logger.info(GlobalStaticInfo.accountsHolding.get(accountsHoldingElement)+" is equal,value is "+resultset3.getString(accountsHoldingElement));
					}
					else
						logger.info(GlobalStaticInfo.accountsHolding.get(accountsHoldingElement)+" is null");	
			}
		}
		
		
		query4 = "Select HOLDINGSOURCETYPECODEVALUE  from (Select * from holdingsummaryread where accountid = '"+accountId+"' order by updateddate desc)where ROWNUM <=1";
		
		
		ResultSet resultset4  = DBConnection.execStatement(con,query4);	
	
		
		
		while(resultset4.next()) 
		{
			
			
			sourceTypeCode=accounts.getsourceTypeCode();
			
			
			if(sourceTypeCode.equals("INTERNAL")){
				Assert.assertEquals(resultset4.getString(1), "1");
				System.out.println( "Source Type Coe : Internal and HOLDINGSOURCETYPECODEVALUE in DB is : 1 " );
			}
			else if(sourceTypeCode.equals("EXTERNAL")){
				Assert.assertEquals(resultset4.getString(1), "2");
				System.out.println( "Source Type Coe : External and HOLDINGSOURCETYPECODEVALUE in DB is : 2 " );
			}
			else if(sourceTypeCode.equals("MANUAL")) {
				Assert.assertEquals(resultset4.getString(1), "3");
			System.out.println( "Source Type Coe : Manual and HOLDINGSOURCETYPECODEVALUE in DB is : 3 " );
			}
			
		}
		
		query5 = "Select HoldingId  from (Select * from partyholdingmapping where holdingid = '"+holdingId+"' order by updateddate desc)where ROWNUM <=1";
		
		
		
ResultSet resultset5  = DBConnection.execStatement(con,query5);	
	
		
		
		while(resultset5.next()) 
		{
			

			if(resultset5.getString(1).equals(holdingId)){
				Assert.assertEquals(resultset5.getString(1), holdingId);
				logger.info("--------Holdin id in the response and the DB are the same--------------------");
		
			}
			else
				System.out.println( "HOLDING ID is NOT EQUAL " );
		}
		
		query2 = "Select *  from (Select * from holdingsummaryread where accountNumber = '"+accountNumber+"' order by updateddate desc)where ROWNUM <=1";
ResultSet resultset21  = DBConnection.execStatement(con,query2);		
		
		Set<String> accountsHoldingSummarySet1 = GlobalStaticInfo.accountsHoldingSummary3.keySet();
		
	
		
		
						
		while(resultset21.next()){


for(String accountsHoldingSummaryElement:accountsHoldingSummarySet1){

	
	if(!accountsObject.get(GlobalStaticInfo.accountsHoldingSummary3.get(accountsHoldingSummaryElement)).isJsonNull()){
		
	
				
		Assert.assertEquals(resultset21.getString(accountsHoldingSummaryElement),accountsObject.get(GlobalStaticInfo.accountsHoldingSummary3.get(accountsHoldingSummaryElement)).getAsString(),GlobalStaticInfo.accountsHoldingSummary3.get(accountsHoldingSummaryElement)+" is Equal");
		 logger.info(GlobalStaticInfo.accountsHoldingSummary3.get(accountsHoldingSummaryElement)+" is equal,value is "+resultset21.getString(accountsHoldingSummaryElement));
		}
		else
			logger.info(GlobalStaticInfo.accountsHoldingSummary3.get(accountsHoldingSummaryElement)+" is null");	
}
  
		}
		
		query6 = "Select accountId from (Select * from holdingsummaryread where accountNumber = '"+accountNumber+"' order by updateddate desc)where ROWNUM <=1";
		
		ResultSet resultset6  = DBConnection.execStatement(con,query6);	
	
		
		
		while(resultset6.next()) 
		{
			
			boolean a=sourceTypeCode.equals("MANUAL") && accounts.getaccountID().equals("");
			
			
			System.out.println("*********************************");
			System.out.println(a);
			accountId=accounts.getaccountID();
			sourceTypeCode=accounts.getsourceTypeCode();
			System.out.println("*********************************");
			System.out.println(accounts.getsourceTypeCode());
			System.out.println(resultset6.getString(1));
			System.out.println("*********************************");
			
			if(sourceTypeCode.equals("INTERNAL")){
				Assert.assertEquals(resultset6.getString(1), accountId);
				System.out.println( "  INTERNAL -------------------- Account ID : POST request and Accountid in DB in DB Both are equal " );
			}
			else if(sourceTypeCode.equals("EXTERNAL")){
				Assert.assertEquals(resultset6.getString(1), accountId);
				System.out.println( "EXTERNAL -------------- Account ID : POST request and Accountid in DB in DB Both are equal " );
			}
			else if(a) {
				//Assert.assertEquals(resultset6.getString(1), accountId);
				Assert.assertFalse(resultset6.getString(1).equals( accountId));
			System.out.println( "MANUAL ---------------Account ID : POST request and Accountid in DB in DB Both are  NOT EQUAL equal " );
			}
			
			
		}
		
		
		
		
		}
	catch(Exception e){
	logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				con1.close();
				}
			}
		

	} 

}
