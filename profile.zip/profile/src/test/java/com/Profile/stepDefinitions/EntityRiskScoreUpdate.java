package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalInt;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.DB_Module;
import com.Profile.supportLibraries.GeneratePayloadRepInput;
import com.Profile.supportLibraries.GenericEvent;
import com.Profile.supportLibraries.GetSmsessionToken;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class EntityRiskScoreUpdate {
	
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static RequestSpecification request1;
	static Response Res;
	static Response Res1;
	static String payload;
	static String payload2;
    String resultbody;
	static Map<String,String> cookie_Data = new HashMap<String,String>();
	static Map<String,String> Repu_Data = new HashMap<String,String>();
	Map<String, String> valueDiff = new HashMap<String,String>();
	static Map<String, String> OldValueMap = new HashMap<String,String>();
	static Map<String, String> OldValueMap1 = new HashMap<String,String>();
	static Map<String, String> OldValueMap2 = new HashMap<String,String>();
	static Map<String, String> OldValueMap3 = new HashMap<String,String>();
	static Map<String, String> OldValueMap4 = new HashMap<String,String>();
	static Map<String, String> OldValueMap5 = new HashMap<String,String>();
	static Map<String, String> OldValueMap6 = new HashMap<String,String>();
	static Map<String, String> NewValueMap = new HashMap<String,String>();
	static Map<String, String> NewValueMap1 = new HashMap<String,String>();
	static Map<String, String> NewValueMap2 = new HashMap<String,String>();
	static Map<String, String> NewValueMap3 = new HashMap<String,String>();
	static Map<String, String> NewValueMap4 = new HashMap<String,String>();
	static Map<String, String> NewValueMap5 = new HashMap<String,String>();
	static Map<String, String> NewValueMap6 = new HashMap<String,String>();
	ResultSet rs;
	String Authorization = getEnvInfo.getRepAuthorization();
	String Service_Url = getEnvInfo.getSecureUrlRiskScore();
	String ivUser = getEnvInfo.getIVuser();
	String requestID = null;
	String userTransactionlogID = null;	
	
	@Given("^working endpoint exists \"([^\"]*)\" API$")
	public void valid_endpoint_for_accounts_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	@When("^valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate the smsession$")
	public void valid_user_to_generate_smsession(String username, String password, String buid) throws Throwable {		
		resultbody = GetSmsessionToken.generateSmsessionToken(username,password);
		logger.info("SMSession Cookie: " +resultbody);	    
	}

	@When("^request for sourceOfFunds is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_sourceOfFunds_is_submitted_with_(String eftcb, String eftsb, String dcccc, String dccctp, String cash, String check, String mo, String tc, String cbc, String fedwirec, String fedwiretp, String achus, String achint, String ddefault, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityPaymentMethod'";
    	logger.info("Query: "+query); 
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);    	    	
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("EFTCB", eftcb+ m.getAsInt());
    	Repu_Data.put("EFTSB", eftsb+ m.getAsInt());
    	Repu_Data.put("DCCCC", dcccc+ m.getAsInt());
    	Repu_Data.put("DCCCTP", dccctp+ m.getAsInt());
    	Repu_Data.put("CASH", cash+ m.getAsInt());
    	Repu_Data.put("CHECK", check+ m.getAsInt());
    	Repu_Data.put("MO", mo+ m.getAsInt());
    	Repu_Data.put("TC", tc+ m.getAsInt());
    	Repu_Data.put("CBC", cbc+ m.getAsInt());
    	Repu_Data.put("FEDWIREC", fedwirec+ m.getAsInt());
    	Repu_Data.put("FEDWIRETP", fedwiretp+ m.getAsInt());
    	Repu_Data.put("ACHUS", achus+ m.getAsInt());
    	Repu_Data.put("ACHINT", achint+ m.getAsInt());
    	Repu_Data.put("DDEFAULT", ddefault+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.src_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}

	@When("^request for product is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_product_is_submitted_with_(String prody, String prodn, String pdefault, String multprody, String multprodn, String mdefault, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='ProductCashvalue'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='MultipleProductCashvalue'";
    	logger.info("Query: "+query);
    	logger.info("Query: "+query1);
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("PRODY", prody+ m.getAsInt());
    	Repu_Data.put("PRODN", prodn+ m.getAsInt());
    	Repu_Data.put("PDEFAULT", pdefault+ m.getAsInt());
    	Repu_Data.put("MULTPRODY", multprody+ m.getAsInt());
    	Repu_Data.put("MULTPRODN", multprodn+ m.getAsInt());
    	Repu_Data.put("MDEFAULT", mdefault+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.prod_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for highRiskThreshold is submitted with (.*),(.*),(.*),(.*)$")
	public void request_for_highRiskThreshold_is_submitted_with_(String finalHigh, String IndvHigh, String operator, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityFinalSummation'";
		logger.info("Query: "+query);
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("finalhighriskthreshold", finalHigh+ m.getAsInt());
    	Repu_Data.put("individualhighriskthreshold", IndvHigh+ m.getAsInt());
    	Repu_Data.put("operator", operator);
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.finalSum_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for demography is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_demography_is_submitted_with_(String beneAddy, String beneAddn, String beneAddDef, String benePery, String benePern, String benePerDef, String opc, String sc, String bscorp, String ngo, String embconss, String tppp, String trustf, String trusto, String spv, String dfi, String ffi, String ffio, String pic, String typeDef, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='BeneficialOwnersNameAddress'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='BeneficialPercent'";
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityTypeCode'";
    	logger.info("Query: "+query); 
    	logger.info("Query: "+query1);
    	logger.info("Query: "+query2);
    	OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);    
    	OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1); 
    	OldValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2); 
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("beneAddy", beneAddy+ m.getAsInt());
    	Repu_Data.put("beneAddn", beneAddn+ m.getAsInt());
    	Repu_Data.put("beneAddDef", beneAddDef+ m.getAsInt());
    	Repu_Data.put("benePery", benePery+ m.getAsInt());
    	Repu_Data.put("benePern", benePern+ m.getAsInt());
    	Repu_Data.put("benePerDef", benePerDef+ m.getAsInt());
    	Repu_Data.put("opc", opc+ m.getAsInt());
    	Repu_Data.put("sc", sc+ m.getAsInt());
    	Repu_Data.put("bscorp", bscorp+ m.getAsInt());
    	Repu_Data.put("ngo", ngo+ m.getAsInt());
    	Repu_Data.put("embconss", embconss+ m.getAsInt());
    	Repu_Data.put("tppp", tppp+ m.getAsInt());
    	Repu_Data.put("trustf", trustf+ m.getAsInt());
    	Repu_Data.put("trusto", trusto+ m.getAsInt());
    	Repu_Data.put("spv", spv+ m.getAsInt());
    	Repu_Data.put("dfi", dfi+ m.getAsInt());
    	Repu_Data.put("ffi", ffi+ m.getAsInt());
    	Repu_Data.put("ffio", ffio+ m.getAsInt());
    	Repu_Data.put("pic", pic+ m.getAsInt());
    	Repu_Data.put("typeDef", typeDef+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.demo_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for reputation is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_reputation_is_submitted_with_(String mariy, String marin, String mariDef, String pfcy, String pfcn, String pfcDef, String advmedy, String advmedn, String advmedDef, String transmedy, String transmedn, String transmedDef, String ofacy, String ofacn, String ofacDef, String locsany, String locsann, String locsanDef, String sary, String sarn, String sarDef, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityTransactionMedia'";
		OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntitySAR'";
		OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityPFC'";
		OldValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityOFAC'";
		OldValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);
		String query4 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityMarijuana'";
		OldValueMap4 = DB_Module.seperatevalueSinglecolumn(con, query4);
		String query5 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityLocalTrans'";
		OldValueMap5 = DB_Module.seperatevalueSinglecolumn(con, query5);
		String query6 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityAdverseMedia'";
		OldValueMap6 = DB_Module.seperatevalueSinglecolumn(con, query6);
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("mariy", mariy+ m.getAsInt());
    	Repu_Data.put("marin", marin+ m.getAsInt());
    	Repu_Data.put("mariDef", mariDef+ m.getAsInt());
    	Repu_Data.put("pfcy", pfcy+ m.getAsInt());
    	Repu_Data.put("pfcn", pfcn+ m.getAsInt());
    	Repu_Data.put("pfcDef", pfcDef+ m.getAsInt());
    	Repu_Data.put("advmedy", advmedy+ m.getAsInt());
    	Repu_Data.put("advmedn", advmedn+ m.getAsInt());
    	Repu_Data.put("advmedDef", advmedDef+ m.getAsInt());
    	Repu_Data.put("transmedy", transmedy+ m.getAsInt());
    	Repu_Data.put("transmedn", transmedn+ m.getAsInt());
    	Repu_Data.put("transmedDef", transmedDef+ m.getAsInt());
    	Repu_Data.put("ofacy", ofacy+ m.getAsInt());
    	Repu_Data.put("ofacn", ofacn+ m.getAsInt());
    	Repu_Data.put("ofacDef", ofacDef+ m.getAsInt());
    	Repu_Data.put("locsany", locsany+ m.getAsInt());
    	Repu_Data.put("locsann", locsann+ m.getAsInt());
    	Repu_Data.put("locsanDef", locsanDef+ m.getAsInt());
    	Repu_Data.put("sary", sary+ m.getAsInt());
    	Repu_Data.put("sarn", sarn+ m.getAsInt());
    	Repu_Data.put("sarDef", sarDef+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.rep_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	
	@When("^request for benereputation is submitted with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)$")
	public void request_for_benereputation_is_submitted_with_(String benemariy, String benemarin, String benemariDef, String benepfcy, String benepfcn, String benepfcDef, String beneofacy, String beneofacn, String beneofacDef, String beneadvy, String beneadvn, String beneadvDef, String type) throws Throwable {
		logger.info("In When");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneAdverseMedia'";
		OldValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneMarijuana'";
		OldValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBenePFC'";
		OldValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneOFAC'";
		OldValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);    	 
    	 
    	Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		OptionalInt m = rand.ints(100, 0, 500).findAny();
		requestID = "AMLUEntRisk" + n;
		request = given().log().all().header("Authorization", Authorization)
				.header("X-PruRequestID", requestID).header("X-PruComponentId","AMLUEntRisk").header("iv-user", ivUser);		
    	Repu_Data.put("benemariy", benemariy+ m.getAsInt());
    	Repu_Data.put("benemarin", benemarin+ m.getAsInt());
    	Repu_Data.put("benemariDef", benemariDef+ m.getAsInt());
    	Repu_Data.put("benepfcy", benepfcy+ m.getAsInt());
    	Repu_Data.put("benepfcn", benepfcn+ m.getAsInt());
    	Repu_Data.put("benepfcDef", benepfcDef+ m.getAsInt());
    	Repu_Data.put("beneofacy", beneofacy+ m.getAsInt());
    	Repu_Data.put("beneofacn", beneofacn+ m.getAsInt());
    	Repu_Data.put("beneofacDef", beneofacDef+ m.getAsInt());
    	Repu_Data.put("beneadvy", beneadvy+ m.getAsInt());
    	Repu_Data.put("beneadvn", beneadvn+ m.getAsInt());
    	Repu_Data.put("beneadvDef", beneadvDef+ m.getAsInt());
    	Repu_Data.put("TYPE", type);
    	ObjectMapper mapper = new ObjectMapper();
    	payload = mapper.writeValueAsString(GeneratePayloadRepInput.benerep_payload(Repu_Data));
    	Res = request.log().all().body(payload).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
	}
	@Then("^success response is received from put api$")
	public void success_response_is_received_from_the_api() throws Throwable {
		try{
			logger.info("In Then the data is updated and success response code 200 is recieved");
			Integer actualResponseCode = Res.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}

	@Then("^response for sourceofFunds should match with values in DB$")
	public void response_for_sourceofFunds_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityPaymentMethod'";
    	logger.info("Query: "+query);    	  
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Assert.assertEquals(Repu_Data.get("EFTCB"),NewValueMap.get("eft-cb") );
    	logger.info("EFTCB is equal, value is "+Repu_Data.get("EFTCB"));
    	Assert.assertEquals(Repu_Data.get("EFTSB"),NewValueMap.get("eft-sb") );  
    	logger.info("EFTSB is equal, value is "+Repu_Data.get("EFTSB"));
    	Assert.assertEquals(Repu_Data.get("DCCCC"),NewValueMap.get("dc/cc-c") ); 
    	logger.info("DCCCC is equal, value is "+Repu_Data.get("DCCCC"));
    	Assert.assertEquals(Repu_Data.get("DCCCTP"),NewValueMap.get("dc/cc-tp") );   
    	logger.info("DCCCTP is equal, value is "+Repu_Data.get("DCCCTP"));
    	Assert.assertEquals(Repu_Data.get("CASH"),NewValueMap.get("cash") ); 
    	logger.info("CASH is equal, value is "+Repu_Data.get("CASH"));
    	Assert.assertEquals(Repu_Data.get("CHECK"),NewValueMap.get("check") ); 
    	logger.info("CHECK is equal, value is "+Repu_Data.get("CHECK"));
    	Assert.assertEquals(Repu_Data.get("MO"),NewValueMap.get("mo") );
    	logger.info("MO is equal, value is "+Repu_Data.get("MO"));
    	Assert.assertEquals(Repu_Data.get("TC"),NewValueMap.get("tc") );
    	logger.info("TC is equal, value is "+Repu_Data.get("TC"));
    	Assert.assertEquals(Repu_Data.get("CBC"),NewValueMap.get("c/b-c") );
    	logger.info("CBC is equal, value is "+Repu_Data.get("CBC"));
    	Assert.assertEquals(Repu_Data.get("FEDWIREC"),NewValueMap.get("fedwire-c") );  
    	logger.info("FEDWIREC is equal, value is "+Repu_Data.get("FEDWIREC"));
    	Assert.assertEquals(Repu_Data.get("FEDWIRETP"),NewValueMap.get("fedwire-tp") ); 
    	logger.info("FEDWIRETP is equal, value is "+Repu_Data.get("FEDWIRETP"));
    	Assert.assertEquals(Repu_Data.get("ACHUS"),NewValueMap.get("ach-us") );   
    	logger.info("ACHUS is equal, value is "+Repu_Data.get("ACHUS"));
    	Assert.assertEquals(Repu_Data.get("ACHINT"),NewValueMap.get("ach-int") ); 
    	logger.info("ACHINT is equal, value is "+Repu_Data.get("ACHINT"));
	}
	
	@Then("^response for product should match with values in DB$")
	public void response_for_product_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='ProductCashvalue'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='MultipleProductCashvalue'";
    	logger.info("Query: "+query);
    	logger.info("Query: "+query1);
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);  
    	Assert.assertEquals(Repu_Data.get("PRODY"),NewValueMap.get("y") );
    	logger.info("PRODY is equal, value is "+Repu_Data.get("PRODY"));
    	Assert.assertEquals(Repu_Data.get("PRODN"),NewValueMap.get("n") );  
    	logger.info("PRODN is equal, value is "+Repu_Data.get("PRODN"));
    	Assert.assertEquals(Repu_Data.get("MULTPRODY"),NewValueMap1.get("y") ); 
    	logger.info("MULTPRODY is equal, value is "+Repu_Data.get("MULTPRODY"));
    	Assert.assertEquals(Repu_Data.get("MULTPRODN"),NewValueMap1.get("n") );   
    	logger.info("MULTPRODN is equal, value is "+Repu_Data.get("MULTPRODN"));    	
	}
	
	@Then("^response for highRiskThreshold should match with values in DB$")
	public void response_for_highRiskThreshold_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityFinalSummation'";
		logger.info("Query: "+query);
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	Assert.assertEquals(Repu_Data.get("finalhighriskthreshold"),NewValueMap.get("finalhighriskthreshold") );
    	logger.info("Finalhighriskthreshold is equal, value is "+Repu_Data.get("finalhighriskthreshold"));
    	Assert.assertEquals(Repu_Data.get("individualhighriskthreshold"),NewValueMap.get("individualhighriskthreshold") );  
    	logger.info("individualhighriskthreshold is equal, value is "+Repu_Data.get("individualhighriskthreshold"));
    	Assert.assertEquals(Repu_Data.get("operator"),NewValueMap.get("operator") ); 
    	logger.info("operator is equal, value is "+Repu_Data.get("operator"));    	    	
	}
	
	@Then("^response for demography should match with values in DB$")
	public void response_for_demography_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='BeneficialOwnersNameAddress'";
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='BeneficialPercent'";
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityTypeCode'";
    	NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
    	NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);  
    	NewValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
    	Assert.assertEquals(Repu_Data.get("beneAddy"),NewValueMap.get("y") );
    	logger.info("BENEADDY is equal, value is "+Repu_Data.get("beneAddy"));
    	Assert.assertEquals(Repu_Data.get("beneAddn"),NewValueMap.get("n") );  
    	logger.info("BENEADDN is equal, value is "+Repu_Data.get("beneAddn"));
    	Assert.assertEquals(Repu_Data.get("benePery"),NewValueMap1.get("y") ); 
    	logger.info("BENEPERY is equal, value is "+Repu_Data.get("benePery"));
    	Assert.assertEquals(Repu_Data.get("benePern"),NewValueMap1.get("n") );   
    	logger.info("BENEPERN is equal, value is "+Repu_Data.get("benePern")); 
    	Assert.assertEquals(Repu_Data.get("opc"),NewValueMap2.get("opc") );
    	logger.info("OPC is equal, value is "+Repu_Data.get("opc"));
    	Assert.assertEquals(Repu_Data.get("sc"),NewValueMap2.get("sc") );  
    	logger.info("SC is equal, value is "+Repu_Data.get("sc"));
    	Assert.assertEquals(Repu_Data.get("bscorp"),NewValueMap2.get("bs-corp") ); 
    	logger.info("BSCORP is equal, value is "+Repu_Data.get("bscorp"));
    	Assert.assertEquals(Repu_Data.get("ngo"),NewValueMap2.get("ngo") );   
    	logger.info("NGO is equal, value is "+Repu_Data.get("ngo"));
    	Assert.assertEquals(Repu_Data.get("embconss"),NewValueMap2.get("emb/cons") );
    	logger.info("EMB/CONS is equal, value is "+Repu_Data.get("embconss"));
    	Assert.assertEquals(Repu_Data.get("tppp"),NewValueMap2.get("tppp") );  
    	logger.info("TPPP is equal, value is "+Repu_Data.get("tppp"));
    	Assert.assertEquals(Repu_Data.get("trustf"),NewValueMap2.get("trust-f") ); 
    	logger.info("TRUSTF is equal, value is "+Repu_Data.get("trustf"));
    	Assert.assertEquals(Repu_Data.get("trusto"),NewValueMap2.get("ngo") );   
    	logger.info("TRUSTO is equal, value is "+Repu_Data.get("trusto"));
    	Assert.assertEquals(Repu_Data.get("spv"),NewValueMap2.get("spv") );
    	logger.info("SPV is equal, value is "+Repu_Data.get("spv"));
    	Assert.assertEquals(Repu_Data.get("dfi"),NewValueMap2.get("dfi") );  
    	logger.info("DFI is equal, value is "+Repu_Data.get("dfi"));
    	Assert.assertEquals(Repu_Data.get("ffi"),NewValueMap2.get("ffi") ); 
    	logger.info("FFI is equal, value is "+Repu_Data.get("ffi"));
    	Assert.assertEquals(Repu_Data.get("ffio"),NewValueMap2.get("ffi-o") );   
    	logger.info("FFIO is equal, value is "+Repu_Data.get("ffio"));
    	Assert.assertEquals(Repu_Data.get("pic"),NewValueMap2.get("pic") );   
    	logger.info("PIC is equal, value is "+Repu_Data.get("pic"));
	}

	@Then("^response for reputation should match with values in DB$")
	public void response_for_reputation_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityTransactionMedia'";
		NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntitySAR'";
		NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityPFC'";
		NewValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityOFAC'";
		NewValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);
		String query4 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityMarijuana'";
		NewValueMap4 = DB_Module.seperatevalueSinglecolumn(con, query4);
		String query5 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityLocalTrans'";
		NewValueMap5 = DB_Module.seperatevalueSinglecolumn(con, query5);
		String query6 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityAdverseMedia'";
		NewValueMap6 = DB_Module.seperatevalueSinglecolumn(con, query6);
    	Assert.assertEquals(Repu_Data.get("mariy"),NewValueMap4.get("y") );
    	logger.info("MARIJUANAY is equal, value is "+Repu_Data.get("mariy"));
    	Assert.assertEquals(Repu_Data.get("marin"),NewValueMap4.get("n") );  
    	logger.info("MARIJUANAN is equal, value is "+Repu_Data.get("marin"));
    	Assert.assertEquals(Repu_Data.get("pfcy"),NewValueMap2.get("y") ); 
    	logger.info("PFCY is equal, value is "+Repu_Data.get("pfcy"));
    	Assert.assertEquals(Repu_Data.get("pfcn"),NewValueMap2.get("n") );   
    	logger.info("PFCN is equal, value is "+Repu_Data.get("pfcn")); 
    	Assert.assertEquals(Repu_Data.get("advmedy"),NewValueMap6.get("y") );
    	logger.info("ADVERSEMEDIAY is equal, value is "+Repu_Data.get("advmedy"));
    	Assert.assertEquals(Repu_Data.get("advmedn"),NewValueMap6.get("n") );  
    	logger.info("ADVERSEMEDIAN is equal, value is "+Repu_Data.get("advmedn"));
    	Assert.assertEquals(Repu_Data.get("transmedy"),NewValueMap.get("y") );
    	logger.info("TRANSMEDIAY is equal, value is "+Repu_Data.get("transmedy"));
    	Assert.assertEquals(Repu_Data.get("transmedn"),NewValueMap.get("n") );  
    	logger.info("TRANSMEDIAN is equal, value is "+Repu_Data.get("transmedn"));
    	Assert.assertEquals(Repu_Data.get("ofacy"),NewValueMap3.get("y") );
    	logger.info("OFACY is equal, value is "+Repu_Data.get("ofacy"));
    	Assert.assertEquals(Repu_Data.get("ofacn"),NewValueMap3.get("n") );  
    	logger.info("OFACN is equal, value is "+Repu_Data.get("ofacn"));
    	Assert.assertEquals(Repu_Data.get("locsany"),NewValueMap5.get("y") );
    	logger.info("LOCSANY is equal, value is "+Repu_Data.get("locsany"));
    	Assert.assertEquals(Repu_Data.get("locsann"),NewValueMap5.get("n") );  
    	logger.info("LOCSANN is equal, value is "+Repu_Data.get("locsann"));
    	Assert.assertEquals(Repu_Data.get("sary"),NewValueMap1.get("y") );
    	logger.info("SARY is equal, value is "+Repu_Data.get("sary"));
    	Assert.assertEquals(Repu_Data.get("sarn"),NewValueMap1.get("n") );  
    	logger.info("SARN is equal, value is "+Repu_Data.get("sarn"));
    	
	}
	
	@Then("^response for benereputation should match with values in DB$")
	public void response_for_benereputation_should_match_with_values_in_DB() throws Throwable {
		logger.info("In Then response should match with values in DB");
		Connection con = DBConnection.InitConnection();
		String query = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneAdverseMedia'";
		NewValueMap = DB_Module.seperatevalueSinglecolumn(con, query);
		String query1 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneMarijuana'";
		NewValueMap1 = DB_Module.seperatevalueSinglecolumn(con, query1);
		String query2 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBenePFC'";
		NewValueMap2 = DB_Module.seperatevalueSinglecolumn(con, query2);
		String query3 = "select SUBRULECONFIG from ruleconfig where SUBRULENAME='EntityBeneOFAC'";
		NewValueMap3 = DB_Module.seperatevalueSinglecolumn(con, query3);
		Assert.assertEquals(Repu_Data.get("beneadvy"),NewValueMap.get("y") );
    	logger.info("BENEADVY is equal, value is "+Repu_Data.get("beneadvy"));
    	Assert.assertEquals(Repu_Data.get("beneadvn"),NewValueMap.get("n") );  
    	logger.info("BENEADVNN is equal, value is "+Repu_Data.get("beneadvn"));
    	Assert.assertEquals(Repu_Data.get("benemariy"),NewValueMap1.get("y") ); 
    	logger.info("BENEMARY is equal, value is "+Repu_Data.get("benemariy"));
    	Assert.assertEquals(Repu_Data.get("benemarin"),NewValueMap1.get("n") );
    	logger.info("BENEMARN is equal, value is "+Repu_Data.get("benemarin"));
    	Assert.assertEquals(Repu_Data.get("benepfcy"),NewValueMap2.get("y") );
    	logger.info("BENEPFCY is equal, value is "+Repu_Data.get("benepfcy"));
    	Assert.assertEquals(Repu_Data.get("benepfcn"),NewValueMap2.get("n") );  
    	logger.info("BENEPFCN is equal, value is "+Repu_Data.get("benepfcn"));
    	Assert.assertEquals(Repu_Data.get("beneofacy"),NewValueMap3.get("y") ); 
    	logger.info("BENEOFACY is equal, value is "+Repu_Data.get("beneofacy"));
    	Assert.assertEquals(Repu_Data.get("beneofacn"),NewValueMap3.get("n") );
    	logger.info("BENEOFACN is equal, value is "+Repu_Data.get("beneofacn"));
	}
	
	@Then("^usertransactionlog validation for sourceofFunds should be successful (.*)$")
	public void usertransactionlog_validation_also_should_be_successful_for(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.srcfFundsAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}		
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for product should be successful (.*)$")
	public void usertransactionlog_validation_for_product_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.prodAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryM : OldValueMap1.entrySet()) {			  
			  if(!entryM.getValue().equalsIgnoreCase(NewValueMap1.get(entryM.getKey()))) {
				valueDiff.put(GlobalStaticInfo.mulprodAmlu.get(entryM.getKey()),entryM.getValue()+','+NewValueMap1.get(entryM.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for highRiskThreshold should be successful (.*)$")
	public void usertransactionlog_validation_for_highRiskThreshold_should_be_successful_for(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.highRisThresAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}		
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}
		ObjectMapper mapper = new ObjectMapper();
		OldValueMap.put("TYPE","entity");
		payload2 = mapper.writeValueAsString(GeneratePayloadRepInput.finalSum_payload(OldValueMap));
    	Res = request.log().all().body(payload2).contentType(ContentType.JSON).cookie(resultbody).put(Service_Url).andReturn();
    	logger.info("Response----->:" + Res.prettyPrint());
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for demography should be successful (.*)$")
	public void usertransactionlog_validation_for_demography_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entry1 : OldValueMap.entrySet()) {			  
			  if(!entry1.getValue().equalsIgnoreCase(NewValueMap.get(entry1.getKey()))) {
				valueDiff.put(GlobalStaticInfo.beneAddrAmlu.get(entry1.getKey()),entry1.getValue()+','+NewValueMap.get(entry1.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryM : OldValueMap1.entrySet()) {			  
			  if(!entryM.getValue().equalsIgnoreCase(NewValueMap1.get(entryM.getKey()))) {
				valueDiff.put(GlobalStaticInfo.benePerAmlu.get(entryM.getKey()),entryM.getValue()+','+NewValueMap1.get(entryM.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryT : OldValueMap2.entrySet()) {			  
			  if(!entryT.getValue().equalsIgnoreCase(NewValueMap2.get(entryT.getKey()))) {
				valueDiff.put(GlobalStaticInfo.typeCodeAmlu.get(entryT.getKey()),entryT.getValue()+','+NewValueMap2.get(entryT.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;	
	}
	
	@Then("^usertransactionlog validation for reputation should be successful (.*)$")
	public void usertransactionlog_validation_for_reputation_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entryM : OldValueMap4.entrySet()) {			  
			  if(!entryM.getValue().equalsIgnoreCase(NewValueMap4.get(entryM.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuMarAmlu.get(entryM.getKey()),entryM.getValue()+','+NewValueMap4.get(entryM.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryS : OldValueMap1.entrySet()) {			  
			  if(!entryS.getValue().equalsIgnoreCase(NewValueMap1.get(entryS.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuSarAmlu.get(entryS.getKey()),entryS.getValue()+','+NewValueMap1.get(entryS.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryP : OldValueMap2.entrySet()) {			  
			  if(!entryP.getValue().equalsIgnoreCase(NewValueMap2.get(entryP.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repupfcAmlu.get(entryP.getKey()),entryP.getValue()+','+NewValueMap2.get(entryP.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryT : OldValueMap.entrySet()) {			  
			  if(!entryT.getValue().equalsIgnoreCase(NewValueMap.get(entryT.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuTransMAmlu.get(entryT.getKey()),entryT.getValue()+','+NewValueMap.get(entryT.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryO : OldValueMap3.entrySet()) {			  
			  if(!entryO.getValue().equalsIgnoreCase(NewValueMap3.get(entryO.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuofacAmlu.get(entryO.getKey()),entryO.getValue()+','+NewValueMap3.get(entryO.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryL : OldValueMap5.entrySet()) {			  
			  if(!entryL.getValue().equalsIgnoreCase(NewValueMap5.get(entryL.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuLocSanAmlu.get(entryL.getKey()),entryL.getValue()+','+NewValueMap5.get(entryL.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryA : OldValueMap6.entrySet()) {			  
			  if(!entryA.getValue().equalsIgnoreCase(NewValueMap6.get(entryA.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repuAdvMAmlu.get(entryA.getKey()),entryA.getValue()+','+NewValueMap6.get(entryA.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;
	}
	
	@Then("^usertransactionlog validation for benereputation should be successful (.*)$")
	public void usertransactionlog_validation_for_benereputation_should_be_successful(String Jwtcoid) throws Throwable {
		logger.info("In -----> The success message is logged in audit table for type AMLU");
		TransactionLog audit = new TransactionLog();
		String linkedContextCode = "RiskScoreRequest";
		userTransactionlogID = audit.auditlog_should_match_in_db_for_AMLU("900001", "ENTITY", Jwtcoid, linkedContextCode, "\"900001\"");
		
		for (Map.Entry<String, String> entryT : OldValueMap.entrySet()) {			  
			  if(!entryT.getValue().equalsIgnoreCase(NewValueMap.get(entryT.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repubeneAdvMAmlu.get(entryT.getKey()),entryT.getValue()+','+NewValueMap.get(entryT.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryS : OldValueMap1.entrySet()) {			  
			  if(!entryS.getValue().equalsIgnoreCase(NewValueMap1.get(entryS.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repubeneMarAmlu.get(entryS.getKey()),entryS.getValue()+','+NewValueMap1.get(entryS.getKey()));
			  }
		}
		for (Map.Entry<String, String> entryP : OldValueMap2.entrySet()) {			  
			  if(!entryP.getValue().equalsIgnoreCase(NewValueMap2.get(entryP.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repubenepfcAmlu.get(entryP.getKey()),entryP.getValue()+','+NewValueMap2.get(entryP.getKey()));
			  }
		}		
		for (Map.Entry<String, String> entryO : OldValueMap3.entrySet()) {			  
			  if(!entryO.getValue().equalsIgnoreCase(NewValueMap3.get(entryO.getKey()))) {
				valueDiff.put(GlobalStaticInfo.repubeneofacAmlu.get(entryO.getKey()),entryO.getValue()+','+NewValueMap3.get(entryO.getKey()));
			  }
		}
		for(Map.Entry<String, String> entry2 : valueDiff.entrySet()){
			  String oldInd = entry2.getValue().split(",")[0];
			  String newInd = entry2.getValue().split(",")[1];
			  audit.getReputationAuditLogs(userTransactionlogID, entry2.getKey(), newInd, oldInd);
		}		
		TransactionLog.dbRows = null;
	}
	
	@When("^valid user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" to generate the invalid smsession$")
	public void valid_user_to_generate_invalid_smsession(String username, String password, String buid) throws Throwable {		
		resultbody = "a"+GetSmsessionToken.generateSmsessionToken(username,password);
		logger.info("SMSession Cookie: " +resultbody);	
	}
	
	@Then("^API should return error message and response should contain error code as \"([^\"]*)\" and error message as \"([^\"]*)\"$")
	public void api_should_return_proper_error_message_and_response_should_contain_error_code_as_and_error_message_as(String errCode, String errMsg) throws Throwable {
		Assert.assertEquals(Res.getStatusCode(), 400);
		JsonPath jsonPathEvaluator = Res.jsonPath();
		Assert.assertEquals(jsonPathEvaluator.get("errorDetail.fieldError[0].code").toString(),errCode);
		Assert.assertEquals(jsonPathEvaluator.get("errorDetail.fieldError[0].fieldName").toString(),errMsg); 
	}
}


