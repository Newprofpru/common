package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.auditTrailAmlu;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class auditTrailAmluGet {
	
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	static Response Res1;
	String Service_Url = getEnvInfo.getAuditTrailSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	ResultSet rs,rs1,rs2,rs3;
	static Map<String, String> data;
	static String transactionRequestId = null;
	auditTrailAmlu auditTrailAmlu = new auditTrailAmlu();
	JsonObject responseObject = new JsonObject();
	JsonArray eventsArray = new JsonArray();
	static Set<String> paramNames;
	
	@Given("^the valid endpoint exists for \"([^\"]*)\" api$")
	public void valid_endpoint_for_auditTrail_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();
	}
	
	
	
	@When("^the user sends a GET request to audit API get Records with below parameters$")
	public void the_user_sends_a_GET_request_to_audit_API_get_records_with_below_parameters(DataTable parameters){
		data = parameters.asMap(String.class, String.class);
		paramNames=data.keySet();
		logger.info("In When");
		Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "auditTrail" + n;
		RestAssured.baseURI =getEnvInfo.getAuditTrailGetRequestGetRecordsURL();
		request = given().log().all()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		for(String paramName:paramNames) {
		request.param(paramName,data.get(paramName));
		}
		Res1 = request.when().get().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
	}
	
	@When("^the user sends a GET request to audit API view records with below parameters$")
	public void the_user_sends_a_GET_request_to_audit_API_view_records_with_below_parameters(DataTable parameters){
		data = parameters.asMap(String.class, String.class);
		Set<String> paramNames=data.keySet();
		logger.info("In When");
		Random rand = new Random();
		int n = rand.nextInt(00450) + 12344;
		String requestID = "auditTrail" + n;
		RestAssured.baseURI = getEnvInfo.getAuditTrailGetRequestViewRecordsURL();
		request = given().log().all()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization)
				.header("X-Forwarded-For", "0.0.0.0");
		for(String paramName:paramNames) {
		request.param(paramName,data.get(paramName));
		}
		Res1 = request.when().get().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		logger.info(Res1.asString());
	}
	
	@Then("^the user recieves correct responsebody content for the get Records and Validated with DB$")
	public void user_recieves_correct_responsebody_from_Profile_API_and_verified_with_the_db() throws SQLException, ParseException{
		String query1 = null,query2=null,query3=null,query4=null;
		
		Connection con = null;
		Connection con1 = null;
		
		Gson gson = new Gson();
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
			
		
	String resBody=Res1.getBody().asString();
		JsonObject amluObject = (JsonObject) new JsonParser().parse(resBody);
		
		boolean a = data.containsKey("coUserId");
		
		System.out.println(a);
		
		Set<String> paramNames=data.keySet();
		
		//data.get
		
		System.out.println(data.get("coUserId"));
		//System.out.println(data.get("partyId"));
		//System.out.println(data.get("ssoid"));
		
		

		try {
			if(amluObject.has("response"))
				responseObject = amluObject.get("response").getAsJsonObject();
			System.out.println(responseObject);
			
			if(responseObject.has("eventsList"))
				eventsArray = responseObject.get("eventsList").getAsJsonArray();
			System.out.println(eventsArray);
		
		con = DBConnection.InitConnection();
		con1 = DBConnection.InitConnection();
		
		if(data.containsKey("coUserId") && data.containsKey("partyType") && data.containsKey("fields") && data.containsKey("partyId") )
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where coUserId = '"+data.get("coUserId")+"' and partyType = '"+data.get("partyType")+"'and fieldname='"+data.get("fields")+"' and partyId='"+data.get("partyId")+"' order by usertransactionlog.updateddate desc";
				
		}
		else if(data.containsKey("coUserId") && data.containsKey("partyType") && data.containsKey("fields"))
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where coUserId = '"+data.get("coUserId")+"' and partyType = '"+data.get("partyType")+"'and fieldname='"+data.get("fields")+"' order by usertransactionlog.updateddate desc";
		
		}
		else if(data.containsKey("partyType") && data.containsKey("fields") && data.containsKey("partyId"))
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where partyType = '"+data.get("partyType")+"'and fieldname='"+data.get("fields")+"' and partyId='"+data.get("partyId")+"' order by usertransactionlog.updateddate desc";	
		System.out.println("partyId");
		}
		else if(data.containsKey("partyType") &&  data.containsKey("partyId"))
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where  partyType = '"+data.get("partyType")+"'and partyId='"+data.get("partyId")+"' order by usertransactionlog.updateddate desc";	
		
		}
		else if(data.containsKey("coUserId") &&  data.containsKey("fields"))
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where coUserId = '"+data.get("coUserId")+"' and fieldname='"+data.get("fields")+"' order by usertransactionlog.updateddate desc";	
		
		}
		else if(data.containsKey("partyType") &&  data.containsKey("partyId") &&  data.containsKey("fields") && data.containsKey("linkedContextRefId") )
		{
			query1 = "select * from usertransactionlog right join usertransactionlogdtl on usertransactionlog.usertransactionlogid=usertransactionlogdtl.usertransactionlogid where coUserId = '"+data.get("coUserId")+"' and partyType = '"+data.get("partyType")+"'and fieldname='"+data.get("fields")+"'  and linkedContextRefId='"+data.get("linkedContextRefId")+"' order by usertransactionlog.updateddate desc";	
		
		}
		
		

			ResultSet resultset = DBConnection.execStatement(con1,query1);
			
			
						
		
	Set<String> eventSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
	if(responseObject.has("eventsList")){
	for(int m=0;m<eventsArray.size();m++){
	JsonObject eventsListObject = eventsArray.get(m).getAsJsonObject();	
	
	
	

			
	while(resultset.next())
	{			
	for(String fieldsElement:eventSet){
		
		System.out.println((GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)));
	if(!eventsListObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
		
	{				
		logger.info("****************** after query 5  *********************");
		
		Assert.assertEquals(resultset.getString(fieldsElement),eventsListObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
	}
		else
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
	}
} 
	}
}
		}		
		
	

	catch(Exception e){
	logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				con1.close();
				}
			}
}
		
		

	@Then("^the user recieves correct responsebody content as No events found$")
	public void user_recieves_correct_responsebody_No() throws SQLException, ParseException{
	
	
		Gson gson = new Gson();
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		
	
		}
	@Then("^BAD_REQUEST response for AMLU is returned with correct error response code 400$")
	public void Bad_Request_recieves_correct_responsebody_No() throws SQLException, ParseException{
	
		
		Gson gson = new Gson();
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 400, "responseCode received in the Response");
		
	
		}
	
	@Then("^the user recieves correct responsebody content$")
	public void user_recieves_correct_responsebody() throws SQLException, ParseException{
	
	
		Gson gson = new Gson();
		logger.info("In Then");
		logger.info("ResponseCode received from Response-->: " + Res1.getStatusCode());
		// Validate the response
		Assert.assertEquals(Res1.getStatusCode(), 200, "responseCode received in the Response");
		
	
		}

}
	




		
	
	
	
		
		
		
				
		
		
	


