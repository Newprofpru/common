package com.Profile.stepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import com.Profile.RequestBodyPojo.RequestBodyPojoCreater;
import com.Profile.RequestBodyPojo.auditTrailAmlu;
import com.Profile.RequestBodyPojo.fields;
import com.Profile.RequestBodyPojo.profile;
import com.Profile.supportLibraries.DBConnection;
import com.Profile.supportLibraries.GlobalStaticInfo;
import com.Profile.supportLibraries.getEnvInfo;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class auditTrailAmluCreate {
	
	private static Logger logger = LogManager.getLogger();
	static RequestSpecification request;
	String TRANSACTIONREQUESTID=null;
	String SSOID=null;
	static Response Res1;
	String Service_Url = getEnvInfo.getAuditTrailSecureURL();
	String Authorization = getEnvInfo.getAuthorization();
	String partyIdRequest = null;
	String coUserId = null;
	String partyId = null;
	String ssoid = null;
	String transactionRequestId = null;
	String pruPrimaryIdentity = null;
	String usertansactionlogid=null;
	String auditTrailAmlu_id = null;
	String requestID = null;
	String auditStr=null;
	String resBody=null;
	
	JsonObject auditTrailAmluObject = new JsonObject();;
	JsonObject responseObject = new JsonObject();
	JsonArray fieldsArray = new JsonArray();
	boolean isNullNeeded = false;
	auditTrailAmlu auditTrailAmlu = new auditTrailAmlu();
	fields field1 = new fields();

	

	
	@Given("^a working endpoint exists for the \"([^\"]*)\" trail API$")
	public void valid_endpoint_for_auditTrail_API(String serviceName) throws Throwable {
		logger.info("In Given");
		logger.info("testService On-------------->:" + serviceName);
		GlobalStaticInfo.loadGlobalStaticInfo();		
	}
	
	public boolean isUniqueTransactRequestId(){
		Connection con = DBConnection.InitConnection();
		String query = "Select * from usertransactionlog where transactionRequestId = '"+TRANSACTIONREQUESTID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("TRANSACTIONREQUESTID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	public boolean isUniqueSSOID(){
		Connection con = DBConnection.InitConnection();
		String query = "select * from couser where ssoid = '"+SSOID+"'";
		ResultSet rssso = DBConnection.execStatement(con,query);
		try{
			rssso.next();
			rssso.getString("SSOID");
		}catch(SQLException e){
			return true;
		}
		return false;
	}
	
	
	@When("^a POST request is sent to udbauditservice API with below request body data$")
	public void a_post_request_is_sent_to_udbauditservice_API_with_below_request_body(DataTable parameters) throws EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, SQLException{
		logger.info("\nIn--------------------> When a POST request is sent to udbauditservice API with below request body data");
		Random rand = new Random();
		isNullNeeded = false;
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		requestID = "profileCreate" + n;	
		RestAssured.baseURI = Service_Url;
		Map<String, String> data = parameters.asMap(String.class, String.class);
		auditTrailAmlu_id = data.get("auditTrailAmlu_id");
		auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);	
		while(!isUniqueTransactRequestId()){
			TRANSACTIONREQUESTID = rand.ints(10,11111111,99999999).findFirst().getAsInt()+"";
		}	
		auditTrailAmlu.settransactionRequestId(TRANSACTIONREQUESTID);
		//transactionRequestId=auditTrailAmlu.gettransactionRequestId();	
		
		
		
		
		request = given()
				.header("X-PruRequestId", requestID)
				.header("Authorization", Authorization);
		Gson gson = new Gson();
		String body = gson.toJson(auditTrailAmlu);
		logger.info("body ----> "+body);
		Res1 = request.log().all().body(body).contentType(ContentType.JSON).post().andReturn();
		logger.info("Response----->:" + Res1.prettyPrint());
		}
		
	
	@Then("^the audit data is updated correctly and the success response code 200 is recieved succesfully$")
	public void the_audit_data_is_updated_and_the_success_response_code_200_is_recieved_successfully(){
		try{
			logger.info("\nIn--------------------> Then the audit data is updated correctly and the success response code 200 is recieved succesfully");
			Integer actualResponseCode = Res1.getStatusCode();
			logger.info("ResponseCode received from Response-->: " + actualResponseCode);
			// Validate the response
			Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}

	@And("^the data is created in the db and verified successfully with Party Id and Partytype as null$")
	public void the_data_is_created_in_the_db_and_verified_succesfully_with_PartyId_and_Partytype_as_null() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
		String query1 = null,query2=null,query3=null,query4=null;
		
		Connection con = null;
		Connection con1 = null;
		System.out.println("the data is created in the db and verified successfully");
		
		coUserId=auditTrailAmlu.getcoUserId();
		ssoid = auditTrailAmlu.getpruPrimaryIdentity();
		System.out.println(ssoid);
		partyId =auditTrailAmlu.getpartyId();	
		logger.info("In And the data is updated in db");
		Gson gson = new Gson();
		
		try{
		
		auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);
		auditStr = gson.toJson(auditTrailAmlu);
		
		resBody=Res1.getBody().asString();
		auditTrailAmluObject = (JsonObject) new JsonParser().parse(auditStr);
		responseObject = (JsonObject) new JsonParser().parse(resBody);
		
			
		if(auditTrailAmluObject.has("fields"))
		fieldsArray = auditTrailAmluObject.get("fields").getAsJsonArray();
		
		con = DBConnection.InitConnection();
		con1 = DBConnection.InitConnection();
		
		if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals(""))
		{
		query1 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
		System.out.println("PARTY ID");
		}
		else if( partyId.equals("") && coUserId.equals(""))
		{
		query1 = "Select * from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
		System.out.println("ssoid");
		}
		else
		{
		query1 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";	
		System.out.println("couser ID");
		}
		
		
		ResultSet resultset1  = DBConnection.execStatement(con,query1);		
		logger.info("****************** usertransaction log id *********************");			
		Set<String> Auditset = GlobalStaticInfo.amluUserTransLog.keySet();
		
		int count = Auditset.size();
		
		System.out.println(count);
						
		while(resultset1.next())
		{
		logger.info("****************** IN WHILE ROLE log id *********************");
		for(String AuditElements:Auditset)
        {                    
 System.out.println(auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString());
        if(!auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString().equals(null)){
                     System.out.println(resultset1.getString(AuditElements));
                     if(AuditElements.contains("PARTYID")){
                         if(!auditTrailAmluObject.get("coUserId").getAsString().equals("") || !auditTrailAmluObject.get("coUserId").getAsString().equals(null) ) {
                                if (!auditTrailAmluObject.get("partyId").getAsString().equals("")){
                         Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                                }
                                else {
                                Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                       logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                                }
                               
                  }
              }
                     else {
                         Assert.assertEquals(resultset1.getString(AuditElements),auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString(),GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                     }     
        }                 
                     else
                 		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(AuditElements)+" is null");
        }
     }

			
			if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals("") )
			{
			query3 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
	System.out.println("PARTY ID");
			}
			else if( partyId.equals("") && coUserId.equals(""))
			{
			query3 = "Select *  from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
			System.out.println("ssoid");
			}
			else
			{
				query3 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";
			
				System.out.println("couser ID");
			}
			
			ResultSet resultset2 = DBConnection.execStatement(con1,query3);
			Long usertransactionlogid = null;
			while(resultset2.next())
			{
				usertransactionlogid = resultset2.getLong(1);
				System.out.println(usertransactionlogid);
			}
			
						
		logger.info("****************** Before query 2  *********************");
		query2 = "Select * from usertransactionlogdtl where USERTRANSACTIONLOGID = '"+usertransactionlogid+"' order by updateddate desc ";
		ResultSet resultset = DBConnection.execStatement(con1,query2);
		
		
		Set<String> fieldsSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
		if(auditTrailAmluObject.has("fields")){
		for(int m=0;m<fieldsArray.size();m++){
		JsonObject fieldsObject = fieldsArray.get(m).getAsJsonObject();	
				
		while(resultset.next())
		{			
		for(String fieldsElement:fieldsSet){
		if(!fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
		{					
			Assert.assertEquals(resultset.getString(fieldsElement),fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
			logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
		}
			else
			logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
		}
	}
} } 
		  }
		
		
	

	catch(Exception e){
	logger.info(e.getMessage());
		}finally {
			if (con != null) {
				con.close();
				con1.close();
				}
			}
		

	} 



@And("^the data is created in the db and verified successfully without couserid$")
public void the_data_is_created_in_the_db_and_verified_succesfully_without_couserid() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
	String query1 = null,query2=null,query3=null,query4=null;
	
	Connection con = null;
	Connection con1 = null;
	System.out.println("the data is created in the db and verified successfully");
	
	coUserId=auditTrailAmlu.getcoUserId();
	ssoid = auditTrailAmlu.getpruPrimaryIdentity();
	System.out.println(ssoid);
	partyId =auditTrailAmlu.getpartyId();	
	logger.info("In And the data is updated in db");
	Gson gson = new Gson();
	
	try{
	
	auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);
	auditStr = gson.toJson(auditTrailAmlu);
	
	resBody=Res1.getBody().asString();
	auditTrailAmluObject = (JsonObject) new JsonParser().parse(auditStr);
	responseObject = (JsonObject) new JsonParser().parse(resBody);
	
		
	if(auditTrailAmluObject.has("fields"))
	fieldsArray = auditTrailAmluObject.get("fields").getAsJsonArray();
	
	con = DBConnection.InitConnection();
	con1 = DBConnection.InitConnection();
	
	if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals(""))
	{
	query1 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
	System.out.println("PARTY ID");
	}
	else if( partyId.equals("") && coUserId.equals(""))
	{
	query1 = "Select * from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
	System.out.println("ssoid");
	}
	else
	{
	query1 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";	
	System.out.println("couser ID");
	}
	
	
	ResultSet resultset1  = DBConnection.execStatement(con,query1);		
	logger.info("****************** usertransaction log id *********************");			
	Set<String> Auditset = GlobalStaticInfo.amluUserTransLog.keySet();
	
	int count = Auditset.size();
	
	System.out.println(count);
					
	while(resultset1.next())
	{
	logger.info("****************** IN WHILE ROLE log id *********************");
	for(String AuditElements:Auditset)
    {                    
System.out.println(auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString());
    if(!auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString().equals(null)){
                 System.out.println(resultset1.getString(AuditElements));
                 if(AuditElements.contains("COUSERID")){
                     if(auditTrailAmluObject.get("coUserId").getAsString().equals("") || auditTrailAmluObject.get("coUserId").getAsString().equals(null) ) {
                            if (!auditTrailAmluObject.get("partyId").getAsString().equals("") || auditTrailAmluObject.get("partyId").getAsString().equals("") ){
                     Assert.assertEquals(resultset1.getString(AuditElements),"101",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                            logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                            }
                            else {
                            Assert.assertEquals(resultset1.getString(AuditElements),"101",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                   logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                            }
                           
              }
          }
                 else {
                     Assert.assertEquals(resultset1.getString(AuditElements),auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString(),GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                            logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                 }     
    }                 
                 else
             		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(AuditElements)+" is null");
    }
 }

		
		if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals("") )
		{
		query3 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
System.out.println("PARTY ID");
		}
		else if( partyId.equals("") && coUserId.equals(""))
		{
		query3 = "Select *  from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
		System.out.println("ssoid");
		}
		else
		{
			query3 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";
		
			System.out.println("couser ID");
		}
		
		ResultSet resultset2 = DBConnection.execStatement(con1,query3);
		Long usertransactionlogid = null;
		while(resultset2.next())
		{
			usertransactionlogid = resultset2.getLong(1);
			System.out.println(usertransactionlogid);
		}
		
					
	logger.info("****************** Before query 2  *********************");
	query2 = "Select * from usertransactionlogdtl where USERTRANSACTIONLOGID = '"+usertransactionlogid+"' order by updateddate desc ";
	ResultSet resultset = DBConnection.execStatement(con1,query2);
	
	
	Set<String> fieldsSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
	if(auditTrailAmluObject.has("fields")){
	for(int m=0;m<fieldsArray.size();m++){
	JsonObject fieldsObject = fieldsArray.get(m).getAsJsonObject();	
			
	while(resultset.next())
	{			
	for(String fieldsElement:fieldsSet){
	if(!fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
	{					
		Assert.assertEquals(resultset.getString(fieldsElement),fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
	}
		else
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
	}
}
} } 
	  }
	
	


catch(Exception e){
logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			con1.close();
			}
		}
	

} 

@And("^the data is created in the db and verified successfully without couserid and party Id$")
public void the_data_is_created_in_the_db_and_verified_succesfully_without_couserid_and_partyid() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
	String query1 = null,query2=null,query3=null,query4=null;
	
	Connection con = null;
	Connection con1 = null;
	System.out.println("the data is created in the db and verified successfully");
	
	coUserId=auditTrailAmlu.getcoUserId();
	ssoid = auditTrailAmlu.getpruPrimaryIdentity();
	System.out.println(ssoid);
	partyId =auditTrailAmlu.getpartyId();	
	logger.info("In And the data is updated in db");
	Gson gson = new Gson();
	
	try{
	
	auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);
	auditStr = gson.toJson(auditTrailAmlu);
	
	resBody=Res1.getBody().asString();
	auditTrailAmluObject = (JsonObject) new JsonParser().parse(auditStr);
	responseObject = (JsonObject) new JsonParser().parse(resBody);
	
		
	if(auditTrailAmluObject.has("fields"))
	fieldsArray = auditTrailAmluObject.get("fields").getAsJsonArray();
	
	con = DBConnection.InitConnection();
	con1 = DBConnection.InitConnection();
	
	if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals(""))
	{
	query1 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
	System.out.println("PARTY ID");
	}
	else if( partyId.equals("") && coUserId.equals(""))
	{
	query1 = "Select * from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
	System.out.println("ssoid");
	}
	else
	{
	query1 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";	
	System.out.println("couser ID");
	}
	
	
	ResultSet resultset1  = DBConnection.execStatement(con,query1);		
	logger.info("****************** usertransaction log id *********************");			
	Set<String> Auditset = GlobalStaticInfo.amluUserTransLog.keySet();
	
	int count = Auditset.size();
	
	System.out.println(count);
					
	while(resultset1.next())
	{
	logger.info("****************** IN WHILE ROLE log id *********************");
	for(String AuditElements:Auditset)
    {                    
System.out.println(auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString());
    if(!auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString().equals(null)){
                 System.out.println(resultset1.getString(AuditElements));
                 if(AuditElements.contains("COUSERID")){
                     if(auditTrailAmluObject.get("coUserId").getAsString().equals("") || auditTrailAmluObject.get("coUserId").getAsString().equals(null) ) {
                            if (!auditTrailAmluObject.get("partyId").getAsString().equals("") || auditTrailAmluObject.get("partyId").getAsString().equals("") ){
                     Assert.assertEquals(resultset1.getString(AuditElements),"101",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                            logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                            }
                            else {
                            Assert.assertEquals(resultset1.getString(AuditElements),"101",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                   logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                            }
                           
              }
          }
                 
                 else if(AuditElements.contains("PARTYID")){
                     if(auditTrailAmluObject.get("coUserId").getAsString().equals("") || auditTrailAmluObject.get("coUserId").getAsString().equals(null) ) {
                         if (auditTrailAmluObject.get("partyId").getAsString().equals("") ){
                  Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                         logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                         }
                         else {
                         Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                                logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                         }
                        
           }
       }
                 else {
                     Assert.assertEquals(resultset1.getString(AuditElements),auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString(),GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                            logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                 }     
    }                 
                 else
             		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(AuditElements)+" is null");
    }
 }
	

		
		if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals("") )
		{
		query3 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
System.out.println("PARTY ID");
		}
		else if( partyId.equals("") && coUserId.equals(""))
		{
		query3 = "Select *  from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
		System.out.println("ssoid");
		}
		else
		{
			query3 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";
		
			System.out.println("couser ID");
		}
		
		ResultSet resultset2 = DBConnection.execStatement(con1,query3);
		Long usertransactionlogid = null;
		while(resultset2.next())
		{
			usertransactionlogid = resultset2.getLong(1);
			System.out.println(usertransactionlogid);
		}
		
					
	logger.info("****************** Before query 2  *********************");
	query2 = "Select * from usertransactionlogdtl where USERTRANSACTIONLOGID = '"+usertransactionlogid+"' order by updateddate desc ";
	ResultSet resultset = DBConnection.execStatement(con1,query2);
	
	
	Set<String> fieldsSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
	if(auditTrailAmluObject.has("fields")){
	for(int m=0;m<fieldsArray.size();m++){
	JsonObject fieldsObject = fieldsArray.get(m).getAsJsonObject();	
			
	while(resultset.next())
	{			
	for(String fieldsElement:fieldsSet){
	if(!fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
	{					
		Assert.assertEquals(resultset.getString(fieldsElement),fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
	}
		else
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
	}
}
} } 
	  }
	
	


catch(Exception e){
logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			con1.close();
			}
		}
	

} 

@And("^the data is created in the db and verified successfully with Party Id and Partytype as inidvidual$")
public void the_data_is_created_in_the_db_and_verified_succesfully_with_PartyId_and_Partytype_as_individual() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
	String query1 = null,query2=null,query3=null,query4=null;
	
	Connection con = null;
	Connection con1 = null;
	System.out.println("the data is created in the db and verified successfully");
	
	coUserId=auditTrailAmlu.getcoUserId();
	ssoid = auditTrailAmlu.getpruPrimaryIdentity();
	System.out.println(ssoid);
	partyId =auditTrailAmlu.getpartyId();	
	logger.info("In And the data is updated in db");
	Gson gson = new Gson();
	
	try{
	
	auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);
	auditStr = gson.toJson(auditTrailAmlu);
	
	resBody=Res1.getBody().asString();
	auditTrailAmluObject = (JsonObject) new JsonParser().parse(auditStr);
	responseObject = (JsonObject) new JsonParser().parse(resBody);
	
		
	if(auditTrailAmluObject.has("fields"))
	fieldsArray = auditTrailAmluObject.get("fields").getAsJsonArray();
	
	con = DBConnection.InitConnection();
	con1 = DBConnection.InitConnection();
	
	if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals(""))
	{
	query1 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
	System.out.println("PARTY ID");
	}
	else if( partyId.equals("") && coUserId.equals(""))
	{
	query1 = "Select * from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
	System.out.println("ssoid");
	}
	else
	{
	query1 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";	
	System.out.println("couser ID");
	}
	
	
	ResultSet resultset1  = DBConnection.execStatement(con,query1);		
	logger.info("****************** usertransaction log id *********************");			
	Set<String> Auditset = GlobalStaticInfo.amluUserTransLog.keySet();
	
	int count = Auditset.size();
	
	System.out.println(count);
					
	while(resultset1.next())
	{
	logger.info("****************** IN WHILE ROLE log id *********************");
	for(String AuditElements:Auditset)
    {                    
System.out.println(auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString());
if(!auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString().equals(null)){
    System.out.println(resultset1.getString(AuditElements));
    if(AuditElements.contains("PARTYTYPE")){
        if(!auditTrailAmluObject.get("coUserId").getAsString().equals("") ) {
               if (auditTrailAmluObject.get("partyType").getAsString().equals("INDIVIDUAL") ){
        Assert.assertEquals(resultset1.getString(AuditElements),"null",GlobalStaticInfo.amluUserTransLogPartyType.get(AuditElements)+" is Equal");
               logger.info(GlobalStaticInfo.amluUserTransLogPartyType.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
               }
               else {
               Assert.assertEquals(resultset1.getString(AuditElements),"null",GlobalStaticInfo.amluUserTransLogPartyType.get(AuditElements)+" is Equal");
                      logger.info(GlobalStaticInfo.amluUserTransLogPartyType.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
               }
              
 }
}
    
    else if(AuditElements.contains("PARTYID")){
        if(!auditTrailAmluObject.get("coUserId").getAsString().equals("") || !auditTrailAmluObject.get("coUserId").getAsString().equals(null) ) {
            if (auditTrailAmluObject.get("partyId").getAsString().equals("") ){
     Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
            logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
            }
            else {
            Assert.assertEquals(resultset1.getString(AuditElements),"0",GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                   logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
            }
           
}
}
    else {
        Assert.assertEquals(resultset1.getString(AuditElements),auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString(),GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
               logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
    }     
}                      
                 else
             		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(AuditElements)+" is null");
    }
 }

		
		if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals("") )
		{
		query3 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
System.out.println("PARTY ID");
		}
		else if( partyId.equals("") && coUserId.equals(""))
		{
		query3 = "Select *  from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
		System.out.println("ssoid");
		}
		else
		{
			query3 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";
		
			System.out.println("couser ID");
		}
		
		ResultSet resultset2 = DBConnection.execStatement(con1,query3);
		Long usertransactionlogid = null;
		while(resultset2.next())
		{
			usertransactionlogid = resultset2.getLong(1);
			System.out.println(usertransactionlogid);
		}
		
					
	logger.info("****************** Before query 2  *********************");
	query2 = "Select * from usertransactionlogdtl where USERTRANSACTIONLOGID = '"+usertransactionlogid+"' order by updateddate desc ";
	ResultSet resultset = DBConnection.execStatement(con1,query2);
	
	
	Set<String> fieldsSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
	if(auditTrailAmluObject.has("fields")){
	for(int m=0;m<fieldsArray.size();m++){
	JsonObject fieldsObject = fieldsArray.get(m).getAsJsonObject();	
			
	while(resultset.next())
	{			
	for(String fieldsElement:fieldsSet){
	if(!fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
	{					
		Assert.assertEquals(resultset.getString(fieldsElement),fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
	}
		else
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
	}
}
} } 
	  }
	
	


catch(Exception e){
logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			con1.close();
			}
		}
	

} 

@And("^the data is created in the db and verified successfully with Partytype as inidvidual$")
public void the_data_is_created_in_the_db_and_verified_succesfully_with_Partytype_as_individual() throws SQLException, ParseException, EncryptedDocumentException, InvalidFormatException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{
	String query1 = null,query2=null,query3=null,query4=null;
	
	Connection con = null;
	Connection con1 = null;
	System.out.println("the data is created in the db and verified successfully");
	
	coUserId=auditTrailAmlu.getcoUserId();
	ssoid = auditTrailAmlu.getpruPrimaryIdentity();
	System.out.println(ssoid);
	partyId =auditTrailAmlu.getpartyId();	
	logger.info("In And the data is updated in db");
	Gson gson = new Gson();
	
	try{
	
	auditTrailAmlu = RequestBodyPojoCreater.getAuditTrailAmlu(auditTrailAmlu_id,isNullNeeded);
	auditStr = gson.toJson(auditTrailAmlu);
	
	resBody=Res1.getBody().asString();
	auditTrailAmluObject = (JsonObject) new JsonParser().parse(auditStr);
	responseObject = (JsonObject) new JsonParser().parse(resBody);
	
		
	if(auditTrailAmluObject.has("fields"))
	fieldsArray = auditTrailAmluObject.get("fields").getAsJsonArray();
	
	con = DBConnection.InitConnection();
	con1 = DBConnection.InitConnection();
	
	if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals(""))
	{
	query1 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
	System.out.println("PARTY ID");
	}
	else if( partyId.equals("") && coUserId.equals(""))
	{
	query1 = "Select * from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
	System.out.println("ssoid");
	}
	else
	{
	query1 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";	
	System.out.println("couser ID");
	}
	
	
	ResultSet resultset1  = DBConnection.execStatement(con,query1);		
	logger.info("****************** usertransaction log id *********************");			
	Set<String> Auditset = GlobalStaticInfo.amluUserTransLog.keySet();
	
	int count = Auditset.size();
	
	System.out.println(count);
					
	while(resultset1.next())
	{
	logger.info("****************** IN WHILE ROLE log id *********************");
	for(String AuditElements:Auditset)
    {                    
System.out.println(auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString());
if(!auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString().equals(null)){
    System.out.println(resultset1.getString(AuditElements));
    //String PartyId = "auditTrailAmluObject.get("+partyId+").getAsString()";
    if(AuditElements.contains("PARTYID")){
        if(auditTrailAmluObject.get("coUserId").getAsString().equals("") ) {
               if (!auditTrailAmluObject.get("partyId").getAsString().equals("") ){
            	   
        Assert.assertEquals(resultset1.getString(AuditElements),partyId,GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
               logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
               }
               else {
               Assert.assertEquals(resultset1.getString(AuditElements),partyId,GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                      logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
               }
              
 }
}
    
    else if(AuditElements.contains("COUSERID")){
    	if(auditTrailAmluObject.get("coUserId").getAsString().equals("") ) {
            if (!auditTrailAmluObject.get("partyId").getAsString().equals("") ){
            	 Assert.assertEquals(resultset1.getString(AuditElements),partyId,GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                 logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                 }
                 else {
                 Assert.assertEquals(resultset1.getString(AuditElements),partyId,GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
                        logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
                 }
           
}
}
    else {
        Assert.assertEquals(resultset1.getString(AuditElements),auditTrailAmluObject.get(GlobalStaticInfo.amluUserTransLog.get(AuditElements)).getAsString(),GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is Equal");
               logger.info(GlobalStaticInfo.amluUserTransLog.get(AuditElements)+" is equal,value is "+resultset1.getString(AuditElements));
    }     
}                      
                 else
             		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(AuditElements)+" is null");
    }
 }

		
		if(coUserId.equals("") && !ssoid.equals("") && !partyId.equals("") )
		{
		query3 = "Select *  from (Select * from usertransactionlog where partyId = '"+partyId+"' order by updateddate desc)where ROWNUM <=1";
System.out.println("PARTY ID");
		}
		else if( partyId.equals("") && coUserId.equals(""))
		{
		query3 = "Select *  from (Select * from usertransactionlog where ssoid = '"+ssoid+"' order by updateddate desc ) where ROWNUM <=1";
		System.out.println("ssoid");
		}
		else
		{
			query3 = "Select *  from (Select * from usertransactionlog where coUserId = '"+coUserId+"' order by updateddate desc ) where ROWNUM <=1";
		
			System.out.println("couser ID");
		}
		
		ResultSet resultset2 = DBConnection.execStatement(con1,query3);
		Long usertransactionlogid = null;
		while(resultset2.next())
		{
			usertransactionlogid = resultset2.getLong(1);
			System.out.println(usertransactionlogid);
		}
		
					
	logger.info("****************** Before query 2  *********************");
	query2 = "Select * from usertransactionlogdtl where USERTRANSACTIONLOGID = '"+usertransactionlogid+"' order by updateddate desc ";
	ResultSet resultset = DBConnection.execStatement(con1,query2);
	
	
	Set<String> fieldsSet = GlobalStaticInfo.amluUserTransLogDtl.keySet();
	if(auditTrailAmluObject.has("fields")){
	for(int m=0;m<fieldsArray.size();m++){
	JsonObject fieldsObject = fieldsArray.get(m).getAsJsonObject();	
			
	while(resultset.next())
	{			
	for(String fieldsElement:fieldsSet){
	if(!fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString().equals(""))
	{					
		Assert.assertEquals(resultset.getString(fieldsElement),fieldsObject.get(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)).getAsString(),GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is Equal");			
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is equal,value is "+resultset.getString(fieldsElement));
	}
		else
		logger.info(GlobalStaticInfo.amluUserTransLogDtl.get(fieldsElement)+" is null");	
	}
}
} } 
	  }
	
	


catch(Exception e){
logger.info(e.getMessage());
	}finally {
		if (con != null) {
			con.close();
			con1.close();
			}
		}
	

} 

}


