package com.Profile.stepDefinitions;
import com.Profile.RequestBodyPojo.*;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Assert;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import com.Profile.supportLibraries.*;

public class SOUpdate {
	
		private static Logger logger = LogManager.getLogger();
		static String Path =  System.getProperty("user.dir")+Util.getFileSeparator()+"src"+Util.getFileSeparator()+"test"+Util.getFileSeparator()+"java"+Util.getFileSeparator()+"com"+Util.getFileSeparator()+"Profile"+Util.getFileSeparator()+"RequestBodyPojo"+Util.getFileSeparator()+"TestData.xlsx";
		 static RequestSpecification request;
		 //static RequestSpecification request2;
		static Response Res1;
		static Response Res2;
		 private Response response = null;
		static String requestID = null;
		static String contractId;
static JsonObject profileObject ;
	    private String XPruAuthJWT = null;
		Map<String, String> cookie_Data = new HashMap<String, String>();
		private String Authorization = "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==";

		Map<String, String> cookies = new HashMap<>();
		Random rand = new Random();
		static String Sourceid;
		static JsonObject responseObject = new JsonObject();
		static JsonArray policiesArray;
		static String INDVssoid = null;
		String SSOID =null;
		String ContractID = null;
		String EventStatusId = null;
		String userTransactionlogID=null;
		String profileStr=null,coUserId = null;
		String resBody=null;
		boolean isNullNeeded = false;
		static JsonElement eachphoneNumbersArray;
		static JsonElement ContactChannelIDs;
		static JsonElement ContactAddressesIDs;
		static JsonElement emailAddressIDs;
		static JsonElement eachemailAddressesArray;
		static JsonElement eachPoliciesArray;
		profileV4 profile1 = new profileV4();
		profileV4 profile2 = new profileV4();
		public static List<contactChannelsV4> temp = new ArrayList<>();
		public static List<contactChannelsV4> temp1 = new ArrayList<>();
		public static List<contactChannelsV4> temp2 = new ArrayList<>();
		public static List<contactAddressesV4> temp3 = new ArrayList<>();
		public static List<contactAddressesV4> temp4 = new ArrayList<>();
		
		public static contactChannelsV4 B = new contactChannelsV4();
		public static Map<String,String> PhoneID = 
			    new HashMap<String, String>();
		public static Map<String,String> EmailId = 
			    new HashMap<String, String>();
		public static Map<String,String> Channel_Value1 = 
			    new HashMap<String, String>();
		public static Map<String,String> ContactAdress= 
			    new HashMap<String, String>();
		public static Map<String,String> ContactAdressID= 
			    new HashMap<String, String>();
		static String INDVBuRelationship;
		static String userSourceCode;
		
		//GetBUSetChannelID SetChannelID=new GetBUSetChannelID();
		
		contactChannels contactChannels=new contactChannels();
		private String EventSourseTrackingID;
		static Gson gson = new Gson();
		//RequestBodyPojoCreater RequestBody=new RequestBodyPojoCreater();
		@Given("^back to back a working endpoint exists for \"([^\"]*)\" APIs$")
		public void user_has_primary_email_address_in_for_single_profiles(String serviceName) throws Throwable {
			//logger.getRootLogger().removeAllAppenders();
			//logger.getRootLogger().addAppender(new NullAppender());
	logger.info("In Given");
			logger.info("testService On-------------->:" + serviceName);
			GlobalStaticInfo.loadGlobalStaticInfo();
		}
		
		@Then("^GET ILI Profile details from APIs using sourceID \"([^\"]*)\"$")
		public void GET_request_sent_to_Event_Api_to_Update_primary_email(String sourceid) throws Throwable {
		logger.info("In When a POST request is sent to profile API with below request body data");
			
			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			Random random = new Random();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
			LocalDate localDate = LocalDate.now();
			Calendar now = Calendar.getInstance();
			int h = now.get(Calendar.HOUR_OF_DAY);
			int m = now.get(Calendar.MINUTE);
			int s = now.get(Calendar.SECOND);
			EventSourseTrackingID = "ApplicationStarted" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
			
			
		 Sourceid = sourceid;
			
			
			RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/"+Sourceid+"";
			request = given().log().all()
					.header("Content-Type", "application/x-www-form-urlencoded")
					  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
					  .header("cache-control", "no-cache")
					  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
				
			Res1 = request.when().get().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			
			String resBody=Res1.getBody().asString();
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray phoneNumbersArray = new JsonArray();
			JsonArray emailAddressesArray = new JsonArray();
			JsonArray postalAddressesArray = new JsonArray();
			
			policiesArray=responseObject.get("policies").getAsJsonArray();
			
			
			
			if(responseObject.has("phoneNumbers")){
			phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
		
			
			for ( JsonElement eachphoneNumbersArray : phoneNumbersArray) {
				
				
				
				ContactChannelIDs = eachphoneNumbersArray;
				
				temp.add(getcontactChannels());
				
				

			}
			}
			if(responseObject.has("emailAddresses")){
				emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
		
				
				for (JsonElement eachemailAddressesArray : emailAddressesArray) {
					
					emailAddressIDs = eachemailAddressesArray;
					
					
					
					temp.add(getcontactChannels1());
					
				}
			
				profile1.setcontactChannels(temp);
			}
		
			
			 PhoneID.putAll(EmailId);
			if(responseObject.has("postalAddresses")){
				postalAddressesArray=responseObject.get("postalAddresses").getAsJsonArray();
				
				for ( JsonElement eachpostalAddressesArray : postalAddressesArray) {
					
					
					
					
					ContactAddressesIDs = eachpostalAddressesArray;
					
					temp3.add(getcontactAddresses());
					
					

				}
				profile1.setcontactAddresses(temp3);
				
		}
			
			PhoneID.putAll(ContactAdressID);
			
		}			
			
	
		
		@Then("^GET ILI Profile details from APIs using sourceID \"([^\"]*)\" country code US$")
		public void GET_request_sent_to_Event_Api_to_Update_primary_country_US(String sourceid) throws Throwable {
		logger.info("In When a POST request is sent to profile API with below request body data");
			
			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			Random random = new Random();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
			LocalDate localDate = LocalDate.now();
			Calendar now = Calendar.getInstance();
			int h = now.get(Calendar.HOUR_OF_DAY);
			int m = now.get(Calendar.MINUTE);
			int s = now.get(Calendar.SECOND);
			EventSourseTrackingID = "ApplicationStarted" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
			
			
		 Sourceid = sourceid;
			
			
			RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/"+Sourceid+"";
			request = given().log().all()
					.header("Content-Type", "application/x-www-form-urlencoded")
					  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
					  .header("cache-control", "no-cache")
					  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
				
			Res1 = request.when().get().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			
			String resBody=Res1.getBody().asString();
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray phoneNumbersArray = new JsonArray();
			JsonArray emailAddressesArray = new JsonArray();
			JsonArray postalAddressesArray = new JsonArray();
			
			policiesArray=responseObject.get("policies").getAsJsonArray();
			
			
			
			if(responseObject.has("phoneNumbers")){
			phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
		
			
			for ( JsonElement eachphoneNumbersArray : phoneNumbersArray) {
				
				
				
				ContactChannelIDs = eachphoneNumbersArray;
				
				temp.add(getcontactChannels());
				
				

			}
			}
			if(responseObject.has("emailAddresses")){
				emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
		
				
				for (JsonElement eachemailAddressesArray : emailAddressesArray) {
					
					emailAddressIDs = eachemailAddressesArray;
					
					
					
					temp.add(getcontactChannels1());
					
				}
			
				profile1.setcontactChannels(temp);
			}
		
			
			 PhoneID.putAll(EmailId);
			if(responseObject.has("postalAddresses")){
				postalAddressesArray=responseObject.get("postalAddresses").getAsJsonArray();
				
				for ( JsonElement eachpostalAddressesArray : postalAddressesArray) {
					
					
					
					
					ContactAddressesIDs = eachpostalAddressesArray;
					
					temp3.add(getcontactAddressesUS());
					
					

				}
				profile1.setcontactAddresses(temp3);
				
		}
			
			PhoneID.putAll(ContactAdressID);
			
		}			
			
		
		public contactChannelsV4 getcontactChannels() {
			
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			String Contact = "10"+Integer.toString(n);
			 contactChannelsV4 A = new contactChannelsV4();
				String ContactChannelID=ContactChannelIDs.getAsJsonObject().get("phoneNumberID").getAsString();
				String type=ContactChannelIDs.getAsJsonObject().get("type").getAsString();
				
				PhoneID.put(type,ContactChannelID);

				A.setcontactChannelType(type);
				A.setcontactChannelId(ContactChannelID);
				A.setcontactChannel("PHONE");
				A.setcontactChannelValue(Contact);
				A.setisDeleted("false");
				A.setisEditable("true");
				A.setisUpdated("true");
				
			
			return A;
			
		
	}
		
public contactChannelsV4 getcontactChannels1() {
			
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			contactChannelsV4 C = new contactChannelsV4();
			String Contact = Integer.toString(n);
			
			String emailAddressID=emailAddressIDs.getAsJsonObject().get("emailAddressID").getAsString();
			String type=emailAddressIDs.getAsJsonObject().get("type").getAsString();
			
			String Email =RandomStringUtils.random(10, true, true).toUpperCase();
			EmailId.put(type,emailAddressID);
			C.setcontactChannelType(type);
			C.setcontactChannelId(emailAddressID);
			C.setcontactChannel("EMAIL");
			C.setcontactChannelValue("SridharSubramani"+Contact+"@prudential.com");
			C.setisDeleted("false");
			C.setisEditable("true");
			C.setisUpdated("true");
		
				
			return C;
			
		
	}


public contactAddressesV4 getcontactAddresses() throws EncryptedDocumentException, InvalidFormatException, IOException {
	
	Random rand = new Random();

	 contactAddressesV4 ContactAddress1 = new contactAddressesV4();
		String ContactAddressesID=ContactAddressesIDs.getAsJsonObject().get("postalAddressID").getAsString();
		String Addresstype=ContactAddressesIDs.getAsJsonObject().get("addressType").getAsString();
		
		if(Addresstype.equalsIgnoreCase("Primary"))
		{
			
			Addresstype = "HOME";
		}
		else if(Addresstype.equalsIgnoreCase("Mailing"))
		{
			
			Addresstype = "CORRESPONDENCE";
		}
		
		Random rand1 = new Random();
		
		rand1.ints(106, 115);
        
        int num = rand1.ints(106, 115).findFirst().getAsInt();
       
        String contactAddresses_id="contactAddresses"+num;
       
        FileInputStream file = new FileInputStream(new File(Path));
        
        
        
        
        
        Workbook wb = WorkbookFactory.create(file);
        Sheet sheet = wb.getSheet("contactAddressesV4");
        
       
        int rownum=0,colnum=0,i=-1,j=-1;
        DataFormatter dataFormatter = new DataFormatter();
        Iterator<Row> rowIterator = sheet.rowIterator();
        while (rowIterator.hasNext()) {
      Row row = rowIterator.next();
      Iterator<Cell> cellIterator = row.cellIterator();
      i++;
      if(i==0){
      while (cellIterator.hasNext()) {
      j++;
          Cell cell = cellIterator.next();
          String cellValue = dataFormatter.formatCellValue(cell);
          if(cellValue.equalsIgnoreCase("contactAddresses_id"))
              colnum = j;
      }
      }
      else{
      Cell cell = row.getCell(colnum);
      String temp = dataFormatter.formatCellValue(cell);
      if(temp.equalsIgnoreCase(contactAddresses_id)) {
              rownum = i;
      }
      }
        }
        Row row1=sheet.getRow(0);
        Row row2=sheet.getRow(rownum);
        for(int k=1;k<row1.getLastCellNum();k++){
        	 
               Cell cell1=row1.getCell(k);
               Cell cell2=row2.getCell(k);
               String cellValue1=dataFormatter.formatCellValue(cell1);
               String cellValue2=dataFormatter.formatCellValue(cell2);
               ContactAdress.put(cellValue1, cellValue2);
        }

		
		
        ContactAdressID.put(Addresstype, ContactAddressesID); 
		ContactAddress1.setaddressType(Addresstype);
		ContactAddress1.setcontactAddressID(ContactAddressesID);
		 
		ContactAddress1.setaddressLine1(ContactAdress.get("addressLine1").toUpperCase());
		ContactAddress1.setaddressLine2(ContactAdress.get("addressLine2").toUpperCase());
		ContactAddress1.setaddressLine3(ContactAdress.get("addressLine3").toUpperCase());
		ContactAddress1.setcity(ContactAdress.get("city").toUpperCase());
		ContactAddress1.setcountry(ContactAdress.get("country"));
		ContactAddress1.setstate(ContactAdress.get("state"));
		ContactAddress1.setzipCode(ContactAdress.get("zipCode"));
		ContactAddress1.setisUpdated("true");
		ContactAddress1.setisEditable("true");
		return ContactAddress1;

}
		
public contactAddressesV4 getcontactAddressesUS() throws EncryptedDocumentException, InvalidFormatException, IOException {
	
	Random rand = new Random();

	 contactAddressesV4 ContactAddress1 = new contactAddressesV4();
		String ContactAddressesID=ContactAddressesIDs.getAsJsonObject().get("postalAddressID").getAsString();
		String Addresstype=ContactAddressesIDs.getAsJsonObject().get("addressType").getAsString();
		
		if(Addresstype.equalsIgnoreCase("Primary"))
		{
			
			Addresstype = "HOME";
		}
		else if(Addresstype.equalsIgnoreCase("Mailing"))
		{
			
			Addresstype = "CORRESPONDENCE";
		}
		
		Random rand1 = new Random();
		
		rand1.ints(106, 115);
        
        int num = rand1.ints(106, 115).findFirst().getAsInt();
       
        String contactAddresses_id="contactAddresses"+num;
       
        FileInputStream file = new FileInputStream(new File(Path));
        
        
        
        
        
        Workbook wb = WorkbookFactory.create(file);
        Sheet sheet = wb.getSheet("contactAddressesV4");
        
       
        int rownum=0,colnum=0,i=-1,j=-1;
        DataFormatter dataFormatter = new DataFormatter();
        Iterator<Row> rowIterator = sheet.rowIterator();
        while (rowIterator.hasNext()) {
      Row row = rowIterator.next();
      Iterator<Cell> cellIterator = row.cellIterator();
      i++;
      if(i==0){
      while (cellIterator.hasNext()) {
      j++;
          Cell cell = cellIterator.next();
          String cellValue = dataFormatter.formatCellValue(cell);
          if(cellValue.equalsIgnoreCase("contactAddresses_id"))
              colnum = j;
      }
      }
      else{
      Cell cell = row.getCell(colnum);
      String temp = dataFormatter.formatCellValue(cell);
      if(temp.equalsIgnoreCase(contactAddresses_id)) {
              rownum = i;
      }
      }
        }
        Row row1=sheet.getRow(0);
        Row row2=sheet.getRow(rownum);
        for(int k=1;k<row1.getLastCellNum();k++){
        	 
               Cell cell1=row1.getCell(k);
               Cell cell2=row2.getCell(k);
               String cellValue1=dataFormatter.formatCellValue(cell1);
               String cellValue2=dataFormatter.formatCellValue(cell2);
               ContactAdress.put(cellValue1, cellValue2);
        }

		
		
        ContactAdressID.put(Addresstype, ContactAddressesID); 
		ContactAddress1.setaddressType(Addresstype);
		ContactAddress1.setcontactAddressID(ContactAddressesID);
		 
		ContactAddress1.setaddressLine1(ContactAdress.get("addressLine1").toUpperCase());
		ContactAddress1.setaddressLine2(ContactAdress.get("addressLine2").toUpperCase());
		ContactAddress1.setaddressLine3(ContactAdress.get("addressLine3").toUpperCase());
		ContactAddress1.setcity(ContactAdress.get("city").toUpperCase());
		ContactAddress1.setcountry("US");
		ContactAddress1.setstate(ContactAdress.get("state"));
		ContactAddress1.setzipCode(ContactAdress.get("zipCode"));
		ContactAddress1.setisUpdated("true");
		ContactAddress1.setisEditable("true");
		return ContactAddress1;

}
		
		@When("^PUT hit the request with the details obtained from GET ILI using the credentials username \"([^\"]*)\" and password \"([^\"]*)\" and with the ssoid \"([^\"]*)\"$")
		public void post_request_sent_to_Event_Api_to_Update_primary_email(String username , String Password , String ssoid) throws Throwable {
	logger.info("In When a PUT request is sent to profile API with below request body data");
	
				String JWTuser = username;		
				String JWTpassword = Password;
				String SSOID= ssoid;
				
				Connection Con2 = null;
				
					
				Con2 = DBConnection.InitConnection();
				Thread.sleep(30000);
				String query = "select couserid from usersso where legacyssoid='"+SSOID+"'and USERSOURCECODE!='CO' and DELETED='N'";
			
				//String query = "select * from customerdb.usereventstatus where requestId='Abi_tst_207'";
				ResultSet rs = DBConnection.execStatement(Con2,query);
				logger.info("Validating Event status table ");
				
				logger.info("Query Input : "+query);
				
				String COUSERId = null;
				
					while(rs.next()){
						
						COUSERId = rs.getString("COUSERID");
					
					}
				
				

		
			
				
				for(int i=0;i<policiesArray.size();i++){
					logger.info("Verifying the Policies : "+(i+1));
					JsonObject profileObject = policiesArray.get(i).getAsJsonObject();
				
					
					
		
					contractId=profileObject.get("policyNumber").getAsString();
			
				
				profile1.setssoId(SSOID);
			profile1.setcoUserId(COUSERId);
				profile1.setcontractId(contractId);
				profile1.setlineOfBusinessCode("ILI");
				profile1.setbURelationShip("LIFE");
				profile1.setuserSourceCode("CIS");
				profile1.setsourceId(Sourceid);
//				profile1.setisEditable("true");
			
				
				 RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
				 
				 int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
					requestID = "PorifleV4_Update_" + n;
				 request = given().log().all()
							.header("X-PruRequestId", requestID)
							.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
							.header("X-Forwarded-For", "0.0.0.0")	
							.header("X-PruPrimaryIdentity", "X223793")
							.header("X-PruImpersonatedIdentity", SSOID);
					
						//request.param("ssoId",data.get("Header_ssoId"));
					Gson gson = new Gson();
					String body = gson.toJson(profile1);
					Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
					logger.info("Response----->:" + Res1.prettyPrint());
					logger.info(Res1.asString());
		}

		}
		
		
		
		

		@When("^PUT hit the request with the details obtained from GET ILI using the credentials username \"([^\"]*)\" and password \"([^\"]*)\" and with the couserid \"([^\"]*)\"$")
		public void post_request_sent_to_Event_Api_to_Update_ILI_couserid(String username , String Password , String couserid) throws Throwable {
	logger.info("In When a PUT request is sent to profile API with below request body data");
	
				String JWTuser = username;		
				String JWTpassword = Password;
				String COUSERID= couserid;

				for(int i=0;i<policiesArray.size();i++){
					logger.info("Verifying the Policies : "+(i+1));
					JsonObject profileObject = policiesArray.get(i).getAsJsonObject();
	
					contractId=profileObject.get("policyNumber").getAsString();
			
				
				profile1.setcoUserId(COUSERID);
				profile1.setcontractId(contractId);
				profile1.setlineOfBusinessCode("ILI");
				profile1.setbURelationShip("LIFE");
				profile1.setuserSourceCode("CIS");
				profile1.setsourceId(Sourceid);
//				profile1.setisEditable("true");
			
				
				 RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
				 
				 int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
					requestID = "PorifleV4_Update_" + n;
				 request = given().log().all()
							.header("X-PruRequestId", requestID)
							.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
							.header("X-Forwarded-For", "0.0.0.0")	
							.header("X-PruPrimaryIdentity", "X223793")
							.header("X-Pru-Imp-CO-USER-ID", COUSERID);
					
						//request.param("ssoId",data.get("Header_ssoId"));
					Gson gson = new Gson();
					String body = gson.toJson(profile1);
					Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
					logger.info("Response----->:" + Res1.prettyPrint());
					logger.info(Res1.asString());
		}

		}
		
		@Then("^the data is updated correctly and success response code 200 is recieved succesfull result$")
		public void the_data_is_updated_and_success_response_code_200_is_recieved_successfully_result(){
			try{
				logger.info("\nIn--------------------> Then the data is updated and success response code 200 is recieved");
				Integer actualResponseCode = Res1.getStatusCode();
				logger.info("ResponseCode received from Response-->: " + actualResponseCode);
				// Validate the response
				Assert.assertEquals(actualResponseCode.toString(), "200", "responseCode received in the Response");
			}catch(Exception e){
				logger.info(e.getMessage());
			}
		}
		
		
	
		@Then("^verify table USEREVENTSTATUS for contact channel update121222$")
		public void verify_table_USEREVENTSTATUS_for_Added_contact_channel() throws Throwable 
		{
			
			Connection Con2 = null;
			try{
				
			Con2 = DBConnection.InitConnection();
			Thread.sleep(30000);
			String query = "select * from usereventstatus where requestId='"+requestID+"'";
		
			//String query = "select * from customerdb.usereventstatus where requestId='Abi_tst_207'";
			ResultSet rs = DBConnection.execStatement(Con2,query);
			logger.info("Validating Event status table ");
		
			logger.info("Query Input : "+query);
			
			Set<String> PhoneIDSet = PhoneID.keySet();
				while(rs.next()){
			
				
					
					for(String PhoneIDelement:PhoneIDSet)
					{
					String Type = PhoneIDelement;
					
					Type = Type.toUpperCase();
					
					
					
					if(rs.getString("EVENTSUBTYPE").equalsIgnoreCase(PhoneIDelement) &&  rs.getString("EVENTTYPE").equalsIgnoreCase("PHONE")  )
					{
				
						logger.info(Type);
						
						Assert.assertEquals(rs.getString("EVENTSUBTYPE"),Type , "TYPE is MATCHING "+Type);
						Assert.assertEquals(rs.getString("EVENTTYPE"),"PHONE" , "TYPE is MATCHING "+Type);
						//Assert.assertEquals(rs.getString("EVENTSTATUSDESCRIPTION"),"COMPLETED" , "TYPE is MATCHING "+Type);
						Assert.assertEquals(rs.getString("ACTION"),"UPDATE" , "TYPE is MATCHING "+Type);
			

					
					
					}				
					else if(rs.getString("EVENTSUBTYPE").equalsIgnoreCase(PhoneIDelement)&&rs.getString("EVENTTYPE").equalsIgnoreCase("EMAIL"))
							{
					
							logger.info(Type);
							
							Assert.assertEquals(rs.getString("EVENTSUBTYPE"),Type , "TYPE is MATCHING "+Type);
							Assert.assertEquals(rs.getString("EVENTTYPE"),"EMAIL" , "TYPE is MATCHING "+Type);	
							//Assert.assertEquals(rs.getString("EVENTSTATUSDESCRIPTION"),"COMPLETED" , "TYPE is MATCHING "+Type);
							Assert.assertEquals(rs.getString("ACTION"),"UPDATE" , "TYPE is MATCHING "+Type);
				
						
							}
					}
					
								
				}
				
				
			}finally {
					if (Con2 != null) {
						Con2.close();
						}

			}	// DBConnection.DbConnection_close(con2);
			}
		@Then("^verify update on BU is complete by verifying GET BU api contact channel update$")
		public void verify_update_on_BU_is_complete_by_verifying_GET_BU_api() throws Throwable {
			Thread.sleep(5000);

			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			Random random = new Random();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
			LocalDate localDate = LocalDate.now();
			Calendar now = Calendar.getInstance();
			int h = now.get(Calendar.HOUR_OF_DAY);
			int m = now.get(Calendar.MINUTE);
			int s = now.get(Calendar.SECOND);
			EventSourseTrackingID = "ApplicationStarted" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
			
			
		 
			
			
			RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/"+Sourceid+"";
			request = given().log().all()
					.header("Content-Type", "application/x-www-form-urlencoded")
					  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
					  .header("cache-control", "no-cache")
					  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
				
			Res1 = request.when().get().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			Res1 = request.when().get().andReturn();
			//logger.info("Response----->:" + Res1.prettyPrint());
			//logger.info(Res1.asString());
			//Channel_Value1.putAll(RequestBodyPojoCreater.Channel_Value);
			
			String resBody=Res1.getBody().asString();
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray phoneNumbersArray = new JsonArray();
			JsonArray emailAddressesArray = new JsonArray();
			
			
			
			List<contactChannelsV4> contactChannelsTest = new ArrayList<>();
			if(profile1.getContactChannels()!=null)
			{
			contactChannelsTest = profile1.getContactChannels();
			int contactchannelsize=contactChannelsTest.size();
		
			if(responseObject.has("phoneNumbers")){
				phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
		
				}
			if(responseObject.has("emailAddresses")){
			emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
	
			}
			
			for(contactChannelsV4 cc : contactChannelsTest){
				
				String ActualContactChannleValue = cc.getContactChannelValue();
				ActualContactChannleValue=ActualContactChannleValue.toUpperCase();

				for (JsonElement eachphoneNumbersArray : phoneNumbersArray) {
					
				
					String Phonetype=eachphoneNumbersArray.getAsJsonObject().get("type").getAsString();
					
					if(Phonetype.equalsIgnoreCase(cc.getContactChannelType()))
					{
						String PhoneNo=eachphoneNumbersArray.getAsJsonObject().get("localAreaCode").getAsString()+eachphoneNumbersArray.getAsJsonObject().get("localPhoneNumber").getAsString();
						
					
						
						
						Assert.assertEquals(ActualContactChannleValue,PhoneNo , "PHONE NUMBER  is MATCHING "+PhoneNo);
						logger.info(ActualContactChannleValue+"   "+PhoneNo+"       "+"PHONE NUMBER  is MATCHING "+PhoneNo);
					}
					}	
			    
				
				
			
				for (JsonElement eachemailAddressesArray : emailAddressesArray) {
					String type=eachemailAddressesArray.getAsJsonObject().get("type").getAsString();
				if(type.equalsIgnoreCase(cc.getContactChannelType()))
				{
					String emailAddress=eachemailAddressesArray.getAsJsonObject().get("emailAddress").getAsString();
					
					
					
					Assert.assertEquals(ActualContactChannleValue,emailAddress , "UpdatedEmailAddress  is MATCHING "+ActualContactChannleValue);
				
					logger.info(ActualContactChannleValue+"   "+emailAddress+"       "+"EMAIL ADRES  is MATCHING "+emailAddress);
				}
					
					
				
		} }
			}
		}
				//RequestBodyPojoCreater.Channel_Value.clear();
		
		@Then("^GET INDV Profile details from APIs using SSOID \"([^\"]*)\"$")
		public void GET_request_sent_to_Event_Api_to_Update_INDV(String ssoid) throws Throwable {
		logger.info("In When a POST request is sent to profile API with below request body data");
			
			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			Random random = new Random();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
			LocalDate localDate = LocalDate.now();
			Calendar now = Calendar.getInstance();
			int h = now.get(Calendar.HOUR_OF_DAY);
			int m = now.get(Calendar.MINUTE);
			int s = now.get(Calendar.SECOND);
			EventSourseTrackingID = "ApplicationStarted" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
			
			
			INDVssoid = ssoid;
			
			int on = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			requestID = "PorifleV4_Update_" + on;
			RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
			request = given().log().all()
					.header("X-PruRequestId", requestID)
					.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
					.header("X-Forwarded-For", "0.0.0.0")	
					.header("X-PruPrimaryIdentity", "X223793")
					.header("X-PruImpersonatedIdentity", INDVssoid);
			
			
			request.param("ssoId",INDVssoid);
			request.param("sections","personalInfo,contactChannels,contactAddresses,");
			
			
			Res1 = request.when().get().andReturn();
			
			
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			
			String resBody=Res1.getBody().asString();
			
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray profileArray = responseObject.getAsJsonArray("profiles");
			JsonArray contactChannelArray = new JsonArray();
			JsonArray contactAddressArray = new JsonArray();
			
			for(int i=0;i<profileArray.size();i++){
				logger.info("Verifying the profile : "+(i+1));
				JsonObject profileObject = profileArray.get(i).getAsJsonObject();
			
				
				 INDVBuRelationship = profileObject.get("bURelationShip").getAsString();
				 userSourceCode = profileObject.get("userSourceCode").getAsString();
				
				
				
				
				if(profileObject.has("contactChannels")) {
					contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
			
			
			for ( JsonElement eachphoneNumbersArray : contactChannelArray) {
				
				
				
				ContactChannelIDs = eachphoneNumbersArray;
				
				temp2.add(getcontactChannelsINDV());
				
				

			}
			profile2.setcontactChannels(temp2);
			}
				
				if(profileObject.has("contactAddresses")) {
					contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
			
			
			for ( JsonElement eachAddressesArray : contactAddressArray) {
				
				
				
				ContactAddressesIDs = eachAddressesArray;
				
				temp4.add(getcontactAddressesINDV());
				
				

			}
			profile2.setcontactAddresses(temp4);
			}
				
				
				
			}
		}
						
		
		@Then("^GET INDV Profile details from APIs using CouserID \"([^\"]*)\"$")
		public void GET_request_sent_to_Event_Api_to_Update_INDV_courserid(String couserId) throws Throwable {
		logger.info("In When a POST request is sent to profile API with below request body data");
			
			isNullNeeded = false;
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			Random random = new Random();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM");
			LocalDate localDate = LocalDate.now();
			Calendar now = Calendar.getInstance();
			int h = now.get(Calendar.HOUR_OF_DAY);
			int m = now.get(Calendar.MINUTE);
			int s = now.get(Calendar.SECOND);
			EventSourseTrackingID = "ApplicationStarted" + dtf.format(localDate) + "_V" + h + "-" + m + "-" + s;
			
			
			INDVssoid = couserId;
			
			int on = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			requestID = "PorifleV4_Update_" + on;
			RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
			request = given().log().all()
					.header("X-PruRequestId", requestID)
					.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
					.header("X-Forwarded-For", "0.0.0.0")	
					.header("X-PruPrimaryIdentity", "X223793")
					.header("X-Pru-Imp-CO-USER-ID", INDVssoid);
			
			
			request.param("couserId",INDVssoid);
			request.param("sections","personalInfo,contactChannels,contactAddresses,");
			
			
			Res1 = request.when().get().andReturn();
			logger.info("Response----->:" + Res1.prettyPrint());
			logger.info(Res1.asString());
			
			String resBody=Res1.getBody().asString();
			
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray profileArray = responseObject.getAsJsonArray("profiles");
			JsonArray contactChannelArray = new JsonArray();
			JsonArray contactAddressArray = new JsonArray();
			
			for(int i=0;i<profileArray.size();i++){
				logger.info("Verifying the profile : "+(i+1));
				JsonObject profileObject = profileArray.get(i).getAsJsonObject();
			
				
				 INDVBuRelationship = profileObject.get("bURelationShip").getAsString();
				 userSourceCode = profileObject.get("userSourceCode").getAsString();
				
				
				
				
				if(profileObject.has("contactChannels")) {
					contactChannelArray = profileObject.get("contactChannels").getAsJsonArray();
			
			
			for ( JsonElement eachphoneNumbersArray : contactChannelArray) {
				
				
				
				ContactChannelIDs = eachphoneNumbersArray;
				
				temp2.add(getcontactChannelsINDV());
				
				

			}
			profile2.setcontactChannels(temp2);
			}
				
				if(profileObject.has("contactAddresses")) {
					contactAddressArray = profileObject.get("contactAddresses").getAsJsonArray();
			
			
			for ( JsonElement eachAddressesArray : contactAddressArray) {
				
				
				
				ContactAddressesIDs = eachAddressesArray;
				
				temp4.add(getcontactAddressesINDV());
				
				

			}
			profile2.setcontactAddresses(temp4);
			}
				
				
				
			}
		}
						
	public contactAddressesV4 getcontactAddressesINDV() throws EncryptedDocumentException, InvalidFormatException, IOException {
			
			Random rand = new Random();
			int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
			
			String Contact = "10"+Integer.toString(n);
			contactAddressesV4 ContactAddressINDV = new contactAddressesV4();
				String ContactAddressID=ContactAddressesIDs.getAsJsonObject().get("contactAddressId").getAsString();
				String addressType=ContactAddressesIDs.getAsJsonObject().get("addressType").getAsString();
				
				
				Random rand1 = new Random();
				
				rand1.ints(106, 115);
		        
		        int num = rand1.ints(106, 115).findFirst().getAsInt();
		       
		        String contactAddresses_id="contactAddresses"+num;
		    
		        FileInputStream file1 = new FileInputStream(new File(Path));
		        
		        
		 
		        
		        
		        Workbook WW = WorkbookFactory.create(file1);
		        Sheet sheet = WW.getSheet("contactAddressesV4");
		        
	
		        int rownum=0,colnum=0,i=-1,j=-1;
		        DataFormatter dataFormatter = new DataFormatter();
		        Iterator<Row> rowIterator = sheet.rowIterator();
		        while (rowIterator.hasNext()) {
		      Row row = rowIterator.next();
		      Iterator<Cell> cellIterator = row.cellIterator();
		      i++;
		      if(i==0){
		      while (cellIterator.hasNext()) {
		      j++;
		          Cell cell = cellIterator.next();
		          String cellValue = dataFormatter.formatCellValue(cell);
		          if(cellValue.equalsIgnoreCase("contactAddresses_id"))
		              colnum = j;
		      }
		      }
		      else{
		      Cell cell = row.getCell(colnum);
		      String temp = dataFormatter.formatCellValue(cell);
		      if(temp.equalsIgnoreCase(contactAddresses_id)) {
		              rownum = i;
		      }
		      }
		        }
		        Row row1=sheet.getRow(0);
		        Row row2=sheet.getRow(rownum);
		        for(int k=1;k<row1.getLastCellNum();k++){
		        
		               Cell cell1=row1.getCell(k);
		               Cell cell2=row2.getCell(k);
		               String cellValue1=dataFormatter.formatCellValue(cell1);
		               String cellValue2=dataFormatter.formatCellValue(cell2);
		               ContactAdress.put(cellValue1, cellValue2);
		        }

				
				
				logger.info(ContactAddressID);
				
				logger.info(addressType);
				

				logger.info(ContactAddressID);
				
				logger.info(addressType);

				
			

				
				ContactAddressINDV.setaddressType(addressType);
				ContactAddressINDV.setcontactAddressID(ContactAddressID);
			
				  ContactAddressINDV.setaddressLine1(ContactAdress.get("addressLine1").toUpperCase());
				  ContactAddressINDV.setaddressLine2(ContactAdress.get("addressLine2").toUpperCase());
				  ContactAddressINDV.setaddressLine3(ContactAdress.get("addressLine3").toUpperCase());
				  ContactAddressINDV.setcity(ContactAdress.get("city").toUpperCase());
				  ContactAddressINDV.setcountry(ContactAdress.get("country"));
				  ContactAddressINDV.setstate(ContactAdress.get("state"));
				  ContactAddressINDV.setzipCode(ContactAdress.get("zipCode"));
				  ContactAddressINDV.setisUpdated("true");
				  ContactAddressINDV.setisEditable("true");
				
			
			return ContactAddressINDV;
			
		
	}
	
	public contactChannelsV4 getcontactChannelsINDV() {
		
		Random rand = new Random();
		int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
		
		String Contact = "10"+Integer.toString(n);
		contactChannelsV4 D = new contactChannelsV4();
			String ContactChannelID=ContactChannelIDs.getAsJsonObject().get("contactChannelId").getAsString();
			String type=ContactChannelIDs.getAsJsonObject().get("contactChannelType").getAsString();
			String contactChannel=ContactChannelIDs.getAsJsonObject().get("contactChannel").getAsString();
			
			
			
			
			logger.info(ContactChannelID);
			
			logger.info(type);
			
			logger.info(contactChannel);
			
logger.info(ContactChannelID);
			
			logger.info(type);
			
			logger.info(contactChannel);
			
		

			D.setcontactChannelType(type);
			D.setcontactChannelId(ContactChannelID);
			D.setcontactChannel(contactChannel);
			if(contactChannel.equalsIgnoreCase("email")) {
			D.setcontactChannelValue("SridharSubramani"+Contact+"@prudential.com");
			}
			else {
				D.setcontactChannelValue(Contact);
			}
			D.setisDeleted("false");
			D.setisEditable("true");
			D.setisUpdated("true");
			
			
		
		return D;
		
	
}
	
	
	
	
	
	@When("^PUT hit the request with the details obtained from GET INDV with ssoid$")
	public void post_request_sent_to_Event_Api_to_Update_INDV() throws Throwable {
logger.info("In When a PUT request is sent to profile API with below request body data");

			
Connection Con2 = DBConnection.InitConnection();

String query = "select COUSERID from couser where ssoid='"+INDVssoid+"' and DELETED='N'";



//String query = "select * from customerdb.usereventstatus where requestId='Abi_tst_207'";
ResultSet rs = DBConnection.execStatement(Con2,query);

		JsonArray policiesArray = new JsonArray();
		String couserid;
	
		while(rs.next()){
			
			
			  couserid = rs.getString("COUSERID");
			  
			  profile2.setcoUserId(couserid);
		}
			profile2.setssoId(INDVssoid);
			
			profile2.setbURelationShip(INDVBuRelationship);
			profile2.setuserSourceCode(userSourceCode);
		
//			profile1.setisEditable("true");
		
			
			 RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
			 
			 int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
				requestID = "PorifleV4_Update_" + n;
			 request = given().log().all()
						.header("X-PruRequestId", requestID)
						.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
						.header("X-Forwarded-For", "0.0.0.0")	
						.header("X-PruPrimaryIdentity", "X223793")
						.header("X-PruImpersonatedIdentity", INDVssoid);
				
					//request.param("ssoId",data.get("Header_ssoId"));
				Gson gson = new Gson();
				String body = gson.toJson(profile2);
				Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
				logger.info("Response----->:" + Res1.prettyPrint());
				logger.info(Res1.asString());
	}

	@When("^PUT hit the request with the details obtained from GET INDV with couserId$")
	public void post_request_sent_to_Event_Api_to_Update_INDV_couserid() throws Throwable {
logger.info("In When a PUT request is sent to profile API with below request body data");

			
Connection Con2 = DBConnection.InitConnection();

String query = "select SSOID from couser where ssoid='"+INDVssoid+"' and DELETED='N'";



//String query = "select * from customerdb.usereventstatus where requestId='Abi_tst_207'";
ResultSet rs = DBConnection.execStatement(Con2,query);

		JsonArray policiesArray = new JsonArray();
		String ssoid;
	
		while(rs.next()){
			
			
			ssoid = rs.getString("SSOID");
			
			  profile2.setssoId(ssoid);
			  
		}
		profile2.setcoUserId(INDVssoid);
			
			profile2.setbURelationShip(INDVBuRelationship);
			profile2.setuserSourceCode(userSourceCode);
		
//			profile1.setisEditable("true");
		
			
			 RestAssured.baseURI = "https://api-dev.prudential.com/co/qa/secure/profiles/v4/profile";
			 
			 int n = rand.ints(5,11111111,99999999).findFirst().getAsInt();
				requestID = "PorifleV4_Update_" + n;
			 request = given().log().all()
						.header("X-PruRequestId", requestID)
						.header("Authorization", "Basic R2pRd0NOU2dpaUdsVUNrU1J1RG1wR1BTRUlkRzJyOGc6NzJkRzBoVjhlOTRTVHFMQg==")
						.header("X-Forwarded-For", "0.0.0.0")	
						.header("X-PruPrimaryIdentity", "X223793")
						.header("X-Pru-Imp-CO-USER-ID", INDVssoid);
				
					//request.param("ssoId",data.get("Header_ssoId"));
				Gson gson = new Gson();
				String body = gson.toJson(profile2);
				Res1 = request.log().all().body(body).contentType(ContentType.JSON).put().andReturn();
				logger.info("Response----->:" + Res1.prettyPrint());
				logger.info(Res1.asString());
	}

	
	
				
				

		@Then("^verify Add contact channel on BU is complete by verifying GET BU api for \"([^\"]*)\"$")
		public void verify_Add_contact_channel_on_BU_is_complete_by_verifying_GET_BU_api(String channelType) throws Throwable {
			Thread.sleep(5000);
			
			//RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/KNiBHjEU19Ze4_f_pGVo1g";
			RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/8K6DOZMZVOdRHVWuqYP9Ew";
			request = given().log().all()
					.header("Content-Type", "application/x-www-form-urlencoded")
					  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
					  .header("cache-control", "no-cache")
					  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
				
			Res1 = request.when().get().andReturn();
			//logger.info("Response----->:" + Res1.prettyPrint());
			//logger.info(Res1.asString());
			//Channel_Value1.putAll(RequestBodyPojoCreater.Channel_Value);
			
			String resBody=Res1.getBody().asString();
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray phoneNumbersArray = new JsonArray();
			JsonArray emailAddressesArray = new JsonArray();
			if(responseObject.has("phoneNumbers")){
				phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
		
				}
				for (JsonElement eachphoneNumbersArray : phoneNumbersArray) {
					
				
					String Phonetype=eachphoneNumbersArray.getAsJsonObject().get("type").getAsString();
					
					if(Phonetype.equalsIgnoreCase(channelType))
					{
						String PhoneNo=eachphoneNumbersArray.getAsJsonObject().get("localAreaCode").getAsString()+eachphoneNumbersArray.getAsJsonObject().get("localPhoneNumber").getAsString();
						
					for(String  eachChannelValue : Channel_Value1.keySet())
					{
						if(eachChannelValue.equalsIgnoreCase(channelType))
						{
							
							Assert.assertEquals(Channel_Value1.get(eachChannelValue), PhoneNo,"Updated value is verified In BU");
							logger.info("Added channel value for type "+channelType+" is verified in BU");
						}
						
					}
					}	
			    }
				
			if(responseObject.has("emailAddresses")){
				emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
		
				}
				for (JsonElement eachemailAddressesArray : emailAddressesArray) {
					String type=eachemailAddressesArray.getAsJsonObject().get("type").getAsString();
				if(type.equalsIgnoreCase(channelType))
				{
					String emailAddress=eachemailAddressesArray.getAsJsonObject().get("emailAddress").getAsString();
					for(String  eachChannelValue : Channel_Value1.keySet())
					{
						
						if(eachChannelValue.equalsIgnoreCase(channelType))
						{
							Assert.assertEquals(Channel_Value1.get(eachChannelValue).toUpperCase(), emailAddress,"Updated value is verified In BU");
							logger.info("updated channel value for type "+channelType+" is verified in BU");
						}
						
			    }
					
					
				}
		}
				//RequestBodyPojoCreater.Channel_Value.clear();
				
		Channel_Value1.clear();
				
				}
				
		@Then("^verify table USEREVENTSTATUS for Deleted contact channel \"([^\"]*)\"$")
		public void verify_table_USEREVENTSTATUS_for_for_Deleted_contact_channel(String Channeltype) throws Throwable {
	
			Connection Con2 = null;
			try{
				
			Con2 = DBConnection.InitConnection();
			String query = "select * from customerdb.usereventstatus where requestId='"+requestID+"'";
			Thread.sleep(8000);
			//String query = "select * from customerdb.usereventstatus where requestId='Abi_tst_207'";
			ResultSet rs = DBConnection.execStatement(Con2,query);
			logger.info("Validating Event status table ");
			logger.info("Query Input : "+query);
			
				List<String> caseID = new ArrayList<String>();
				List<String> TransID = new ArrayList<String>();
				Set<String> eventsubtype = new HashSet<String>();
				Map< String,String> codes =  
	                    new HashMap< String,String>();
				while(rs.next()){
					caseID.add(rs.getString("CASEID"));
					TransID.add(rs.getString("TRANSACTIONID"));
					eventsubtype.add(rs.getString("EVENTSUBTYPE"));
					codes.put(rs.getString("TRANSACTIONID"),rs.getString("TRANSACTIONDESCRIPTION"));
					//logger.info(rs.getString("CASEID"));
					//logger.info(rs.getString("TRANSACTIONID")+rs.getString("TRANSACTIONDESCRIPTION"));
					if(rs.getString("EVENTSUBTYPE").equalsIgnoreCase(Channeltype)&&!"Primary".equalsIgnoreCase(Channeltype))
					{
						
						try {
						Assert.assertEquals(rs.getString("TRANSACTIONDESCRIPTION"), "BU_NOTIFIED");
						Assert.assertEquals(rs.getString("EVENTSTATUSDESCRIPTION"), "PENDING");
						logger.info("Channeltype " +rs.getString("EVENTSUBTYPE")+"is updated for Transaction ID "+rs.getString("TRANSACTIONID")+" And status is "+rs.getString("TRANSACTIONDESCRIPTION"));
						}catch (AssertionError e) {
							logger.info(e.getMessage());
							logger.info("Updating Channeltype " +rs.getString("EVENTSUBTYPE")+" is failed status "+rs.getString("TRANSACTIONDESCRIPTION"));
							logger.info("Transaction message is  " +rs.getString("TRANSACTIONMESSAGE"));
							logger.info("Status description is  " +rs.getString("EVENTSTATUSDESCRIPTION"));
						}
										
					}else if(rs.getString("EVENTSUBTYPE").equalsIgnoreCase(Channeltype)&&"Phone".equalsIgnoreCase(rs.getString("EVENTTYPE")))
							{
						
						try {
							Assert.assertEquals(rs.getString("TRANSACTIONDESCRIPTION"), "BU_NOTIFIED");
							Assert.assertEquals(rs.getString("EVENTSTATUSDESCRIPTION"), "PENDING");
							logger.info("Channeltype " +rs.getString("EVENTSUBTYPE")+"is updated for Transaction ID "+rs.getString("TRANSACTIONID")+" And status is "+rs.getString("TRANSACTIONDESCRIPTION"));
							}catch (AssertionError e) {
								logger.info(e.getMessage());
								logger.info("Updating Channeltype " +rs.getString("EVENTSUBTYPE")+" is failed status "+rs.getString("TRANSACTIONDESCRIPTION"));
								logger.info("Transaction message is  " +rs.getString("TRANSACTIONMESSAGE"));
								logger.info("Status description is  " +rs.getString("EVENTSTATUSDESCRIPTION"));
							}
						
							}
						else
							{
							logger.info("No record in Db for corresponding channel Type "+Channeltype);
							}
					
								
				}
				
				// caseID validation
				String First_caseID = caseID.get(0);
				int count=0;
				for (String eachcaseID : caseID) {
					
					try {
					Assert.assertEquals(First_caseID, eachcaseID);
					count=count+1;
					
					}catch (AssertionError e) {
						logger.info(e.getMessage());
						
					}
					}
					if(count==caseID.size())
					{
						logger.info("CaseID is Same for all transactions "+caseID.get(0));
					}
					else
					{
						logger.info("CaseID is not Same for all transactions ");
					}
				
				
				// TransactionID validation
				Set<String> keySet = codes.keySet();
				if(keySet.size()==TransID.size())
				{
					logger.info("TRANSACTIONID is Unique for all transactions ");
				}
				else
				{
					logger.info("TRANSACTIONID is not Unique for all transactions ");
				}
					
				
		
			}catch (Exception e) {
				logger.info(e.getMessage());
				}finally {
					if (Con2 != null) {
						Con2.close();
						}

			}	// DBConnection.DbConnection_close(con2);
			}
		@Then("^verify Delete on BU is complete by verifying GET BU api for \"([^\"]*)\" contact channel$")
		public void verify_Delete_on_BU_is_complete_by_verifying_GET_BU_api(String channelType) throws Throwable {
			Thread.sleep(5000);
			
			//RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/KNiBHjEU19Ze4_f_pGVo1g";
			RestAssured.baseURI = "https://api-stage.prudential.com/isg/v1/contacts/parties/8K6DOZMZVOdRHVWuqYP9Ew";
			request = given().log().all()
					.header("Content-Type", "application/x-www-form-urlencoded")
					  .header("Authorization", "Basic VllxZDY2UTJJWkZWQUo2RjI0Q1lxR0dnTUZ1QzVBcDE6S1oxZUVBa0ZVQzdleVRWMw==")
					  .header("cache-control", "no-cache")
					  .header("Postman-Token", "98d0345c-f514-4986-9a57-4f949f8a2144");
				
			Res1 = request.when().get().andReturn();
			//logger.info("Response----->:" + Res1.prettyPrint());
			//logger.info(Res1.asString());
			//Channel_Value1.putAll(RequestBodyPojoCreater.Channel_Value);
			List<String> Type = new ArrayList<String>();
			String resBody=Res1.getBody().asString();
			JsonObject responseObject = (JsonObject) new JsonParser().parse(resBody);
			JsonArray phoneNumbersArray = new JsonArray();
			JsonArray emailAddressesArray = new JsonArray();
			if(responseObject.has("phoneNumbers")){
				phoneNumbersArray=responseObject.get("phoneNumbers").getAsJsonArray();
		
				}
				for (JsonElement eachphoneNumbersArray : phoneNumbersArray) {
					
				
					String Phonetype=eachphoneNumbersArray.getAsJsonObject().get("type").getAsString();
					
					
					Type.add(Phonetype);
			    }
				
			if(responseObject.has("emailAddresses")){
				emailAddressesArray=responseObject.get("emailAddresses").getAsJsonArray();
		
				}
				for (JsonElement eachemailAddressesArray : emailAddressesArray) {
					String type=eachemailAddressesArray.getAsJsonObject().get("type").getAsString();
				Type.add(type);
		}
				//RequestBodyPojoCreater.Channel_Value.clear();
				
		Channel_Value1.clear();
		int count=0;
				for (String eachType : Type) {
					if(channelType.equalsIgnoreCase(eachType))
					{
						logger.info(channelType+" channelType not get deleted in BU.");
					}
					else {
						count++;
					}
					}
				if(Type.size()==count) {
					logger.info(channelType+" channelType is deleted in BU.");
				}
				
				}
						}

		

