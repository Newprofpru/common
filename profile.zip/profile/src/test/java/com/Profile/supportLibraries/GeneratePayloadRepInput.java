package com.Profile.supportLibraries;

import java.util.Map;

import com.Profile.RequestBodyPojo.amluReputation;
import com.Profile.RequestBodyPojo.amluRiskScore;
import com.Profile.RequestBodyPojo.demography;
import com.Profile.RequestBodyPojo.finalSummation;
import com.Profile.RequestBodyPojo.highRiskThreshold;
import com.Profile.RequestBodyPojo.paymentMethod;
import com.Profile.RequestBodyPojo.product;
import com.Profile.RequestBodyPojo.reputation;
import com.Profile.RequestBodyPojo.residentStatus;
import com.Profile.RequestBodyPojo.riskScore;
import com.Profile.RequestBodyPojo.riskScoreConfig;
import com.Profile.RequestBodyPojo.riskreputation;
import com.Profile.RequestBodyPojo.sourceOfFunds;
import com.Profile.RequestBodyPojo.typeCode;

public class GeneratePayloadRepInput {
	
	public static amluReputation repu_payload(Map<String,String> Repu_Data){
		
		reputation Repu_Info = new reputation();
		
		Repu_Info.setAdverseMedia(Repu_Data.get("ADVERSEMEDIA"));
		Repu_Info.setAml(Repu_Data.get("AML"));
		Repu_Info.setLocalSanctions(Repu_Data.get("LOCALSANCTIONS"));
		Repu_Info.setMarijuana(Repu_Data.get("MARIJUANA"));
		Repu_Info.setOfac(Repu_Data.get("OFAC"));
		Repu_Info.setPoliticallyExposed(Repu_Data.get("POLITICALLYEXPOSED"));
		Repu_Info.setPfc(Repu_Data.get("PLM"));
		Repu_Info.setSarorstrInd(Repu_Data.get("SARORSTRIND"));
		
		
		amluReputation request = new amluReputation();
		
		request.setReputation(Repu_Info);
		
		return request;
		
		}

	public static amluRiskScore src_payload(Map<String,String> Repu_Data){
		
		paymentMethod pay1_Info = new paymentMethod();
		
		pay1_Info.setAchint(Repu_Data.get("ACHINT"));
		pay1_Info.setAchus(Repu_Data.get("ACHUS"));
		pay1_Info.setCash(Repu_Data.get("CASH"));
		pay1_Info.setCbc(Repu_Data.get("CBC"));
		pay1_Info.setCheck(Repu_Data.get("CHECK"));
		pay1_Info.setDcccc(Repu_Data.get("DCCCC"));
		pay1_Info.setDccctp(Repu_Data.get("DCCCTP"));
		pay1_Info.setDdefault(Repu_Data.get("DDEFAULT"));
		pay1_Info.setEftcb(Repu_Data.get("EFTCB"));
		pay1_Info.setEftsb(Repu_Data.get("EFTSB"));
		pay1_Info.setFedwirec(Repu_Data.get("FEDWIREC"));
		pay1_Info.setFedwiretp(Repu_Data.get("FEDWIRETP"));
		pay1_Info.setMo(Repu_Data.get("MO"));
		pay1_Info.setTc(Repu_Data.get("TC"));		
		
		sourceOfFunds src = new sourceOfFunds();
		src.setPaymentMethod(pay1_Info);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setSourceOfFunds(src);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
	
	public static amluRiskScore prod_payload(Map<String,String> Repu_Data){
		
		riskScore prod_Info = new riskScore();
		riskScore mulprod_Info = new riskScore();
		
		prod_Info.setY(Repu_Data.get("PRODY"));
		prod_Info.setN(Repu_Data.get("PRODN"));
		prod_Info.setRdefault(Repu_Data.get("PDEFAULT"));
		mulprod_Info.setY(Repu_Data.get("MULTPRODY"));
		mulprod_Info.setN(Repu_Data.get("MULTPRODN"));
		mulprod_Info.setRdefault(Repu_Data.get("MDEFAULT"));
		
		product prod = new product();
		prod.setProductCashvalue(prod_Info);
		prod.setMultipleProductCashvalue(mulprod_Info);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setProduct(prod);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
		
	public static amluRiskScore finalSum_payload(Map<String,String> Repu_Data){
			
		finalSummation finSum = new finalSummation();
		
		finSum.setFinalhighriskthreshold(Repu_Data.get("finalhighriskthreshold"));
		finSum.setIndividualhighriskthreshold(Repu_Data.get("individualhighriskthreshold"));
		finSum.setOperator(Repu_Data.get("operator"));
		
		highRiskThreshold risk = new highRiskThreshold();
		risk.setFinalSummation(finSum);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setHighRiskThreshold(risk);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
	
	public static amluRiskScore demo_payload(Map<String,String> Repu_Data){
		
		riskScore benNameAddr = new riskScore();
		riskScore benePercent = new riskScore();
		typeCode typeCode = new typeCode();
		
		benNameAddr.setY(Repu_Data.get("beneAddy"));
		benNameAddr.setN(Repu_Data.get("beneAddn"));
		benNameAddr.setRdefault(Repu_Data.get("beneAddDef"));
		benePercent.setY(Repu_Data.get("benePery"));
		benePercent.setN(Repu_Data.get("benePern"));
		benePercent.setRdefault(Repu_Data.get("benePerDef"));
		typeCode.setOpc(Repu_Data.get("opc"));
		typeCode.setSc(Repu_Data.get("sc"));
		typeCode.setBscorp(Repu_Data.get("bscorp"));
		typeCode.setNgo(Repu_Data.get("ngo"));
		typeCode.setEmbcons(Repu_Data.get("embconss"));
		typeCode.setTppp(Repu_Data.get("tppp"));
		typeCode.setTrustf(Repu_Data.get("trustf"));
		typeCode.setTrusto(Repu_Data.get("trusto"));
		typeCode.setSpv(Repu_Data.get("spv"));
		typeCode.setFfi(Repu_Data.get("ffi"));
		typeCode.setFfio(Repu_Data.get("ffio"));
		typeCode.setDfi(Repu_Data.get("dfi"));
		typeCode.setPic(Repu_Data.get("pic"));
		typeCode.setTdefault(Repu_Data.get("typeDef"));
		
		demography dem = new demography();
		dem.setBeneOwnersNameAddress(benNameAddr);
		dem.setBeneOwnersPercent(benePercent);
		dem.setTypeCode(typeCode);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setDemography(dem);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
	
public static amluRiskScore rep_payload(Map<String,String> Repu_Data){
		
		riskScore mar = new riskScore();
		riskScore pfc = new riskScore();
		riskScore advmedia = new riskScore();
		riskScore transmedia = new riskScore();
		riskScore ofac = new riskScore();
		riskScore locsan = new riskScore();
		riskScore sar = new riskScore();
		
		mar.setY(Repu_Data.get("mariy"));
		mar.setN(Repu_Data.get("marin"));
		mar.setRdefault(Repu_Data.get("mariDef"));
		pfc.setY(Repu_Data.get("pfcy"));
		pfc.setN(Repu_Data.get("pfcn"));
		pfc.setRdefault(Repu_Data.get("pfcDef"));
		advmedia.setY(Repu_Data.get("advmedy"));
		advmedia.setN(Repu_Data.get("advmedn"));
		advmedia.setRdefault(Repu_Data.get("advmedDef"));
		transmedia.setY(Repu_Data.get("transmedy"));
		transmedia.setN(Repu_Data.get("transmedn"));
		transmedia.setRdefault(Repu_Data.get("transmedDef"));
		ofac.setY(Repu_Data.get("ofacy"));
		ofac.setN(Repu_Data.get("ofacn"));
		ofac.setRdefault(Repu_Data.get("ofacDef"));
		locsan.setY(Repu_Data.get("locsany"));
		locsan.setN(Repu_Data.get("locsann"));
		locsan.setRdefault(Repu_Data.get("locsanDef"));
		sar.setY(Repu_Data.get("sary"));
		sar.setN(Repu_Data.get("sarn"));
		sar.setRdefault(Repu_Data.get("sarDef"));
		
		riskreputation rep = new riskreputation();
		rep.setMarijuana(mar);
		rep.setPfc(pfc);
		rep.setAdverseMedia(advmedia);
		rep.setTransactionMedia(transmedia);
		rep.setOfac(ofac);
		rep.setLocalSanctions(locsan);
		rep.setSar(sar);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setReputation(rep);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}

	public static amluRiskScore benerep_payload(Map<String,String> Repu_Data){
		
		riskScore benemar = new riskScore();
		riskScore benepfc = new riskScore();
		riskScore beneofac = new riskScore();
		riskScore beneadv = new riskScore();		
		
		benemar.setY(Repu_Data.get("benemariy"));
		benemar.setN(Repu_Data.get("benemarin"));
		benemar.setRdefault(Repu_Data.get("benemariDef"));
		benepfc.setY(Repu_Data.get("benepfcy"));
		benepfc.setN(Repu_Data.get("benepfcn"));
		benepfc.setRdefault(Repu_Data.get("benepfcDef"));
		beneofac.setY(Repu_Data.get("beneofacy"));
		beneofac.setN(Repu_Data.get("beneofacn"));
		beneofac.setRdefault(Repu_Data.get("beneofacDef"));
		beneadv.setY(Repu_Data.get("beneadvy"));
		beneadv.setN(Repu_Data.get("beneadvn"));
		beneadv.setRdefault(Repu_Data.get("beneadvDef"));
		
		riskreputation rep = new riskreputation();
		rep.setBenePFC(benepfc);
		rep.setBeneMarijuana(benemar);
		rep.setBeneOFAC(beneofac);
		rep.setBeneAdverseMedia(beneadv);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setReputation(rep);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
	
public static amluRiskScore indvrep_payload(Map<String,String> Repu_Data){
		
		riskScore mar = new riskScore();
		riskScore pfc = new riskScore();
		riskScore advmedia = new riskScore();
		riskScore transmedia = new riskScore();
		riskScore ofac = new riskScore();
		riskScore locsan = new riskScore();
		riskScore sar = new riskScore();
		riskScore pep = new riskScore();
		
		mar.setY(Repu_Data.get("mariy"));
		mar.setN(Repu_Data.get("marin"));
		mar.setRdefault(Repu_Data.get("mariDef"));
		pfc.setY(Repu_Data.get("pfcy"));
		pfc.setN(Repu_Data.get("pfcn"));
		pfc.setRdefault(Repu_Data.get("pfcDef"));
		advmedia.setY(Repu_Data.get("advmedy"));
		advmedia.setN(Repu_Data.get("advmedn"));
		advmedia.setRdefault(Repu_Data.get("advmedDef"));
		transmedia.setY(Repu_Data.get("transmedy"));
		transmedia.setN(Repu_Data.get("transmedn"));
		transmedia.setRdefault(Repu_Data.get("transmedDef"));
		ofac.setY(Repu_Data.get("ofacy"));
		ofac.setN(Repu_Data.get("ofacn"));
		ofac.setRdefault(Repu_Data.get("ofacDef"));
		locsan.setY(Repu_Data.get("locsany"));
		locsan.setN(Repu_Data.get("locsann"));
		locsan.setRdefault(Repu_Data.get("locsanDef"));
		sar.setY(Repu_Data.get("sary"));
		sar.setN(Repu_Data.get("sarn"));
		sar.setRdefault(Repu_Data.get("sarDef"));
		pep.setY(Repu_Data.get("pepy"));
		pep.setN(Repu_Data.get("pepn"));
		pep.setRdefault(Repu_Data.get("pepDef"));
		
		riskreputation rep = new riskreputation();
		rep.setMarijuana(mar);
		rep.setPfc(pfc);
		rep.setAdverseMedia(advmedia);
		rep.setTransactionMedia(transmedia);
		rep.setOfac(ofac);
		rep.setLocalSanctions(locsan);
		rep.setSar(sar);
		rep.setPep(pep);

		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setReputation(rep);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}

	public static amluRiskScore resStatus_payload(Map<String,String> Repu_Data){
		
		residentStatus res = new residentStatus();	
		
		res.setNra(Repu_Data.get("nra"));
		res.setPra(Repu_Data.get("pra"));
		res.setPrc(Repu_Data.get("prc"));
		res.setTra(Repu_Data.get("tra"));
		res.setRdefault(Repu_Data.get("rdefault"));
		
		demography demRes = new demography();
		demRes.setResidentStatus(res);
		riskScoreConfig riskCon = new riskScoreConfig();
		riskCon.setDemography(demRes);		
		amluRiskScore request = new amluRiskScore();
		request.setRiskScoreConfig(riskCon);
		request.setType(Repu_Data.get("TYPE"));
		
		return request;
		}
}
