package com.Profile.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;



 public class getEnvInfo {
	
	//static Properties properties = Settings.getInstance();
	static Properties properties = loadFromPropFile();
	static Logger log = Logger.getLogger(getEnvInfo.class);
	static String Url;
	public static String getURL() {
		return properties.getProperty("URL");
	}
	public static String getPublicURL() {
		
		System.out.println(properties.getProperty("Environment"));
		if(properties.getProperty("Environment").equals("QA"))
		{
		System.out.println("In IF");		
		Url=properties.getProperty("PublicUrl");
		System.out.println(Url);
		}
		if(properties.getProperty("Environment").equals("Stage"))
		Url=properties.getProperty("PublicUrl");
		
			
			
		return Url;
	}
	public static String getSecureURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQA");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGE");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlSTAGE2");
		return null;
	}
	
	public static String getSecureHRTBypassURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureHRTBypassUrlQA");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureHRTBypassUrlSTAGE");
		return null;
	}
	
	public static String getAccountsSecureURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAAaccounts");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEaccounts");
		return null;
		
	}
	
	public static String getAuditTrailSecureURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAAuditTrail");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEAuditTrail");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlSTAGE2AuditTrail");
		return null;
		
	}
	
	public static String getAuditTrailGetRequestGetRecordsURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAGetRecordsAuditAmlu");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageGetRecordsAuditAmlu");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlStage2GetRecordsAuditAmlu");
		return null;
		
	}
	public static String getAuditTrailGetRequestViewRecordsURL() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAViewRecordsAuditAmlu");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlStageViewRecordsAuditAmlu");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlStage2ViewRecordsAuditAmlu");
		return null;
		
	}
	
	public static String getSecureURLIndvRep() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQAIndvRep");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGEIndvRep");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlSTAGE2IndvRep");
		return null;
		
	}

	 public static String getSecureURLBeneRep() {
		 if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			 return properties.getProperty("SecureUrlQABeneRep");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			 return properties.getProperty("SecureUrlSTAGEBeneRep");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			 return properties.getProperty("SecureUrlSTAGE2BeneRep");
		 return null;

	 }

	 public static String getSecureURLEntityRep() {
		 if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			 return properties.getProperty("SecureUrlQAEntityRep");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			 return properties.getProperty("SecureUrlSTAGEEntityRep");
		 else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			 return properties.getProperty("SecureUrlSTAGE2EntityRep");
		 return null;

	 }
	
	public static String getSecureUrlSMSession() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQASMSession");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGESMSession");
		return null;
		
	}
	
	public static String getSecureUrlRiskScore() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("SecureUrlQARiskScore");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("SecureUrlSTAGERiskScore");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("SecureUrlSTAGE2RiskScore");
		return null;
		
	}

	public static String getAuthorization() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AuthorizationQA");
		else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")
				|| properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("AuthorizationSTAGE");
		return null;
	}
	
	public static String getRepAuthorization() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("AuthorizationRepQA");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AuthorizationRepSTAGE");
		return null;
	}
	
	public static String getIVuser() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("IVuserQARep");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("IVuserStageRep");
		return null;
	}
	public static String getdb() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("DBqa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("DBstg");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("DBstg2");
		return null;
	}
	
	public static String getdbUserName() {
		return properties.getProperty("dbUserName");
	}
	public static String getdbPass() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			return properties.getProperty("dbPassqa");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("dbPassstg");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE2"))
			return properties.getProperty("dbPassstg2");
		return null;
	}
	
	public static String getaccountsdb() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			System.out.println(properties.getProperty("AccountsDBqa"));
			return properties.getProperty("AccountsDBqa");
		}
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
		{
			return properties.getProperty("AccountsDBstg");
		}
		return null;
	}

	public static String getAuthorizationSMSESSION(){
		if(properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
			return properties.getProperty("AuthorizationSMSESSIONQA");
		}
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
		{
			System.out.println(properties.getProperty("AuthorizationSMSESSIONSTAGE"));
			return properties.getProperty("AuthorizationSMSESSIONSTAGE");
		}
		System.out.println(properties.getProperty("AuthorizationSMSESSIONQA"));
		return null;
	}
	
	public static String getAuthorizationHRTBypass(){
		if (properties.getProperty("Environment").equalsIgnoreCase("QA")) {
			return properties.getProperty("AuthorizationHRTBYPASSQA");
		} else if (properties.getProperty("Environment").equalsIgnoreCase("STAGE")) {
			return properties.getProperty("AuthorizationHRTBYPASSSTAGE");
		}
		return null;
	}
	
	public static String getaccountsdbUserName() {
		System.out.println(properties.getProperty("AccountsdbUserName"));
		return properties.getProperty("AccountsdbUserName");
	}
	public static String getaccountsdbPass() {
		if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
		{System.out.println(properties.getProperty("AccountsdbPassqa"));
			return properties.getProperty("AccountsdbPassqa");
		}
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			return properties.getProperty("AccountsdbPassstg");
		return null;
	}
	
	public static String getEnvironment() {
		return properties.getProperty("Environment");
	}
	
	public static String getAuthUrl() {
		return properties.getProperty("AuthUrl");
	}
	public static String getCSRUrl() {
		return properties.getProperty("CSRUrl");
	}
	
	
	public static Properties getInstance() {
		return properties;
	}

	private static Properties loadFromPropFile() {
		Properties properties = new Properties();
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();
		relativePath = relativePath + Util.getFileSeparator() + "src"
				+ Util.getFileSeparator() + "test" + Util.getFileSeparator()
				+ "resources" ;

		try {
			properties.load(new FileInputStream(relativePath
					+ Util.getFileSeparator() + "GlobalSettings.properties"));
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}

		return properties;
	}

}

