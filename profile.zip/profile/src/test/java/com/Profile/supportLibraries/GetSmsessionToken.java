package com.Profile.supportLibraries;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetSmsessionToken{

    static String URL = getEnvInfo.getSecureUrlSMSession();
    static String authorization = getEnvInfo.getAuthorizationSMSESSION();
    static RequestSpecification request1;
    static String payload1;
    static Response Res1;
    static String resultbody = "";
    static Map<String,String> cookie_Data = new HashMap<String,String>();

    public static String generateSmsessionToken(String userid, String password){

        try {
            request1 = given().log().all().header("Authorization", authorization).header("Content-Type", "application/json");
            cookie_Data.put("userid", userid);
            cookie_Data.put("password", password);
            cookie_Data.put("buidtype", "INDV");
            ObjectMapper mapper = new ObjectMapper();

            payload1 = mapper.writeValueAsString(GeneratePayloadSMSession.Reputation_payload(cookie_Data));
            Res1 = request1.log().all().body(payload1).contentType(ContentType.JSON).post(URL).andReturn();

            JsonPath sessionres = new JsonPath(Res1.asString());

            System.out.println("sessionres" + sessionres);
            resultbody = sessionres.getString("message");

        }catch(Exception e){
            e.printStackTrace();
        }

        return resultbody;
    }
}