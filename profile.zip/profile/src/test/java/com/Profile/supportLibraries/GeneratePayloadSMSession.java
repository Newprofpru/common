package com.Profile.supportLibraries;

import java.util.Map;

public class GeneratePayloadSMSession {
	
	public static Session_info Reputation_payload(Map<String,String> Repu_Data){
		
		Session_info request = new Session_info();
		
		request.setUserid(Repu_Data.get("userid"));
		request.setpassword(Repu_Data.get("password"));
		request.setbuidtype(Repu_Data.get("buidtype"));
		
		
		
		//Session request = new Session();
		
		//request.setSession(ses_Info);
		
		return request;
		
	}

}
