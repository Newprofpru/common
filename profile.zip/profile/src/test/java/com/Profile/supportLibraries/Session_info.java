package com.Profile.supportLibraries;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"userid",
"password",
"buidtype"
})


public class Session_info {
	
	
	

	@JsonProperty("userid")
	private String userid;
	@JsonProperty("password")
	private String password;
	@JsonProperty("buidtype")
	private String buidtype;
	
	@JsonProperty("userid")
	public String getUserid() {
	return userid;
	}

	@JsonProperty("userid")
	public void setUserid(String userid) {
	this.userid = userid;
	}

	@JsonProperty("password")
	public String getpassword() {
	return password;
	}

	@JsonProperty("password")
	public void setpassword(String password) {
	this.password = password;
	}

	@JsonProperty("buidtype")
	public String getSarorstrInd() {
	return buidtype;
	}

	@JsonProperty("buidtype")
	public void setbuidtype(String buidtype) {
	this.buidtype = buidtype;
	}

	
}
