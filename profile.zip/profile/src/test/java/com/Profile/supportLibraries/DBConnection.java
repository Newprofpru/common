/* This Module is connect to DB and get results from DB
 * Author : Krishnapriya.vellanki@prudential.com
 * 
 */
package com.Profile.supportLibraries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;

import com.Profile.supportLibraries.getEnvInfo;

public class DBConnection {

	static Connection con = null;
	static Statement stmt = null;
	//static PreparedStatement ps = null;
	// static //static ResultSet Res = null;
	//static ResultSet Res;
	static Properties properties = getEnvInfo.getInstance();

	public static Connection getConnection() {
		
		String user = getEnvInfo.getdbUserName();
		String pass = getEnvInfo.getdbPass();
		String db = getEnvInfo.getdb();
//		System.out.println("DB is " + db);
//		System.out.println("User is" + user);
//		System.out.println("Pass is" + pass);
		return getConnection(db, user, pass);

	}
public static Connection InitConnection() {
		
		String user = getEnvInfo.getdbUserName();
		String pass = getEnvInfo.getdbPass();
		String db = getEnvInfo.getdb();
//		System.out.println("DB is " + db);
//		System.out.println("User is" + user);
//		System.out.println("Pass is" + pass);
		return getConnection(db, user, pass);

	}

public static Connection getaccountsDbConnection() {
	
	String user = getEnvInfo.getaccountsdbUserName();
	String pass = getEnvInfo.getaccountsdbPass();
	String db = getEnvInfo.getaccountsdb();
	System.out.println("DB is " + db);
//	System.out.println("User is" + user);
//	System.out.println("Pass is" + pass);
	return getConnection(db, user, pass);

}
public static Connection InitAccountsDbConnection() {
	
	String user = getEnvInfo.getaccountsdbUserName();
	String pass = getEnvInfo.getaccountsdbPass();
	String db = getEnvInfo.getaccountsdb();
//	System.out.println("DB is " + db);
//	System.out.println("User is" + user);
//	System.out.println("Pass is" + pass);
	return getConnection(db, user, pass);

}


	public static Connection getConnection(String db, String Username, String Pass) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(db, Username, Pass);

		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public static ResultSet execStatement(Connection conn, String query) {
		// Statement stmt;
		ResultSet Res = null;
		try {
			//System.out.println("Inside execStatement.");
			PreparedStatement ps = conn.prepareStatement(query);
			ps.getConnection();
			 Res = ps.executeQuery(query);
			//System.out.println(Res.getFetchSize());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return Res;

	}

	public static void DbConnection_close(Connection conn) {
		try {

			conn.close();
			//ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
