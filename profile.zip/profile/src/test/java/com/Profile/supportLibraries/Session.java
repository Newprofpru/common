package com.Profile.supportLibraries;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"session"
})

public class Session {
	
	@JsonProperty("session")
	private Session_info session;

	@JsonProperty("session")
	public Session_info getSession() {
	return session;
	}

	@JsonProperty("session")
	public void setSession(Session_info session) {
	this.session = session;
	}

}
