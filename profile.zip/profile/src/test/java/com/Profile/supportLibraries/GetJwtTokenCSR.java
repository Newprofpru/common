package com.Profile.supportLibraries;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Properties;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class GetJwtTokenCSR {
	static Properties properties = getEnvInfo.getInstance();
	
	public static String getCSRToken() throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.gecko.driver", "Z:\\Javalibs\\Selenium\\geckodriver-v0.19.1\\geckodriver.exe");
		//System.setProperty("webdriver.chrome.driver", "Z:\\Javalibs\\Selenium\\Browser Drivers\\chromedriver2.35.exe");
//		WebDriver driver = new FirefoxDriver();
		

		//WebDriver driver = new ChromeDriver();

		/*DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
//        options.setExperimentalOption("useAutomationExtension", false);
//         options.addArguments("start-maximized");
		options.addArguments("start-maximized"); // https://stackoverflow.com/a/26283818/1689770
        options.addArguments("enable-automation"); // https://stackoverflow.com/a/43840128/1689770
        options.addArguments("--headless"); // only if you are ACTUALLY running headless
        options.addArguments("--no-sandbox"); //https://stackoverflow.com/a/50725918/1689770
        options.addArguments("--disable-infobars"); //https://stackoverflow.com/a/43840128/1689770
        options.addArguments("--disable-dev-shm-usage"); //https://stackoverflow.com/a/50725918/1689770
        options.addArguments("--disable-browser-side-navigation"); //https://stackoverflow.com/a/49123152/1689770
        options.addArguments("--disable-gpu");
        options.addArguments("--disable-extensions");
        options.addArguments("--dns-prefetch-disable");
        options.addArguments("disable-features=NetworkService") ;
        //https://stackoverflow.com/questions/51959986/how-to-solve-selenium-chromedriver-timed-out-receiving-message-from-renderer-exc
//        WebDriver driver = new ChromeDriver(options);
        // options.addArguments("test-type");
//         options.setBinary("C:\\ProgramData\\App-V\\DDE2035B-4505-4E77-8524-E736E92F47B9\\95CC0CDA-96BE-4617-A7F6-DD94D5B0F70C\\Root\\VFS\\ProgramFilesX86\\Google\\Chrome\\Application\\chrome.exe");
         options.setBinary("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
         System.setProperty("webdriver.chrome.driver",
                              properties.getProperty("ChromeDriverPath"));
         capabilities.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
         capabilities.setCapability(ChromeOptions.CAPABILITY, options);
         WebDriver driver = new ChromeDriver(capabilities);*/
//         
         /*File pathToBinary = new File("C:\\AppVirt\\5\\7480AF94-C4E9-461B-B0AB-7A10F40A496D\\Root\\VFS\\ProgramFilesX86\\Mozilla Firefox\\firefox.exe");
//         FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
//         FirefoxProfile firefoxProfile = new FirefoxProfile();
//         FirefoxDriver driver = new FirefoxDriver(ffBinary,firefoxProfile);
         
         FirefoxOptions options = new FirefoxOptions();
         options.setBinary(new FirefoxBinary(pathToBinary));
         options.setProfile(new FirefoxProfile());
                                 

                     DesiredCapabilities capabilities = DesiredCapabilities.firefox();
                     capabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options);
                     capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
                     System.setProperty("webdriver.gecko.driver", properties.getProperty("GeckoDriverPath"));
                     FirefoxDriver driver = new FirefoxDriver();
                     driver.manage().window().maximize();
*/
		// --------------- For Mozilla browser --------------
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setCapability("acceptInsecureCerts", true); 
		System.setProperty("webdriver.gecko.driver", properties.getProperty("GeckoDriverPath"));
         System.setProperty("webdriver.firefox.bin","C:\\AppVirt\\5\\7480AF94-C4E9-461B-B0AB-7A10F40A496D\\Root\\VFS\\ProgramFilesX86\\Mozilla Firefox\\firefox.exe");
         WebDriver driver = new FirefoxDriver(capabilities);
         Thread.sleep(500);
         
         if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
			driver.get("https://csrawssw1-dev.prudential.com/");
		else if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
			driver.get("https://csrawssw1-stage.prudential.com/");
		System.out.println(" **************************1*******************************");
/*	
		driver.findElement(By.xpath("//input[contains(@name,'USER')]")).sendKeys("tsqa68@pru.com");
		driver.findElement(By.xpath("//input[contains(@name,'PASSWORD')]")).sendKeys("password1");
		driver.findElement(By.xpath("//input[contains(@name,'BUIDTYPE')]")).sendKeys("INDV");
		driver.findElement(By.xpath("//form/table/tbody/tr[5]/td/input[contains(@value,'Login')]")).click();
		*/
	
		
		Thread.sleep(2000);
		
		
		do{
			if (driver.getTitle().contains("Select a certificate")) {
			
				Thread.sleep(1000);
				driver.get("javascript:document.getElementById('overridelink').click()");
			}
			
			}while(driver.getTitle().contains("Select a certificate"));
		
		Runnable mlauncher = () -> {
		    try {

		    	if(properties.getProperty("Environment").equalsIgnoreCase("QA"))
					driver.get("https://api-dev.prudential.com/.signjwt");
		    	Thread.sleep(2000);
				if(properties.getProperty("Environment").equalsIgnoreCase("STAGE"))
					driver.get("https://api-stage.prudential.com/.signjwt");
				Thread.sleep(2000);
		     } catch (Exception e) {
		          e.printStackTrace();
		       }
		    };

		    
		 try {

		   Thread mthread = new Thread(mlauncher);
		  
		   mthread.start();

		  Robot robot = new Robot();
		  robot.keyPress(KeyEvent.VK_ENTER);
		  robot.keyRelease(KeyEvent.VK_ENTER);

		 } catch (Exception e) {
		          e.printStackTrace();
		       }
		
		

		Thread.sleep(5000);
	//	String responsenew = driver.findElement(By.xpath("/html//body")).getText();  //*[@id="rawdata-panel"]
		 String responsenew = driver.findElement(By.xpath("//*[@id=\"/jwt\"]")).getText();
		 String[] value = responsenew.split(" ");
		 String value2 = value[1];
		 String jwt = value2.substring(1, value2.length()-1);
		 //String responsenew=driver.getPageSource();
		//Object parsedResponse = new JsonSlurper().parseText(responsenew);
		//String responsenew = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]")).getText();
		/*JSONObject obj = new JSONObject(responsenew);
		String jwtToken = obj.getString("jwt");
		System.out.println( "out put is " + jwtToken);*/

		//Object parsedResponse = new JsonSlurper().parseText(responsenew);
		//System.out.println( "APEX Response: $parsedResponse");
		//def jwtToken = parsedResponse.jwt;
		//System.out.println( "JWT Token: $jwtToken");
		driver.quit() ;

		return jwt
				;


	}

}
