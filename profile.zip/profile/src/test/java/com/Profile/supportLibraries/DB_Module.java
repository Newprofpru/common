/* This Module is Connect to DB and Retrive different Results Ex: Single Field,Single Row,Multiple Rows
 * Author : krishnapriya.vellanki@prudential.com
 */
package com.Profile.supportLibraries;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DB_Module {

	public static GenericEvent DBRS_SingleArraylist(Connection Con2, String query) throws SQLException {

		GenericEvent db_res = null;
		ResultSet rs = DBConnection.execStatement(Con2, query);

		if (rs != null && rs.next()) {
			System.out.println("rs is not empty!");
			db_res = new GenericEvent(rs);

			System.out.println("Hi");

			for (int i = 0; i < db_res.event_cols.size(); i++) {
				System.out.print(db_res.event_cols.get(i) + " ");

			}
		}
		return db_res;
	}

	public static Map<String,String> DBRS_Map(Connection Con2, String query) throws SQLException {

		Map<String,String> db_res= new HashMap<String,String>();		
		ResultSet rs = DBConnection.execStatement(Con2, query);

		if (rs != null && rs.next()) {
			System.out.println("rs is not empty!");
			ResultSetMetaData rs_md;
			try {
				rs_md = rs.getMetaData();
				int n = rs_md.getColumnCount();

				for (int i = 1; i <= n; i++) {
					db_res.put(rs_md.getColumnName(i),rs.getString(rs_md.getColumnName(i)));
					
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return db_res;
	}
	
	public static Map<String,String> seperatevalueSinglecolumn(Connection Con2, String query) throws SQLException {

		Map<String,String> db_res= new HashMap<String,String>();		
		ResultSet rs = DBConnection.execStatement(Con2, query);

		if (rs != null && rs.next()) {
			System.out.println("rs is not empty!");			
			try {
		    		String subRule = rs.getString("SUBRULECONFIG").toString();
		    		for(String element :subRule.substring(1, subRule.length()-1).split(",")){
		    			String [] keyValuePair=element.split(":");
		    			db_res.put(keyValuePair[0].trim().substring(1, keyValuePair[0].length()-1), keyValuePair[1].trim().substring(1, keyValuePair[1].length()-1));
		    		}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return db_res;
	}
	public static ArrayList<GenericEvent> DBRS_ArraylistMultipleRows(Connection Con2, String query) throws SQLException {

		//GenericEvent db_res = null;
		ResultSet rs = DBConnection.execStatement(Con2, query);
		ArrayList<GenericEvent> db_res = new ArrayList<>();

		if (rs != null) {

			try {
				while (rs.next()) {
					// System.out.println(rs.getString(1));
					db_res.add(new GenericEvent(rs));
					// System.out.println(rs.getString(1));

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		} else {

			System.out.println("RS is null!");
		}


		return db_res;
	}

	public static String DBRS_ArraylistSingleRow(Connection Con2, String query) throws SQLException {

		GenericEvent db_res = null;
		ResultSet rs = DBConnection.execStatement(Con2, query);
		String Res_Str = null;

		if (rs != null && rs.next()) {
			System.out.println("rs is not empty!");

			Res_Str = rs.getString(1);
			System.out.println("Result is " + Res_Str);

		}
		return Res_Str;
	}
}
