package com.Profile.supportLibraries;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.json.*;

public class GetJwtTokenUser {

	public static void main(String[] args) throws InterruptedException {
		
		//String JwtToken = GetJwtToken.getAuthJwtToken("a48286399_indv", "Pru12345", "INDV");
		//String JwtToken = PruISLogin("a48286399_indv", "Pru12345", "INDV");
       // System.out.println(JwtToken);
	/*	// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "Z:\\QA Share\\Javalibs\\Selenium\\geckodriver-v0.19.1\\geckodriver.exe");
		System.setProperty("webdriver.firefox.bin","C:\\Users\\X214090\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\X214090\\Desktop\\Javalibs\\Selenium\\Browser Drivers\\chromedriver.exe");
		WebDriver driver = new FirefoxDriver();
		//WebDriver driver = new ChromeDriver();
		driver.get("https://ssologin-qa.prudential.com/app/ssologin/AuthLogin.fcc");

		driver.findElement(By.xpath("//input[contains(@name,'USER')]")).sendKeys("tsqa68@pru.com");
		driver.findElement(By.xpath("//input[contains(@name,'PASSWORD')]")).sendKeys("password1");
		driver.findElement(By.xpath("//input[contains(@name,'BUIDTYPE')]")).sendKeys("INDV");
		driver.findElement(By.xpath("//form/table/tbody/tr[5]/td/input[contains(@value,'Login')]")).click();
		//Thread.sleep(10000);
		driver.get("https://api-dev.prudential.com/.signjwt");

		//Thread.sleep(10000);
		String responsenew = driver.findElement(By.xpath("/html//body")).getText();
		//String responsenew=driver.getPageSource();
		//Object parsedResponse = new JsonSlurper().parseText(responsenew);
		//String responsenew = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]")).getText();
		JSONObject obj = new JSONObject(responsenew);
		String jwtToken = obj.getString("jwt");
		System.out.println( "out put is " + jwtToken);

		//Object parsedResponse = new JsonSlurper().parseText(responsenew);
		//System.out.println( "APEX Response: $parsedResponse");
		//def jwtToken = parsedResponse.jwt;
		System.out.println( "JWT Token: $jwtToken");
		driver.quit() ;

		*/
	}
	
	

}
